import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import crypto from 'crypto';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

const orderNumberValidation = [
  param('orderNumber').isString().trim().isLength({ min: 1 }),
];

// Public: track order by order number (no auth required)
router.get('/track/:orderNumber', orderNumberValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }
    const db = getDb();
    const order = db.prepare(
      `SELECT o.*, u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email, u.phone as customer_phone
       FROM orders o
       JOIN users u ON o.user_id = u.id
       WHERE o.order_number = ?`
    ).get(req.params.orderNumber);
    if (!order) throw new AppError('Order not found', 404);
    const statusHistory = db.prepare(
      'SELECT status, note, created_at FROM order_status_history WHERE order_id = (SELECT id FROM orders WHERE order_number = ?) ORDER BY created_at ASC'
    ).all(req.params.orderNumber);
    const items = db.prepare(
      `SELECT oi.*, (SELECT url FROM product_images WHERE product_id = oi.product_id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM order_items oi WHERE oi.order_id = ?`
    ).all(order.id);
    let courier = null;
    if (order.courier_id) {
      courier = db.prepare('SELECT name, slug FROM couriers WHERE id = ?').get(order.courier_id);
    }
    const trackingUrl = order.tracking_number && courier ? `https://${courier.slug}.com/tracking/${order.tracking_number}` : null;
    let shippingAddress = null;
    try { shippingAddress = JSON.parse(order.shipping_address); } catch (e) { shippingAddress = order.shipping_address; }
    res.json({
      success: true,
      data: {
        order: {
          order_number: order.order_number,
          status: order.status,
          created_at: order.created_at,
          updated_at: order.updated_at,
          shipped_at: order.shipped_at,
          delivered_at: order.delivered_at,
          subtotal: order.subtotal,
          discount: order.discount,
          shipping_cost: order.shipping_cost,
          total: order.total,
          payment_method: order.payment_method,
          payment_status: order.payment_status,
          customer_name: order.customer_name,
          customer_phone: order.customer_phone,
          courier: courier ? { name: courier.name, slug: courier.slug } : null,
          tracking_number: order.tracking_number,
          tracking_url: trackingUrl,
          consignment_id: order.consignment_id,
          shipping_address: shippingAddress,
          notes: order.notes,
          status_history: statusHistory,
          items,
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.use(authenticate);

const createOrderValidation = [
  body('address_id').optional().isInt({ min: 1 }).toInt(),
  body('shipping_address').optional().isObject(),
  body('shipping_address.name').optional().isString().trim(),
  body('shipping_address.phone').optional().isString().trim(),
  body('shipping_address.address').optional().isString().trim(),
  body('shipping_address.city').optional().isString().trim(),
  body('shipping_address.division').optional().isString().trim(),
  body('shipping_address.postal_code').optional().isString().trim(),
  body('payment_method').isIn(['cod', 'bkash', 'nagad', 'card', 'wallet', 'sslcommerz', 'rocket']).withMessage('Invalid payment method'),
  body('notes').optional().isString().trim().isLength({ max: 500 }),
];

const idValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid order ID'),
];

const cancelValidation = [
  param('id').isInt({ min: 1 }).toInt(),
  body('reason').optional().isString().trim().isLength({ max: 500 }),
];

const returnValidation = [
  param('id').isInt({ min: 1 }).toInt(),
  body('reason').isString().trim().isLength({ min: 5, max: 500 }).withMessage('Reason is required (5-500 chars)'),
  body('items').isArray({ min: 1 }).withMessage('At least one item is required'),
  body('items.*.order_item_id').isInt({ min: 1 }).toInt(),
  body('items.*.quantity').isInt({ min: 1 }).toInt(),
];

router.post('/', createOrderValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const { address_id, shipping_address, payment_method, notes } = req.body;

    const cart = db.prepare('SELECT id, coupon_code, coupon_discount FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    const cartItems = db.prepare(
      `SELECT ci.*, p.name as product_name, p.stock_quantity, p.is_active as product_active,
              pv.stock_quantity as variant_stock
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       LEFT JOIN product_variants pv ON ci.variant_id = pv.id
       WHERE ci.cart_id = ? AND p.is_active = 1`
    ).all(cart.id);

    if (cartItems.length === 0) {
      throw new AppError('Cart is empty', 400);
    }

    for (const item of cartItems) {
      const availableStock = item.variant_id ? item.variant_stock : item.stock_quantity;
      if (availableStock < item.quantity) {
        throw new AppError(`Insufficient stock for ${item.product_name}`, 400);
      }
    }

    let address;
    let addressId = address_id;

    if (address_id) {
      address = db.prepare('SELECT * FROM user_addresses WHERE id = ? AND user_id = ?').get(address_id, userId);
      if (!address) {
        throw new AppError('Address not found', 404);
      }
    } else if (shipping_address && shipping_address.name && shipping_address.phone && shipping_address.address && shipping_address.city) {
      const sa = shipping_address;
      const result = db.prepare(
        `INSERT INTO user_addresses (user_id, label, full_name, phone, division, district, upazila, address_line1, postal_code, is_default, created_at, updated_at)
         VALUES (?, 'shipping', ?, ?, ?, ?, ?, ?, ?, 0, datetime('now'), datetime('now'))`
      ).run(userId, sa.name, sa.phone, sa.division || 'Dhaka', sa.city, '', sa.address, sa.postal_code || '');
      addressId = result.lastInsertRowid;
      address = db.prepare('SELECT * FROM user_addresses WHERE id = ?').get(addressId);
    } else {
      throw new AppError('Either address_id or shipping_address (name, phone, address, city) is required', 400);
    }

    let subtotal = 0;
    cartItems.forEach(item => { subtotal += item.total_price; });

    const couponDiscount = cart.coupon_discount || 0;

    // Calculate delivery charge based on district
    const district = (sa.city || sa.district || 'Dhaka').toLowerCase();
    const insideDhaka = district === 'dhaka';
    let shippingCost;
    if (insideDhaka) {
      if (subtotal <= 3000) shippingCost = 100;
      else if (subtotal <= 6000) shippingCost = 120;
      else shippingCost = 120 + Math.ceil((subtotal - 6000) / 3000) * 20;
    } else {
      if (subtotal <= 3000) shippingCost = 150;
      else if (subtotal <= 7000) shippingCost = 170;
      else if (subtotal <= 12000) shippingCost = 250;
      else shippingCost = 250 + Math.ceil((subtotal - 12000) / 5000) * 100;
    }

    const serviceCharge = 5;
    const total = subtotal - couponDiscount + shippingCost + serviceCharge;

    const orderNumber = `ORD-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const orderUuid = crypto.randomUUID();

    const insertOrder = db.prepare(
      `INSERT INTO orders (uuid, user_id, order_number, status, subtotal, discount, shipping_cost, total,
                          payment_method, payment_status, shipping_address, notes, created_at, updated_at)
       VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, ?, 'pending', ?, ?, datetime('now'), datetime('now'))`
    );

    const shippingAddress = JSON.stringify({
      name: address.full_name, phone: address.phone,
      line1: address.address_line1, line2: address.address_line2 || null,
      city: address.district, division: address.division,
      district: address.district, postal_code: address.postal_code || null,
    });

    const orderResult = insertOrder.run(
      orderUuid, userId, orderNumber, subtotal, couponDiscount, shippingCost, total,
      payment_method, shippingAddress, notes || null
    );

    const orderId = orderResult.lastInsertRowid;

    const insertItem = db.prepare(
      `INSERT INTO order_items (order_id, product_id, variant_id, product_name, product_sku, quantity, price, total, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`
    );

    const updateStock = db.prepare(
      `UPDATE products SET stock_quantity = stock_quantity - ?, total_sold = total_sold + ?, updated_at = datetime('now') WHERE id = ?`
    );

    const updateVariantStock = db.prepare(
      `UPDATE product_variants SET stock_quantity = stock_quantity - ?, updated_at = datetime('now') WHERE id = ?`
    );

    const transaction = db.transaction(() => {
      for (const item of cartItems) {
        insertItem.run(
          orderId, item.product_id, item.variant_id || null,
          item.product_name, item.product_sku || `SKU-${item.product_id}`,
          item.quantity, item.price, item.total_price
        );

        updateStock.run(item.quantity, item.quantity, item.product_id);

        if (item.variant_id) {
          updateVariantStock.run(item.quantity, item.variant_id);
        }
      }

      db.prepare(
        `INSERT INTO order_status_history (order_id, status, created_at) VALUES (?, 'pending', datetime('now'))`
      ).run(orderId);
    });

    transaction();

    db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(cart.id);
    db.prepare(
      `UPDATE carts SET coupon_code = NULL, coupon_discount = 0, updated_at = datetime('now') WHERE id = ?`
    ).run(cart.id);

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);

    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      data: {
        order: { ...order, items },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 10, 50);
    const offset = (page - 1) * limit;
    const status = req.query.status;

    let where = 'WHERE o.user_id = ?';
    let params = [userId];

    if (status) {
      where += ' AND o.status = ?';
      params.push(status);
    }

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM orders o ${where}`
    ).get(...params);

    const orders = db.prepare(
      `SELECT o.id, o.order_number, o.status, o.subtotal, o.discount, o.shipping_cost, o.total,
              o.payment_method, o.payment_status, o.created_at,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
       FROM orders o
       ${where}
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        orders,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const order = db.prepare(
      'SELECT * FROM orders WHERE id = ? AND user_id = ?'
    ).get(req.params.id, userId);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    const items = db.prepare(
      `SELECT oi.*,
              (SELECT url FROM product_images WHERE product_id = oi.product_id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM order_items oi
       WHERE oi.order_id = ?`
    ).all(order.id);

    const statusHistory = db.prepare(
      'SELECT * FROM order_status_history WHERE order_id = ? ORDER BY created_at DESC'
    ).all(order.id);

    res.json({
      success: true,
      data: {
        order: { ...order, items, status_history: statusHistory },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/cancel', cancelValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const order = db.prepare(
      'SELECT * FROM orders WHERE id = ? AND user_id = ?'
    ).get(req.params.id, userId);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    if (!['pending', 'confirmed'].includes(order.status)) {
      throw new AppError('Order cannot be cancelled in current status', 400);
    }

    const { reason } = req.body;

    const transaction = db.transaction(() => {
      db.prepare(
        `UPDATE orders SET status = 'cancelled', cancel_reason = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(reason || 'Cancelled by customer', order.id);

      db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, created_by, created_at)
         VALUES (?, 'cancelled', ?, ?, datetime('now'))`
      ).run(order.id, reason || 'Cancelled by customer', userId);

      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      for (const item of items) {
        db.prepare(
          `UPDATE products SET stock_quantity = stock_quantity + ?, total_sold = total_sold - ?, updated_at = datetime('now') WHERE id = ?`
        ).run(item.quantity, item.quantity, item.product_id);

        if (item.variant_id) {
          db.prepare(
            `UPDATE product_variants SET stock_quantity = stock_quantity + ?, updated_at = datetime('now') WHERE id = ?`
          ).run(item.quantity, item.variant_id);
        }
      }
    });

    transaction();

    res.json({ success: true, message: 'Order cancelled successfully' });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/return', returnValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const order = db.prepare(
      'SELECT * FROM orders WHERE id = ? AND user_id = ?'
    ).get(req.params.id, userId);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    if (!['delivered'].includes(order.status)) {
      throw new AppError('Return can only be requested for delivered orders', 400);
    }

    const deliveredAt = db.prepare(
      `SELECT created_at FROM order_status_history WHERE order_id = ? AND status = 'delivered' ORDER BY created_at DESC LIMIT 1`
    ).get(order.id);

    if (deliveredAt) {
      const daysSinceDelivery = (Date.now() - new Date(deliveredAt.created_at).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSinceDelivery > 7) {
        throw new AppError('Return window has expired (7 days from delivery)', 400);
      }
    }

    const { reason, items } = req.body;

    const insertReturn = db.prepare(
      `INSERT INTO returns (order_id, user_id, reason, status, created_at, updated_at)
       VALUES (?, ?, ?, 'pending', datetime('now'), datetime('now'))`
    );

    const insertReturnItem = db.prepare(
      `INSERT INTO return_items (return_id, order_item_id, quantity, reason, created_at)
       VALUES (?, ?, ?, ?, datetime('now'))`
    );

    const transaction = db.transaction(() => {
      const returnResult = insertReturn.run(order.id, userId, reason);
      const returnId = returnResult.lastInsertRowid;

      for (const item of items) {
        insertReturnItem.run(returnId, item.order_item_id, item.quantity, reason);
      }

      db.prepare(
        `UPDATE orders SET status = 'return_requested', updated_at = datetime('now') WHERE id = ?`
      ).run(order.id);

      db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, created_by, created_at)
         VALUES (?, 'return_requested', ?, ?, datetime('now'))`
      ).run(order.id, `Return requested: ${reason}`, userId);
    });

    transaction();

    res.status(201).json({
      success: true,
      message: 'Return request submitted',
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id/invoice', idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const order = db.prepare(
      'SELECT * FROM orders WHERE id = ? AND user_id = ?'
    ).get(req.params.id, userId);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    const items = db.prepare(
      'SELECT * FROM order_items WHERE order_id = ?'
    ).all(order.id);

    const company = db.prepare(
      "SELECT * FROM settings WHERE key = 'company_info'"
    ).get();

    const companyInfo = company ? JSON.parse(company.value) : {};

    const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};

    res.json({
      success: true,
      data: {
        invoice: {
          order_number: order.order_number,
          date: order.created_at,
          status: order.status,
          payment_method: order.payment_method,
          payment_status: order.payment_status,
          shipping_address: shippingAddr,
          items: items.map(item => ({
            name: item.product_name,
            quantity: item.quantity,
            price: item.price,
            total: item.total,
          })),
          subtotal: order.subtotal,
          discount: order.discount,
          shipping_cost: order.shipping_cost,
          total: order.total,
          company: companyInfo,
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
