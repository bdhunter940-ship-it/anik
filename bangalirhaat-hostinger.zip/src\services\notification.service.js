import { getDb } from '../database/db.js';

const NOTIFICATION_TYPES = {
  ORDER_UPDATE: 'order_update',
  PROMOTION: 'promotion',
  SYSTEM: 'system',
  STOCK_ALERT: 'stock_alert',
  SECURITY: 'security',
  LOYALTY: 'loyalty',
  DELIVERY: 'delivery',
  REFUND: 'refund',
};

const ORDER_STATUS_MESSAGES = {
  confirmed: {
    title: 'Order Confirmed',
    message: 'Your order {orderNumber} has been confirmed and is being processed.',
  },
  packaging: {
    title: 'Order Being Packaged',
    message: 'Great news! Your order {orderNumber} is being carefully packaged for shipment.',
  },
  ready_to_ship: {
    title: 'Ready to Ship',
    message: 'Your order {orderNumber} is ready and will be dispatched shortly.',
  },
  courier_sent: {
    title: 'Order Dispatched',
    message: 'Your order {orderNumber} has been dispatched and is on its way to you!',
  },
  in_transit: {
    title: 'Order In Transit',
    message: 'Your order {orderNumber} is currently in transit. Hang tight!',
  },
  delivered: {
    title: 'Order Delivered',
    message: 'Your order {orderNumber} has been delivered successfully. We hope you love your purchase!',
  },
  cancelled: {
    title: 'Order Cancelled',
    message: 'Your order {orderNumber} has been cancelled. If you have questions, contact support.',
  },
  returned: {
    title: 'Order Returned',
    message: 'Your return for order {orderNumber} has been processed.',
  },
};

class NotificationService {
  constructor() {
    this._wsClients = new Map();
  }

  registerWebSocketClient(userId, ws) {
    if (!this._wsClients.has(userId)) {
      this._wsClients.set(userId, new Set());
    }
    this._wsClients.get(userId).add(ws);
    console.log(`[NotificationService] WebSocket client registered for user ${userId}. Total: ${this._wsClients.get(userId).size}`);
  }

  removeWebSocketClient(userId, ws) {
    const clients = this._wsClients.get(userId);
    if (clients) {
      clients.delete(ws);
      if (clients.size === 0) {
        this._wsClients.delete(userId);
      }
    }
  }

  _broadcastToUser(userId, data) {
    const clients = this._wsClients.get(userId);
    if (!clients || clients.size === 0) return;

    const payload = JSON.stringify(data);
    for (const ws of clients) {
      try {
        if (ws.readyState === 1) {
          ws.send(payload);
        } else {
          clients.delete(ws);
        }
      } catch (error) {
        console.error(`[NotificationService] WebSocket send error for user ${userId}:`, error.message);
        clients.delete(ws);
      }
    }
  }

  async create(userId, title, message, type = 'info', data = null) {
    const db = getDb();

    const stmt = db.prepare(
      `INSERT INTO notifications (user_id, title, message, type, is_read, data, created_at)
       VALUES (?, ?, ?, ?, 0, ?, datetime('now'))`
    );

    const result = stmt.run(userId, title, message, type, data ? JSON.stringify(data) : null);

    const notification = {
      id: result.lastInsertRowid,
      user_id: userId,
      title,
      message,
      type,
      is_read: 0,
      data,
      created_at: new Date().toISOString(),
    };

    this._broadcastToUser(userId, {
      type: 'notification',
      action: 'new',
      notification,
    });

    return notification;
  }

  async createBulk(userIds, title, message, type = 'info', data = null) {
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return { success: false, reason: 'No users provided' };
    }

    const db = getDb();
    const stmt = db.prepare(
      `INSERT INTO notifications (user_id, title, message, type, is_read, data, created_at)
       VALUES (?, ?, ?, ?, 0, ?, datetime('now'))`
    );

    const insertMany = db.transaction((ids) => {
      const results = [];
      for (const userId of ids) {
        const result = stmt.run(userId, title, message, type, data ? JSON.stringify(data) : null);
        results.push({ userId, notificationId: result.lastInsertRowid });
      }
      return results;
    });

    const results = insertMany(userIds);

    for (const { userId, notificationId } of results) {
      this._broadcastToUser(userId, {
        type: 'notification',
        action: 'new',
        notification: {
          id: notificationId,
          user_id: userId,
          title,
          message,
          type,
          data,
          created_at: new Date().toISOString(),
        },
      });
    }

    return { success: true, count: results.length, notificationIds: results.map(r => r.notificationId) };
  }

  async markAsRead(notificationId, userId = null) {
    const db = getDb();

    let query = 'UPDATE notifications SET is_read = 1 WHERE id = ?';
    const params = [notificationId];

    if (userId) {
      query += ' AND user_id = ?';
      params.push(userId);
    }

    const result = db.prepare(query).run(...params);

    if (result.changes === 0) {
      return { success: false, reason: 'Notification not found or already read' };
    }

    const notification = db.prepare('SELECT * FROM notifications WHERE id = ?').get(notificationId);
    if (notification) {
      this._broadcastToUser(notification.user_id, {
        type: 'notification',
        action: 'read',
        notificationId,
      });
    }

    return { success: true, notificationId };
  }

  async markAllAsRead(userId) {
    const db = getDb();
    const result = db.prepare(
      'UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0'
    ).run(userId);

    this._broadcastToUser(userId, {
      type: 'notification',
      action: 'all_read',
    });

    return { success: true, count: result.changes };
  }

  async getUnreadCount(userId) {
    const db = getDb();
    const result = db.prepare(
      'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0'
    ).get(userId);

    return { count: result.count };
  }

  async getAll(userId, { page = 1, limit = 20, type = null, unreadOnly = false } = {}) {
    const db = getDb();
    const offset = (page - 1) * limit;
    const conditions = ['user_id = ?'];
    const params = [userId];

    if (type) {
      conditions.push('type = ?');
      params.push(type);
    }

    if (unreadOnly) {
      conditions.push('is_read = 0');
    }

    const whereClause = conditions.join(' AND ');

    const countResult = db.prepare(
      `SELECT COUNT(*) as total FROM notifications WHERE ${whereClause}`
    ).get(...params);

    const notifications = db.prepare(
      `SELECT id, user_id, title, message, type, is_read, data, created_at
       FROM notifications
       WHERE ${whereClause}
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    const parsed = notifications.map(n => ({
      ...n,
      data: n.data ? JSON.parse(n.data) : null,
    }));

    return {
      notifications: parsed,
      pagination: {
        total: countResult.total,
        page,
        limit,
        totalPages: Math.ceil(countResult.total / limit),
      },
    };
  }

  async delete(notificationId, userId) {
    const db = getDb();
    const result = db.prepare(
      'DELETE FROM notifications WHERE id = ? AND user_id = ?'
    ).run(notificationId, userId);

    return { success: result.changes > 0, deleted: result.changes > 0 };
  }

  async deleteAll(userId) {
    const db = getDb();
    const result = db.prepare('DELETE FROM notifications WHERE user_id = ?').run(userId);
    return { success: true, deleted: result.changes };
  }

  async sendOrderUpdate(order, status) {
    const template = ORDER_STATUS_MESSAGES[status];
    if (!template) {
      console.warn(`[NotificationService] No notification template for status: ${status}`);
      return null;
    }

    const title = template.title;
    const message = template.message.replace('{orderNumber}', order.order_number);

    const notificationData = {
      order_id: order.id,
      order_number: order.order_number,
      status,
      type: 'order_update',
    };

    return this.create(order.user_id, title, message, 'order_update', notificationData);
  }

  async sendStockAlert(productId, productName, currentStock, threshold) {
    const db = getDb();
    const admins = db.prepare(
      `SELECT id FROM users WHERE role IN ('admin', 'staff') AND is_active = 1`
    ).all();

    if (admins.length === 0) return null;

    const title = 'Low Stock Alert';
    const message = `"${productName}" has only ${currentStock} units remaining (threshold: ${threshold}).`;
    const userIds = admins.map(a => a.id);

    return this.createBulk(userIds, title, message, 'stock_alert', {
      product_id: productId,
      product_name: productName,
      current_stock: currentStock,
      threshold,
    });
  }

  async sendPromotionalToAll(title, message, targetRole = 'customer') {
    const db = getDb();
    const users = db.prepare(
      `SELECT id FROM users WHERE role = ? AND is_active = 1 AND deleted_at IS NULL`
    ).all(targetRole);

    if (users.length === 0) return { count: 0 };

    const userIds = users.map(u => u.id);
    return this.createBulk(userIds, title, message, 'promotion');
  }

  async cleanupOldNotifications(daysOld = 90) {
    const db = getDb();
    const result = db.prepare(
      `DELETE FROM notifications WHERE created_at < datetime('now', '-' || ? || ' days') AND is_read = 1`
    ).run(daysOld);

    console.log(`[NotificationService] Cleaned up ${result.changes} old notifications (>${daysOld} days, read)`);
    return { deleted: result.changes };
  }
}

export default new NotificationService();
