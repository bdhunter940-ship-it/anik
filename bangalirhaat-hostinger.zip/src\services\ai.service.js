import crypto from 'crypto';
import { getDb } from '../database/db.js';

const POSITIVE_WORDS = [
  'excellent', 'great', 'amazing', 'love', 'perfect', 'best', 'fantastic', 'wonderful',
  'beautiful', 'quality', 'fast', 'recommended', 'satisfied', 'happy', 'good', 'nice',
  'comfortable', 'durable', 'premium', 'elegant', 'worth', 'value', 'superb', 'outstanding',
];

const NEGATIVE_WORDS = [
  'bad', 'poor', 'terrible', 'worst', 'slow', 'broken', 'cheap', 'defective',
  'disappointed', 'waste', 'damaged', 'fake', 'small', 'late', 'refund', 'return',
  'complaint', 'issue', 'problem', 'ugly', 'rough', 'thin', 'faded', 'torn',
];

const BANGLA_DESCRIPTORS = {
  'saree': ['handloom', 'cotton', 'silk', 'jamdani', 'naksi', 'traditional', 'authentic'],
  'dress': ['elegant', 'comfortable', 'stylish', 'trendy', 'premium'],
  'home': ['artisan', 'handcrafted', 'traditional', 'authentic', 'eco-friendly'],
  'food': ['organic', 'natural', 'fresh', 'traditional', 'authentic'],
  'jewelry': ['handcrafted', 'traditional', 'gold-plated', 'premium', 'elegant'],
};

class AIService {
  generateProductDescription(product) {
    const { name, category, features = [], price } = product;
    const categoryName = (product.category_name || category || '').toLowerCase();

    const descriptors = [];
    for (const [key, values] of Object.entries(BANGLA_DESCRIPTORS)) {
      if (categoryName.includes(key) || name.toLowerCase().includes(key)) {
        descriptors.push(...values.slice(0, 3));
        break;
      }
    }
    if (descriptors.length === 0) {
      descriptors.push('premium', 'authentic', 'quality');
    }

    const lines = [];
    lines.push(`Discover the beauty of ${name}, a ${descriptors.join(', ')} product from Bangalirhaat.`);

    if (features.length > 0) {
      lines.push(`Features: ${features.join(', ')}.`);
    }

    if (price) {
      if (price < 500) {
        lines.push('An affordable choice without compromising on quality.');
      } else if (price < 2000) {
        lines.push('Premium quality at a great value.');
      } else {
        lines.push('A luxurious addition to your collection.');
      }
    }

    lines.push('Order now from Bangalirhaat for fast delivery across Bangladesh.');

    return lines.join(' ');
  }

  generateSEO(product) {
    const { name, category_name, price, tags } = product;
    const category = category_name || 'Products';
    const keywords = [
      name, category, 'Bangalirhaat', 'Bangladesh', 'online shopping',
      `buy ${name}`, `${name} price`, `best ${category}`,
    ];

    if (tags) {
      try {
        const parsed = typeof tags === 'string' ? JSON.parse(tags) : tags;
        if (Array.isArray(parsed)) keywords.push(...parsed.slice(0, 5));
      } catch {}
    }

    const metaTitle = `${name} - Buy Online | Bangalirhaat`;
    const metaDescription = `Buy ${name} from Bangalirhaat. ${category} collection${price ? ` starting from ৳${price}` : ''}. Fast delivery across Bangladesh. Shop now!`;

    return {
      metaTitle,
      metaDescription,
      keywords: [...new Set(keywords)].slice(0, 15),
    };
  }

  generateReviewSummary(reviews) {
    if (!reviews || reviews.length === 0) {
      return { totalReviews: 0, averageRating: 0, positive: 0, negative: 0, neutral: 0, themes: [] };
    }

    const totalReviews = reviews.length;
    const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews;

    let positive = 0, negative = 0, neutral = 0;
    const wordCounts = {};

    for (const review of reviews) {
      const text = `${review.title || ''} ${review.comment || ''}`.toLowerCase();
      const words = text.split(/\s+/);

      let sentiment = 0;
      for (const word of words) {
        const clean = word.replace(/[^a-z]/g, '');
        if (POSITIVE_WORDS.includes(clean)) sentiment++;
        if (NEGATIVE_WORDS.includes(clean)) sentiment--;

        if (clean.length > 3) {
          wordCounts[clean] = (wordCounts[clean] || 0) + 1;
        }
      }

      if (sentiment > 0 || review.rating >= 4) positive++;
      else if (sentiment < 0 || review.rating <= 2) negative++;
      else neutral++;
    }

    const themes = Object.entries(wordCounts)
      .filter(([, count]) => count >= 2)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([word, count]) => ({ word, count }));

    return {
      totalReviews,
      averageRating: parseFloat(avgRating.toFixed(2)),
      positive,
      negative,
      neutral,
      themes,
    };
  }

  predictSales(productId, days = 30) {
    const db = getDb();
    const product = db.prepare('SELECT id, name, stock_quantity FROM products WHERE id = ?').get(productId);
    if (!product) throw new Error('Product not found');

    const dailySales = db.prepare(`
      SELECT DATE(o.created_at) as date, SUM(oi.quantity) as quantity
      FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      WHERE oi.product_id = ? AND o.payment_status = 'paid' AND o.deleted_at IS NULL
        AND o.created_at >= datetime('now', '-60 days')
      GROUP BY DATE(o.created_at)
      ORDER BY date DESC
    `).all(productId);

    if (dailySales.length === 0) {
      return {
        productId, productName: product.name,
        avgDailySales: 0, predictedUnits: 0,
        confidence: 0, period: `${days} days`,
      };
    }

    const recent7 = dailySales.slice(0, 7);
    const recent30 = dailySales.slice(0, 30);

    const avgRecent7 = recent7.reduce((s, r) => s + r.quantity, 0) / Math.max(recent7.length, 1);
    const avgRecent30 = recent30.reduce((s, r) => s + r.quantity, 0) / Math.max(recent30.length, 1);

    const avgDaily = avgRecent7 * 0.6 + avgRecent30 * 0.4;

    const variance = recent30.reduce((s, r) => s + Math.pow(r.quantity - avgDaily, 2), 0) / Math.max(recent30.length, 1);
    const confidence = Math.max(0, Math.min(100, Math.round(100 - variance * 5)));

    return {
      productId,
      productName: product.name,
      avgDailySales: parseFloat(avgDaily.toFixed(2)),
      predictedUnits: Math.round(avgDaily * days),
      confidence,
      period: `${days} days`,
      basedOnDays: dailySales.length,
    };
  }

  predictStock(productId) {
    const db = getDb();
    const product = db.prepare(
      'SELECT id, name, stock_quantity, low_stock_threshold FROM products WHERE id = ?'
    ).get(productId);
    if (!product) throw new Error('Product not found');

    const prediction = this.predictSales(productId, 30);
    const avgDaily = prediction.avgDailySales;

    if (avgDaily === 0) {
      return {
        productId, productName: product.name,
        currentStock: product.stock_quantity,
        daysUntilStockout: null,
        avgDailySales: 0,
        recommendation: 'No recent sales. Consider promoting this product.',
      };
    }

    const daysUntilStockout = Math.floor(product.stock_quantity / avgDaily);
    let recommendation;
    if (daysUntilStockout <= 3) {
      recommendation = 'URGENT: Restock immediately. Stock will run out within 3 days.';
    } else if (daysUntilStockout <= 7) {
      recommendation = 'Restock soon. Less than a week of stock remaining.';
    } else if (daysUntilStockout <= 14) {
      recommendation = 'Plan restocking within the next two weeks.';
    } else {
      recommendation = 'Stock levels are healthy for the near term.';
    }

    return {
      productId,
      productName: product.name,
      currentStock: product.stock_quantity,
      lowStockThreshold: product.low_stock_threshold,
      avgDailySales: avgDaily,
      daysUntilStockout,
      reorderSuggested: daysUntilStockout <= 7,
      recommendation,
    };
  }

  optimizeSearch(query, products) {
    if (!query || !products || products.length === 0) return [];

    const queryLower = query.toLowerCase().trim();
    const queryWords = queryLower.split(/\s+/).filter(w => w.length > 1);

    const scored = products.map(product => {
      const name = (product.name || '').toLowerCase();
      const description = (product.description || '').toLowerCase();
      const tags = (product.tags || '').toLowerCase();
      const category = (product.category_name || '').toLowerCase();

      let score = 0;

      if (name === queryLower) score += 100;
      else if (name.startsWith(queryLower)) score += 80;
      else if (name.includes(queryLower)) score += 60;

      for (const word of queryWords) {
        if (name.includes(word)) score += 20;
        if (category.includes(word)) score += 15;
        if (tags.includes(word)) score += 10;
        if (description.includes(word)) score += 5;
      }

      if (product.is_featured) score += 5;
      if (product.average_rating >= 4) score += 5;
      if (product.stock_quantity > 0) score += 3;

      return { ...product, searchScore: score };
    });

    return scored
      .filter(p => p.searchScore > 0)
      .sort((a, b) => b.searchScore - a.searchScore);
  }

  async smartRecommend(userId, productId) {
    const db = getDb();

    const product = db.prepare(
      'SELECT id, category_id, price, brand_id FROM products WHERE id = ? AND is_active = 1'
    ).get(productId);
    if (!product) throw new Error('Product not found');

    const priceMin = product.price * 0.5;
    const priceMax = product.price * 2;

    let candidates = db.prepare(`
      SELECT p.id, p.name, p.slug, p.price, p.average_rating, p.review_count,
             c.name as category_name,
             (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail,
             0 as score
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.is_active = 1 AND p.id != ? AND p.deleted_at IS NULL
        AND p.stock_quantity > 0
      ORDER BY p.review_count DESC, p.average_rating DESC
      LIMIT 100
    `).all(productId);

    candidates = candidates.map(c => {
      let score = 0;

      if (c.category_name === product.category_name) score += 30;
      if (c.brand_id === product.brand_id) score += 20;

      const priceDiff = Math.abs(c.price - product.price) / product.price;
      if (priceDiff < 0.3) score += 25;
      else if (priceDiff < 0.6) score += 15;
      else if (priceDiff < 1.0) score += 5;

      score += (c.average_rating || 0) * 3;
      score += Math.min((c.review_count || 0) * 0.5, 10);

      return { ...c, score: parseFloat(score.toFixed(2)) };
    });

    candidates.sort((a, b) => b.score - a.score);
    const recommendations = candidates.slice(0, 8);

    if (userId) {
      const insert = db.prepare(`
        INSERT INTO smart_recommendations (id, user_id, product_id, score, algorithm, created_at)
        VALUES (?, ?, ?, ?, 'content_based', datetime('now'))
      `);
      for (const rec of recommendations) {
        try {
          insert.run(crypto.randomUUID(), String(userId), String(rec.id), rec.score);
        } catch {}
      }
    }

    return recommendations;
  }

  async getAISalesPredictions({ startDate, endDate } = {}) {
    const db = getDb();
    let where = ["prediction_type = 'sales'"];
    let params = [];

    if (startDate) { where.push('created_at >= ?'); params.push(startDate); }
    if (endDate) { where.push('created_at <= ?'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const cached = db.prepare(`
      SELECT * FROM ai_predictions WHERE ${whereClause} ORDER BY created_at DESC LIMIT 50
    `).all(...params);

    if (cached.length > 0) {
      return {
        source: 'cache',
        predictions: cached.map(c => ({
          ...c,
          prediction_data: (() => { try { return JSON.parse(c.prediction_data); } catch { return c.prediction_data; } })(),
        })),
      };
    }

    const products = db.prepare(
      'SELECT id, name FROM products WHERE is_active = 1 AND deleted_at IS NULL ORDER BY total_sold DESC LIMIT 20'
    ).all();

    const predictions = [];
    const insert = db.prepare(`
      INSERT INTO ai_predictions (id, prediction_type, entity_type, entity_id, prediction_data, confidence, period, created_at, expires_at)
      VALUES (?, 'sales', 'product', ?, ?, ?, '30d', datetime('now'), datetime('now', '+1 day'))
    `);

    const generateAll = db.transaction(() => {
      for (const product of products) {
        const prediction = this.predictSales(product.id, 30);
        const data = JSON.stringify(prediction);
        insert.run(crypto.randomUUID(), String(product.id), data, prediction.confidence / 100);
        predictions.push(prediction);
      }
    });

    generateAll();

    return { source: 'generated', predictions };
  }

  async getAIStockPredictions() {
    const db = getDb();

    const cached = db.prepare(
      "SELECT * FROM ai_predictions WHERE prediction_type = 'stock' ORDER BY created_at DESC LIMIT 50"
    ).all();

    if (cached.length > 0) {
      return {
        source: 'cache',
        predictions: cached.map(c => ({
          ...c,
          prediction_data: (() => { try { return JSON.parse(c.prediction_data); } catch { return c.prediction_data; } })(),
        })),
      };
    }

    const products = db.prepare(
      'SELECT id, name FROM products WHERE is_active = 1 AND deleted_at IS NULL AND track_stock = 1 ORDER BY stock_quantity ASC LIMIT 20'
    ).all();

    const predictions = [];
    const insert = db.prepare(`
      INSERT INTO ai_predictions (id, prediction_type, entity_type, entity_id, prediction_data, confidence, created_at, expires_at)
      VALUES (?, 'stock', 'product', ?, ?, 1, datetime('now'), datetime('now', '+1 day'))
    `);

    const generateAll = db.transaction(() => {
      for (const product of products) {
        try {
          const prediction = this.predictStock(product.id);
          const data = JSON.stringify(prediction);
          insert.run(crypto.randomUUID(), String(product.id), data);
          predictions.push(prediction);
        } catch {}
      }
    });

    generateAll();

    return { source: 'generated', predictions };
  }
}

export default new AIService();
