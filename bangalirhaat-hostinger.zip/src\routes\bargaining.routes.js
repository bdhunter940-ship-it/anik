import { Router } from 'express';
import { param, body, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate, optionalAuth } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import { v4 as uuid } from 'uuid';

const router = Router();

const makeOfferValidation = [
  body('product_id').isInt({ min: 1 }).toInt(),
  body('offered_price').isFloat({ min: 1 }),
  body('quantity').optional().isInt({ min: 1 }).toInt(),
  body('buyer_note').optional().isString().trim(),
];

router.post('/offers', authenticate, makeOfferValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

    const db = getDb();
    const { product_id, offered_price, quantity, buyer_note } = req.body;

    const product = db.prepare('SELECT id, name, price, stock_quantity FROM products WHERE id = ? AND is_active = 1 AND deleted_at IS NULL').get(product_id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    if (offered_price >= product.price) return res.status(400).json({ success: false, message: 'Your offer must be lower than the product price (' + product.price + ')' });
    if (offered_price <= 0) return res.status(400).json({ success: false, message: 'Invalid offer price' });

    const existing = db.prepare("SELECT id FROM bargaining_offers WHERE product_id = ? AND user_id = ? AND status = 'pending'").get(product_id, req.user.id);
    if (existing) return res.status(400).json({ success: false, message: 'You already have a pending offer for this product' });

    const result = db.prepare(
      `INSERT INTO bargaining_offers (uuid, product_id, user_id, offered_price, quantity, buyer_note, expires_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now', '+7 days'), datetime('now'), datetime('now'))`
    ).run(uuid(), product_id, req.user.id, offered_price, quantity || 1, buyer_note || null);

    const offer = db.prepare('SELECT * FROM bargaining_offers WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({ success: true, data: { offer }, message: 'Your offer has been submitted! The seller will review it.' });
  } catch (error) { next(error); }
});

router.get('/offers', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;
    const status = req.query.status;

    let where = 'WHERE bo.user_id = ?';
    let params = [req.user.id];
    if (status && ['pending','accepted','countered','rejected','expired'].includes(status)) {
      where += ' AND bo.status = ?'; params.push(status);
    }

    const total = db.prepare(`SELECT COUNT(*) as count FROM bargaining_offers bo ${where}`).get(...params).count;
    const offers = db.prepare(
      `SELECT bo.*, p.name as product_name, p.slug as product_slug, p.price as product_price,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as product_image
       FROM bargaining_offers bo
       JOIN products p ON bo.product_id = p.id
       ${where}
       ORDER BY bo.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({ success: true, data: { items: offers, total, page, limit, totalPages: Math.ceil(total / limit) } });
  } catch (error) { next(error); }
});

router.get('/offers/product/:productId', optionalAuth, async (req, res, next) => {
  try {
    const productId = parseInt(req.params.productId);
    if (!req.user) return res.json({ success: true, data: { offers: [] } });
    const db = getDb();
    const offers = db.prepare(
      "SELECT id, offered_price, counter_price, status, buyer_note, seller_note, quantity, created_at FROM bargaining_offers WHERE product_id = ? AND user_id = ? ORDER BY created_at DESC"
    ).all(productId, req.user.id);
    res.json({ success: true, data: { offers } });
  } catch (error) { next(error); }
});

router.put('/offers/:id/respond', authenticate, async (req, res, next) => {
  try {
    const offerId = parseInt(req.params.id);
    const { action, counter_price, seller_note } = req.body;
    if (!['accept','counter','reject'].includes(action)) return res.status(400).json({ success: false, message: 'Invalid action' });

    const db = getDb();
    const offer = db.prepare('SELECT * FROM bargaining_offers WHERE id = ? AND status = ?').get(offerId, 'pending');
    if (!offer) return res.status(404).json({ success: false, message: 'Offer not found or already responded' });

    const product = db.prepare('SELECT user_id FROM products WHERE id = ?').get(offer.product_id);
    if (!product || product.user_id !== req.user.id) return res.status(403).json({ success: false, message: 'Only the product seller can respond' });

    let newStatus = action === 'accept' ? 'accepted' : action === 'counter' ? 'countered' : 'rejected';
    db.prepare(
      `UPDATE bargaining_offers SET status = ?, counter_price = ?, seller_note = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(newStatus, action === 'counter' ? (counter_price || null) : null, seller_note || null, offerId);

    const updated = db.prepare('SELECT * FROM bargaining_offers WHERE id = ?').get(offerId);
    res.json({ success: true, data: { offer: updated }, message: action === 'accept' ? 'Offer accepted!' : action === 'counter' ? 'Counter offer sent' : 'Offer rejected' });
  } catch (error) { next(error); }
});

router.get('/admin/offers', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;
    const status = req.query.status;

    let where = 'WHERE 1=1';
    let params = [];

    if (req.user.role !== 'super_admin' && req.user.role !== 'admin') {
      where += ' AND p.user_id = ?'; params.push(req.user.id);
    }
    if (status && ['pending','accepted','countered','rejected','expired'].includes(status)) {
      where += ' AND bo.status = ?'; params.push(status);
    }

    const total = db.prepare(`SELECT COUNT(*) as count FROM bargaining_offers bo JOIN products p ON bo.product_id = p.id ${where}`).get(...params).count;
    const offers = db.prepare(
      `SELECT bo.*, p.name as product_name, p.slug as product_slug, p.price as product_price,
              u.first_name || ' ' || u.last_name as user_name, u.email as user_email, u.phone as user_phone,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as product_image
       FROM bargaining_offers bo
       JOIN products p ON bo.product_id = p.id
       JOIN users u ON bo.user_id = u.id
       ${where}
       ORDER BY bo.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({ success: true, data: { items: offers, total, page, limit, totalPages: Math.ceil(total / limit) } });
  } catch (error) { next(error); }
});

export default router;