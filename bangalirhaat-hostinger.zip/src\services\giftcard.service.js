import crypto from 'crypto';
import { getDb } from '../database/db.js';

function uuid() {
  return crypto.randomUUID();
}

class GiftCardService {
  async generateCode() {
    const db = getDb();
    let code;
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      const segment1 = crypto.randomBytes(2).toString('hex').toUpperCase();
      const segment2 = crypto.randomBytes(2).toString('hex').toUpperCase();
      code = `GC-${segment1}-${segment2}`;

      const exists = db.prepare('SELECT id FROM gift_cards WHERE code = ?').get(code);
      if (!exists) break;
      attempts++;
    }

    if (attempts >= maxAttempts) {
      throw new Error('Failed to generate unique gift card code');
    }

    return code;
  }

  async createGiftCard({ amount, purchaserId, recipientEmail, recipientName, message, expiresAt }) {
    const db = getDb();

    if (!amount || amount <= 0) throw new Error('Amount must be greater than 0');

    const code = await this.generateCode();

    const result = db.prepare(
      `INSERT INTO gift_cards (uuid, code, amount, balance, purchaser_id, recipient_email, recipient_name, message, status, expires_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), code, amount, amount, purchaserId || null,
      recipientEmail || null, recipientName || null, message || null,
      expiresAt || null
    );

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(result.lastInsertRowid);

    return giftCard;
  }

  async getGiftCard(code) {
    const db = getDb();
    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE code = ?').get(code);
    return giftCard || null;
  }

  async getGiftCardById(id) {
    const db = getDb();
    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(id);
    return giftCard || null;
  }

  async redeemGiftCard(code, amount, orderId) {
    const db = getDb();

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE code = ?').get(code);
    if (!giftCard) throw new Error('Gift card not found');
    if (giftCard.status !== 'active') throw new Error('Gift card is not active');
    if (giftCard.expires_at && new Date(giftCard.expires_at) < new Date()) {
      throw new Error('Gift card has expired');
    }
    if (giftCard.balance < amount) throw new Error('Insufficient gift card balance');

    const redeemTransaction = db.transaction(() => {
      db.prepare(
        `UPDATE gift_cards SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?`
      ).run(amount, giftCard.id);

      db.prepare(
        `INSERT INTO gift_card_transactions (uuid, gift_card_id, type, amount, order_id, created_at)
         VALUES (?, ?, 'redeem', ?, ?, datetime('now'))`
      ).run(uuid(), giftCard.id, -amount, orderId || null);

      if (giftCard.balance - amount <= 0) {
        db.prepare(
          `UPDATE gift_cards SET status = 'used', updated_at = datetime('now') WHERE id = ?`
        ).run(giftCard.id);
      }
    });

    redeemTransaction();

    const updated = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(giftCard.id);
    return updated;
  }

  async refundToGiftCard(giftCardId, amount, orderId) {
    const db = getDb();

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(giftCardId);
    if (!giftCard) throw new Error('Gift card not found');

    const refundTransaction = db.transaction(() => {
      db.prepare(
        `UPDATE gift_cards SET balance = balance + ?, status = 'active', updated_at = datetime('now') WHERE id = ?`
      ).run(amount, giftCardId);

      db.prepare(
        `INSERT INTO gift_card_transactions (uuid, gift_card_id, type, amount, order_id, created_at)
         VALUES (?, ?, 'refund', ?, ?, datetime('now'))`
      ).run(uuid(), giftCardId, amount, orderId || null);
    });

    refundTransaction();

    const updated = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(giftCardId);
    return updated;
  }

  async getGiftCardTransactions(giftCardId) {
    const db = getDb();
    const transactions = db.prepare(
      `SELECT * FROM gift_card_transactions WHERE gift_card_id = ? ORDER BY created_at DESC`
    ).all(giftCardId);
    return transactions;
  }

  async getUserGiftCards(userId) {
    const db = getDb();
    const giftCards = db.prepare(
      `SELECT * FROM gift_cards WHERE purchaser_id = ? ORDER BY created_at DESC`
    ).all(userId);
    return giftCards;
  }

  async getAllGiftCards({ page = 1, limit = 20, status } = {}) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (status) {
      where.push('status = ?');
      params.push(status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const total = db.prepare(
      `SELECT COUNT(*) as count FROM gift_cards ${whereClause}`
    ).get(...params).count;

    const giftCards = db.prepare(
      `SELECT * FROM gift_cards ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    return {
      giftCards,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async updateGiftCard(id, data) {
    const db = getDb();

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(id);
    if (!giftCard) throw new Error('Gift card not found');

    const { status, amount, recipient_email, recipient_name, message, expires_at } = data;

    db.prepare(
      `UPDATE gift_cards SET
        status = ?, amount = ?, recipient_email = ?, recipient_name = ?,
        message = ?, expires_at = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      status !== undefined ? status : giftCard.status,
      amount !== undefined ? amount : giftCard.amount,
      recipient_email !== undefined ? recipient_email : giftCard.recipient_email,
      recipient_name !== undefined ? recipient_name : giftCard.recipient_name,
      message !== undefined ? message : giftCard.message,
      expires_at !== undefined ? expires_at : giftCard.expires_at,
      id
    );

    const updated = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(id);
    return updated;
  }

  async deleteGiftCard(id) {
    const db = getDb();

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(id);
    if (!giftCard) throw new Error('Gift card not found');

    if (giftCard.balance > 0 && giftCard.status === 'active') {
      throw new Error('Cannot delete gift card with remaining balance');
    }

    db.prepare('DELETE FROM gift_card_transactions WHERE gift_card_id = ?').run(id);
    db.prepare('DELETE FROM gift_cards WHERE id = ?').run(id);

    return { deleted: true };
  }

  async validateGiftCard(code, amount) {
    const db = getDb();

    const giftCard = db.prepare('SELECT * FROM gift_cards WHERE code = ?').get(code);
    if (!giftCard) return { valid: false, message: 'Gift card not found' };
    if (giftCard.status !== 'active') return { valid: false, message: 'Gift card is not active' };
    if (giftCard.expires_at && new Date(giftCard.expires_at) < new Date()) {
      return { valid: false, message: 'Gift card has expired' };
    }
    if (giftCard.balance < amount) {
      return { valid: false, message: 'Insufficient gift card balance' };
    }

    return {
      valid: true,
      giftCard: {
        id: giftCard.id,
        code: giftCard.code,
        balance: giftCard.balance,
        expires_at: giftCard.expires_at,
      },
    };
  }
}

export default new GiftCardService();
