import express from 'express';
import crypto from 'crypto';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import courierService from '../services/courier.service.js';
import config from '../config/index.js';

const router = express.Router();

const adminAuth = [authenticate, authorize('admin', 'super_admin')];

const VALID_SHIPMENT_STATUSES = [
  'pending', 'confirmed', 'picked', 'in_transit',
  'out_for_delivery', 'delivered', 'returned', 'cancelled',
];

// =====================================================================
//  WEBHOOK — SteadFast delivery status callbacks
//  POST /api/courier/webhook/steadfast
//  No auth — validated via Bearer token header from SteadFast dashboard
// =====================================================================
router.post('/webhook/steadfast', async (req, res, next) => {
  try {
    const webhookToken = config.courier?.steadfast?.webhookToken;
    if (webhookToken) {
      const authHeader = req.headers.authorization || '';
      const token = authHeader.replace(/^Bearer\s+/i, '');
      if (token !== webhookToken) {
        return res.status(401).json({ success: false, message: 'Unauthorized webhook' });
      }
    }

    const payload = req.body;
    console.log('[Webhook] SteadFast payload:', JSON.stringify(payload).substring(0, 500));

    if (payload.notification_type === 'delivery_status' || payload.notification_type === 'tracking_update') {
      const result = courierService.handleSteadfastWebhook(payload);
      res.json({ status: 'ok', ...result });
    } else {
      console.warn('[Webhook] Unknown notification_type:', payload.notification_type);
      res.json({ status: 'ok', message: 'Ignored unknown notification type' });
    }
  } catch (error) {
    console.error('[Webhook] SteadFast error:', error.message);
    res.status(200).json({ status: 'ok', message: 'Webhook received but processing error' });
  }
});

// =====================================================================
//  SHIPMENTS CRUD
// =====================================================================

// POST /shipments — Create shipment via courier API (admin)
router.post('/shipments', ...adminAuth, async (req, res, next) => {
  try {
    const { order_id, courier_id } = req.body;

    if (!order_id) throw new AppError('order_id is required', 400);
    if (!courier_id) throw new AppError('courier_id is required', 400);

    const result = await courierService.createShipment(parseInt(order_id), parseInt(courier_id));

    const db = getDb();
    const shipment = db.prepare(
      `SELECT s.*, c.name as courier_name, c.slug as courier_slug
       FROM shipments s
       JOIN couriers c ON s.courier_id = c.id
       WHERE s.id = ?`
    ).get(result.shipmentId);

    res.status(201).json({
      success: true,
      data: { shipment, ...result },
      message: 'Shipment created successfully via courier API',
    });
  } catch (error) {
    next(error);
  }
});

// GET /shipments — List all shipments (admin)
router.get('/shipments', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.status) {
      where.push('s.status = ?');
      params.push(req.query.status);
    }

    if (req.query.courier_id) {
      where.push('s.courier_id = ?');
      params.push(parseInt(req.query.courier_id));
    }

    if (req.query.search) {
      where.push('(s.tracking_number LIKE ? OR s.consignment_id LIKE ? OR o.order_number LIKE ?)');
      const term = `%${req.query.search}%`;
      params.push(term, term, term);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total
       FROM shipments s
       JOIN orders o ON s.order_id = o.id
       ${whereClause}`
    ).get(...params);

    const shipments = db.prepare(
      `SELECT s.*, c.name as courier_name, c.slug as courier_slug,
              o.order_number, o.total as order_total, o.status as order_status,
              u.first_name || ' ' || u.last_name as customer_name
       FROM shipments s
       JOIN couriers c ON s.courier_id = c.id
       JOIN orders o ON s.order_id = o.id
       JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY s.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: shipments,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /shipments/:id — Get shipment detail
router.get('/shipments/:id', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const shipmentId = parseInt(req.params.id);

    if (isNaN(shipmentId)) {
      throw new AppError('Invalid shipment ID', 400);
    }

    const shipment = db.prepare(
      `SELECT s.*, c.name as courier_name, c.slug as courier_slug,
              o.id as order_id, o.order_number, o.total as order_total, o.status as order_status,
              o.shipping_address, o.payment_method, o.payment_status,
              u.id as user_id, u.first_name || ' ' || u.last_name as customer_name,
              u.email as customer_email, u.phone as customer_phone
       FROM shipments s
       JOIN couriers c ON s.courier_id = c.id
       JOIN orders o ON s.order_id = o.id
       JOIN users u ON o.user_id = u.id
       WHERE s.id = ?`
    ).get(shipmentId);

    if (!shipment) {
      throw new AppError('Shipment not found', 404);
    }

    if (req.user.role === 'customer' && shipment.user_id !== req.user.id) {
      throw new AppError('Access denied', 403);
    }

    let statusUpdates = [];
    if (shipment.status_update) {
      try {
        statusUpdates = JSON.parse(shipment.status_update);
      } catch {
        statusUpdates = [];
      }
    }

    const shippingAddr = shipment.shipping_address ? JSON.parse(shipment.shipping_address) : null;

    res.json({
      success: true,
      data: {
        shipment: {
          id: shipment.id,
          order_id: shipment.order_id,
          order_number: shipment.order_number,
          courier_name: shipment.courier_name,
          courier_slug: shipment.courier_slug,
          consignment_id: shipment.consignment_id,
          tracking_number: shipment.tracking_number,
          status: shipment.status,
          estimated_delivery: shipment.estimated_delivery,
          actual_delivery: shipment.actual_delivery,
          cost: shipment.cost,
          created_at: shipment.created_at,
          updated_at: shipment.updated_at,
        },
        order: {
          order_number: shipment.order_number,
          total: shipment.order_total,
          status: shipment.order_status,
          payment_method: shipment.payment_method,
          payment_status: shipment.payment_status,
          shipping_address: shippingAddr,
        },
        customer: {
          name: shipment.customer_name,
          email: shipment.customer_email,
          phone: shipment.customer_phone,
        },
        status_updates: statusUpdates,
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /shipments/:id/track — Track shipment via courier API
router.post('/shipments/:id/track', authenticate, async (req, res, next) => {
  try {
    const shipmentId = parseInt(req.params.id);

    if (isNaN(shipmentId)) {
      throw new AppError('Invalid shipment ID', 400);
    }

    const result = await courierService.trackShipment(shipmentId);

    res.json({
      success: true,
      data: { tracking: result },
    });
  } catch (error) {
    next(error);
  }
});

// PUT /shipments/:id — Update shipment status (admin)
router.put('/shipments/:id', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const shipmentId = parseInt(req.params.id);
    const { status, tracking_number, consignment_id, estimated_delivery } = req.body;

    if (status && !VALID_SHIPMENT_STATUSES.includes(status)) {
      throw new AppError(`Invalid status. Must be one of: ${VALID_SHIPMENT_STATUSES.join(', ')}`, 400);
    }

    const shipment = db.prepare('SELECT * FROM shipments WHERE id = ?').get(shipmentId);
    if (!shipment) throw new AppError('Shipment not found', 404);

    const updates = [];
    const params = [];

    if (status) { updates.push('status = ?'); params.push(status); }
    if (tracking_number) { updates.push('tracking_number = ?'); params.push(tracking_number); }
    if (consignment_id) { updates.push('consignment_id = ?'); params.push(consignment_id); }
    if (estimated_delivery) { updates.push('estimated_delivery = ?'); params.push(estimated_delivery); }

    if (updates.length > 0) {
      params.push(shipmentId);
      db.prepare(`UPDATE shipments SET ${updates.join(', ')}, updated_at = datetime('now') WHERE id = ?`).run(...params);

      if (status === 'delivered') {
        db.prepare(`UPDATE shipments SET actual_delivery = datetime('now') WHERE id = ?`).run(shipmentId);
        db.prepare(`UPDATE orders SET status = 'delivered', delivered_at = datetime('now') WHERE id = ?`).run(shipment.order_id);
      }

      if (status === 'cancelled') {
        db.prepare(`UPDATE orders SET status = 'cancelled' WHERE id = ?`).run(shipment.order_id);
      }

      const statusEntry = { status: status || shipment.status, timestamp: new Date().toISOString(), note: 'Manual update' };
      const existingUpdates = shipment.status_update ? JSON.parse(shipment.status_update) : [];
      existingUpdates.push(statusEntry);
      db.prepare('UPDATE shipments SET status_update = ? WHERE id = ?').run(JSON.stringify(existingUpdates), shipmentId);
    }

    const updated = db.prepare(
      `SELECT s.*, c.name as courier_name
       FROM shipments s
       JOIN couriers c ON s.courier_id = c.id
       WHERE s.id = ?`
    ).get(shipmentId);

    res.json({ success: true, message: 'Shipment updated', data: { shipment: updated } });
  } catch (error) {
    next(error);
  }
});

// DELETE /shipments/:id — Delete shipment (admin only)
router.delete('/shipments/:id', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const shipmentId = parseInt(req.params.id);

    const shipment = db.prepare('SELECT order_id FROM shipments WHERE id = ?').get(shipmentId);
    if (!shipment) throw new AppError('Shipment not found', 404);

    db.prepare('DELETE FROM shipments WHERE id = ?').run(shipmentId);

    res.json({ success: true, message: 'Shipment deleted' });
  } catch (error) {
    next(error);
  }
});

// POST /bulk-send — Bulk send orders to courier (SteadFast)
router.post('/bulk-send', ...adminAuth, async (req, res, next) => {
  try {
    const { order_ids, courier_id } = req.body;
    if (!order_ids || !Array.isArray(order_ids) || order_ids.length === 0) {
      throw new AppError('order_ids array is required', 400);
    }
    if (!courier_id) throw new AppError('courier_id is required', 400);

    const results = { success: [], failed: [] };
    for (const orderId of order_ids) {
      try {
        const result = await courierService.createShipment(parseInt(orderId), parseInt(courier_id));
        results.success.push({ order_id: orderId, shipment_id: result.shipmentId, consignment_id: result.consignment_id });
      } catch (err) {
        results.failed.push({ order_id: orderId, error: err.message });
      }
    }

    res.json({
      success: true,
      message: `Bulk send complete: ${results.success.length} succeeded, ${results.failed.length} failed`,
      data: results,
    });
  } catch (error) {
    next(error);
  }
});

// GET /invoice/:orderId — Generate invoice data with consignment info
router.get('/invoice/:orderId', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const orderId = parseInt(req.params.orderId);

    const order = db.prepare(
      `SELECT o.*, u.first_name || ' ' || u.last_name as customer_name,
              u.email, u.phone,
              s.consignment_id, s.tracking_number, c.name as courier_name
       FROM orders o
       JOIN users u ON o.user_id = u.id
       LEFT JOIN shipments s ON s.order_id = o.id
       LEFT JOIN couriers c ON s.courier_id = c.id
       WHERE o.id = ?`
    ).get(orderId);
    if (!order) throw new AppError('Order not found', 404);

    const items = db.prepare(
      `SELECT oi.*, (SELECT url FROM product_images WHERE product_id = oi.product_id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM order_items oi WHERE oi.order_id = ?`
    ).all(orderId);

    const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};

    res.json({
      success: true,
      data: {
        order: {
          id: order.id,
          order_number: order.order_number,
          created_at: order.created_at,
          status: order.status,
          subtotal: order.subtotal,
          discount: order.discount,
          shipping_cost: order.shipping_cost,
          total: order.total,
          payment_method: order.payment_method,
          payment_status: order.payment_status,
        },
        customer: {
          name: order.customer_name,
          email: order.email,
          phone: order.phone,
        },
        shipping_address: shippingAddr,
        items,
        courier: {
          name: order.courier_name || 'N/A',
          consignment_id: order.consignment_id || '',
          tracking_number: order.tracking_number || '',
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /invoice/bulk — Get invoice data for multiple orders
router.post('/invoice/bulk', ...adminAuth, async (req, res, next) => {
  try {
    const { order_ids } = req.body;
    if (!order_ids || !Array.isArray(order_ids) || order_ids.length === 0) {
      throw new AppError('order_ids array is required', 400);
    }

    const db = getDb();
    const invoices = [];

    for (const orderId of order_ids) {
      const order = db.prepare(
        `SELECT o.*, u.first_name || ' ' || u.last_name as customer_name,
                u.email, u.phone,
                s.consignment_id, s.tracking_number, c.name as courier_name
         FROM orders o
         JOIN users u ON o.user_id = u.id
         LEFT JOIN shipments s ON s.order_id = o.id
         LEFT JOIN couriers c ON s.courier_id = c.id
         WHERE o.id = ?`
      ).get(orderId);
      if (!order) continue;

      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);
      const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};

      invoices.push({
        order: {
          id: order.id,
          order_number: order.order_number,
          created_at: order.created_at,
          total: order.total,
          payment_method: order.payment_method,
          payment_status: order.payment_status,
        },
        customer: { name: order.customer_name, phone: order.phone },
        shipping_address: shippingAddr,
        items,
        courier: {
          name: order.courier_name || '',
          consignment_id: order.consignment_id || '',
          tracking_number: order.tracking_number || '',
        },
      });
    }

    res.json({ success: true, data: { invoices } });
  } catch (error) {
    next(error);
  }
});

// POST /sync — Bulk sync all pending shipment statuses (admin)
router.post('/sync', ...adminAuth, async (req, res, next) => {
  try {
    const result = await courierService.syncStatuses();

    res.json({
      success: true,
      message: `Sync complete: ${result.updated} updated, ${result.failed} failed`,
      data: result,
    });
  } catch (error) {
    next(error);
  }
});

// =====================================================================
//  STEADFAST-SPECIFIC ENDPOINTS
// =====================================================================

// GET /steadfast/balance — Check SteadFast account balance
router.get('/steadfast/balance', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const courier = db.prepare(`SELECT * FROM couriers WHERE slug LIKE '%steadfast%' AND is_active = 1 LIMIT 1`).get();
    if (!courier) throw new AppError('No active SteadFast courier found', 404);

    const result = await courierService.getSteadfastBalance(courier);
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// GET /steadfast/payments — Get SteadFast payment/cashout history
router.get('/steadfast/payments', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const courier = db.prepare(`SELECT * FROM couriers WHERE slug LIKE '%steadfast%' AND is_active = 1 LIMIT 1`).get();
    if (!courier) throw new AppError('No active SteadFast courier found', 404);

    const result = await courierService.getSteadfastPayments(courier);
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// POST /steadfast/fraud-check — Check phone number fraud risk
router.post('/steadfast/fraud-check', ...adminAuth, async (req, res, next) => {
  try {
    const { phone } = req.body;
    if (!phone) throw new AppError('phone is required', 400);

    const db = getDb();
    const courier = db.prepare(`SELECT * FROM couriers WHERE slug LIKE '%steadfast%' AND is_active = 1 LIMIT 1`).get();
    if (!courier) throw new AppError('No active SteadFast courier found', 404);

    const result = await courierService.fraudCheckSteadfast(phone, courier);
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// POST /steadfast/return — Create return request
router.post('/steadfast/return', ...adminAuth, async (req, res, next) => {
  try {
    const { consignment_id, reason } = req.body;
    if (!consignment_id) throw new AppError('consignment_id is required', 400);

    const db = getDb();
    const courier = db.prepare(`SELECT * FROM couriers WHERE slug LIKE '%steadfast%' AND is_active = 1 LIMIT 1`).get();
    if (!courier) throw new AppError('No active SteadFast courier found', 404);

    const result = await courierService.createSteadfastReturnRequest(consignment_id, reason, courier);
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// =====================================================================
//  COURIERS LIST & SHIPPING COST CALC
// =====================================================================

// PUT /couriers/:id — Update courier settings (admin)
router.put('/couriers/:id', ...adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const courierId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);
    if (!existing) throw new AppError('Courier not found', 404);

    const { api_key, api_secret, api_url, is_active } = req.body;
    db.prepare(
      `UPDATE couriers SET api_key = ?, api_secret = ?, api_url = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      api_key || existing.api_key,
      api_secret || existing.api_secret,
      api_url || existing.api_url,
      is_active !== undefined ? is_active : existing.is_active,
      courierId
    );
    const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);
    res.json({ success: true, message: 'Courier updated', data: { courier } });
  } catch (error) { next(error); }
});

// GET /couriers — List available couriers
router.get('/couriers', authenticate, async (req, res, next) => {
  try {
    const db = getDb();

    const couriers = db.prepare(
      `SELECT c.id, c.name, c.slug, c.is_active, c.created_at,
              (SELECT COUNT(*) FROM shipments WHERE courier_id = c.id) as total_shipments,
              (SELECT COUNT(*) FROM shipments WHERE courier_id = c.id AND status = 'in_transit') as active_shipments
       FROM couriers c
       WHERE c.is_active = 1
       ORDER BY c.name ASC`
    ).all();

    res.json({
      success: true,
      data: { items: couriers },
    });
  } catch (error) {
    next(error);
  }
});

// POST /calculate-shipping — Calculate shipping cost
router.post('/calculate-shipping', async (req, res, next) => {
  try {
    const { destination_district, weight, courier_id } = req.body;

    if (!destination_district) {
      throw new AppError('destination_district is required', 400);
    }

    const db = getDb();

    let couriers;
    if (courier_id) {
      couriers = db.prepare(
        `SELECT id, name, slug, is_active FROM couriers WHERE is_active = 1 AND id = ?`
      ).all(parseInt(courier_id));
    } else {
      couriers = db.prepare(
        `SELECT id, name, slug, is_active FROM couriers WHERE is_active = 1 ORDER BY name ASC`
      ).all();
    }

    if (couriers.length === 0) {
      return res.json({
        success: true,
        data: { shipping_options: [], message: 'No couriers available for this destination' },
      });
    }

    const weightKg = weight || 0.5;

    const SAME_DISTRICT = 'Dhaka';
    const isSameDistrict = destination_district.toLowerCase() === SAME_DISTRICT.toLowerCase();

    const shippingOptions = couriers.map(courier => {
      let cost;
      let estimatedDays;

      if (isSameDistrict) {
        if (weightKg <= 0.5) {
          cost = 60;
          estimatedDays = '1-2';
        } else if (weightKg <= 2) {
          cost = 70;
          estimatedDays = '1-2';
        } else {
          cost = 70 + Math.ceil((weightKg - 2) * 15);
          estimatedDays = '1-2';
        }
      } else {
        if (weightKg <= 0.5) {
          cost = 100;
          estimatedDays = '2-4';
        } else if (weightKg <= 2) {
          cost = 120;
          estimatedDays = '2-4';
        } else {
          cost = 120 + Math.ceil((weightKg - 2) * 20);
          estimatedDays = '2-5';
        }
      }

      return {
        courier_id: courier.id,
        courier_name: courier.name,
        courier_slug: courier.slug,
        cost,
        estimated_delivery: estimatedDays,
        weight: weightKg,
        destination: destination_district,
        same_district: isSameDistrict,
      };
    });

    shippingOptions.sort((a, b) => a.cost - b.cost);

    res.json({
      success: true,
      data: {
        shipping_options: shippingOptions,
        destination: destination_district,
        weight: weightKg,
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
