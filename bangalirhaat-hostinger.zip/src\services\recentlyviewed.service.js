import crypto from 'crypto';
import { getDb } from '../database/db.js';

class RecentlyViewedService {
  async trackView({ userId, sessionId, productId }) {
    const db = getDb();

    const product = db.prepare(
      'SELECT id, is_active FROM products WHERE id = ? AND deleted_at IS NULL'
    ).get(productId);
    if (!product || product.is_active !== 1) {
      throw new Error('Product not found or unavailable');
    }

    const identifier = userId || sessionId;
    if (!identifier) {
      throw new Error('Either userId or sessionId is required');
    }

    const existing = db.prepare(
      'SELECT id FROM recently_viewed WHERE product_id = ? AND (user_id = ? OR session_id = ?)'
    ).get(productId, userId || null, sessionId || null);

    if (existing) {
      db.prepare(
        `UPDATE recently_viewed SET viewed_at = datetime('now') WHERE id = ?`
      ).run(existing.id);
      return { id: existing.id, updated: true };
    }

    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO recently_viewed (id, user_id, session_id, product_id, viewed_at)
       VALUES (?, ?, ?, ?, datetime('now'))`
    ).run(id, userId || null, sessionId || null, productId);

    return { id, updated: false };
  }

  async getRecentlyViewed({ userId, sessionId, limit = 20 }) {
    const db = getDb();

    const items = db.prepare(
      `SELECT rv.id, rv.product_id, rv.viewed_at,
              p.name, p.slug, p.price, p.compare_price, p.average_rating, p.stock_quantity,
              b.name as brand_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM recently_viewed rv
       JOIN products p ON rv.product_id = p.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE (rv.user_id = ? OR rv.session_id = ?)
         AND p.is_active = 1 AND p.deleted_at IS NULL
       ORDER BY rv.viewed_at DESC
       LIMIT ?`
    ).all(userId || null, sessionId || null, limit);

    return { items, total: items.length };
  }

  async clearHistory({ userId, sessionId }) {
    const db = getDb();

    const result = db.prepare(
      'DELETE FROM recently_viewed WHERE user_id = ? OR session_id = ?'
    ).run(userId || null, sessionId || null);

    return { deleted: result.changes };
  }
}

export default new RecentlyViewedService();
