import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import bcrypt from 'bcryptjs';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

router.use(authenticate);

const updateProfileValidation = [
  body('first_name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('First name must be 2-50 characters'),
  body('last_name').optional().trim().isLength({ max: 50 }),
  body('email').optional().isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('phone').optional().matches(/^(\+88)?01[3-9]\d{8}$/).withMessage('Valid Bangladeshi phone number is required'),
  body('avatar').optional().isURL().withMessage('Valid URL required for avatar'),
];

const changePasswordValidation = [
  body('current_password').notEmpty().withMessage('Current password is required'),
  body('new_password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Password must contain uppercase, lowercase, and number'),
];

const addressValidation = [
  body('name').trim().isLength({ min: 2, max: 100 }).withMessage('Name is required'),
  body('phone').matches(/^(\+88)?01[3-9]\d{8}$/).withMessage('Valid phone is required'),
  body('line1').trim().isLength({ min: 3, max: 200 }).withMessage('Address line 1 is required'),
  body('line2').optional({ nullable: true }).isString().trim().isLength({ max: 200 }),
  body('city').trim().isLength({ min: 2, max: 100 }).withMessage('City is required'),
  body('district').trim().isLength({ min: 2, max: 100 }).withMessage('District is required'),
  body('postal_code').optional({ nullable: true }).isString().trim().isLength({ max: 10 }),
  body('is_default').optional().isBoolean().toBoolean(),
];

const addressIdValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid address ID'),
];

const notificationIdValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid notification ID'),
];

router.get('/profile', async (req, res, next) => {
  try {
    const db = getDb();
    const user = db.prepare(
      `SELECT id, first_name || ' ' || last_name as name, email, phone, avatar, role, referral_code, loyalty_points, wallet_balance,
              email_verified, created_at, updated_at
       FROM users WHERE id = ?`
    ).get(req.user.id);

    if (!user) {
      throw new AppError('User not found', 404);
    }

    res.json({ success: true, data: { user } });
  } catch (error) {
    next(error);
  }
});

router.put('/profile', updateProfileValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const { first_name, last_name, email, phone, avatar } = req.body;

    if (email) {
      const existing = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, userId);
      if (existing) {
        throw new AppError('Email already in use', 409);
      }
    }

    if (phone) {
      const existing = db.prepare('SELECT id FROM users WHERE phone = ? AND id != ?').get(phone, userId);
      if (existing) {
        throw new AppError('Phone number already in use', 409);
      }
    }

    const updates = [];
    const params = [];

    if (first_name) { updates.push('first_name = ?'); params.push(first_name); }
    if (last_name !== undefined) { updates.push('last_name = ?'); params.push(last_name); }
    if (email) { updates.push('email = ?'); params.push(email); }
    if (phone) { updates.push('phone = ?'); params.push(phone); }
    if (avatar !== undefined) { updates.push('avatar = ?'); params.push(avatar); }

    if (updates.length === 0) {
      return res.json({ success: true, message: 'No changes to update' });
    }

    updates.push("updated_at = datetime('now')");
    params.push(userId);

    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);

    const user = db.prepare(
      'SELECT id, first_name || \' \' || last_name as name, email, phone, avatar, role, referral_code, loyalty_points, wallet_balance, created_at FROM users WHERE id = ?'
    ).get(userId);

    res.json({ success: true, message: 'Profile updated', data: { user } });
  } catch (error) {
    next(error);
  }
});

router.put('/password', changePasswordValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const { current_password, new_password } = req.body;

    const user = db.prepare('SELECT id, password_hash FROM users WHERE id = ?').get(req.user.id);

    const isMatch = await bcrypt.compare(current_password, user.password_hash);
    if (!isMatch) {
      throw new AppError('Current password is incorrect', 400);
    }

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(new_password, salt);

    db.prepare(
      `UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(hashedPassword, user.id);

    res.json({ success: true, message: 'Password changed successfully' });
  } catch (error) {
    next(error);
  }
});

router.get('/addresses', async (req, res, next) => {
  try {
    const db = getDb();
    const addresses = db.prepare(
      'SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC'
    ).all(req.user.id);

    res.json({ success: true, data: { addresses } });
  } catch (error) {
    next(error);
  }
});

router.post('/addresses', addressValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const { name, phone, line1, line2, city, district, postal_code, is_default } = req.body;

    if (is_default) {
      db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').run(userId);
    }

    const result = db.prepare(
      `INSERT INTO addresses (user_id, name, phone, line1, line2, city, district, postal_code, is_default, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(userId, name, phone, line1, line2 || null, city, district, postal_code || null, is_default ? 1 : 0);

    const address = db.prepare('SELECT * FROM addresses WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({ success: true, message: 'Address added', data: { address } });
  } catch (error) {
    next(error);
  }
});

router.put('/addresses/:id', [...addressValidation, ...addressIdValidation], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const existing = db.prepare('SELECT id FROM addresses WHERE id = ? AND user_id = ?').get(req.params.id, userId);
    if (!existing) {
      throw new AppError('Address not found', 404);
    }

    const { name, phone, line1, line2, city, district, postal_code, is_default } = req.body;

    if (is_default) {
      db.prepare('UPDATE addresses SET is_default = 0 WHERE user_id = ?').run(userId);
    }

    db.prepare(
      `UPDATE addresses SET name = ?, phone = ?, line1 = ?, line2 = ?, city = ?, district = ?,
       postal_code = ?, is_default = ?, updated_at = datetime('now') WHERE id = ? AND user_id = ?`
    ).run(name, phone, line1, line2 || null, city, district, postal_code || null, is_default ? 1 : 0, req.params.id, userId);

    const address = db.prepare('SELECT * FROM addresses WHERE id = ?').get(req.params.id);

    res.json({ success: true, message: 'Address updated', data: { address } });
  } catch (error) {
    next(error);
  }
});

router.delete('/addresses/:id', addressIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const result = db.prepare('DELETE FROM addresses WHERE id = ? AND user_id = ?').run(req.params.id, userId);
    if (result.changes === 0) {
      throw new AppError('Address not found', 404);
    }

    res.json({ success: true, message: 'Address deleted' });
  } catch (error) {
    next(error);
  }
});

router.get('/notifications', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare('SELECT COUNT(*) as total FROM notifications WHERE user_id = ?').get(userId);

    const notifications = db.prepare(
      `SELECT id, title, message, type, is_read, created_at
       FROM notifications
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`
    ).all(userId, limit, offset);

    const unreadCount = db.prepare(
      'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0'
    ).get(userId);

    res.json({
      success: true,
      data: {
        notifications,
        unread_count: unreadCount.count,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.put('/notifications/:id/read', notificationIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const result = db.prepare(
      'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?'
    ).run(req.params.id, userId);

    if (result.changes === 0) {
      throw new AppError('Notification not found', 404);
    }

    res.json({ success: true, message: 'Notification marked as read' });
  } catch (error) {
    next(error);
  }
});

router.get('/wallet', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const user = db.prepare('SELECT wallet_balance FROM users WHERE id = ?').get(userId);

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare('SELECT COUNT(*) as total FROM wallet_transactions WHERE user_id = ?').get(userId);

    const transactions = db.prepare(
      `SELECT id, type, amount, description, reference_type, reference_id, balance_after, created_at
       FROM wallet_transactions
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`
    ).all(userId, limit, offset);

    res.json({
      success: true,
      data: {
        balance: user.wallet_balance,
        transactions,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/loyalty', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const user = db.prepare('SELECT loyalty_points FROM users WHERE id = ?').get(userId);

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare('SELECT COUNT(*) as total FROM loyalty_transactions WHERE user_id = ?').get(userId);

    const transactions = db.prepare(
      `SELECT id, type, points, description, reference_type, reference_id, created_at
       FROM loyalty_transactions
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`
    ).all(userId, limit, offset);

    res.json({
      success: true,
      data: {
        points: user.loyalty_points,
        transactions,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/referral', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const user = db.prepare('SELECT referral_code FROM users WHERE id = ?').get(userId);

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare(
      'SELECT COUNT(*) as total FROM referral_history WHERE referrer_id = ?'
    ).get(userId);

    const referrals = db.prepare(
      `SELECT rh.id, rh.referred_name, rh.referred_email, rh.status, rh.reward_amount, rh.created_at
       FROM referral_history rh
       WHERE rh.referrer_id = ?
       ORDER BY rh.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(userId, limit, offset);

    const totalRewards = db.prepare(
      'SELECT COALESCE(SUM(reward_amount), 0) as total FROM referral_history WHERE referrer_id = ? AND status = ?'
    ).get(userId, 'completed');

    res.json({
      success: true,
      data: {
        referral_code: user.referral_code,
        referral_link: `${process.env.FRONTEND_URL}/ref/${user.referral_code}`,
        total_referrals: countRow.total,
        total_rewards: totalRewards.total,
        referrals,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
