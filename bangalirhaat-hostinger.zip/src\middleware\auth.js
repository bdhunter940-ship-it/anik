import jwt from 'jsonwebtoken';
import config from '../config/index.js';
import { getDb } from '../database/db.js';
import { UnauthorizedError, ForbiddenError, AppError } from './errorHandler.js';

const ACCESS_TOKEN_EXPIRY_SECONDS = parseExpiry(config.jwt.expiresIn);
const REFRESH_TOKEN_EXPIRY_SECONDS = parseExpiry(config.jwt.refreshExpiresIn);

function parseExpiry(value) {
  const match = String(value).match(/^(\d+)([smhd])$/);
  if (!match) return 30 * 24 * 60 * 60;
  const num = parseInt(match[1], 10);
  const unit = match[2];
  switch (unit) {
    case 's': return num;
    case 'm': return num * 60;
    case 'h': return num * 60 * 60;
    case 'd': return num * 24 * 60 * 60;
    default: return 30 * 24 * 60 * 60;
  }
}

function extractToken(req) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  if (req.cookies && req.cookies.accessToken) {
    return req.cookies.accessToken;
  }
  return null;
}

function extractRefreshToken(req) {
  if (req.cookies && req.cookies.refreshToken) {
    return req.cookies.refreshToken;
  }
  const body = req.body;
  if (body && body.refreshToken) {
    return body.refreshToken;
  }
  return null;
}

function verifyAccessToken(token) {
  return jwt.verify(token, config.jwt.secret);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, config.jwt.refreshSecret);
}

function fetchUserFromDb(userId) {
  const db = getDb();
  const user = db.prepare(`
    SELECT id, uuid, email, phone, first_name, last_name, avatar,
           role, is_active, email_verified, phone_verified,
           two_factor_enabled, loyalty_points, wallet_balance,
           created_at, updated_at
    FROM users
    WHERE id = ? AND is_active = 1 AND deleted_at IS NULL
  `).get(userId);
  return user || null;
}

export function generateTokens(user) {
  const payload = {
    id: user.id,
    uuid: user.uuid,
    email: user.email,
    role: user.role,
  };

  const accessToken = jwt.sign(payload, config.jwt.secret, {
    expiresIn: config.jwt.expiresIn,
    issuer: 'bangalirhaat',
    audience: 'bangalirhaat-api',
  });

  const refreshToken = jwt.sign(
    { id: user.id, uuid: user.uuid, type: 'refresh' },
    config.jwt.refreshSecret,
    {
      expiresIn: config.jwt.refreshExpiresIn,
      issuer: 'bangalirhaat',
      audience: 'bangalirhaat-api',
    },
  );

  return { accessToken, refreshToken };
}

export function setTokenCookies(res, accessToken, refreshToken) {
  const accessCookieOptions = {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: config.isProduction ? 'strict' : 'lax',
    maxAge: ACCESS_TOKEN_EXPIRY_SECONDS * 1000,
    path: '/',
    signed: false,
  };

  const refreshCookieOptions = {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: config.isProduction ? 'strict' : 'lax',
    maxAge: REFRESH_TOKEN_EXPIRY_SECONDS * 1000,
    path: '/api/auth',
    signed: false,
  };

  res.cookie('accessToken', accessToken, accessCookieOptions);
  res.cookie('refreshToken', refreshToken, refreshCookieOptions);
}

export function clearTokenCookies(res) {
  res.clearCookie('accessToken', {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: config.isProduction ? 'strict' : 'lax',
    path: '/',
  });
  res.clearCookie('refreshToken', {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: config.isProduction ? 'strict' : 'lax',
    path: '/api/auth',
  });
}

export function authenticate(req, _res, next) {
  try {
    const token = extractToken(req);
    if (!token) {
      throw new UnauthorizedError('No authentication token provided');
    }

    const decoded = verifyAccessToken(token);

    if (decoded.type === 'refresh') {
      throw new UnauthorizedError('Invalid token type: refresh token cannot be used for authentication');
    }

    const user = fetchUserFromDb(decoded.id);
    if (!user) {
      throw new UnauthorizedError('User not found or account deactivated');
    }

    req.user = user;
    next();
  } catch (err) {
    if (err instanceof AppError) {
      return next(err);
    }
    if (err.name === 'JsonWebTokenError') {
      return next(new UnauthorizedError('Invalid token'));
    }
    if (err.name === 'TokenExpiredError') {
      return next(new UnauthorizedError('Token expired'));
    }
    return next(new UnauthorizedError('Authentication failed'));
  }
}

export function optionalAuth(req, _res, next) {
  try {
    const token = extractToken(req);
    if (!token) {
      req.user = null;
      return next();
    }

    const decoded = verifyAccessToken(token);
    if (decoded.type === 'refresh') {
      req.user = null;
      return next();
    }

    const user = fetchUserFromDb(decoded.id);
    req.user = user || null;
    next();
  } catch {
    req.user = null;
    next();
  }
}

export function authorize(...roles) {
  return (req, _res, next) => {
    if (!req.user) {
      return next(new UnauthorizedError('Authentication required'));
    }
    if (roles.length > 0 && !roles.includes(req.user.role)) {
      return next(
        new ForbiddenError(
          `Access denied. Required role${roles.length > 1 ? 's' : ''}: ${roles.join(', ')}`,
        ),
      );
    }
    next();
  };
}

export async function rotateRefreshToken(req, _res, next) {
  try {
    const refreshToken = extractRefreshToken(req);
    if (!refreshToken) {
      throw new UnauthorizedError('No refresh token provided');
    }

    const decoded = verifyRefreshToken(refreshToken);

    const db = getDb();
    const storedToken = db.prepare(`
      SELECT id, user_id, revoked_at, expires_at
      FROM refresh_tokens
      WHERE token = ? AND user_id = ?
    `).get(refreshToken, decoded.id);

    if (!storedToken) {
      throw new UnauthorizedError('Refresh token not recognized');
    }

    if (storedToken.revoked_at) {
      db.prepare(`DELETE FROM refresh_tokens WHERE user_id = ?`).run(decoded.id);
      throw new UnauthorizedError('Refresh token was revoked. Please log in again.');
    }

    if (new Date(storedToken.expires_at) < new Date()) {
      db.prepare(`DELETE FROM refresh_tokens WHERE id = ?`).run(storedToken.id);
      throw new UnauthorizedError('Refresh token expired. Please log in again.');
    }

    const user = fetchUserFromDb(decoded.id);
    if (!user) {
      throw new UnauthorizedError('User not found or account deactivated');
    }

    const { accessToken, refreshToken: newRefreshToken } = generateTokens(user);

    db.prepare(`
      UPDATE refresh_tokens
      SET revoked_at = datetime('now')
      WHERE id = ?
    `).run(storedToken.id);

    const expiresAt = new Date(Date.now() + REFRESH_TOKEN_EXPIRY_SECONDS * 1000).toISOString();
    db.prepare(`
      INSERT INTO refresh_tokens (user_id, token, user_agent, ip_address, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(user.id, newRefreshToken, req.get('user-agent') || null, req.ip, expiresAt);

    req.user = user;
    req.newAccessToken = accessToken;
    req.newRefreshToken = newRefreshToken;
    next();
  } catch (err) {
    if (err instanceof AppError) {
      return next(err);
    }
    if (err.name === 'JsonWebTokenError') {
      return next(new UnauthorizedError('Invalid refresh token'));
    }
    if (err.name === 'TokenExpiredError') {
      return next(new UnauthorizedError('Refresh token expired'));
    }
    next(new UnauthorizedError('Token refresh failed'));
  }
}
