import { existsSync, unlinkSync } from 'node:fs';
import { initializeDatabase, closeDatabase } from './db.js';

function main() {
  try {
    const dbPath = new URL('../data/bangalirhaat.db', import.meta.url).pathname;

    if (existsSync(dbPath)) {
      console.log('Removing existing database...');
      unlinkSync(dbPath);
      console.log('Existing database removed.');
    }

    console.log('Re-initializing database...');
    initializeDatabase();
    console.log('Database re-initialized.');

    closeDatabase();
    console.log('Database reset complete.');
    process.exit(0);
  } catch (error) {
    console.error('Failed to reset database:', error.message);
    process.exit(1);
  }
}

main();
