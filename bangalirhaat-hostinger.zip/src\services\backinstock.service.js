import { getDb } from '../database/db.js';

class BackInStockService {
  async subscribe({ productId, userId, email }) {
    const db = getDb();

    if (!productId) throw new Error('Product ID is required');
    if (!email) throw new Error('Email is required');

    const product = db.prepare('SELECT id, name FROM products WHERE id = ? AND deleted_at IS NULL').get(productId);
    if (!product) throw new Error('Product not found');

    const existing = db.prepare(
      'SELECT id, status FROM back_in_stock_subscriptions WHERE product_id = ? AND email = ?'
    ).get(productId, email);

    if (existing) {
      if (existing.status === 'pending') {
        throw new Error('Already subscribed for this product');
      }
      if (existing.status === 'notified' || existing.status === 'unsubscribed') {
        db.prepare(
          `UPDATE back_in_stock_subscriptions
           SET status = 'pending', notified_at = NULL, updated_at = datetime('now')
           WHERE id = ?`
        ).run(existing.id);

        const subscription = db.prepare('SELECT * FROM back_in_stock_subscriptions WHERE id = ?').get(existing.id);
        return { subscription };
      }
    }

    const result = db.prepare(
      `INSERT INTO back_in_stock_subscriptions (product_id, user_id, email, status, created_at, updated_at)
       VALUES (?, ?, ?, 'pending', datetime('now'), datetime('now'))`
    ).run(productId, userId || null, email);

    const subscription = db.prepare('SELECT * FROM back_in_stock_subscriptions WHERE id = ?').get(result.lastInsertRowid);

    return { subscription };
  }

  async unsubscribe(productId, email) {
    const db = getDb();

    if (!productId || !email) throw new Error('Product ID and email are required');

    const result = db.prepare(
      `UPDATE back_in_stock_subscriptions
       SET status = 'unsubscribed', updated_at = datetime('now')
       WHERE product_id = ? AND email = ? AND status = 'pending'`
    ).run(productId, email);

    if (result.changes === 0) {
      throw new Error('Subscription not found or already unsubscribed');
    }

    return { message: 'Successfully unsubscribed' };
  }

  async getSubscribers(productId) {
    const db = getDb();

    const subscribers = db.prepare(
      `SELECT id, product_id, email, status, notified_at, created_at
       FROM back_in_stock_subscriptions
       WHERE product_id = ? AND status = 'pending'
       ORDER BY created_at ASC`
    ).all(productId);

    return { subscribers, total: subscribers.length };
  }

  async notifySubscribers(productId) {
    const db = getDb();

    const pendingSubscribers = db.prepare(
      `SELECT id, email, user_id
       FROM back_in_stock_subscriptions
       WHERE product_id = ? AND status = 'pending'`
    ).all(productId);

    if (pendingSubscribers.length === 0) {
      return { notified: 0, subscribers: [] };
    }

    const product = db.prepare('SELECT id, name, slug FROM products WHERE id = ?').get(productId);

    const notifyTransaction = db.transaction(() => {
      db.prepare(
        `UPDATE back_in_stock_subscriptions
         SET status = 'notified', notified_at = datetime('now'), updated_at = datetime('now')
         WHERE product_id = ? AND status = 'pending'`
      ).run(productId);
    });

    notifyTransaction();

    const notifiedSubscribers = pendingSubscribers.map((s) => ({
      email: s.email,
      userId: s.user_id,
      product: { id: product.id, name: product.name, slug: product.slug },
    }));

    return {
      notified: pendingSubscribers.length,
      subscribers: notifiedSubscribers,
    };
  }

  async getAllSubscriptions({ page = 1, limit = 20, status } = {}) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (status) {
      where.push('bis.status = ?');
      params.push(status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const total = db.prepare(
      `SELECT COUNT(*) as count FROM back_in_stock_subscriptions bis ${whereClause}`
    ).get(...params).count;

    const subscriptions = db.prepare(
      `SELECT bis.*, p.name as product_name, p.slug as product_slug
       FROM back_in_stock_subscriptions bis
       JOIN products p ON bis.product_id = p.id
       ${whereClause}
       ORDER BY bis.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    return {
      subscriptions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getSubscriptionStats() {
    const db = getDb();

    const stats = db.prepare(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'notified' THEN 1 ELSE 0 END) as notified,
        SUM(CASE WHEN status = 'unsubscribed' THEN 1 ELSE 0 END) as unsubscribed,
        COUNT(DISTINCT product_id) as subscribed_products
       FROM back_in_stock_subscriptions`
    ).get();

    return { stats };
  }
}

export default new BackInStockService();
