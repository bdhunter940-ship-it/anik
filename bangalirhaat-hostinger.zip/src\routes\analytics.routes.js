import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import analyticsService from '../services/analytics.service.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

router.post('/pageview', async (req, res) => {
  try {
    const result = await analyticsService.trackPageView(req.body);
    res.status(201).json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/heatmap', async (req, res) => {
  try {
    const result = await analyticsService.trackHeatmap(req.body);
    res.status(201).json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/conversion', async (req, res) => {
  try {
    const result = await analyticsService.trackConversion(req.body);
    res.status(201).json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/daily-sales', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getDailySalesReport({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/monthly-sales', adminAuth, async (req, res) => {
  try {
    const { year } = req.query;
    const data = await analyticsService.getMonthlySalesReport({ year: year ? parseInt(year) : undefined });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/yearly-sales', adminAuth, async (req, res) => {
  try {
    const { year } = req.query;
    const data = await analyticsService.getYearlySalesReport({ year: year ? parseInt(year) : undefined });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/funnel', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getConversionFunnel({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/conversion-rate', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getConversionRate({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/customers', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getCustomerAnalytics({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/roi', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getROIReport({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/profit-margin', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await analyticsService.getProfitMargin({ startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/page-views', adminAuth, async (req, res) => {
  try {
    const { startDate, endDate, page, limit } = req.query;
    const data = await analyticsService.getPageViews({ startDate, endDate, page, limit: limit ? parseInt(limit) : undefined });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/heatmap/:page', adminAuth, async (req, res) => {
  try {
    const data = await analyticsService.getHeatmapData(req.params.page);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/top-products', adminAuth, async (req, res) => {
  try {
    const { limit, startDate, endDate } = req.query;
    const data = await analyticsService.getTopProducts({ limit: limit ? parseInt(limit) : undefined, startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/low-stock', adminAuth, async (req, res) => {
  try {
    const { threshold } = req.query;
    const data = await analyticsService.getLowStockProducts({ threshold: threshold ? parseInt(threshold) : undefined });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
