import { getDb } from '../database/db.js';

const DHAKA_DISTRICT = 'Dhaka';

const RATE_TABLE = {
  same_district: {
    tiers: [
      { maxWeight: 0.5, baseCost: 60, perKg: 0 },
      { maxWeight: 2, baseCost: 70, perKg: 0 },
      { maxWeight: Infinity, baseCost: 70, perKg: 15 },
    ],
    estimatedDays: '1-2',
  },
  outside_district: {
    tiers: [
      { maxWeight: 0.5, baseCost: 100, perKg: 0 },
      { maxWeight: 2, baseCost: 120, perKg: 0 },
      { maxWeight: Infinity, baseCost: 120, perKg: 20 },
    ],
    estimatedDays: '2-4',
  },
};

const RETURN_CHARGE_MULTIPLIER = 1.5;

class DeliveryService {
  _resolveRate(weight, zone) {
    const tiers = RATE_TABLE[zone].tiers;
    for (const tier of tiers) {
      if (weight <= tier.maxWeight) {
        const extra = weight > 2 ? Math.ceil((weight - 2) * tier.perKg) : 0;
        return { cost: tier.baseCost + extra, estimatedDays: RATE_TABLE[zone].estimatedDays };
      }
    }
    const fallback = tiers[tiers.length - 1];
    return { cost: fallback.baseCost, estimatedDays: RATE_TABLE[zone].estimatedDays };
  }

  _getZone(district) {
    return district.toLowerCase() === DHAKA_DISTRICT.toLowerCase()
      ? 'same_district'
      : 'outside_district';
  }

  async calculateDeliveryCharge({ district, upazila, weight, courierId }) {
    if (!district) throw new Error('district is required');

    const db = getDb();
    const weightKg = weight || 0.5;
    const zone = this._getZone(district);

    let couriers;
    if (courierId) {
      couriers = db.prepare(
        'SELECT id, name, slug FROM couriers WHERE id = ? AND is_active = 1'
      ).get(parseInt(courierId));
      couriers = couriers ? [couriers] : [];
    } else {
      couriers = db.prepare(
        'SELECT id, name, slug FROM couriers WHERE is_active = 1 ORDER BY name ASC'
      ).all();
    }

    const options = couriers.map(courier => {
      const { cost, estimatedDays } = this._resolveRate(weightKg, zone);

      const surcharge = db.prepare(
        `SELECT additional_cost FROM courier_zone_rates WHERE courier_id = ? AND district = ? LIMIT 1`
      ).get(courier.id, district);

      const finalCost = cost + (surcharge?.additional_cost || 0);

      return {
        courier_id: courier.id,
        courier_name: courier.name,
        courier_slug: courier.slug,
        cost: finalCost,
        estimated_delivery: estimatedDays,
        weight: weightKg,
        district,
        upazila: upazila || null,
        zone,
      };
    });

    options.sort((a, b) => a.cost - b.cost);

    return {
      shipping_options: options,
      destination: district,
      weight: weightKg,
      zone,
    };
  }

  async calculateReturnCharge({ orderId, reason }) {
    const db = getDb();

    const order = db.prepare(
      `SELECT o.id, o.total, o.shipping_cost, o.shipping_address, o.courier_id,
              c.name as courier_name
       FROM orders o
       LEFT JOIN couriers c ON o.courier_id = c.id
       WHERE o.id = ?`
    ).get(orderId);

    if (!order) throw new Error('Order not found');

    let district = 'Dhaka';
    if (order.shipping_address) {
      try {
        const addr = JSON.parse(order.shipping_address);
        district = addr.district || addr.city || 'Dhaka';
      } catch {
        district = 'Dhaka';
      }
    }

    const zone = this._getZone(district);
    const { cost } = this._resolveRate(0.5, zone);
    const returnCost = Math.round(cost * RETURN_CHARGE_MULTIPLIER);

    return {
      order_id: order.id,
      original_shipping: order.shipping_cost,
      return_cost: returnCost,
      reason: reason || 'Customer return',
      district,
      zone,
      courier_name: order.courier_name || 'N/A',
    };
  }

  async getCourierPerformance({ courierId, startDate, endDate }) {
    const db = getDb();
    const courier = db.prepare('SELECT id, name, slug FROM couriers WHERE id = ?').get(courierId);
    if (!courier) throw new Error('Courier not found');

    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const end = endDate || new Date().toISOString().split('T')[0];

    const stats = db.prepare(`
      SELECT
        COUNT(*) as total_shipments,
        SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered,
        SUM(CASE WHEN status = 'returned' THEN 1 ELSE 0 END) as returned,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
        SUM(CASE WHEN status IN ('pending','confirmed','picked','in_transit','out_for_delivery') THEN 1 ELSE 0 END) as in_progress
      FROM shipments
      WHERE courier_id = ? AND created_at BETWEEN ? AND ?
    `).get(courierId, start, end + ' 23:59:59');

    const avgTime = db.prepare(`
      SELECT AVG(julianday(actual_delivery) - julianday(created_at)) as avg_days
      FROM shipments
      WHERE courier_id = ? AND status = 'delivered' AND actual_delivery IS NOT NULL
        AND created_at BETWEEN ? AND ?
    `).get(courierId, start, end + ' 23:59:59');

    const total = stats.total_shipments || 0;
    const successRate = total > 0 ? Math.round((stats.delivered / total) * 100) : 0;

    return {
      courier: { id: courier.id, name: courier.name, slug: courier.slug },
      period: { start, end },
      stats: {
        total_shipments: total,
        delivered: stats.delivered || 0,
        returned: stats.returned || 0,
        cancelled: stats.cancelled || 0,
        in_progress: stats.in_progress || 0,
        avg_delivery_days: avgTime?.avg_days ? Math.round(avgTime.avg_days * 10) / 10 : null,
        success_rate: successRate,
      },
    };
  }

  async getAllCouriersPerformance({ startDate, endDate }) {
    const db = getDb();
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const end = endDate || new Date().toISOString().split('T')[0];

    const couriers = db.prepare(
      'SELECT id, name, slug FROM couriers WHERE is_active = 1 ORDER BY name ASC'
    ).all();

    const performances = [];
    for (const courier of couriers) {
      const perf = await this.getCourierPerformance({
        courierId: courier.id,
        startDate: start,
        endDate: end,
      });
      performances.push(perf);
    }

    performances.sort((a, b) => b.stats.success_rate - a.stats.success_rate);

    return {
      period: { start, end },
      couriers: performances,
    };
  }

  async getDeliveryZones() {
    const db = getDb();

    const customRates = db.prepare(
      'SELECT * FROM courier_zone_rates ORDER BY courier_id ASC, district ASC'
    ).all();

    const zones = [
      {
        name: 'Same District (Dhaka)',
        slug: 'same_district',
        districts: ['Dhaka'],
        base_rates: RATE_TABLE.same_district.tiers.map(t => ({
          max_weight: t.maxWeight === Infinity ? null : t.maxWeight,
          base_cost: t.baseCost,
          per_kg: t.perKg,
        })),
        estimated_delivery: RATE_TABLE.same_district.estimatedDays,
      },
      {
        name: 'Outside District',
        slug: 'outside_district',
        districts: ['All other districts'],
        base_rates: RATE_TABLE.outside_district.tiers.map(t => ({
          max_weight: t.maxWeight === Infinity ? null : t.maxWeight,
          base_cost: t.baseCost,
          per_kg: t.perKg,
        })),
        estimated_delivery: RATE_TABLE.outside_district.estimatedDays,
      },
    ];

    return {
      zones,
      custom_rates: customRates,
    };
  }
}

export default new DeliveryService();
