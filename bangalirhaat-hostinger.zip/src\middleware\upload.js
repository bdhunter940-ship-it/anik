import multer from 'multer';
import { randomUUID } from 'node:crypto';
import { extname, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync } from 'node:fs';
import { AppError } from './errorHandler.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const ROOT = resolve(__dirname, '..', '..');

const UPLOADS_BASE = resolve(ROOT, 'public', 'uploads');

const PRODUCT_IMAGES_DIR = resolve(UPLOADS_BASE, 'products');
const AVATARS_DIR = resolve(UPLOADS_BASE, 'avatars');
const RECEIPTS_DIR = resolve(UPLOADS_BASE, 'receipts');
const GENERAL_DIR = resolve(UPLOADS_BASE, 'general');

const ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/avif',
];

const ALLOWED_DOCUMENT_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'application/pdf',
  'image/heic',
  'image/heif',
];

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;
const MAX_DOCUMENT_SIZE = 10 * 1024 * 1024;

function ensureDir(dir) {
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
}

function generateFilename(originalname) {
  const ext = extname(originalname).toLowerCase();
  return `${Date.now()}-${randomUUID().slice(0, 8)}${ext}`;
}

function createStorage(subdirectory) {
  return multer.diskStorage({
    destination: (_req, _file, cb) => {
      const dest = resolve(UPLOADS_BASE, subdirectory);
      ensureDir(dest);
      cb(null, dest);
    },
    filename: (_req, file, cb) => {
      cb(null, generateFilename(file.originalname));
    },
  });
}

function fileFilter(allowedTypes) {
  return (_req, file, cb) => {
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(
        new AppError(
          `Invalid file type: ${file.mimetype}. Allowed: ${allowedTypes.map((t) => t.split('/').pop()).join(', ')}`,
          400,
        ),
        false,
      );
    }
  };
}

const productImageUpload = multer({
  storage: createStorage('products'),
  limits: {
    fileSize: MAX_IMAGE_SIZE,
    files: 10,
  },
  fileFilter: fileFilter(ALLOWED_IMAGE_TYPES),
});

const avatarUpload = multer({
  storage: createStorage('avatars'),
  limits: {
    fileSize: MAX_IMAGE_SIZE,
    files: 1,
  },
  fileFilter: fileFilter(ALLOWED_IMAGE_TYPES),
});

const receiptUpload = multer({
  storage: createStorage('receipts'),
  limits: {
    fileSize: MAX_DOCUMENT_SIZE,
    files: 5,
  },
  fileFilter: fileFilter(ALLOWED_DOCUMENT_TYPES),
});

const generalUpload = multer({
  storage: createStorage('general'),
  limits: {
    fileSize: MAX_DOCUMENT_SIZE,
    files: 10,
  },
  fileFilter: fileFilter(ALLOWED_DOCUMENT_TYPES),
});

function formatFileUrl(file) {
  const relative = file.path.replace(UPLOADS_BASE, '').replace(/\\/g, '/');
  return `/uploads${relative}`;
}

function formatUploadedFiles(files) {
  if (!files || files.length === 0) return null;
  return files.map((file) => ({
    filename: file.filename,
    originalname: file.originalname,
    mimetype: file.mimetype,
    size: file.size,
    url: formatFileUrl(file),
  }));
}

function handleUploadError(err, req, res, next) {
  if (err instanceof multer.MulterError) {
    let message;
    let statusCode = 400;

    switch (err.code) {
      case 'LIMIT_FILE_SIZE':
        message = `File too large. Maximum size is ${err.field === 'receipt' || err.field === 'document' ? '10MB' : '5MB'}`;
        break;
      case 'LIMIT_FILE_COUNT':
        message = 'Too many files uploaded';
        break;
      case 'LIMIT_UNEXPECTED_FILE':
        message = 'Unexpected field name in file upload';
        break;
      case 'LIMIT_PART_COUNT':
        message = 'Too many parts in multipart form';
        break;
      case 'LIMIT_FIELD_KEY':
        message = 'Field name too long';
        break;
      case 'LIMIT_FIELD_VALUE':
        message = 'Field value too long';
        break;
      case 'LIMIT_FIELD_COUNT':
        message = 'Too many fields';
        break;
      default:
        message = 'File upload error';
    }

    return res.status(statusCode).json({
      success: false,
      message,
    });
  }

  next(err);
}

export const uploadProductImages = (req, res, next) => {
  const upload = productImageUpload.array('images', 10);
  upload(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    if (req.files && req.files.length > 0) {
      req.uploadedFiles = formatUploadedFiles(req.files);
    }
    next();
  });
};

export const uploadAvatar = (req, res, next) => {
  const upload = avatarUpload.single('avatar');
  upload(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    if (req.file) {
      req.uploadedFile = formatUploadedFiles([req.file])[0];
    }
    next();
  });
};

export const uploadReceipt = (req, res, next) => {
  const upload = receiptUpload.array('receipts', 5);
  upload(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    if (req.files && req.files.length > 0) {
      req.uploadedFiles = formatUploadedFiles(req.files);
    }
    next();
  });
};

export const uploadGeneral = (req, res, next) => {
  const upload = generalUpload.array('files', 10);
  upload(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    if (req.files && req.files.length > 0) {
      req.uploadedFiles = formatUploadedFiles(req.files);
    }
    next();
  });
};

export const uploadSingleProductImage = (req, res, next) => {
  const upload = productImageUpload.single('image');
  upload(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    if (req.file) {
      req.uploadedFile = formatUploadedFiles([req.file])[0];
    }
    next();
  });
};

export {
  UPLOADS_BASE,
  PRODUCT_IMAGES_DIR,
  AVATARS_DIR,
  RECEIPTS_DIR,
  GENERAL_DIR,
  ALLOWED_IMAGE_TYPES,
  ALLOWED_DOCUMENT_TYPES,
  MAX_IMAGE_SIZE,
  MAX_DOCUMENT_SIZE,
};
