import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');

// ── Build the SPA index.html ──────────────────────────────────────────────

const EXTRA_CSS = `
/* ── Loading Screen ────────────────────────────────────── */
.loading-screen { position:fixed; inset:0; z-index:10000; background:#080808; display:flex; align-items:center; justify-content:center; }
.loading-content { text-align:center; }
.loading-logo { font-size:clamp(2rem,5vw,3.5rem); font-weight:700; background:linear-gradient(135deg,#dc143c,#d4af37); -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin-bottom:24px; letter-spacing:2px; }
.loading-bar { width:200px; height:3px; background:rgba(255,255,255,0.1); border-radius:99px; overflow:hidden; margin:0 auto; }
.loading-bar-fill { height:100%; width:0%; background:linear-gradient(90deg,#dc143c,#d4af37); border-radius:99px; transition:width 0.2s; }
.loading-percent { font-size:12px; color:rgba(255,255,255,0.4); margin-top:12px; font-variant-numeric:tabular-nums; }

/* ── Review Card ───────────────────────────────────────── */
.review-card { background:var(--card); border:1px solid var(--card-border); border-radius:var(--radius-lg); padding:var(--space-6); height:100%; }
.review-card-header { display:flex; align-items:center; gap:var(--space-3); margin-bottom:var(--space-4); }
.review-card-name { font-size:var(--text-sm); font-weight:var(--weight-semibold); color:var(--text); }
.review-card-date { font-size:var(--text-xs); color:var(--text-muted); }
.review-card-text { font-size:var(--text-sm); color:var(--text-secondary); line-height:var(--leading-relaxed); font-style:italic; }
.review-card-verified { font-size:var(--text-xs); color:var(--color-success); margin-top:var(--space-2); display:inline-block; font-weight:var(--weight-medium); }

/* ── Newsletter Card ───────────────────────────────────── */
.newsletter-card { position:relative; overflow:hidden; }

/* ── Video Banner ──────────────────────────────────────── */
.video-banner { position:relative; }

/* ── Admin extras ───────────────────────────────────────── */
.admin-actions { display:flex; gap:var(--space-2); flex-wrap:nowrap; }
.page-btn { display:inline-flex; align-items:center; justify-content:center; min-width:36px; height:36px; padding:0 var(--space-2); font-size:var(--text-sm); border:1px solid var(--border); border-radius:var(--radius-sm); background:transparent; color:var(--text-secondary); cursor:pointer; transition:all 0.15s; }
.page-btn:hover { background:var(--glass-bg); color:var(--text); border-color:var(--border-strong); }
.page-btn.active { background:var(--primary); color:#fff; border-color:var(--primary); }
.page-btn:disabled { opacity:0.4; cursor:not-allowed; }

/* ── Swiper nav fix ────────────────────────────────────── */
:root { --swiper-navigation-color: var(--primary); --swiper-pagination-color: var(--primary); }
:root .swiper { overflow:visible; }
:root .swiper-wrapper { overflow:visible; }
.swiper-button-next, .swiper-button-prev { width:40px; height:40px; border-radius:50%; background:var(--surface); border:1px solid var(--border); box-shadow:var(--shadow-lg); }
.swiper-button-next::after, .swiper-button-prev::after { font-size:14px; }

/* ── Star rating in home ──────────────────────────────── */
.star.filled { color:var(--gold-500); }
.star.half { position:relative; color:var(--neutral-700); }

/* ── Off-canvas page header margin fix ──────────────────── */
.page-section { min-height:100vh; }
.page-section .page-content, .page-section > .section:first-child { padding-top:0; }

/* ── Mobile performance & touch ─────────────────────────── */
* { -webkit-tap-highlight-color:transparent; }
button, a, .btn, .chip, .color-option, .payment-method, .category-tree-item, .quantity-btn, .navbar-action, .bottom-nav-item { touch-action:manipulation; }
.page-section { content-visibility:auto; contain:content; }
.page-section#page-home { content-visibility:visible; }
@media (max-width:640px) {
  .btn, .btn-lg, .btn-sm, .chip, .quantity-btn, .navbar-action, .bottom-nav-item, .color-option, .payment-method, .category-tree-item { min-height:44px; }
  .product-add-row .btn-primary { min-height:48px; }
  .product-card .btn { min-height:40px; }
}

/* ── Iconic visual effects ──────────────────────────────── */
.product-card { transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.3s ease; }
.product-card:hover { transform:translateY(-4px); box-shadow:0 12px 40px rgba(0,0,0,0.12); }
.btn-primary { transition:transform 0.2s, box-shadow 0.2s; }
.btn-primary:hover { transform:translateY(-1px); box-shadow:0 4px 15px rgba(220,20,60,0.3); }
.btn-primary:active { transform:translateY(0); }
.card-hover { transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.3s; }
.card-hover:hover { transform:translateY(-3px); box-shadow:0 8px 30px rgba(0,0,0,0.08); }
.navbar { backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px); }
.hero-floating { animation:float 6s ease-in-out infinite; }
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }

/* ── Go to top button ───────────────────────────────────── */
.gotop-btn { position:fixed; bottom:80px; right:16px; z-index:999; width:44px; height:44px; border-radius:50%; background:var(--primary); color:#fff; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; box-shadow:0 4px 15px rgba(220,20,60,0.3); opacity:0; transform:translateY(20px) scale(0.8); transition:opacity 0.3s, transform 0.3s cubic-bezier(0.34,1.56,0.64,1); pointer-events:none; }
.gotop-btn.visible { opacity:1; transform:translateY(0) scale(1); pointer-events:auto; }
.gotop-btn:hover { transform:translateY(-2px) scale(1.05); box-shadow:0 6px 20px rgba(220,20,60,0.4); }
@media (min-width:641px) { .gotop-btn { bottom:32px; right:32px; width:48px; height:48px; } }

/* ── Page transition overlay ────────────────────────────── */
.page-transition { position:fixed; inset:0; z-index:9999; background:var(--bg); pointer-events:none; opacity:0; transition:opacity 0.3s; }
.page-transition.active { opacity:1; }

/* ── Admin white theme enhancements ─────────────────────── */
.admin-body { background:#f5f5f7 !important; }
.admin-sidebar { background:#ffffff !important; border-right-color:#e5e7eb !important; }
.admin-sidebar-header { border-bottom-color:#e5e7eb !important; }
.admin-sidebar-brand { color:#111 !important; }
.admin-nav-item { color:#555 !important; }
.admin-nav-item:hover { color:#111 !important; background:rgba(0,0,0,0.04) !important; }
.admin-nav-item.active { color:#dc143c !important; background:rgba(220,20,60,0.06) !important; border-left-color:#dc143c !important; }
.admin-topbar { background:rgba(255,255,255,0.9) !important; border-bottom-color:#e5e7eb !important; }
.admin-search { background:#f5f5f7 !important; border-color:#e5e7eb !important; }
.admin-topbar-btn { color:#555 !important; }
.admin-topbar-btn:hover { background:rgba(0,0,0,0.04) !important; color:#111 !important; }
.admin-main { background:#f5f5f7 !important; }
.admin-card, .admin-chart-card, .admin-form-section { background:#ffffff !important; border-color:#e5e7eb !important; }
.admin-stats-value { color:#111 !important; }
.admin-stats-label { color:#666 !important; }
.admin-avatar { background:var(--primary) !important; color:#fff !important; }
`;

const EXTRA_JS = `
// ── Page-specific init handlers ───────────────────────────────────
function initPageHandlers(pageName) {
  switch(pageName) {
    case 'home':
      if (typeof loadFeaturedProducts === 'function') loadFeaturedProducts();
      if (typeof loadNewArrivals === 'function') loadNewArrivals();
      if (typeof loadFlashSales === 'function') loadFlashSales();
      if (typeof loadCategories === 'function') loadCategories();
      if (typeof loadReviews === 'function') loadReviews();
      if (typeof initCountdown === 'function') initCountdown(Date.now() + 86400000);
      break;
    case 'products':
      if (typeof initProductListing === 'function') initProductListing();
      break;
    case 'product':
      if (typeof initProductDetail === 'function') initProductDetail();
      break;
    case 'cart':
      if (typeof Cart !== 'undefined') Cart.load();
      break;
    case 'wishlist':
      if (typeof Wishlist !== 'undefined') Wishlist.load();
      break;
    case 'categories':
      if (typeof initCategoryPage === 'function') initCategoryPage();
      break;
    case 'checkout':
      if (typeof initCheckout === 'function') initCheckout();
      break;
  }
  if (typeof initSwipers === 'function') setTimeout(initSwipers, 100);
  if (typeof BAnimation !== 'undefined') {
    if (typeof BAnimation.init === 'function' && window.innerWidth > 768) setTimeout(function() { BAnimation.init(); }, 500);
    if (typeof BAnimation.refresh === 'function') setTimeout(function() { BAnimation.refresh(); }, 300);
  }
  if (typeof BAnalytics !== 'undefined' && typeof BAnalytics.trackPageView === 'function') BAnalytics.trackPageView();
}

// ── Close mobile menu helper ──────────────────────────────
function closeMobileMenu() {
  const mm = document.getElementById('mobileMenu');
  const mo = document.getElementById('mobileMenuOverlay');
  const mt = document.getElementById('mobileMenuToggle');
  if (mm) mm.classList.remove('active');
  if (mo) mo.classList.remove('active');
  if (mt) mt.classList.remove('active');
  document.body.style.overflow = '';
}

// ── Go to top ─────────────────────────────────────────────
document.addEventListener('scroll', function() {
  var btn = document.getElementById('goToTopBtn');
  if (btn) btn.classList.toggle('visible', window.scrollY > 400);
}, { passive: true });

// ── Admin always light ─────────────────────────────────---
function setAdminTheme() {
  var dt = document.documentElement.getAttribute('data-theme');
  if (document.body.classList.contains('admin-body') && dt !== 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
  }
}

// ── Boot on DOM ready ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  Theme.init();
  Auth._init();
  setAdminTheme();
  initNavbar();
  initSearch();
  initCartSidebar();
  initThemeToggle();
  setTimeout(function() { Cart.load(); Wishlist.load(); }, 200);
  // Loading screen fade
  var loadingScreen = document.getElementById('loading-screen');
  if (loadingScreen) {
    setTimeout(function() { loadingScreen.classList.add('hidden'); document.body.style.overflow = ''; }, 800);
  }
});
`;

function buildIndex() {
  // 1. Read all CSS
  let css = '';
  const cssDir = path.join(publicDir, 'css');
  const cssFiles = ['variables.css', 'base.css', 'animation.css', 'components.css', 'layout.css', 'pages.css', 'admin.css', 'responsive.css'];
  for (const f of cssFiles) {
    try {
      css += fs.readFileSync(path.join(cssDir, f), 'utf-8') + '\n';
    } catch { console.warn(`CSS file not found: ${f}`); }
  }

  // 2. Build page sections from HTML files
  const pagesDir = path.join(publicDir, 'pages');
  let pageSections = '';
  const pageFiles = fs.readdirSync(pagesDir).filter(f => f.endsWith('.html'));
  
  // Map of page name -> HTML content
  const pageMap = {};
  for (const file of pageFiles) {
    const name = file.replace('.html', '');
    let html = fs.readFileSync(path.join(pagesDir, file), 'utf-8');
    // Extract content between <body> and </body>
    const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) html = bodyMatch[1];
    else {
      // Try to extract from <main> or content area
      const mainMatch = html.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
      if (mainMatch) html = mainMatch[1];
    }
    // Remove all script tags (inline + external) since JS is already in app.js
    html = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
    // Convert internal /pages/ links to hash links
    html = html.replace(/(href=["'])\/pages\/([^"']+)["']/g, (m, pre, url) => {
      const [pathPart, query] = url.split('?');
      const pageName = pathPart.replace('.html', '');
      return `${pre}#${pageName}${query ? '?' + query : ''}"`;
    });
    pageMap[name] = html;
  }

  // Order pages: home first, then auth pages, then main pages, then misc
  const pageOrder = [
    'home', 'login', 'register', 'forgot-password',
    'products', 'product', 'categories', 'cart', 'checkout', 'order-success',
    'wishlist', 'compare', 'search', 'collections', 'gift-cards',
    'dashboard', 'track-order', 'about', 'contact', 'faq',
    'privacy', 'terms', 'ai-assistant', 'back-in-stock', 'bulk-order',
    'whatsapp-order', 'pre-orders', 'loyalty', 'referral'
  ];

  for (const name of pageOrder) {
    if (pageMap[name]) {
      pageSections += `<div id="page-${name}" class="page-section" style="display:none">${pageMap[name]}</div>\n`;
    }
  }

  // 3. Read admin index.html
  let adminHTML = '';
  try {
    adminHTML = fs.readFileSync(path.join(publicDir, 'admin', 'index.html'), 'utf-8');
    const bodyMatch = adminHTML.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) adminHTML = bodyMatch[1];
    adminHTML = adminHTML.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
    // Convert admin page links
    adminHTML = adminHTML.replace(/(href=["'])([^"']+)["']/g, (m, pre, url) => {
      if (url.startsWith('http') || url.startsWith('#') || url.startsWith('javascript') || url.startsWith('/')) return m;
      return `${pre}${url}"`;
    });
  } catch { console.warn('Admin index.html not found'); }

  // 4. Read JS files  
  const jsDir = path.join(publicDir, 'js');
  let js = '';
  const jsFiles = ['app.js', 'admin.js', 'animations.js', 'analytics.js'];
  for (const f of jsFiles) {
    try {
      js += fs.readFileSync(path.join(jsDir, f), 'utf-8') + '\n';
    } catch { console.warn(`JS file not found: ${f}`); }
  }

  // 5. Write combined JS to external file for caching
  const bundlePath = path.join(jsDir, 'bundle.js');
  fs.writeFileSync(bundlePath, js, 'utf-8');

  // 6. Build the complete index.html
  const router = `// ── SPA Router ──────────────────────────────────────────────────────
(function() {
  const pages = document.querySelectorAll('.page-section');
  const adminContainer = document.getElementById('adminContainer');
  let currentPage = null;

  function showPage(pageName) {
    // Hide all page sections
    pages.forEach(p => p.style.display = 'none');
    if (adminContainer) adminContainer.style.display = 'none';

    // Check if it's the admin page
    if (pageName === 'admin' || pageName.startsWith('admin/')) {
      if (adminContainer) {
        adminContainer.style.display = 'block';
        currentPage = 'admin';
        document.body.className = 'admin-body';
        document.documentElement.setAttribute('data-theme', 'light');
        // Trigger admin init
        if (typeof initAdmin === 'function') initAdmin();
      }
      return;
    }

    document.body.className = '';

    // Show the matching page section
    const target = document.getElementById('page-' + pageName);
    if (target) {
      target.style.display = 'block';
      currentPage = pageName;
      // Trigger page-specific init
      if (typeof initPageHandlers === 'function') initPageHandlers(pageName);
    } else {
      // 404 - show home
      const home = document.getElementById('page-home');
      if (home) home.style.display = 'block';
      currentPage = 'home';
    }

    window.scrollTo(0, 0);
  }

  function getPageFromHash() {
    let hash = window.location.hash.replace('#', '');
    if (!hash || hash === '/') return 'home';
    // Remove leading / if present
    hash = hash.replace(/^\\//, '');
    // Extract page name (before ?)
    const pageName = hash.split('?')[0];
    return pageName || 'home';
  }

  // Listen for hash changes
  window.addEventListener('hashchange', function() {
    showPage(getPageFromHash());
  });

  // Also catch regular navigation (e.g. from links with onclick that change location)
  const origPushState = history.pushState;
  history.pushState = function() {
    origPushState.apply(this, arguments);
    // Don't trigger on admin hash changes (admin handles its own routing)
    if (!window.location.hash.startsWith('#admin')) {
      showPage(getPageFromHash());
    }
  };

  window.addEventListener('popstate', function() {
    if (!window.location.hash.startsWith('#admin')) {
      showPage(getPageFromHash());
    }
  });

  // Override all anchor links to use hash routing
  document.addEventListener('click', function(e) {
    const link = e.target.closest('a[href]');
    if (!link) return;
    const href = link.getAttribute('href');
    if (!href || href.startsWith('http') || href.startsWith('javascript:') || href.startsWith('#') || href.startsWith('tel:') || href.startsWith('mailto:')) return;
    if (href.startsWith('/api/') || href.startsWith('/health') || href.endsWith('.json')) return;
    
    // Convert /pages/xxx links to hash routing
    if (href.startsWith('/pages/')) {
      e.preventDefault();
      const url = href.replace('/pages/', '');
      const [pathPart, query] = url.split('?');
      const pageName = pathPart.replace('.html', '');
      window.location.hash = '#' + pageName + (query ? '?' + query : '');
    }
  });

  // Initial page load
  showPage(getPageFromHash());
})();`;

  let indexHTML = `<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bangalirhaat — Premium Bangladeshi E-Commerce</title>
<meta name="description" content="Discover authentic Bangladeshi products — from traditional Jamdani sarees to handcrafted terracotta, brass jewelry, and premium textiles.">
<meta name="theme-color" content="#dc143c">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300..700;800;900&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<style>
${css}
${EXTRA_CSS}
</style>
</head>
<body>

<!-- Loading Screen -->
<div id="loading-screen" class="loading-screen">
  <div class="loading-content">
    <div class="loading-logo">বাঙালিরহাট</div>
    <div class="loading-bar"><div class="loading-bar-fill" id="loadingBar"></div></div>
    <div class="loading-percent" id="loadingPercent">0%</div>
  </div>
</div>

<!-- Page Transition Overlay -->
<div id="pageTransition" class="page-transition"></div>

<!-- Go to Top Button -->
<button id="goToTopBtn" class="gotop-btn" aria-label="Go to top" onclick="window.scrollTo({top:0,behavior:'smooth'})">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m18 15-6-6-6 6"/></svg>
</button>

<!-- Toast Container -->
<div id="toast-container" class="toast-container"></div>

<!-- Confirm Dialog -->
<div id="confirmDialog" class="modal-overlay">
  <div class="modal modal-sm">
    <div class="modal-header"><h3 id="confirmTitle">Confirm</h3><button class="modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">&times;</button></div>
    <div class="modal-body"><p id="confirmMessage" style="color:var(--text-secondary)"></p></div>
    <div class="modal-footer"><button class="btn btn-ghost modal-close" onclick="this.closest('.modal-overlay').classList.remove('active')">Cancel</button><button class="btn btn-primary" id="confirmAction">Confirm</button></div>
  </div>
</div>

<!-- Navbar -->
<nav class="navbar" id="navbar">
  <div class="navbar-inner">
    <a class="navbar-brand" href="#home" onclick="window.location.hash='#home'">
      <svg width="28" height="28" viewBox="0 0 40 40" fill="none"><rect width="40" height="40" rx="8" fill="url(#brandGrad)"/><path d="M12 20L20 12L28 20L20 28L12 20Z" fill="white" opacity="0.9"/><path d="M8 20L20 8L32 20" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.6"/></svg>
      <span class="navbar-brand-text">বাঙালিরহাট</span>
    </a>
    <div class="navbar-menu" id="navbarMenu">
      <a class="navbar-link" href="#home">Home</a>
      <a class="navbar-link" href="#products">Products</a>
      <a class="navbar-link" href="#categories">Categories</a>
      <a class="navbar-link" href="#about">About</a>
      <a class="navbar-link" href="#contact">Contact</a>
    </div>
    <div class="navbar-actions">
      <button class="navbar-action" id="searchToggle" aria-label="Search"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></button>
      <button class="navbar-action" id="themeToggle" aria-label="Toggle theme"><svg id="themeIcon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg></button>
      <a class="navbar-action" href="#wishlist" onclick="window.location.hash='#wishlist'"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg><span class="badge-count" id="wishlistBadge" style="display:none">0</span></a>
      <button class="navbar-action" id="cartToggle" aria-label="Cart"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg><span class="badge-count" id="cartBadge" style="display:none">0</span></button>
      <div class="admin-avatar-dropdown" style="display:none" id="userMenu">
        <div class="admin-avatar" id="userAvatar" style="width:32px;height:32px;font-size:var(--text-xs);">U</div>
        <div class="admin-dropdown" style="right:0;min-width:200px;">
          <div class="admin-dropdown-header" id="userNameDisplay">User</div>
          <button class="admin-dropdown-item" onclick="window.location.hash='#dashboard'">My Dashboard</button>
          <button class="admin-dropdown-item" onclick="Auth.logout()">Sign Out</button>
        </div>
      </div>
      <a class="navbar-action" href="#login" onclick="window.location.hash='#login'" id="loginLink"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></a>
      <button class="navbar-mobile-toggle" id="mobileMenuToggle" aria-label="Menu">
        <div class="hamburger"><span></span><span></span><span></span></div>
      </button>
    </div>
  </div>
</nav>

<!-- Mobile Menu -->
<div class="mobile-menu-overlay" id="mobileMenuOverlay"></div>
<div class="mobile-menu" id="mobileMenu">
  <div class="mobile-menu-header">
    <span style="font-weight:var(--weight-bold);">Menu</span>
    <button class="mobile-menu-close" id="mobileMenuClose">&times;</button>
  </div>
  <div class="mobile-menu-body">
    <a class="mobile-menu-link" href="#home" onclick="closeMobileMenu()">Home</a>
    <a class="mobile-menu-link" href="#products" onclick="closeMobileMenu()">Products</a>
    <a class="mobile-menu-link" href="#categories" onclick="closeMobileMenu()">Categories</a>
    <a class="mobile-menu-link" href="#cart" onclick="closeMobileMenu()">Cart</a>
    <a class="mobile-menu-link" href="#wishlist" onclick="closeMobileMenu()">Wishlist</a>
    <a class="mobile-menu-link" href="#about" onclick="closeMobileMenu()">About</a>
    <a class="mobile-menu-link" href="#contact" onclick="closeMobileMenu()">Contact</a>
    <div class="mobile-menu-divider"></div>
    <a class="mobile-menu-link" href="#login" onclick="closeMobileMenu()">Sign In</a>
    <a class="mobile-menu-link" href="#register" onclick="closeMobileMenu()">Register</a>
    <button class="mobile-menu-link" id="mobileSearchBtn">Search</button>
  </div>
</div>

<!-- Search Overlay -->
<div class="search-overlay" id="searchOverlay" aria-hidden="true">
  <button class="search-overlay-close" id="searchClose">&times;</button>
  <div class="search-bar"><svg class="search-bar-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input class="search-bar-input" id="searchInput" type="search" placeholder="Search products..." autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"><kbd class="search-bar-shortcut">ESC</kbd></div>
  <div id="recentSearches" style="max-width:40rem;width:100%;margin-top:var(--space-6);padding:0 var(--space-4);display:none;"><div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);color:var(--text-muted);margin-bottom:var(--space-3);">Recent Searches</div><div id="recentSearchList" style="display:flex;gap:var(--space-2);flex-wrap:wrap;"></div></div>
  <div id="searchSuggestions" style="max-width:40rem;width:100%;margin-top:var(--space-4);padding:0 var(--space-4);display:none;"><div id="searchResults"></div></div>
</div>

<!-- Cart Sidebar -->
<div class="cart-sidebar-overlay" id="cartSidebarOverlay"></div>
<div class="cart-sidebar" id="cartSidebar">
  <div class="cart-sidebar-header"><span class="cart-sidebar-title">Cart (<span id="cartSidebarCount">0</span>)</span><button class="cart-sidebar-close" id="cartSidebarClose">&times;</button></div>
  <div class="cart-sidebar-body">
    <div id="cartEmpty" style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;gap:var(--space-4);"><div style="font-size:48px;opacity:0.3;">🛒</div><div style="font-size:var(--text-lg);font-weight:var(--weight-semibold);">Your cart is empty</div><p style="font-size:var(--text-sm);color:var(--text-muted);">Add some products to get started!</p></div>
    <div id="cartItemsList" style="display:flex;flex-direction:column;gap:var(--space-4);"></div>
  </div>
  <div class="cart-sidebar-footer" id="cartSidebarFooter" style="display:none;">
    <div style="display:flex;justify-content:space-between;font-size:var(--text-lg);font-weight:var(--weight-bold);margin-bottom:var(--space-4);"><span>Total</span><span id="cartSidebarTotal">৳0</span></div>
    <a class="btn btn-primary w-full" href="#checkout" onclick="document.getElementById('cartSidebarClose').click();">Checkout</a>
  </div>
</div>

<!-- Bottom Nav -->
<div class="bottom-nav">
  <a class="bottom-nav-item" href="#home"><svg class="bottom-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg><span>Home</span></a>
  <a class="bottom-nav-item" href="#categories"><svg class="bottom-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg><span>Categories</span></a>
  <a class="bottom-nav-item" href="#wishlist"><svg class="bottom-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg><span>Wishlist</span><span class="bottom-nav-badge" id="wishlistBadgeMobile" style="display:none">0</span></a>
  <button class="bottom-nav-item" id="cartToggleMobile"><svg class="bottom-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg><span>Cart</span><span class="bottom-nav-badge" id="cartBadgeMobile" style="display:none">0</span></button>
  <a class="bottom-nav-item" href="#dashboard"><svg class="bottom-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span>Account</span></a>
</div>

<!-- Admin Container -->
<div id="adminContainer" style="display:none;">
${adminHTML || '<!-- Admin panel content -->'}
</div>

<!-- Page Sections -->
${pageSections}

<!-- Scripts -->
<script src="js/bundle.js"></script>
<script>
${EXTRA_JS}
${router}
</script>

<!-- Brands SVG gradient -->
<svg width="0" height="0" style="position:absolute">
  <defs>
    <linearGradient id="brandGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#dc143c"/>
      <stop offset="100%" stop-color="#d4af37"/>
    </linearGradient>
  </defs>
</svg>

</body>
</html>`;

  // 7. Minify HTML (safe: only comments + blank lines)
  indexHTML = indexHTML
    .replace(/\n{3,}/g, '\n\n')    // triple+ blank lines → double
    .replace(/<!--[\s\S]*?-->/g, ''); // HTML comments

  const outPath = path.join(__dirname, 'index.html');
  fs.writeFileSync(outPath, indexHTML, 'utf-8');
  console.log('✓ index.html generated (' + (indexHTML.length / 1024).toFixed(0) + ' KB)');
}

buildIndex();
