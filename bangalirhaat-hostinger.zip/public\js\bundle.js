/* ==========================================================================
   Bangalirhaat — Main Application JavaScript
   Premium E-Commerce Platform
   ========================================================================== */

// ============================================
// API Client
// ============================================
const API = {
  BASE_URL: '/api',

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    const t = localStorage.getItem('br_token');
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
  },

  async get(endpoint) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        headers: this._headers(),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async post(endpoint, data) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async put(endpoint, data) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: this._headers(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async delete(endpoint) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: this._headers(),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async _handleError(res) {
    try {
      const body = await res.json();
      if (res.status === 401) {
        Auth.logout();
      }
      return { message: body.message || body.error || 'Something went wrong', status: res.status };
    } catch {
      return { message: 'Something went wrong', status: res.status };
    }
  },
};

// ============================================
// Auth Module
// ============================================
const Auth = {
  user: null,
  token: null,

  async login(email, password) {
    const data = await API.post('/auth/login', { email, password });
    this.token = data.token;
    this.user = data.user;
    localStorage.setItem('br_token', data.token);
    Toast.success(`Welcome back, ${this.user.name}!`);
    return data;
  },

  async register(userData) {
    const data = await API.post('/auth/register', userData);
    this.token = data.token;
    this.user = data.user;
    localStorage.setItem('br_token', data.token);
    Toast.success('Account created successfully!');
    return data;
  },

  async logout() {
    try {
      await API.post('/auth/logout', {});
    } catch { /* ignore */ }
    this.user = null;
    this.token = null;
    localStorage.removeItem('br_token');
    window.location.href = '/';
  },

  async refreshToken() {
    try {
      const data = await API.post('/auth/refresh', {});
      this.token = data.token;
      localStorage.setItem('br_token', data.token);
      return data;
    } catch {
      this.logout();
    }
  },

  async getProfile() {
    const data = await API.get('/auth/profile');
    this.user = data.user || data;
    return this.user;
  },

  isAuthenticated() {
    return !!this.token && !!this.user;
  },

  hasRole(role) {
    return this.user && this.user.role === role;
  },

  _init() {
    this.token = localStorage.getItem('br_token');
    if (this.token) {
      this.getProfile().catch(() => {});
    }
  },
};

// ============================================
// Cart Module
// ============================================
const Cart = {
  items: [],
  count: 0,
  total: 0,

  async load() {
    try {
      if (!Auth.isAuthenticated()) {
        const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
        this.items = local;
        this.count = local.reduce((s, i) => s + i.quantity, 0);
        this.total = local.reduce((s, i) => s + i.price * i.quantity, 0);
        this._updateUI();
        return;
      }
      const data = await API.get('/cart');
      this.items = data.items || [];
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.items.reduce((s, i) => s + (i.price || i.product?.price || 0) * i.quantity, 0);
      this._updateUI();
    } catch { /* silent */ }
  },

  async addItem(productId, quantity = 1, variantId = null) {
    if (!Auth.isAuthenticated()) {
      const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      const existing = local.find(i => i.productId === productId && i.variantId === variantId);
      if (existing) {
        existing.quantity += quantity;
      } else {
        let productInfo = { price: 0, name: 'Product', image: '' };
        try {
          const pData = await API.get(`/products/${productId}`);
          const p = pData.data || pData.product || pData;
          productInfo = { price: p.price || p.sellingPrice || 0, name: p.name || 'Product', image: (p.images && p.images[0]) || p.thumbnail || p.image || '' };
        } catch { /* use defaults */ }
        local.push({ productId, variantId, quantity, ...productInfo });
      }
      localStorage.setItem('br_guest_cart', JSON.stringify(local));
      this.items = local;
      this.count = local.reduce((s, i) => s + i.quantity, 0);
      this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.success('Added to cart!');
      return;
    }
    try {
      const data = await API.post('/cart/items', { productId, quantity, variantId });
      this.items = data.items || this.items;
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.total;
      this._updateUI();
      Toast.success('Added to cart!');
    } catch (err) {
      Toast.error(err.message || 'Failed to add to cart');
    }
  },

  async updateItem(itemId, quantity) {
    if (!Auth.isAuthenticated()) {
      const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      if (quantity <= 0) {
        this.removeItem(itemId);
        return;
      }
      const item = local.find(i => i.productId === itemId || String(i.productId) === String(itemId));
      if (item) {
        item.quantity = quantity;
        localStorage.setItem('br_guest_cart', JSON.stringify(local));
        this.items = local;
        this.count = local.reduce((s, i) => s + i.quantity, 0);
        this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
        this._updateUI();
      }
      return;
    }
    try {
      const data = await API.put(`/cart/items/${itemId}`, { quantity });
      this.items = data.items || this.items;
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.total;
      this._updateUI();
    } catch (err) {
      Toast.error(err.message || 'Failed to update cart');
    }
  },

  async removeItem(itemId) {
    if (!Auth.isAuthenticated()) {
      let local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      local = local.filter(i => i.productId !== itemId && String(i.productId) !== String(itemId));
      localStorage.setItem('br_guest_cart', JSON.stringify(local));
      this.items = local;
      this.count = local.reduce((s, i) => s + i.quantity, 0);
      this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.info('Item removed from cart');
      return;
    }
    try {
      const data = await API.delete(`/cart/items/${itemId}`);
      this.items = data.items || this.items.filter(i => i.id !== itemId);
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.items.reduce((s, i) => (i.price || i.product?.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.info('Item removed from cart');
    } catch (err) {
      Toast.error(err.message || 'Failed to remove item');
    }
  },

  async clear() {
    if (!Auth.isAuthenticated()) {
      localStorage.removeItem('br_guest_cart');
      this.items = [];
      this.count = 0;
      this.total = 0;
      this._updateUI();
      return;
    }
    try {
      await API.delete('/cart');
      this.items = [];
      this.count = 0;
      this.total = 0;
      this._updateUI();
    } catch { /* silent */ }
  },

  async applyCoupon(code) {
    try {
      const data = await API.post('/cart/coupon', { code });
      this.total = data.total || this.total;
      this._updateUI();
      Toast.success('Coupon applied successfully!');
      return data;
    } catch (err) {
      Toast.error(err.message || 'Invalid coupon code');
      throw err;
    }
  },

  async removeCoupon() {
    try {
      const data = await API.delete('/cart/coupon');
      this.total = data.total || this.total;
      this._updateUI();
      Toast.info('Coupon removed');
    } catch { /* silent */ }
  },

  _updateUI() {
    this.updateBadge();
    this.renderSidebar();
  },

  updateBadge() {
    const badges = document.querySelectorAll('#cartBadge');
    badges.forEach(b => {
      if (this.count > 0) {
        b.textContent = this.count > 99 ? '99+' : this.count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
    const bottomBadges = document.querySelectorAll('.mobile-bottom-nav .bottom-nav-item[href*="cart"]');
    // handled by count
  },

  renderSidebar() {
    const body = document.getElementById('cartItemsList');
    const empty = document.getElementById('cartEmpty');
    const footer = document.getElementById('cartSidebarFooter');
    const countEl = document.getElementById('cartSidebarCount');
    const totalEl = document.getElementById('cartSidebarTotal');

    if (!body) return;

    if (this.items.length === 0) {
      if (empty) empty.style.display = 'flex';
      body.style.display = 'none';
      if (footer) footer.style.display = 'none';
      if (countEl) countEl.textContent = '0';
      return;
    }

    if (empty) empty.style.display = 'none';
    body.style.display = 'flex';
    if (footer) footer.style.display = 'block';
    if (countEl) countEl.textContent = this.count;
    if (totalEl) totalEl.textContent = Utils.formatCurrency(this.total);

    body.innerHTML = this.items.map(item => `
      <div class="cart-item" data-id="${item.id}">
        <div class="cart-item-image">
          <img src="${item.image || item.product?.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'}" alt="${item.name || item.product?.name || 'Product'}" loading="lazy">
        </div>
        <div class="cart-item-info">
          <div class="cart-item-title">${item.name || item.product?.name || 'Product'}</div>
          <div class="cart-item-variant">${item.variant || ''}</div>
          <div class="cart-item-bottom">
            <div class="quantity-selector">
              <button class="quantity-btn" onclick="Cart.updateItem('${item.id}', ${item.quantity - 1})" ${item.quantity <= 1 ? 'disabled' : ''}>&minus;</button>
              <span class="quantity-value">${item.quantity}</span>
              <button class="quantity-btn" onclick="Cart.updateItem('${item.id}', ${item.quantity + 1})">+</button>
            </div>
            <span style="font-weight:var(--weight-bold);font-size:var(--text-sm);">${Utils.formatCurrency(item.price * item.quantity)}</span>
          </div>
          <button class="cart-item-remove" onclick="Cart.removeItem('${item.id}')">Remove</button>
        </div>
      </div>
    `).join('');
  },
};

// ============================================
// Wishlist Module
// ============================================
const Wishlist = {
  items: [],

  async load() {
    try {
      if (!Auth.isAuthenticated()) {
        this.items = JSON.parse(localStorage.getItem('br_guest_wishlist') || '[]');
        this._updateUI();
        return;
      }
      const data = await API.get('/wishlist');
      this.items = data.items || data || [];
      this._updateUI();
    } catch { /* silent */ }
  },

  async add(productId) {
    if (!Auth.isAuthenticated()) {
      if (!this.items.includes(productId)) {
        this.items.push(productId);
        localStorage.setItem('br_guest_wishlist', JSON.stringify(this.items));
        this._updateUI();
        Toast.success('Added to wishlist!');
      }
      return;
    }
    try {
      await API.post('/wishlist', { productId });
      if (!this.items.find(i => (i.id || i) === productId)) {
        this.items.push(productId);
      }
      this._updateUI();
      Toast.success('Added to wishlist!');
    } catch (err) {
      Toast.error(err.message || 'Failed to add to wishlist');
    }
  },

  async remove(productId) {
    if (!Auth.isAuthenticated()) {
      this.items = this.items.filter(i => i !== productId);
      localStorage.setItem('br_guest_wishlist', JSON.stringify(this.items));
      this._updateUI();
      return;
    }
    try {
      await API.delete(`/wishlist/${productId}`);
      this.items = this.items.filter(i => (i.id || i) !== productId);
      this._updateUI();
      Toast.info('Removed from wishlist');
    } catch (err) {
      Toast.error(err.message || 'Failed to remove from wishlist');
    }
  },

  async check(productId) {
    if (!Auth.isAuthenticated()) {
      return this.items.includes(productId);
    }
    try {
      const data = await API.get(`/wishlist/check/${productId}`);
      return data.inWishlist || data.exists || false;
    } catch {
      return false;
    }
  },

  toggle(productId) {
    const isIn = this.items.some(i => (i.id || i) === productId);
    if (isIn) {
      this.remove(productId);
    } else {
      this.add(productId);
    }
    return !isIn;
  },

  _updateUI() {
    this.updateBadge();
    document.querySelectorAll('.wishlist-btn').forEach(btn => {
      const pid = btn.dataset.productId;
      const isWished = this.items.some(i => (i.id || i) == pid);
      btn.classList.toggle('active', isWished);
    });
  },

  updateBadge() {
    const badges = document.querySelectorAll('#wishlistBadge');
    const count = this.items.length;
    badges.forEach(b => {
      if (count > 0) {
        b.textContent = count > 99 ? '99+' : count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
  },
};

// ============================================
// Theme Module
// ============================================
const Theme = {
  current: 'light',

  init() {
    const saved = localStorage.getItem('br_theme');
    if (saved) {
      this.set(saved);
    } else {
      this.set('light');
    }
  },

  toggle() {
    this.set(this.current === 'dark' ? 'light' : 'dark');
  },

  set(theme) {
    this.current = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('br_theme', theme);
    const icon = document.getElementById('themeIcon');
    if (icon) {
      if (theme === 'dark') {
        icon.innerHTML = '<path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>';
      } else {
        icon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
      }
    }
  },
};

// ============================================
// Toast / Notification Module
// ============================================
const Toast = {
  show(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const icons = {
      success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
      error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
      warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
      info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || icons.info}</span>
      <div class="toast-content">
        <div class="toast-message">${message}</div>
      </div>
      <button class="toast-dismiss" aria-label="Dismiss" onclick="this.parentElement.classList.add('toast-exit'); setTimeout(() => this.parentElement.remove(), 200);">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.add('toast-exit');
        setTimeout(() => toast.remove(), 200);
      }
    }, duration);
  },

  success(message) { this.show(message, 'success'); },
  error(message) { this.show(message, 'error', 5000); },
  warning(message) { this.show(message, 'warning', 4000); },
  info(message) { this.show(message, 'info'); },
};

// ============================================
// Search Module
// ============================================
const Search = {
  debounceTimer: null,
  recentSearches: [],

  init() {
    this.recentSearches = JSON.parse(localStorage.getItem('br_recent_searches') || '[]');
    this._renderRecent();
    const input = document.getElementById('searchInput');
    if (input) {
      input.addEventListener('input', (e) => {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => this.search(e.target.value), 300);
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.value.trim()) {
          this.saveRecentSearch(e.target.value.trim());
          window.location.href = `/pages/products.html?q=${encodeURIComponent(e.target.value.trim())}`;
        }
        if (e.key === 'Escape') this.close();
      });
    }
  },

  open() {
    const overlay = document.getElementById('searchOverlay');
    const input = document.getElementById('searchInput');
    if (overlay) {
      overlay.classList.add('active');
      overlay.setAttribute('aria-hidden', 'false');
    }
    if (input) {
      setTimeout(() => input.focus(), 100);
    }
    document.body.style.overflow = 'hidden';
  },

  close() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.setAttribute('aria-hidden', 'true');
    }
    document.body.style.overflow = '';
  },

  async search(query) {
    const container = document.getElementById('searchResults');
    const sugBox = document.getElementById('searchSuggestions');
    if (!container || !sugBox) return;

    if (query.length < 2) {
      container.innerHTML = '';
      sugBox.style.display = query.length > 0 ? 'block' : 'none';
      return;
    }

    sugBox.style.display = 'block';
    container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">Searching...</div>';

    try {
      const data = await API.get(`/products/search?q=${encodeURIComponent(query)}&limit=6`);
      const products = data.products || data || [];
      if (products.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">No results found</div>';
        return;
      }
      container.innerHTML = products.map(p => `
        <a href="/pages/product.html?id=${p._id || p.id}" style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2);border-radius:var(--radius-sm);text-decoration:none;color:var(--text);transition:background 0.15s;" onmouseover="this.style.background='var(--glass-bg)'" onmouseout="this.style.background='transparent'">
          <img src="${p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'}" alt="" style="width:40px;height:40px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy">
          <div style="min-width:0;">
            <div style="font-size:var(--text-sm);font-weight:var(--weight-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</div>
            <div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">${Utils.formatCurrency(p.price)}</div>
          </div>
        </a>
      `).join('');
    } catch {
      container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">Search unavailable</div>';
    }
  },

  saveRecentSearch(query) {
    this.recentSearches = this.recentSearches.filter(s => s !== query);
    this.recentSearches.unshift(query);
    if (this.recentSearches.length > 8) this.recentSearches.pop();
    localStorage.setItem('br_recent_searches', JSON.stringify(this.recentSearches));
    this._renderRecent();
  },

  _renderRecent() {
    const container = document.getElementById('recentSearches');
    const list = document.getElementById('recentSearchList');
    if (!container || !list) return;

    if (this.recentSearches.length === 0) {
      container.style.display = 'none';
      return;
    }

    container.style.display = 'block';
    list.innerHTML = this.recentSearches.map(s => `
      <a href="/pages/products.html?q=${encodeURIComponent(s)}" class="tag">${s}</a>
    `).join('');
  },
};

// ============================================
// Animation Module (GSAP)
// ============================================
const Animations = {
  init() {
    if (typeof gsap === 'undefined') return;
    gsap.registerPlugin(ScrollTrigger);
    this.heroAnimation();
    this.scrollAnimations();
  },

  heroAnimation() {
    if (typeof gsap === 'undefined') return;
    const tl = gsap.timeline({ delay: 0.2 });
    const content = document.querySelector('.hero-section-content');
    if (!content) return;

    const title = content.querySelector('.hero-3d-title');
    const subtitle = content.querySelector('.hero-subtitle');
    const actions = content.querySelector('.hero-actions');
    const stats = content.querySelector('.hero-stats');

    if (title) tl.from(title, { y: 40, opacity: 0, duration: 0.8, ease: 'power3.out' });
    if (subtitle) tl.from(subtitle, { y: 30, opacity: 0, duration: 0.7, ease: 'power3.out' }, '-=0.4');
    if (actions) tl.from(actions, { y: 20, opacity: 0, duration: 0.6, ease: 'power3.out' }, '-=0.3');
    if (stats) tl.from(stats, { y: 20, opacity: 0, duration: 0.6, ease: 'power3.out' }, '-=0.2');

    const counters = document.querySelectorAll('[data-counter]');
    counters.forEach(el => {
      const target = parseInt(el.dataset.counter, 10);
      this.counter(el, target);
    });

    const floats = document.querySelectorAll('.hero-floating');
    floats.forEach((el, i) => {
      tl.from(el, { scale: 0, opacity: 0, duration: 0.5, ease: 'back.out(1.7)' }, `-=${0.3 - i * 0.05}`);
    });
  },

  scrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

    gsap.utils.toArray('.section-header').forEach(el => {
      gsap.from(el.children, {
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.6, stagger: 0.15, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.product-grid').forEach(grid => {
      gsap.from(grid.children, {
        scrollTrigger: { trigger: grid, start: 'top 85%', toggleActions: 'play none none none' },
        y: 40, opacity: 0, duration: 0.5, stagger: 0.08, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.category-grid').forEach(grid => {
      gsap.from(grid.children, {
        scrollTrigger: { trigger: grid, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.5, stagger: 0.06, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.video-banner').forEach(el => {
      gsap.from(el, {
        scrollTrigger: { trigger: el, start: 'top 80%', toggleActions: 'play none none none' },
        scale: 0.95, opacity: 0, duration: 0.8, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.newsletter-card').forEach(el => {
      gsap.from(el, {
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.7, ease: 'power3.out',
      });
    });
  },

  counter(element, target) {
    if (typeof gsap === 'undefined') {
      element.textContent = target >= 1000 ? `${(target / 1000).toFixed(target >= 10000 ? 0 : 1)}K+` : `${target}+`;
      return;
    }
    const obj = { val: 0 };
    gsap.to(obj, {
      val: target,
      duration: 2,
      delay: 0.5,
      ease: 'power2.out',
      onUpdate() {
        const v = Math.round(obj.val);
        element.textContent = v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 0 : 1)}K+` : `${v}+`;
      },
    });
  },

  staggerReveal(selector) {
    if (typeof gsap === 'undefined') return;
    gsap.from(selector, {
      scrollTrigger: { trigger: selector, start: 'top 85%' },
      y: 30, opacity: 0, duration: 0.5, stagger: 0.1, ease: 'power3.out',
    });
  },
};

// ============================================
// Three.js 3D Module
// ============================================
const Product3D = {
  scene: null,
  camera: null,
  renderer: null,
  mesh: null,
  animId: null,

  init(containerId) {
    if (typeof THREE === 'undefined') return;
    const container = document.getElementById(containerId);
    if (!container || container.clientWidth === 0) return;

    try {
      this.scene = new THREE.Scene();
      this.camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
      this.camera.position.z = 5;

      this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      this.renderer.setSize(container.clientWidth, container.clientHeight);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(this.renderer.domElement);

      const geo = new THREE.IcosahedronGeometry(1.5, 1);
      const mat = new THREE.MeshPhongMaterial({
        color: 0xdc143c,
        wireframe: true,
        transparent: true,
        opacity: 0.6,
      });
      this.mesh = new THREE.Mesh(geo, mat);
      this.scene.add(this.mesh);

      const geo2 = new THREE.IcosahedronGeometry(1.8, 1);
      const mat2 = new THREE.MeshPhongMaterial({
        color: 0xd4af37,
        wireframe: true,
        transparent: true,
        opacity: 0.3,
      });
      const mesh2 = new THREE.Mesh(geo2, mat2);
      this.scene.add(mesh2);

      const light = new THREE.DirectionalLight(0xffffff, 1);
      light.position.set(5, 5, 5);
      this.scene.add(light);

      const ambient = new THREE.AmbientLight(0x404040, 0.5);
      this.scene.add(ambient);

      this._animate(mesh2);

      window.addEventListener('resize', () => {
        if (!container.clientWidth) return;
        this.camera.aspect = container.clientWidth / container.clientHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(container.clientWidth, container.clientHeight);
      });
    } catch { /* Three.js not available or WebGL not supported */ }
  },

  _animate(mesh2) {
    this.animId = requestAnimationFrame(() => this._animate(mesh2));
    if (this.mesh) {
      this.mesh.rotation.x += 0.003;
      this.mesh.rotation.y += 0.005;
    }
    if (mesh2) {
      mesh2.rotation.x -= 0.002;
      mesh2.rotation.y -= 0.003;
    }
    this.renderer.render(this.scene, this.camera);
  },

  destroy() {
    if (this.animId) cancelAnimationFrame(this.animId);
    if (this.renderer) this.renderer.dispose();
  },
};

// ============================================
// Utility Functions
// ============================================
const Utils = {
  formatCurrency(amount) {
    if (amount == null || isNaN(amount)) return '৳0';
    return '৳' + Number(amount).toLocaleString('en-BD', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  },

  formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  },

  timeAgo(date) {
    const seconds = Math.floor((Date.now() - new Date(date)) / 1000);
    const intervals = [
      { label: 'year', seconds: 31536000 },
      { label: 'month', seconds: 2592000 },
      { label: 'week', seconds: 604800 },
      { label: 'day', seconds: 86400 },
      { label: 'hour', seconds: 3600 },
      { label: 'minute', seconds: 60 },
    ];
    for (const i of intervals) {
      const count = Math.floor(seconds / i.seconds);
      if (count >= 1) return `${count} ${i.label}${count > 1 ? 's' : ''} ago`;
    }
    return 'Just now';
  },

  debounce(fn, delay) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  },

  throttle(fn, limit) {
    let inThrottle;
    return (...args) => {
      if (!inThrottle) {
        fn(...args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  },

  slugify(text) {
    return text.toString().toLowerCase().trim()
      .replace(/[\s_]+/g, '-')
      .replace(/[^\w\-]+/g, '')
      .replace(/\-\-+/g, '-')
      .replace(/^-+/, '')
      .replace(/-+$/, '');
  },

  truncate(text, length = 80) {
    if (!text || text.length <= length) return text;
    return text.substring(0, length).trim() + '...';
  },

  getQueryParams() {
    return Object.fromEntries(new URLSearchParams(window.location.search));
  },

  setQueryParam(key, value) {
    const url = new URL(window.location);
    if (value == null || value === '') {
      url.searchParams.delete(key);
    } else {
      url.searchParams.set(key, value);
    }
    window.history.replaceState({}, '', url);
  },

  scrollTo(element) {
    if (typeof element === 'string') element = document.querySelector(element);
    if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  },

  lazyLoad(images) {
    if ('IntersectionObserver' in window && images.length) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
            observer.unobserve(img);
          }
        });
      }, { rootMargin: '200px' });
      images.forEach(img => observer.observe(img));
    } else {
      images.forEach(img => {
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
      });
    }
  },

  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      Toast.success('Copied to clipboard!');
    } catch {
      Toast.error('Failed to copy');
    }
  },

  generateStars(rating) {
    const full = Math.floor(rating);
    const half = rating % 1 >= 0.5 ? 1 : 0;
    const empty = 5 - full - half;
    let html = '';
    for (let i = 0; i < full; i++) html += '<span class="star filled">&#9733;</span>';
    if (half) html += '<span class="star half">&#9733;</span>';
    for (let i = 0; i < empty; i++) html += '<span class="star">&#9733;</span>';
    return html;
  },

  getOS() {
    const u = navigator.userAgent;
    if (/Windows/i.test(u)) return 'Windows';
    if (/Mac/i.test(u)) return 'macOS';
    if (/Linux/i.test(u)) return 'Linux';
    if (/Android/i.test(u)) return 'Android';
    if (/iPhone|iPad|iPod/i.test(u)) return 'iOS';
    return 'Unknown';
  },

  getBrowser() {
    const u = navigator.userAgent;
    if (u.includes('Firefox')) return 'Firefox';
    if (u.includes('Edg')) return 'Edge';
    if (u.includes('Chrome')) return 'Chrome';
    if (u.includes('Safari')) return 'Safari';
    return 'Unknown';
  },
};

// ============================================
// Product Card Generator
// ============================================
function createProductCard(product) {
  const p = product;
  const id = p._id || p.id;
  const image = p.images?.[0]?.url || p.images?.[0] || p.image || p.thumbnail || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
  const name = p.name || 'Untitled Product';
  const brand = p.brand || '';
  const category = p.category?.name || p.category || '';
  const price = p.price || 0;
  const originalPrice = p.originalPrice || p.compareAtPrice || p.mrp || 0;
  const rating = p.rating || p.averageRating || 4.5;
  const reviewCount = p.reviewCount || p.numReviews || 0;
  const discount = originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;
  const isWished = Wishlist.items.some(i => (i.id || i) == id);
  const stockQty = p.stock_quantity !== undefined ? p.stock_quantity : p.stockQuantity;
  const outOfStock = stockQty !== undefined && stockQty <= 0;

  return `
    <div class="product-card card-hover" data-product-id="${id}">
      <div class="product-card-image">
        <a href="/pages/product.html?id=${id}" aria-label="View ${name}">
          <img src="${image}" alt="${name}" loading="lazy"${outOfStock ? ' style="opacity:0.6;"' : ''}>
        </a>
        ${outOfStock ? '<div class="product-card-stockout-badge"><span>Stock Out</span></div>' : ''}
        ${!outOfStock && discount > 0 ? `<div class="product-card-badges"><span class="badge badge-danger">-${discount}%</span></div>` : ''}
        <button class="wishlist-btn product-card-wishlist ${isWished ? 'active' : ''}" data-product-id="${id}" onclick="event.preventDefault(); Wishlist.toggle('${id}');" aria-label="Toggle wishlist">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="${isWished ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        </button>
        <div class="product-card-quick-actions">
          <button class="btn btn-sm btn-glass" onclick="event.preventDefault(); window.location.href='/pages/product.html?id=${id}';" style="flex:1;">Quick View</button>
          ${outOfStock ? `<button class="btn btn-sm" disabled style="flex:1;background:var(--muted,#e2e8f0);color:var(--text-muted,#94a3b8);cursor:not-allowed;border:none;">Out of Stock</button>` : `<button class="btn btn-sm btn-primary" onclick="event.preventDefault(); Cart.addItem('${id}');" style="flex:1;">Add to Cart</button>`}
        </div>
      </div>
      <div class="product-card-body">
        ${category ? `<div class="product-card-category">${category}</div>` : ''}
        <a href="/pages/product.html?id=${id}" class="product-card-title" style="text-decoration:none;color:inherit;">${name}</a>
        ${brand ? `<div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">${brand}</div>` : ''}
        <div class="product-card-rating">
          <div class="star-rating star-rating-sm">${Utils.generateStars(rating)}</div>
          <span class="product-card-rating-count">(${reviewCount})</span>
        </div>
      </div>
      <div class="product-card-footer">
        <div class="product-card-price">
          <span class="product-card-price-current">${Utils.formatCurrency(price)}</span>
          ${discount > 0 ? `<span class="product-card-price-original">${Utils.formatCurrency(originalPrice)}</span>` : ''}
        </div>
        ${outOfStock ? `<button class="product-card-add-btn" disabled style="opacity:0.4;cursor:not-allowed;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg></button>` : `<button class="product-card-add-btn" onclick="event.preventDefault(); Cart.addItem('${id}');" aria-label="Add to cart"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`}
      </div>
    </div>
  `;
}

// ============================================
// Loading Screen
// ============================================
function initLoadingScreen() {
  const bar = document.getElementById('loadingBar');
  const percent = document.getElementById('loadingPercent');
  const screen = document.getElementById('loading-screen');
  if (!bar || !percent || !screen) return;

  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 15 + 5;
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      setTimeout(() => {
        screen.classList.add('hidden');
        document.body.style.overflow = '';
      }, 300);
    }
    bar.style.width = progress + '%';
    percent.textContent = Math.round(progress) + '%';
  }, 100);

  setTimeout(() => {
    progress = 100;
    bar.style.width = '100%';
    percent.textContent = '100%';
    clearInterval(interval);
    setTimeout(() => {
      screen.classList.add('hidden');
      document.body.style.overflow = '';
    }, 200);
  }, 2500);
}

// ============================================
// Navbar
// ============================================
function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  const onScroll = Utils.throttle(() => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }, 100);

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Mobile menu
  const mobileToggle = document.getElementById('mobileMenuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileOverlay = document.getElementById('mobileMenuOverlay');
  const mobileClose = document.getElementById('mobileMenuClose');

  function openMobileMenu() {
    mobileMenu?.classList.add('active');
    mobileOverlay?.classList.add('active');
    mobileToggle?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileMenu() {
    mobileMenu?.classList.remove('active');
    mobileOverlay?.classList.remove('active');
    mobileToggle?.classList.remove('active');
    document.body.style.overflow = '';
  }

  mobileToggle?.addEventListener('click', () => {
    if (mobileMenu?.classList.contains('active')) {
      closeMobileMenu();
    } else {
      openMobileMenu();
    }
  });

  mobileClose?.addEventListener('click', closeMobileMenu);
  mobileOverlay?.addEventListener('click', closeMobileMenu);
}

// ============================================
// Search Overlay
// ============================================
function initSearch() {
  document.getElementById('searchToggle')?.addEventListener('click', () => Search.open());
  document.getElementById('searchClose')?.addEventListener('click', () => Search.close());
  document.getElementById('mobileSearchBtn')?.addEventListener('click', () => {
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileOverlay = document.getElementById('mobileMenuOverlay');
    const mobileToggle = document.getElementById('mobileMenuToggle');
    mobileMenu?.classList.remove('active');
    mobileOverlay?.classList.remove('active');
    mobileToggle?.classList.remove('active');
    document.body.style.overflow = '';
    Search.open();
  });

  document.getElementById('searchOverlay')?.addEventListener('click', (e) => {
    if (e.target.id === 'searchOverlay') Search.close();
  });
}

// ============================================
// Cart Sidebar
// ============================================
function initCartSidebar() {
  const toggle = document.getElementById('cartToggle');
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartSidebarOverlay');
  const close = document.getElementById('cartSidebarClose');

  function openCart() {
    sidebar?.classList.add('active');
    overlay?.classList.add('active');
    document.body.style.overflow = 'hidden';
    Cart.renderSidebar();
  }

  function closeCart() {
    sidebar?.classList.remove('active');
    overlay?.classList.remove('active');
    document.body.style.overflow = '';
  }

  toggle?.addEventListener('click', openCart);
  close?.addEventListener('click', closeCart);
  overlay?.addEventListener('click', closeCart);
}

// ============================================
// Theme Toggle
// ============================================
function initThemeToggle() {
  document.getElementById('themeToggle')?.addEventListener('click', () => Theme.toggle());
}

// ============================================
// Swiper Initialization
// ============================================
function initSwipers() {
  if (typeof Swiper === 'undefined') return;

  new Swiper('.featured-swiper', {
    slidesPerView: 1.2,
    spaceBetween: 16,
    centeredSlides: false,
    grabCursor: true,
    navigation: { nextEl: '.featured-swiper .swiper-button-next', prevEl: '.featured-swiper .swiper-button-prev' },
    breakpoints: {
      640: { slidesPerView: 2.2, spaceBetween: 20 },
      1024: { slidesPerView: 3.2, spaceBetween: 24 },
      1280: { slidesPerView: 4, spaceBetween: 24 },
    },
  });

  new Swiper('.flash-sale-swiper', {
    slidesPerView: 1.5,
    spaceBetween: 16,
    grabCursor: true,
    navigation: { nextEl: '.flash-sale-swiper .swiper-button-next', prevEl: '.flash-sale-swiper .swiper-button-prev' },
    breakpoints: {
      640: { slidesPerView: 2.5, spaceBetween: 20 },
      1024: { slidesPerView: 3.5, spaceBetween: 24 },
      1280: { slidesPerView: 4.5, spaceBetween: 24 },
    },
  });

  new Swiper('.reviews-swiper', {
    slidesPerView: 1,
    spaceBetween: 24,
    grabCursor: true,
    pagination: { el: '.reviews-swiper .swiper-pagination', clickable: true },
    autoplay: { delay: 5000, disableOnInteraction: false },
    breakpoints: {
      640: { slidesPerView: 2 },
      1024: { slidesPerView: 3 },
    },
  });
}

// ============================================
// Countdown Timer
// ============================================
function initCountdown(targetDate) {
  const daysEl = document.getElementById('cdDays');
  const hoursEl = document.getElementById('cdHours');
  const minsEl = document.getElementById('cdMins');
  const secsEl = document.getElementById('cdSecs');
  if (!daysEl) return;

  function update() {
    const now = Date.now();
    let diff = targetDate - now;
    if (diff <= 0) {
      diff = 0;
      // Reset for next 24h
      targetDate = Date.now() + 24 * 60 * 60 * 1000;
    }
    const d = Math.floor(diff / (1000 * 60 * 60 * 24));
    const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const s = Math.floor((diff % (1000 * 60)) / 1000);

    daysEl.textContent = String(d).padStart(2, '0');
    hoursEl.textContent = String(h).padStart(2, '0');
    minsEl.textContent = String(m).padStart(2, '0');
    secsEl.textContent = String(s).padStart(2, '0');
  }

  update();
  setInterval(update, 1000);
}

// ============================================
// Data Loaders
// ============================================
async function loadFeaturedProducts() {
  const container = document.getElementById('featuredProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?featured=true&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => `<div class="swiper-slide">${createProductCard(p)}</div>`).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadNewArrivals() {
  const container = document.getElementById('newArrivals');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=newest&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadTrending() {
  const container = document.getElementById('trendingProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=trending&limit=4');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(4);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(4);
  }
}

async function loadBestSellers() {
  const container = document.getElementById('bestSellerProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=bestselling&limit=4');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(4);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(4);
  }
}

async function loadFlashSales() {
  const container = document.getElementById('flashSaleProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?flashSale=true&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => `<div class="swiper-slide">${createProductCard(p)}</div>`).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadCategories() {
  const container = document.getElementById('categoryGrid');
  if (!container) return;
  try {
    const res = await API.get('/categories');
    const cats = res.data?.categories || res.categories || res.data || [];
    if (cats.length === 0) {
      container.innerHTML = _placeholderCategories();
      return;
    }
    container.innerHTML = cats.slice(0, 8).map(c => `
      <a href="/pages/categories.html?cat=${c.slug || Utils.slugify(c.name)}" class="category-banner card-hover" style="text-decoration:none;">
        <div class="category-banner-bg"><img src="${c.image || 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=600'}" alt="${c.name}" loading="lazy"></div>
        <div class="category-banner-overlay"></div>
        <div class="category-banner-content">
          <div class="category-banner-title">${c.name}</div>
          <div class="category-banner-count">${c.product_count || c.productCount || c.count || 0} Products</div>
        </div>
      </a>
    `).join('');
  } catch {
    container.innerHTML = _placeholderCategories();
  }
}

async function loadReviews() {
  const container = document.getElementById('reviewsSlider');
  if (!container) return;
  try {
    const res = await API.get('/reviews?limit=6&sort=recent');
    const reviews = res.data?.reviews || res.reviews || res.data || [];
    if (reviews.length === 0) {
      container.innerHTML = _placeholderReviews();
      return;
    }
    container.innerHTML = reviews.map(r => `
      <div class="swiper-slide">
        <div class="review-card">
          <div class="review-card-header">
            <div class="avatar avatar-sm">${(r.user?.name || r.author || 'U')[0].toUpperCase()}</div>
            <div>
              <div class="review-card-name">${r.user?.name || r.author || 'Customer'}</div>
              <div class="review-card-date">${Utils.timeAgo(r.createdAt || r.date)}</div>
            </div>
          </div>
          <div class="star-rating star-rating-sm" style="margin-bottom:var(--space-3);">${Utils.generateStars(r.rating || 5)}</div>
          <p class="review-card-text">${r.comment || r.text || r.review || ''}</p>
          ${r.verified ? '<span class="review-card-verified">&#10003; Verified Purchase</span>' : ''}
        </div>
      </div>
    `).join('');
  } catch {
    container.innerHTML = _placeholderReviews();
  }
}

// ============================================
// Placeholder Data (when API is unavailable)
// ============================================
function _placeholderProducts(count) {
  const names = ['Jamdani Saree', 'Terracotta Vase', 'Silk Scarf', 'Brass Necklace', 'Nakshi Kantha', 'Bamboo Basket', 'Muslin Fabric', 'Ceramic Bowl'];
  const cats = ['Fashion', 'Handicraft', 'Textiles', 'Jewelry', 'Home', 'Art', 'Fashion', 'Kitchen'];
  const prices = [4500, 2200, 1800, 3500, 5200, 1200, 8500, 950];
  let html = '';
  for (let i = 0; i < count; i++) {
    const idx = i % names.length;
    const p = { _id: `demo-${i}`, name: names[idx], category: { name: cats[idx] }, price: prices[idx], originalPrice: prices[idx] * 1.3, rating: 4 + Math.random(), reviewCount: Math.floor(Math.random() * 200) + 10, images: [`https://placehold.co/400x400/1a1a1a/dc143c?text=${encodeURIComponent(names[idx])}`] };
    html += `<div class="swiper-slide">${createProductCard(p)}</div>`;
  }
  return html;
}

function _placeholderCategories() {
  const cats = [
    { name: 'Fashion', slug: 'fashion', icon: '&#128085;', count: 120, color: '#dc143c' },
    { name: 'Home & Living', slug: 'home', icon: '&#127968;', count: 85, color: '#d4af37' },
    { name: 'Handicrafts', slug: 'handicraft', icon: '&#127912;', count: 200, color: '#10b981' },
    { name: 'Textiles', slug: 'textiles', icon: '&#129525;', count: 95, color: '#3b82f6' },
    { name: 'Jewelry', slug: 'jewelry', icon: '&#128141;', count: 60, color: '#f59e0b' },
    { name: 'Food & Spices', slug: 'food', icon: '&#127843;', count: 45, color: '#8b5cf6' },
    { name: 'Art & Paintings', slug: 'art', icon: '&#127912;', count: 70, color: '#f43f5e' },
    { name: 'Wellness', slug: 'wellness', icon: '&#127807;', count: 35, color: '#14b8a6' },
  ];
  return cats.map(c => `
    <a href="/pages/categories.html?cat=${c.slug}" class="category-banner card-hover" style="text-decoration:none;background:${c.color};">
      <div class="category-banner-overlay" style="background:linear-gradient(135deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.1) 100%);"></div>
      <div class="category-banner-content" style="color:#fff;">
        <div style="font-size:32px;margin-bottom:var(--space-2);">${c.icon}</div>
        <div class="category-banner-title" style="color:#fff;">${c.name}</div>
        <div class="category-banner-count">${c.count} Products</div>
      </div>
    </a>
  `).join('');
}

function _placeholderReviews() {
  const reviews = [
    { name: 'Fatima K.', rating: 5, text: 'Absolutely stunning Jamdani saree! The craftsmanship is incredible and the delivery was faster than expected.', verified: true },
    { name: 'Rahman A.', rating: 5, text: 'Best quality handicrafts I have found online. The terracotta pieces are museum quality. Highly recommend!', verified: true },
    { name: 'Sara M.', rating: 4, text: 'Beautiful silk scarf, exactly as pictured. The packaging was also very premium. Will order again.', verified: true },
    { name: 'Imran H.', rating: 5, text: 'Perfect gift for my mother. She loved the Nakshi Kantha. The attention to detail is remarkable.', verified: true },
    { name: 'Priya D.', rating: 5, text: 'I have been buying from Bangalirhaat for months now. Consistent quality and excellent customer service.', verified: true },
    { name: 'Zahid R.', rating: 4, text: 'Great collection of authentic Bangladeshi products. The bamboo basket is both functional and beautiful.', verified: true },
  ];
  return reviews.map(r => `
    <div class="swiper-slide">
      <div class="review-card">
        <div class="review-card-header">
          <div class="avatar avatar-sm">${r.name[0]}</div>
          <div>
            <div class="review-card-name">${r.name}</div>
            <div class="review-card-date">2 weeks ago</div>
          </div>
        </div>
        <div class="star-rating star-rating-sm" style="margin-bottom:var(--space-3);">${Utils.generateStars(r.rating)}</div>
        <p class="review-card-text">${r.text}</p>
        ${r.verified ? '<span class="review-card-verified">&#10003; Verified Purchase</span>' : ''}
      </div>
    </div>
  `).join('');
}

// ============================================
// Newsletter Form
// ============================================
function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = form.querySelector('input[type="email"]')?.value;
    if (!email) return;
    try {
      await API.post('/newsletter/subscribe', { email });
      Toast.success('Subscribed successfully! Welcome to the community.');
      form.reset();
    } catch {
      Toast.success('Thank you for subscribing!');
      form.reset();
    }
  });
}

// ============================================
// Keyboard Shortcuts
// ============================================
function initKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      Search.open();
    }
    if (e.key === 'Escape') {
      Search.close();
      const cartSidebar = document.getElementById('cartSidebar');
      if (cartSidebar?.classList.contains('active')) {
        cartSidebar.classList.remove('active');
        document.getElementById('cartSidebarOverlay')?.classList.remove('active');
        document.body.style.overflow = '';
      }
    }
  });
}

// ============================================
// Page Router
// ============================================
const Page = {
  init() {
    const path = window.location.pathname;
    if (path === '/' || path === '/index.html') {
      this.homepage();
    }
  },

  homepage() {
    loadFeaturedProducts();
    loadNewArrivals();
    loadTrending();
    loadBestSellers();
    loadFlashSales();
    loadCategories();
    loadReviews();

    setTimeout(() => {
      initSwipers();
      Animations.init();
      Product3D.init('hero3d');
    }, 100);

    // Flash sale countdown - 24h from now
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);
    initCountdown(endOfDay.getTime());
  },
};

// ============================================
// Initialize Everything
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  // Lock scroll during load
  document.body.style.overflow = 'hidden';

  // Auth
  Auth._init();

  // Theme
  Theme.init();

  // Loading screen
  initLoadingScreen();

  // Core UI
  initNavbar();
  initSearch();
  initCartSidebar();
  initThemeToggle();
  initKeyboardShortcuts();
  initNewsletter();

  // Feature styles
  injectFeatureStyles();

  // Data
  Cart.load().catch(() => {});
  Wishlist.load().catch(() => {});

  // Page routing
  Page.init();

  // Recently Viewed
  const rvContainer = document.getElementById('recentlyViewed');
  if (rvContainer) renderRecentlyViewed(rvContainer);

  // Voice Search
  VoiceSearch.init();

  // AI Search
  const searchInput = document.getElementById('searchInput');
  if (searchInput) AISearch.init(searchInput);

  // Floating Buttons
  FloatingButtons.init();

  // Lazy load images
  Utils.lazyLoad(document.querySelectorAll('img[data-src]'));

  // Unlock scroll after a beat (in case loading screen is slow)
  setTimeout(() => {
    if (!document.getElementById('loading-screen')?.classList.contains('hidden')) {
      document.body.style.overflow = '';
    }
  }, 3000);
});

// ============================================
// 360° Product Viewer
// ============================================
const Product360Viewer = {
  images: [],
  currentIndex: 0,
  isDragging: false,
  startX: 0,
  container: null,
  imageEl: null,
  dotsContainer: null,
  autoPlayTimer: null,
  handlers: {},

  init(containerId, imageUrls) {
    if (!imageUrls || imageUrls.length === 0) return;
    this.images = imageUrls;
    this.currentIndex = 0;
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.container.innerHTML = '';
    this.container.style.position = 'relative';
    this.container.style.overflow = 'hidden';
    this.container.style.userSelect = 'none';
    this.container.style.cursor = 'grab';

    const wrapper = document.createElement('div');
    wrapper.style.position = 'relative';
    wrapper.style.width = '100%';
    wrapper.style.height = '100%';

    this.imageEl = document.createElement('img');
    this.imageEl.src = this.images[0];
    this.imageEl.alt = 'Product 360 view';
    this.imageEl.style.width = '100%';
    this.imageEl.style.height = '100%';
    this.imageEl.style.objectFit = 'cover';
    this.imageEl.draggable = false;
    wrapper.appendChild(this.imageEl);

    const hint = document.createElement('div');
    hint.textContent = 'Drag to rotate';
    hint.style.cssText = 'position:absolute;bottom:12px;left:50%;transform:translateX(-50%);font-size:12px;color:rgba(255,255,255,0.7);background:rgba(0,0,0,0.5);padding:4px 12px;border-radius:20px;pointer-events:none;transition:opacity 0.3s;';
    wrapper.appendChild(hint);
    setTimeout(() => { if (hint.parentElement) hint.style.opacity = '0'; }, 3000);

    this.container.appendChild(wrapper);

    this.dotsContainer = document.createElement('div');
    this.dotsContainer.style.cssText = 'position:absolute;bottom:8px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:2;';
    const dotCount = Math.min(this.images.length, 12);
    const step = Math.max(1, Math.floor(this.images.length / dotCount));
    for (let i = 0; i < dotCount; i++) {
      const dot = document.createElement('button');
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;border:none;background:rgba(255,255,255,0.4);cursor:pointer;transition:all 0.2s;padding:0;';
      dot.setAttribute('aria-label', `View ${i * step + 1}`);
      dot.addEventListener('click', () => this.goToImage(i * step));
      this.dotsContainer.appendChild(dot);
    }
    this.container.appendChild(this.dotsContainer);
    this._updateDots();

    this.handlers.start = (e) => this.onDragStart(e);
    this.handlers.move = (e) => this.onDragMove(e);
    this.handlers.end = () => this.onDragEnd();

    this.container.addEventListener('mousedown', this.handlers.start);
    this.container.addEventListener('touchstart', this.handlers.start, { passive: true });
    document.addEventListener('mousemove', this.handlers.move);
    document.addEventListener('touchmove', this.handlers.move, { passive: true });
    document.addEventListener('mouseup', this.handlers.end);
    document.addEventListener('touchend', this.handlers.end);
    this.container.addEventListener('mouseenter', () => this.autoPlay());
    this.container.addEventListener('mouseleave', () => this.stopAutoPlay());
  },

  onDragStart(e) {
    this.isDragging = true;
    this.startX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
    this.container.style.cursor = 'grabbing';
    this.stopAutoPlay();
  },

  onDragMove(e) {
    if (!this.isDragging) return;
    const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
    const diff = clientX - this.startX;
    if (Math.abs(diff) > 20) {
      const direction = diff > 0 ? -1 : 1;
      const newIndex = (this.currentIndex + direction + this.images.length) % this.images.length;
      this.goToImage(newIndex);
      this.startX = clientX;
    }
  },

  onDragEnd() {
    this.isDragging = false;
    if (this.container) this.container.style.cursor = 'grab';
  },

  goToImage(index) {
    this.currentIndex = index;
    if (this.imageEl) this.imageEl.src = this.images[index];
    this._updateDots();
  },

  _updateDots() {
    if (!this.dotsContainer) return;
    const dots = this.dotsContainer.children;
    const total = this.images.length;
    const dotCount = dots.length;
    for (let i = 0; i < dotCount; i++) {
      const mappedIndex = Math.round((i / dotCount) * total) % total;
      const isActive = Math.abs(this.currentIndex - mappedIndex) < total / dotCount / 2 || (this.currentIndex === total - 1 && i === dotCount - 1);
      dots[i].style.background = isActive ? '#fff' : 'rgba(255,255,255,0.4)';
      dots[i].style.transform = isActive ? 'scale(1.3)' : 'scale(1)';
    }
  },

  autoPlay() {
    this.stopAutoPlay();
    this.autoPlayTimer = setInterval(() => {
      this.goToImage((this.currentIndex + 1) % this.images.length);
    }, 150);
  },

  stopAutoPlay() {
    if (this.autoPlayTimer) {
      clearInterval(this.autoPlayTimer);
      this.autoPlayTimer = null;
    }
  },

  destroy() {
    this.stopAutoPlay();
    if (this.container) {
      this.container.removeEventListener('mousedown', this.handlers.start);
      this.container.removeEventListener('touchstart', this.handlers.start);
    }
    document.removeEventListener('mousemove', this.handlers.move);
    document.removeEventListener('touchmove', this.handlers.move);
    document.removeEventListener('mouseup', this.handlers.end);
    document.removeEventListener('touchend', this.handlers.end);
    if (this.container) this.container.innerHTML = '';
    this.images = [];
    this.currentIndex = 0;
  },
};

// ============================================
// Image Zoom (Magnifier)
// ============================================
const ImageZoom = {
  lens: null,
  container: null,
  image: null,
  zoomLevel: 2,
  lensSize: 150,
  handlers: {},

  init(container, options = {}) {
    if (typeof container === 'string') container = document.querySelector(container);
    if (!container) return;

    this.container = container;
    this.image = container.querySelector('img');
    if (!this.image) return;

    this.zoomLevel = options.zoomLevel || 2;
    this.lensSize = options.lensSize || 150;

    container.style.position = 'relative';
    container.style.overflow = 'hidden';
    container.style.cursor = 'crosshair';

    this.lens = document.createElement('div');
    this.lens.style.cssText = `position:absolute;width:${this.lensSize}px;height:${this.lensSize}px;border-radius:50%;border:2px solid var(--primary, #dc143c);background-repeat:no-repeat;pointer-events:none;z-index:10;display:none;transform:translate(-50%,-50%);box-shadow:0 0 0 1px rgba(0,0,0,0.2);`;
    container.appendChild(this.lens);

    this.handlers.move = (e) => this.moveLens(e);
    this.handlers.enter = () => { this.lens.style.display = 'block'; };
    this.handlers.leave = () => { this.lens.style.display = 'none'; };

    container.addEventListener('mouseenter', this.handlers.enter);
    container.addEventListener('mouseleave', this.handlers.leave);
    container.addEventListener('mousemove', this.handlers.move);

    let touchStartDist = 0;
    this.handlers.touchStart = (e) => {
      if (e.touches.length === 2) {
        touchStartDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      }
    };
    this.handlers.touchMove = (e) => {
      if (e.touches.length === 2) {
        const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        const scale = dist / touchStartDist;
        this.image.style.transform = `scale(${Math.min(Math.max(scale, 1), 4)})`;
        e.preventDefault();
      }
    };
    container.addEventListener('touchstart', this.handlers.touchStart, { passive: true });
    container.addEventListener('touchmove', this.handlers.touchMove, { passive: false });
  },

  createLens(container) { /* lens is created in init */ },

  moveLens(e) {
    if (!this.lens || !this.image) return;
    const rect = this.container.getBoundingClientRect();
    let x = e.clientX - rect.left;
    let y = e.clientY - rect.top;
    const halfLens = this.lensSize / 2;

    x = Math.max(halfLens, Math.min(x, rect.width - halfLens));
    y = Math.max(halfLens, Math.min(y, rect.height - halfLens));

    this.lens.style.left = x + 'px';
    this.lens.style.top = y + 'px';

    const zoomW = rect.width * this.zoomLevel;
    const zoomH = rect.height * this.zoomLevel;
    const bgX = -(x * this.zoomLevel - halfLens);
    const bgY = -(y * this.zoomLevel - halfLens);

    this.lens.style.backgroundImage = `url(${this.image.src})`;
    this.lens.style.backgroundSize = `${zoomW}px ${zoomH}px`;
    this.lens.style.backgroundPosition = `${bgX}px ${bgY}px`;
  },

  destroy() {
    if (this.container) {
      this.container.removeEventListener('mouseenter', this.handlers.enter);
      this.container.removeEventListener('mouseleave', this.handlers.leave);
      this.container.removeEventListener('mousemove', this.handlers.move);
      this.container.removeEventListener('touchstart', this.handlers.touchStart);
      this.container.removeEventListener('touchmove', this.handlers.touchMove);
      if (this.lens) this.lens.remove();
    }
    this.lens = null;
    this.container = null;
    this.image = null;
  },
};

// ============================================
// Product Gallery
// ============================================
const ProductGallery = {
  mainImage: null,
  thumbnails: [],
  currentIndex: 0,
  isFullscreen: false,

  init() {
    this.mainImage = document.querySelector('.product-gallery-main img');
    this.thumbnails = Array.from(document.querySelectorAll('.product-gallery-thumb'));

    if (!this.mainImage || this.thumbnails.length === 0) return;

    this.thumbnails.forEach((thumb, index) => {
      thumb.addEventListener('click', () => {
        this.goTo(index);
      });
    });

    const mainContainer = this.mainImage.closest('.product-gallery-main');
    if (mainContainer) {
      mainContainer.addEventListener('dblclick', () => this.toggleFullscreen());
    }

    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') this.prev();
      if (e.key === 'ArrowRight') this.next();
      if (e.key === 'Escape' && this.isFullscreen) this.exitFullscreen();
    });

    if (typeof ImageZoom !== 'undefined' && mainContainer) {
      ImageZoom.init(mainContainer);
    }
  },

  goTo(index) {
    if (index < 0 || index >= this.thumbnails.length) return;
    this.currentIndex = index;

    const src = this.thumbnails[index].querySelector('img')?.src;
    if (src && this.mainImage) {
      this.mainImage.src = src;
    }

    this.thumbnails.forEach((t, i) => {
      t.classList.toggle('active', i === index);
    });

    const arrowPrev = document.querySelector('.product-gallery-main .gallery-prev');
    const arrowNext = document.querySelector('.product-gallery-main .gallery-next');
    if (arrowPrev) arrowPrev.style.display = index === 0 ? 'none' : 'flex';
    if (arrowNext) arrowNext.style.display = index === this.thumbnails.length - 1 ? 'none' : 'flex';
  },

  prev() {
    this.goTo(this.currentIndex - 1);
  },

  next() {
    this.goTo(this.currentIndex + 1);
  },

  toggleFullscreen() {
    if (this.isFullscreen) {
      this.exitFullscreen();
    } else {
      this.enterFullscreen();
    }
  },

  enterFullscreen() {
    const container = this.mainImage?.closest('.product-gallery-main');
    if (!container || !document.fullscreenEnabled) return;
    this.isFullscreen = true;
    container.requestFullscreen().catch(() => {});
  },

  exitFullscreen() {
    this.isFullscreen = false;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
  },
};

// ============================================
// Product Comparison
// ============================================
const ProductCompare = {
  STORAGE_KEY: 'compareItems',
  maxItems: 4,

  get items() {
    return JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '[]');
  },

  set items(val) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(val));
    this.updateBadge();
  },

  add(productId) {
    const items = this.items;
    if (items.length >= this.maxItems) {
      Toast.warning(`Maximum ${this.maxItems} products can be compared`);
      return false;
    }
    if (items.includes(productId)) {
      Toast.info('Product already in comparison');
      return false;
    }
    items.push(productId);
    this.items = items;
    Toast.success('Added to comparison');
    this._updateButtons();
    return true;
  },

  remove(productId) {
    let items = this.items;
    items = items.filter(id => id !== productId);
    this.items = items;
    Toast.info('Removed from comparison');
    this._updateButtons();
  },

  clear() {
    this.items = [];
    Toast.info('Comparison cleared');
    this._updateButtons();
  },

  toggle(productId) {
    const items = this.items;
    const idx = items.indexOf(productId);
    if (idx > -1) {
      this.remove(productId);
      return false;
    } else {
      return this.add(productId);
    }
  },

  updateBadge() {
    const items = this.items;
    const count = items.length;
    const badges = document.querySelectorAll('#compareBadge');
    badges.forEach(b => {
      if (count > 0) {
        b.textContent = count > 99 ? '99+' : count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
    const floatBadges = document.querySelectorAll('.compare-float-badge');
    floatBadges.forEach(b => {
      const c = b.querySelector('.count');
      if (count > 0) {
        b.style.display = 'flex';
        if (c) c.textContent = count;
      } else {
        b.style.display = 'none';
      }
    });
  },

  _updateButtons() {
    const items = this.items;
    document.querySelectorAll('.compare-btn, .tp-compare-btn, [data-compare-toggle]').forEach(btn => {
      const pid = btn.dataset.productId || btn.dataset.compareId;
      if (pid) {
        btn.classList.toggle('active', items.some(id => String(id) === String(pid)));
        const label = btn.querySelector('.compare-label');
        if (label) label.textContent = items.includes(Number(pid)) ? 'Remove from Compare' : 'Add to Compare';
      }
    });
  },
};

// ============================================
// Recently Viewed Products
// ============================================
const RecentlyViewed = {
  items: JSON.parse(localStorage.getItem('recentlyViewed') || '[]'),
  maxItems: 20,

  add(product) {
    if (!product || !product.id) return;
    this.items = this.items.filter(item => item.id !== product.id);
    this.items.unshift({
      id: product.id,
      name: product.name || 'Product',
      price: product.price || 0,
      image: product.image || product.images?.[0] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
      category: product.category || '',
      viewedAt: Date.now(),
    });
    if (this.items.length > this.maxItems) {
      this.items = this.items.slice(0, this.maxItems);
    }
    localStorage.setItem('recentlyViewed', JSON.stringify(this.items));
  },

  get() {
    return this.items;
  },

  render(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const items = this.items.slice(0, 8);
    if (items.length === 0) {
      container.innerHTML = '';
      container.style.display = 'none';
      return;
    }
    container.style.display = '';
    container.innerHTML = items.map(item => {
      const p = { _id: item.id, name: item.name, price: item.price, images: [item.image], category: item.category };
      return createProductCard(p);
    }).join('');
  },
};

// ============================================
// Search Autocomplete
// ============================================
const SearchAutocomplete = {
  debounceTimer: null,
  results: [],

  init(input) {
    if (typeof input === 'string') input = document.querySelector(input);
    if (!input) return;

    const dropdown = input.closest('.search-input-wrap')?.querySelector('.search-autocomplete') || document.createElement('div');
    dropdown.classList.add('search-autocomplete');
    if (!dropdown.parentElement) input.parentElement.appendChild(dropdown);

    input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      const query = e.target.value.trim();
      if (query.length < 2) {
        dropdown.classList.remove('active');
        return;
      }
      this.debounceTimer = setTimeout(() => this.search(query).then(results => this.renderDropdown(results, dropdown)), 250);
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        dropdown.classList.remove('active');
      }
      if (e.key === 'Escape') dropdown.classList.remove('active');
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-input-wrap')) {
        dropdown.classList.remove('active');
      }
    });
  },

  async search(query) {
    try {
      const data = await API.get(`/products/search?q=${encodeURIComponent(query)}&limit=6`);
      this.results = data.products || data || [];
    } catch {
      this.results = [];
    }
    return this.results;
  },

  renderDropdown(results, dropdown) {
    if (!dropdown) return;
    if (results.length === 0) {
      dropdown.classList.remove('active');
      return;
    }
    dropdown.innerHTML = results.map(p => {
      const id = p._id || p.id;
      const img = p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
      return `<a href="/pages/product.html?id=${id}" class="search-autocomplete-item">
        <img src="${img}" alt="" loading="lazy">
        <div>
          <div class="search-autocomplete-item-name">${p.name}</div>
          <div class="search-autocomplete-item-price">${Utils.formatCurrency(p.price)}</div>
        </div>
      </a>`;
    }).join('');
    dropdown.classList.add('active');
  },

  select(item) {
    if (item && item.id) {
      window.location.href = `/pages/product.html?id=${item.id}`;
    }
  },
};

// ============================================
// Feature Styles Injection
// ============================================
function injectFeatureStyles() {
  if (document.getElementById('br-feature-styles')) return;
  const s = document.createElement('style');
  s.id = 'br-feature-styles';
  s.textContent = `@keyframes spin{to{transform:rotate(360deg)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes qvSlideIn{from{opacity:0;transform:translateY(20px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes qvOverlayIn{from{opacity:0}to{opacity:1}}
@keyframes qvOverlayOut{from{opacity:1}to{opacity:0}}
.qv-overlay{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6);backdrop-filter:blur(8px);animation:qvOverlayIn .25s}
.qv-exit{animation:qvOverlayOut .25s forwards}
.qv-modal{background:var(--glass-bg,rgba(20,20,30,.95));border:1px solid var(--glass-border,rgba(255,255,255,.1));border-radius:var(--radius-lg,16px);max-width:700px;width:92%;max-height:85vh;overflow-y:auto;backdrop-filter:blur(20px);animation:qvSlideIn .3s;position:relative}
.qv-close{position:absolute;top:12px;right:16px;background:none;border:none;color:var(--text-muted);font-size:28px;cursor:pointer;z-index:2;padding:4px 8px;line-height:1;transition:color .2s}
.qv-close:hover{color:var(--text)}
.qv-body{display:flex;gap:var(--space-4);padding:var(--space-5)}
.qv-image{flex:1;min-width:0;position:relative}
.qv-image img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--radius-md)}
.qv-badge{position:absolute;top:12px;left:12px}
.qv-stockout-badge{position:absolute;top:12px;left:0;background:linear-gradient(135deg,#dc143c,#8b0000);padding:5px 14px 5px 10px;border-radius:0 16px 16px 0;box-shadow:0 4px 12px rgba(220,20,60,.4);z-index:2;animation:stockoutPulse 2s ease-in-out infinite}
.qv-stockout-badge span{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;display:flex;align-items:center;gap:4px}
.qv-stockout-badge span::before{content:"\\2716";font-size:9px}
@keyframes stockoutPulse{0%,100%{box-shadow:0 4px 12px rgba(220,20,60,.4)}50%{box-shadow:0 4px 20px rgba(220,20,60,.7)}}
.qv-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-3)}
.qv-title{margin:0;font-size:var(--text-lg);font-weight:var(--weight-bold);line-height:1.3}
.qv-price-row{display:flex;align-items:center;gap:var(--space-2)}
.qv-price{font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--primary)}
.qv-original-price{font-size:var(--text-sm);text-decoration:line-through;color:var(--text-muted)}
.qv-stock{font-size:var(--text-sm);font-weight:var(--weight-medium)}
.qv-section{display:flex;flex-direction:column;gap:var(--space-1)}
.qv-label{font-size:var(--text-sm);font-weight:var(--weight-medium)}
.qv-colors{display:flex;gap:8px;flex-wrap:wrap}
.qv-color-swatch{width:28px;height:28px;border-radius:50%;border:2px solid var(--glass-border,rgba(255,255,255,.15));cursor:pointer;transition:border-color .2s}
.qv-color-swatch.active{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary)}
.qv-sizes{display:flex;gap:8px;flex-wrap:wrap}
.qv-size-btn{padding:6px 14px;border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:var(--text-sm);transition:all .2s}
.qv-size-btn.active{border-color:var(--primary);background:var(--primary);color:#fff}
.qv-qty{display:flex;align-items:center;gap:var(--space-2)}
.qv-qty-btn{width:32px;height:32px;border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;transition:all .2s}
.qv-qty-btn:hover{border-color:var(--primary)}
.qv-qty-value{font-weight:var(--weight-bold);min-width:24px;text-align:center}
.qv-actions{display:flex;gap:var(--space-2)}
.qv-wishlist-btn{flex:0!important}
.qv-wishlist-btn.active{color:var(--primary)}
@media(max-width:640px){.qv-body{flex-direction:column}.qv-modal{max-height:90vh}}
.ai-search-item:hover{background:var(--glass-bg,rgba(255,255,255,.1))!important}
.voice-search-btn.listening{animation:voicePulse 1s infinite}
.voice-overlay{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.7);backdrop-filter:blur(16px);display:flex;align-items:center;justify-content:center;animation:voiceFadeIn .25s}
.voice-overlay-exit{animation:voiceFadeOut .25s forwards}
.voice-overlay-inner{text-align:center;max-width:480px;width:90%;padding:48px 32px}
.voice-wave{display:flex;align-items:center;justify-content:center;gap:6px;height:60px;margin-bottom:32px}
.voice-wave span{width:6px;height:20px;background:linear-gradient(to top,#dc143c,#ff6b8a);border-radius:20px;animation:voiceWave 1.2s ease-in-out infinite}
.voice-wave span:nth-child(2){animation-delay:.1s;height:30px}
.voice-wave span:nth-child(3){animation-delay:.2s;height:50px}
.voice-wave span:nth-child(4){animation-delay:.3s;height:35px}
.voice-wave span:nth-child(5){animation-delay:.4s;height:25px}
@keyframes voiceWave{0%,100%{transform:scaleY(.5);opacity:.5}50%{transform:scaleY(1);opacity:1}}
@keyframes voiceFadeIn{from{opacity:0}to{opacity:1}}
@keyframes voiceFadeOut{from{opacity:1}to{opacity:0}}
@keyframes voicePulse{0%,100%{box-shadow:0 0 0 0 rgba(220,20,60,.4)}50%{box-shadow:0 0 0 10px rgba(220,20,60,0)}}
.voice-status{font-size:var(--text-sm);color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px}
.voice-text{font-size:var(--text-xl);color:#fff;font-weight:var(--weight-semibold);min-height:60px;display:flex;align-items:center;justify-content:center;margin-bottom:32px;transition:all .2s}
.voice-text.has-text{color:var(--primary);font-size:var(--text-2xl)}
.voice-cancel-btn{padding:12px 40px;border-radius:var(--radius-full);background:rgba(255,255,255,.1);color:rgba(255,255,255,.7);border:1px solid rgba(255,255,255,.15);font-size:var(--text-sm);cursor:pointer;transition:all .2s}
.voice-cancel-btn:hover{background:rgba(255,255,255,.2);color:#fff}
.floating-btn:hover{transform:scale(1.1)!important}
.social-share-btn:hover{transform:scale(1.1)!important}`;
  document.head.appendChild(s);
}

// ============================================
// Recently Viewed - API Tracking
// ============================================
function getSessionId() {
  let sid = localStorage.getItem('br_session_id');
  if (!sid) {
    sid = 'sess_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('br_session_id', sid);
  }
  return sid;
}

async function trackRecentlyViewed(productId) {
  if (!productId) return;
  RecentlyViewed.add({ id: productId });
  try {
    await API.post('/recentlyviewed/track', { product_id: productId, session_id: getSessionId() });
  } catch { /* silent */ }
}

function renderRecentlyViewed(container) {
  if (typeof container === 'string') container = document.getElementById(container);
  if (!container) return;
  (async () => {
    try {
      const data = await API.get(`/recentlyviewed?limit=8&session_id=${getSessionId()}`);
      const items = data.items || data.products || data || [];
      if (items.length > 0) {
        container.innerHTML = items.map(p => {
          const id = p._id || p.id || p.product_id;
          return createProductCard({ _id: id, name: p.name || 'Product', price: p.price || p.sellingPrice || 0, images: [p.images?.[0] || p.image || p.thumbnail || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'] });
        }).join('');
        container.style.display = '';
        return;
      }
    } catch { /* fall through */ }
    const local = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
    if (local.length > 0) {
      container.innerHTML = local.slice(0, 8).map(item =>
        createProductCard({ _id: item.id, name: item.name, price: item.price, images: [item.image] })
      ).join('');
      container.style.display = '';
    } else {
      container.style.display = 'none';
    }
  })();
}

// ============================================
// Quick View Modal
// ============================================
const QuickView = {
  modal: null,
  currentProduct: null,
  selectedColor: null,
  selectedSize: null,
  quantity: 1,

  async open(productId) {
    if (!productId) return;
    let product;
    try {
      const data = await API.get(`/products/id/${productId}`);
      product = data.data || data.product || data;
    } catch {
      Toast.error('Failed to load product details');
      return;
    }
    this.currentProduct = product;
    this.selectedColor = null;
    this.selectedSize = null;
    this.quantity = 1;
    this._render(product);
  },

  close() {
    if (this.modal) {
      this.modal.classList.add('qv-exit');
      setTimeout(() => {
        if (this.modal) this.modal.remove();
        this.modal = null;
        document.body.style.overflow = '';
      }, 250);
    }
  },

  setQuantity(q) {
    this.quantity = Math.max(1, q);
    const qtyEl = this.modal?.querySelector('.qv-qty-value');
    if (qtyEl) qtyEl.textContent = this.quantity;
  },

  selectColor(color, images) {
    this.selectedColor = color;
    const mainImg = this.modal?.querySelector('.qv-image img');
    if (mainImg && images?.length) mainImg.src = images[0];
    this.modal?.querySelectorAll('.qv-color-swatch').forEach(s => {
      s.classList.toggle('active', s.dataset.color === color);
    });
  },

  selectSize(size) {
    this.selectedSize = size;
    this.modal?.querySelectorAll('.qv-size-btn').forEach(s => {
      s.classList.toggle('active', s.dataset.size === size);
    });
    const product = this.currentProduct;
    if (product?.variants?.length) {
      const variant = product.variants.find(v => v.size === size && (!this.selectedColor || v.color === this.selectedColor));
      if (variant) {
        const priceEl = this.modal?.querySelector('.qv-price');
        if (priceEl) priceEl.textContent = Utils.formatCurrency(variant.price || product.price);
        const stockEl = this.modal?.querySelector('.qv-stock');
        if (stockEl) {
          const inStock = variant.stock == null || variant.stock > 0;
          stockEl.textContent = inStock ? 'In Stock' : 'Out of Stock';
          stockEl.style.color = inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)';
        }
      }
    }
  },

  addToCart() {
    const id = this.currentProduct?._id || this.currentProduct?.id;
    if (!id) return;
    Cart.addItem(id, this.quantity);
    this.close();
  },

  _render(product) {
    const id = product._id || product.id;
    const images = product.images || [product.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'];
    const name = product.name || 'Product';
    const price = product.price || 0;
    const originalPrice = product.originalPrice || product.compareAtPrice || product.mrp || 0;
    const discount = originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;
    const colors = product.colors || product.variants?.filter((v, i, a) => v.color && a.findIndex(x => x.color === v.color) === i).map(v => v.color) || [];
    const sizes = product.sizes || product.variants?.filter((v, i, a) => v.size && a.findIndex(x => x.size === v.size) === i).map(v => v.size) || [];
    const isWished = Wishlist.items.some(i => (i.id || i) == id);
    const stock = product.stock_quantity ?? product.stockQuantity ?? product.stock ?? 0;
    const isPreorder = product.is_preorder;
    const inStock = stock > 0;
    const sn = name.replace(/'/g, "\\'");

    this.modal = document.createElement('div');
    this.modal.className = 'qv-overlay';
    let html = '<div class="qv-modal"><button class="qv-close" aria-label="Close">&times;</button><div class="qv-body">';
    html += '<div class="qv-image"><img src="' + images[0] + '" alt="' + name + '" loading="lazy"' + (!inStock ? ' style="opacity:0.5;"' : '') + '>';
    if (!inStock) html += '<div class="qv-stockout-badge"><span>Stock Out</span></div>';
    else if (discount > 0) html += '<span class="badge badge-danger qv-badge">-' + discount + '%</span>';
    html += '</div><div class="qv-info">';
    html += '<h3 class="qv-title">' + name + '</h3>';
    html += '<div class="qv-price-row"><span class="qv-price">' + Utils.formatCurrency(price) + '</span>';
    if (discount > 0) html += '<span class="qv-original-price">' + Utils.formatCurrency(originalPrice) + '</span>';
    html += '</div>';
    html += '<div class="qv-stock" style="color:' + (inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)') + ';">' + (inStock ? 'In Stock' : 'Out of Stock') + '</div>';
    if (colors.length > 0) {
      html += '<div class="qv-section"><div class="qv-label">Color</div><div class="qv-colors">';
      colors.forEach(c => { html += '<button class="qv-color-swatch" data-color="' + c + '" style="background:' + c + ';" title="' + c + '"></button>'; });
      html += '</div></div>';
    }
    if (sizes.length > 0) {
      html += '<div class="qv-section"><div class="qv-label">Size</div><div class="qv-sizes">';
      sizes.forEach(s => { html += '<button class="qv-size-btn" data-size="' + s + '">' + s + '</button>'; });
      html += '</div></div>';
    }
    html += '<div class="qv-section"><div class="qv-label">Quantity</div><div class="qv-qty">';
    html += '<button class="qv-qty-btn" onclick="QuickView.setQuantity(QuickView.quantity - 1)">&minus;</button>';
    html += '<span class="qv-qty-value">1</span>';
    html += '<button class="qv-qty-btn" onclick="QuickView.setQuantity(QuickView.quantity + 1)">+</button></div></div>';
    html += '<div class="qv-actions">';
    if (inStock) {
      html += '<button class="btn btn-primary btn-lg" onclick="QuickView.addToCart()" style="flex:2;">Add to Cart</button>';
    } else if (isPreorder) {
      html += '<button class="btn btn-primary btn-lg" onclick="QuickView.close(); PreOrder.show(\'' + id + '\',\'' + sn + '\');" style="flex:2;">Pre-Order</button>';
    } else {
      html += '<button class="btn btn-glass btn-lg" disabled style="flex:2;opacity:0.5;">Out of Stock</button>';
    }
    html += '<button class="btn btn-glass btn-lg qv-wishlist-btn ' + (isWished ? 'active' : '') + '" onclick="Wishlist.toggle(\'' + id + '\'); this.classList.toggle(\'active\');" aria-label="Wishlist"><svg width="20" height="20" viewBox="0 0 24 24" fill="' + (isWished ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg></button>';
    html += '</div>';
    if (!inStock && !isPreorder) {
      html += '<button class="btn btn-ghost btn-lg" onclick="QuickView.close(); BackInStock.show(\'' + id + '\');" style="width:100%;">Notify When Available</button>';
    }
    html += '<a href="/pages/product.html?id=' + id + '" class="btn btn-ghost btn-lg" style="width:100%;margin-top:var(--space-1);">View Full Details</a>';
    html += '</div></div></div>';
    this.modal.innerHTML = html;
    document.body.appendChild(this.modal);
    document.body.style.overflow = 'hidden';
    this.modal.addEventListener('click', (e) => { if (e.target === this.modal) this.close(); });
    this.modal.querySelector('.qv-close').addEventListener('click', () => this.close());
    this.modal.querySelectorAll('.qv-color-swatch').forEach(s => {
      s.addEventListener('click', () => {
        const color = s.dataset.color;
        const variantImages = product.variants?.filter(v => v.color === color).flatMap(v => v.images || []).filter(Boolean);
        this.selectColor(color, variantImages.length ? variantImages : images);
      });
    });
    this.modal.querySelectorAll('.qv-size-btn').forEach(s => {
      s.addEventListener('click', () => this.selectSize(s.dataset.size));
    });
  },
};

document.addEventListener('click', (e) => {
  const btn = e.target.closest('.quick-view-btn, [data-quick-view]');
  if (btn) {
    e.preventDefault();
    const id = btn.dataset.productId || btn.dataset.quickView;
    if (id) QuickView.open(id);
  }
});

// ============================================
// Pre-Order
// ============================================
const PreOrder = {
  show(productId, productName) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);animation:fadeIn 0.2s;';
    overlay.innerHTML = '<div style="background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-lg,16px);padding:var(--space-6);max-width:420px;width:90%;backdrop-filter:blur(20px);animation:qvSlideIn 0.3s;"><h3 style="margin:0 0 var(--space-2);font-size:var(--text-lg);font-weight:var(--weight-bold);">Pre-Order: ' + (productName || 'Product') + '</h3><p style="color:var(--text-muted);font-size:var(--text-sm);margin:0 0 var(--space-4);">This item is currently out of stock. Place a pre-order to reserve yours.</p><form id="preorderForm"><div style="margin-bottom:var(--space-3);"><label style="display:block;font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Expected Availability Date</label><input type="date" name="expected_date" required style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="margin-bottom:var(--space-4);"><label style="display:block;font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Deposit Amount (Optional)</label><input type="number" name="deposit" min="0" placeholder="0" style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="display:flex;gap:var(--space-2);"><button type="button" class="btn btn-ghost" onclick="this.closest(\'.modal-overlay\').remove()" style="flex:1;">Cancel</button><button type="submit" class="btn btn-primary" style="flex:2;">Place Pre-Order</button></div></form></div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('#preorderForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const payload = { product_id: productId, expected_date: formData.get('expected_date'), deposit: Number(formData.get('deposit')) || 0 };
      try {
        await API.post('/orders/preorder', payload);
        Toast.success('Pre-order placed successfully!');
      } catch { Toast.info('Pre-order request submitted!'); }
      overlay.remove();
    });
  },
};

// ============================================
// Back In Stock Notification
// ============================================
const BackInStock = {
  show(productId) {
    const existing = document.querySelector('.bis-overlay');
    if (existing) existing.remove();
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay bis-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);animation:fadeIn 0.2s;';
    overlay.innerHTML = '<div style="background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-lg,16px);padding:var(--space-6);max-width:400px;width:90%;backdrop-filter:blur(20px);animation:qvSlideIn 0.3s;"><h3 style="margin:0 0 var(--space-2);font-size:var(--text-lg);font-weight:var(--weight-bold);">Notify When Available</h3><p style="color:var(--text-muted);font-size:var(--text-sm);margin:0 0 var(--space-4);">We\'ll email you when this product is back in stock.</p><form id="bisForm"><div style="margin-bottom:var(--space-4);"><input type="email" name="email" placeholder="your@email.com" required style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="display:flex;gap:var(--space-2);"><button type="button" class="btn btn-ghost" onclick="this.closest(\'.modal-overlay\').remove()" style="flex:1;">Cancel</button><button type="submit" class="btn btn-primary" style="flex:2;">Subscribe</button></div></form></div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('#bisForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = new FormData(e.target).get('email');
      try {
        await API.post('/back-in-stock/subscribe', { product_id: productId, email });
        Toast.success('You will be notified when this product is back in stock!');
      } catch {       Toast.success('Subscribed! We\'ll notify you when available.'); }
      overlay.remove();
    });
  },
};

// ============================================
// AI Search Suggestion
// ============================================
const AISearch = {
  activeIndex: -1,
  debounceTimer: null,
  dropdown: null,
  input: null,

  init(input) {
    if (typeof input === 'string') input = document.querySelector(input);
    if (!input) return;
    this.input = input;
    this.dropdown = document.createElement('div');
    this.dropdown.className = 'ai-search-dropdown';
    this.dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;margin-top:4px;background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-md,12px);backdrop-filter:blur(20px);overflow:hidden;z-index:100;display:none;box-shadow:0 12px 40px rgba(0,0,0,0.4);';
    const wrap = input.closest('.search-input-wrap') || input.parentElement;
    if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(this.dropdown); }

    input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      this.activeIndex = -1;
      const q = e.target.value.trim();
      if (q.length < 2) { this.dropdown.style.display = 'none'; return; }
      this.debounceTimer = setTimeout(() => this.fetchSuggestions(q), 300);
    });

    input.addEventListener('keydown', (e) => {
      const items = this.dropdown.querySelectorAll('.ai-search-item');
      if (!items.length || this.dropdown.style.display === 'none') return;
      if (e.key === 'ArrowDown') { e.preventDefault(); this.activeIndex = Math.min(this.activeIndex + 1, items.length - 1); this._highlight(items); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.activeIndex = Math.max(this.activeIndex - 1, -1); this._highlight(items); }
      else if (e.key === 'Enter' && this.activeIndex >= 0 && items[this.activeIndex]) { e.preventDefault(); items[this.activeIndex].click(); }
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-input-wrap') && !e.target.closest('.ai-search-dropdown')) {
        this.dropdown.style.display = 'none';
      }
    });
  },

  async fetchSuggestions(query) {
    if (!this.dropdown) return;
    this.dropdown.style.display = 'block';
    this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">Searching...</div>';
    try {
      const data = await API.post('/ai/search', { query });
      const results = data.results || data.products || data || [];
      if (results.length === 0) {
        this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">No suggestions found</div>';
        return;
      }
      let html = results.slice(0, 6).map(p => {
        const id = p._id || p.id;
        const img = p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
        return '<a href="/pages/product.html?id=' + id + '" class="ai-search-item" style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2) var(--space-3);text-decoration:none;color:var(--text);transition:background 0.15s;"><img src="' + img + '" alt="" style="width:40px;height:40px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy"><div style="min-width:0;flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + p.name + '</div><div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">' + Utils.formatCurrency(p.price) + '</div></div></a>';
      }).join('');
      html += '<div style="padding:var(--space-2) var(--space-3);border-top:1px solid var(--glass-border,rgba(255,255,255,0.1));font-size:var(--text-xs);color:var(--text-muted);display:flex;align-items:center;gap:var(--space-1);"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg> Powered by AI</div>';
      this.dropdown.innerHTML = html;
      this.dropdown.querySelectorAll('.ai-search-item').forEach((item, i) => {
        item.addEventListener('mouseenter', () => { this.activeIndex = i; this._highlight(this.dropdown.querySelectorAll('.ai-search-item')); });
      });
    } catch {
      this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">Suggestions unavailable</div>';
    }
  },

  _highlight(items) {
    items.forEach((item, i) => { item.style.background = i === this.activeIndex ? 'var(--glass-bg,rgba(255,255,255,0.1))' : 'transparent'; });
  },
};

// ============================================
// Voice Search
// ============================================
const VoiceSearch = {
  recognition: null,
  isListening: false,
  btn: null,
  overlay: null,
  finalTranscript: '',

  init() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    this.recognition = new SR();
    this.recognition.continuous = false;
    this.recognition.interimResults = true;
    try { this.recognition.lang = 'bn-BD'; } catch { this.recognition.lang = 'en-US'; }

    this.recognition.onresult = (e) => {
      this.finalTranscript = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) this.finalTranscript += e.results[i][0].transcript;
      }
      const interim = Array.from(e.results).map(r => r[0].transcript).join('');
      const input = document.getElementById('searchInput');
      if (input) {
        input.value = interim;
        input.dispatchEvent(new Event('input'));
      }
      this._updateOverlay(interim);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this._updateUI();
      if (this.finalTranscript.trim()) {
        const input = document.getElementById('searchInput');
        if (input) {
          input.value = this.finalTranscript;
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        }
      }
      this._removeOverlay();
    };

    this.recognition.onerror = (ev) => {
      this.isListening = false;
      this._updateUI();
      this._removeOverlay();
      if (ev.error === 'not-allowed') Toast.warning('Microphone access denied. Please allow microphone permissions.');
    };

    this._createMicButton();
  },

  _createMicButton() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    const wrap = searchInput.closest('.search-input-wrap') || searchInput.parentElement;
    if (!wrap || wrap.querySelector('.voice-search-btn')) return;

    this.btn = document.createElement('button');
    this.btn.className = 'voice-search-btn';
    this.btn.type = 'button';
    this.btn.setAttribute('aria-label', 'Voice search');
    this.btn.innerHTML =
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/>' +
      '<path d="M19 10v2a7 7 0 01-14 0v-2"/>' +
      '<line x1="12" y1="19" x2="12" y2="23"/>' +
      '<line x1="8" y1="23" x2="16" y2="23"/></svg>';
    this.btn.style.cssText = 'position:absolute;right:44px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer;padding:6px;border-radius:var(--radius-full);transition:all 0.3s;display:flex;align-items:center;justify-content:center;z-index:5;';
    this.btn.addEventListener('mouseenter', () => { if (!this.isListening) this.btn.style.background = 'var(--glass-bg)'; });
    this.btn.addEventListener('mouseleave', () => { if (!this.isListening) this.btn.style.background = 'none'; });
    this.btn.addEventListener('click', (e) => { e.preventDefault(); this.toggle(); });
    wrap.appendChild(this.btn);
    wrap.style.position = 'relative';
  },

  toggle() { this.isListening ? this.stop() : this.start(); },

  start() {
    if (!this.recognition) return;
    try {
      this.recognition.start();
      this.isListening = true;
      this._updateUI();
      this._showOverlay();
    } catch { /* already started */ }
  },

  stop() {
    if (!this.recognition) return;
    try { this.recognition.stop(); } catch {}
    this.isListening = false;
    this._updateUI();
    this._removeOverlay();
  },

  _showOverlay() {
    if (this.overlay) return;
    this.overlay = document.createElement('div');
    this.overlay.className = 'voice-overlay';
    this.overlay.innerHTML =
      '<div class="voice-overlay-inner">' +
      '<div class="voice-wave"><span></span><span></span><span></span><span></span><span></span></div>' +
      '<div class="voice-status">Listening...</div>' +
      '<div class="voice-text" id="voiceTranscript">Say a product name like "Jamdani shirt" or "ইলিশ মাছ"</div>' +
      '<button class="voice-cancel-btn" id="voiceCancelBtn">Cancel</button>' +
      '</div>';
    document.body.appendChild(this.overlay);
    document.getElementById('voiceCancelBtn')?.addEventListener('click', () => this.stop());
    this.overlay.addEventListener('click', (e) => { if (e.target === this.overlay) this.stop(); });
  },

  _updateOverlay(text) {
    const el = document.getElementById('voiceTranscript');
    if (el) {
      el.textContent = text || 'Listening...';
      el.classList.add('has-text');
    }
  },

  _removeOverlay() {
    if (this.overlay) {
      this.overlay.classList.add('voice-overlay-exit');
      setTimeout(() => { if (this.overlay) { this.overlay.remove(); this.overlay = null; } }, 300);
    }
  },

  _updateUI() {
    if (!this.btn) return;
    if (this.isListening) {
      this.btn.style.color = '#dc143c';
      this.btn.style.background = 'rgba(220,20,60,0.12)';
      this.btn.style.boxShadow = '0 0 20px rgba(220,20,60,0.3)';
      this.btn.classList.add('listening');
      this.btn.title = 'Tap to stop';
    } else {
      this.btn.style.color = '';
      this.btn.style.background = '';
      this.btn.style.boxShadow = '';
      this.btn.classList.remove('listening');
      this.btn.title = 'Voice search';
    }
  },
};

// ============================================
// Floating Buttons (WhatsApp + Messenger)
// ============================================
const FloatingButtons = {
  init() {
    const c = document.createElement('div');
    c.className = 'floating-social-buttons';
    c.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:999;display:flex;flex-direction:column;gap:12px;';
    c.innerHTML = '<a href="https://wa.me/8801XXXXXXXXX?text=' + encodeURIComponent('Hi, I want to order from Bangalirhaat') + '" target="_blank" rel="noopener noreferrer" class="floating-btn floating-whatsapp" title="Order via WhatsApp" style="width:56px;height:56px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;box-shadow:0 4px 16px rgba(37,211,102,0.4);transition:transform 0.2s,box-shadow 0.2s;"><svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a><a href="https://m.me/bangalirhaat" target="_blank" rel="noopener noreferrer" class="floating-btn floating-messenger" title="Chat with us" style="width:56px;height:56px;border-radius:50%;background:#0084FF;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;box-shadow:0 4px 16px rgba(0,132,255,0.4);transition:transform 0.2s,box-shadow 0.2s;"><svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 0C5.373 0 0 4.974 0 11.111c0 3.498 1.744 6.614 4.469 8.654V24l4.088-2.242c1.092.3 2.246.464 3.443.464 6.627 0 12-4.975 12-11.111C24 4.974 18.627 0 12 0zm1.191 14.963l-3.055-3.26-5.963 3.26L10.732 8.2l3.131 3.259L19.752 8.2l-6.561 6.763z"/></svg></a>';
    document.body.appendChild(c);
  },
};

// ============================================
// Invoice QR Code
// ============================================
const InvoiceQR = {
  generate(orderNumber, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container || !orderNumber) return;
    const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(orderNumber);
    container.innerHTML = '<div style="text-align:center;"><img src="' + qrUrl + '" alt="QR Code for ' + orderNumber + '" style="border-radius:var(--radius-sm);background:#fff;padding:8px;" loading="lazy"><div style="font-size:var(--text-xs);color:var(--text-muted);margin-top:var(--space-2);">Scan to track order</div></div>';
  },
};

// ============================================
// Order Tracking Timeline
// ============================================
const OrderTracking = {
  statuses: ['Order Placed', 'Confirmed', 'Processing', 'Shipped', 'Out for Delivery', 'Delivered'],
  statusKeys: ['placed', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered'],

  render(order, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container || !order) return;
    const currentStatus = (order.status || order.orderStatus || '').toLowerCase().replace(/\s+/g, '_');
    const currentIdx = this.statusKeys.indexOf(currentStatus);
    const timeline = order.timeline || order.statusHistory || [];
    const trackingNumber = order.trackingNumber || order.courier_tracking || null;
    const courierName = order.courierName || order.courier || '';

    let html = '<div style="position:relative;padding:var(--space-4) 0;">';
    this.statuses.forEach((label, i) => {
      let state = 'pending';
      let timestamp = '';
      if (currentIdx >= 0 && i < currentIdx) state = 'completed';
      else if (currentIdx >= 0 && i === currentIdx) state = 'current';
      if (i <= currentIdx) {
        const entry = timeline.find(t => (t.status || '').toLowerCase().replace(/\s+/g, '_') === this.statusKeys[i]);
        if (entry?.date || entry?.createdAt) timestamp = Utils.formatDate(entry.date || entry.createdAt);
      }
      const colors = { completed: 'var(--success, #10b981)', current: 'var(--primary, #dc143c)', pending: 'var(--text-muted, #6b7280)' };
      const color = colors[state];
      const isLast = i === this.statuses.length - 1;
      html += '<div style="display:flex;gap:var(--space-3);position:relative;padding-bottom:' + (isLast ? '0' : 'var(--space-6)') + ';">';
      if (!isLast) html += '<div style="position:absolute;left:15px;top:32px;bottom:0;width:2px;background:' + (i < currentIdx ? color : 'var(--glass-border, rgba(255,255,255,0.1))') + ';"></div>';
      html += '<div style="width:32px;height:32px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:var(--weight-bold);background:' + (state === 'pending' ? 'var(--glass-bg, rgba(255,255,255,0.05))' : color + '20') + ';color:' + color + ';border:2px solid ' + color + ';">';
      html += state === 'completed' ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : (i + 1);
      html += '</div><div style="flex:1;padding-top:4px;">';
      html += '<div style="font-size:var(--text-sm);font-weight:' + (state === 'current' ? 'var(--weight-bold)' : 'var(--weight-medium)') + ';color:' + (state === 'pending' ? 'var(--text-muted)' : 'var(--text)') + ';">' + label + '</div>';
      if (timestamp) html += '<div style="font-size:var(--text-xs);color:var(--text-muted);margin-top:2px;">' + timestamp + '</div>';
      html += '</div></div>';
    });
    html += '</div>';
    if (trackingNumber && currentIdx >= 3) {
      html += '<div style="margin-top:var(--space-4);padding:var(--space-3);background:var(--glass-bg, rgba(255,255,255,0.05));border:1px solid var(--glass-border, rgba(255,255,255,0.1));border-radius:var(--radius-sm);"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Courier Tracking</div><div style="font-size:var(--text-sm);color:var(--text-muted);">' + (courierName ? courierName + ': ' : '') + trackingNumber + '</div></div>';
    }
    container.innerHTML = html;
  },
};

// ============================================
// Infinite Scroll
// ============================================
const InfiniteScroll = {
  observer: null,
  loading: false,
  page: 1,
  hasMore: true,
  grid: null,
  endpoint: '',
  limit: 20,

  init(options = {}) {
    this.grid = typeof options.grid === 'string' ? document.querySelector(options.grid) : options.grid;
    this.endpoint = options.endpoint || '/products';
    this.limit = options.limit || 20;
    this.page = options.startPage || 1;
    this.hasMore = true;
    this.loading = false;
    if (!this.grid) return;
    let sentinel = document.getElementById('infiniteScrollSentinel');
    if (!sentinel) {
      sentinel = document.createElement('div');
      sentinel.id = 'infiniteScrollSentinel';
      sentinel.style.cssText = 'height:1px;width:100%;';
      this.grid.parentElement?.appendChild(sentinel);
    }
    this.observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !this.loading && this.hasMore) this.loadMore();
    }, { rootMargin: '200px' });
    this.observer.observe(sentinel);
  },

  async loadMore() {
    if (this.loading || !this.hasMore) return;
    this.loading = true;
    this._showSpinner();
    try {
      const sep = this.endpoint.includes('?') ? '&' : '?';
      const data = await API.get(this.endpoint + sep + 'page=' + this.page + '&limit=' + this.limit);
      const products = data.products || data.data || data || [];
      if (products.length < this.limit) this.hasMore = false;
      this.page++;
      const fragment = document.createDocumentFragment();
      products.forEach(p => {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = createProductCard(p);
        fragment.appendChild(wrapper.firstElementChild);
      });
      this.grid.appendChild(fragment);
    } catch { this.hasMore = false; }
    finally { this.loading = false; this._hideSpinner(); }
  },

  _showSpinner() {
    let sp = document.getElementById('infiniteScrollSpinner');
    if (!sp) {
      sp = document.createElement('div');
      sp.id = 'infiniteScrollSpinner';
      sp.style.cssText = 'text-align:center;padding:var(--space-6);';
      sp.innerHTML = '<div style="width:32px;height:32px;border:3px solid var(--glass-border);border-top-color:var(--primary);border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto;"></div>';
      this.grid.parentElement?.appendChild(sp);
    }
    sp.style.display = '';
  },

  _hideSpinner() {
    const sp = document.getElementById('infiniteScrollSpinner');
    if (sp) sp.style.display = 'none';
  },

  destroy() {
    if (this.observer) this.observer.disconnect();
    this.loading = false;
    this.hasMore = true;
    document.getElementById('infiniteScrollSentinel')?.remove();
    document.getElementById('infiniteScrollSpinner')?.remove();
  },
};

// ============================================
// Product Variants
// ============================================
const ProductVariants = {
  product: null,
  selectedColor: null,
  selectedSize: null,

  init(product) {
    this.product = product;
    if (!product) return;
    const variants = product.variants || [];
    if (variants.length === 0) return;
    const colors = [...new Set(variants.filter(v => v.color).map(v => v.color))];
    const sizes = [...new Set(variants.filter(v => v.size).map(v => v.size))];
    if (colors.length) this._renderColors(colors);
    if (sizes.length) this._renderSizes(sizes);
  },

  _renderColors(colors) {
    const container = document.querySelector('.variant-colors, [data-variant-colors]');
    if (!container) return;
    container.innerHTML = colors.map(c => {
      const variant = this.product.variants.find(v => v.color === c);
      const img = variant?.image || variant?.images?.[0];
      return '<button class="color-swatch" data-color="' + c + '" style="width:32px;height:32px;border-radius:50%;border:2px solid var(--glass-border, rgba(255,255,255,0.15));background:' + c + ';cursor:pointer;transition:border-color 0.2s;" title="' + c + '"' + (img ? ' data-img="' + img + '"' : '') + '></button>';
    }).join('');
    container.querySelectorAll('.color-swatch').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectedColor = btn.dataset.color;
        container.querySelectorAll('.color-swatch').forEach(b => b.style.borderColor = 'var(--glass-border, rgba(255,255,255,0.15))');
        btn.style.borderColor = 'var(--primary, #dc143c)';
        if (btn.dataset.img) {
          const mainImg = document.querySelector('.product-gallery-main img, .product-main-image');
          if (mainImg) mainImg.src = btn.dataset.img;
        }
        this._updateStockStatus();
      });
    });
  },

  _renderSizes(sizes) {
    const container = document.querySelector('.variant-sizes, [data-variant-sizes]');
    if (!container) return;
    container.innerHTML = sizes.map(s => '<button class="size-btn" data-size="' + s + '" style="padding:var(--space-1) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border, rgba(255,255,255,0.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:var(--text-sm);transition:all 0.2s;">' + s + '</button>').join('');
    container.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectedSize = btn.dataset.size;
        container.querySelectorAll('.size-btn').forEach(b => { b.style.borderColor = 'var(--glass-border, rgba(255,255,255,0.15))'; b.style.background = 'var(--glass-bg)'; b.style.color = 'var(--text)'; });
        btn.style.borderColor = 'var(--primary, #dc143c)';
        btn.style.background = 'var(--primary, #dc143c)';
        btn.style.color = '#fff';
        const variant = this.product.variants.find(v => v.size === this.selectedSize && (!this.selectedColor || v.color === this.selectedColor));
        if (variant) {
          const priceEl = document.querySelector('.product-price-current, [data-product-price]');
          if (priceEl) priceEl.textContent = Utils.formatCurrency(variant.price || this.product.price);
        }
        this._updateStockStatus();
      });
    });
  },

  _updateStockStatus() {
    if (!this.product?.variants) return;
    const variant = this.product.variants.find(v => (!this.selectedColor || v.color === this.selectedColor) && (!this.selectedSize || v.size === this.selectedSize));
    const stockEl = document.querySelector('.product-stock-status, [data-stock-status]');
    if (!stockEl || !variant) return;
    const inStock = variant.stock == null || variant.stock > 0;
    stockEl.textContent = inStock ? 'In Stock' : 'Out of Stock';
    stockEl.style.color = inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)';
    const addBtn = document.querySelector('.add-to-cart-btn, [data-add-to-cart]');
    if (addBtn) addBtn.disabled = !inStock;
  },

  getSelected() {
    return { color: this.selectedColor, size: this.selectedSize };
  },
};

// ============================================
// Gift Card
// ============================================
const GiftCard = {
  async renderBalance(container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/giftcard/balance');
      const balance = data.balance || data.amount || 0;
      container.innerHTML = '<div style="padding:var(--space-4);background:linear-gradient(135deg, var(--primary, #dc143c), #ff6b6b);border-radius:var(--radius-md);color:#fff;margin-bottom:var(--space-4);"><div style="font-size:var(--text-xs);text-transform:uppercase;letter-spacing:1px;opacity:0.8;">Gift Card Balance</div><div style="font-size:var(--text-2xl);font-weight:var(--weight-bold);margin-top:var(--space-1);">' + Utils.formatCurrency(balance) + '</div></div>';
    } catch { container.innerHTML = ''; }
  },

  initRedeemForm(form) {
    if (typeof form === 'string') form = document.querySelector(form);
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = form.querySelector('input[name="giftcard_code"]')?.value?.trim();
      if (!code) return;
      try {
        await API.post('/giftcard/redeem', { code });
        Toast.success('Gift card redeemed successfully!');
        form.reset();
        const balanceEl = document.getElementById('giftCardBalance');
        if (balanceEl) this.renderBalance(balanceEl);
      } catch (err) { Toast.error(err.message || 'Invalid gift card code'); }
    });
  },
};

// ============================================
// Bundle Offer
// ============================================
const BundleOffer = {
  async render(productId, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/products/' + productId + '/bundles');
      const bundles = data.bundles || data || [];
      if (bundles.length === 0) { container.style.display = 'none'; return; }
      container.innerHTML = bundles.map(bundle => {
        const originalTotal = (bundle.products || []).reduce((sum, p) => sum + (p.price || 0), 0);
        const bundlePrice = bundle.bundlePrice || bundle.price || 0;
        const savings = originalTotal - bundlePrice;
        let html = '<div style="padding:var(--space-4);border:1px solid var(--primary, #dc143c);border-radius:var(--radius-md);background:var(--glass-bg);margin-bottom:var(--space-3);">';
        html += '<div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-3);"><span class="badge badge-danger">Bundle Deal</span><span style="font-size:var(--text-sm);color:var(--success, #10b981);font-weight:var(--weight-semibold);">Save ' + Utils.formatCurrency(savings) + '</span></div>';
        html += '<div style="display:flex;gap:var(--space-2);overflow-x:auto;padding-bottom:var(--space-2);">';
        (bundle.products || []).forEach(p => {
          html += '<div style="min-width:80px;text-align:center;flex-shrink:0;"><img src="' + (p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600') + '" alt="' + (p.name || '') + '" style="width:64px;height:64px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy"><div style="font-size:var(--text-xs);margin-top:var(--space-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:80px;">' + (p.name || '') + '</div></div>';
        });
        html += '</div>';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:var(--space-3);"><div><span style="font-size:var(--text-lg);font-weight:var(--weight-bold);color:var(--primary);">' + Utils.formatCurrency(bundlePrice) + '</span><span style="font-size:var(--text-sm);text-decoration:line-through;color:var(--text-muted);margin-left:var(--space-2);">' + Utils.formatCurrency(originalTotal) + '</span></div>';
        html += '<button class="btn btn-primary btn-sm" onclick="BundleOffer.addBundle(\'' + (bundle._id || bundle.id) + '\')">Add Bundle to Cart</button></div></div>';
        return html;
      }).join('');
    } catch { container.style.display = 'none'; }
  },

  async addBundle(bundleId) {
    try {
      await API.post('/cart/bundle', { bundleId });
      Toast.success('Bundle added to cart!');
      Cart.load();
    } catch (err) { Toast.error(err.message || 'Failed to add bundle'); }
  },
};

// ============================================
// Frequently Bought Together (FBT)
// ============================================
const FBT = {
  items: [],
  selected: new Set(),

  async render(productId, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/bundle/fbt/' + productId);
      this.items = data.products || data.items || data || [];
      if (this.items.length === 0) { container.style.display = 'none'; return; }
      this.items.forEach(p => this.selected.add(p._id || p.id));
      container.setAttribute('data-fbt-container', '');
      this._render(productId, container);
    } catch { container.style.display = 'none'; }
  },

  _render(productId, container) {
    const selectedItems = this.items.filter(p => this.selected.has(p._id || p.id));
    const totalPrice = selectedItems.reduce((sum, p) => sum + (p.price || 0), 0);
    const originalTotal = selectedItems.reduce((sum, p) => sum + (p.originalPrice || p.price || 0), 0);
    const savings = originalTotal - totalPrice;
    let html = '<div style="padding:var(--space-4);border:1px solid var(--glass-border, rgba(255,255,255,0.1));border-radius:var(--radius-md);background:var(--glass-bg);">';
    html += '<h4 style="margin:0 0 var(--space-3);font-size:var(--text-md);font-weight:var(--weight-bold);">Frequently Bought Together</h4>';
    html += '<div style="display:flex;gap:var(--space-3);overflow-x:auto;padding-bottom:var(--space-3);align-items:center;">';
    this.items.forEach(p => {
      const id = p._id || p.id;
      const isChecked = this.selected.has(id);
      html += '<label style="min-width:120px;flex-shrink:0;text-align:center;cursor:pointer;display:block;"><input type="checkbox" value="' + id + '"' + (isChecked ? ' checked' : '') + ' onchange="FBT.toggleItem(\'' + id + '\',\'' + productId + '\')" style="display:none;">';
      html += '<div style="border:2px solid ' + (isChecked ? 'var(--primary, #dc143c)' : 'var(--glass-border, rgba(255,255,255,0.1))') + ';border-radius:var(--radius-sm);padding:var(--space-2);transition:border-color 0.2s;">';
      html += '<img src="' + (p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600') + '" alt="' + (p.name || '') + '" style="width:80px;height:80px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy">';
      html += '<div style="font-size:var(--text-xs);margin-top:var(--space-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + (p.name || '') + '</div>';
      html += '<div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">' + Utils.formatCurrency(p.price) + '</div></div></label>';
    });
    html += '</div>';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;padding-top:var(--space-3);border-top:1px solid var(--glass-border, rgba(255,255,255,0.1));"><div><span style="font-size:var(--text-sm);color:var(--text-muted);">Total: </span><span style="font-size:var(--text-lg);font-weight:var(--weight-bold);">' + Utils.formatCurrency(totalPrice) + '</span>';
    if (savings > 0) html += '<span style="font-size:var(--text-xs);color:var(--success, #10b981);margin-left:var(--space-2);">Save ' + Utils.formatCurrency(savings) + '</span>';
    html += '</div><button class="btn btn-primary btn-sm" onclick="FBT.addAllToCart()">Add All to Cart</button></div></div>';
    container.innerHTML = html;
  },

  toggleItem(id, productId) {
    if (this.selected.has(id)) this.selected.delete(id);
    else this.selected.add(id);
    const container = document.querySelector('[data-fbt-container]');
    if (container) this._render(productId, container);
  },

  async addAllToCart() {
    const selected = this.items.filter(p => this.selected.has(p._id || p.id));
    for (const p of selected) await Cart.addItem(p._id || p.id, 1).catch(() => {});
    Toast.success(selected.length + ' items added to cart!');
  },
};

// ============================================
// Social Share
// ============================================
const SocialShare = {
  render(options = {}) {
    const url = options.url || window.location.href;
    const title = options.title || document.title;
    const target = typeof options.container === 'string' ? document.querySelector(options.container) : options.container;
    if (!target) return;
    const eu = encodeURIComponent(url);
    const et = encodeURIComponent(title);
    let html = '<div style="display:flex;gap:var(--space-2);align-items:center;">';
    html += '<span style="font-size:var(--text-sm);color:var(--text-muted);font-weight:var(--weight-medium);">Share:</span>';
    html += '<a href="https://www.facebook.com/sharer/sharer.php?u=' + eu + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on Facebook" style="width:36px;height:36px;border-radius:50%;background:#1877F2;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a>';
    html += '<a href="https://twitter.com/intent/tweet?url=' + eu + '&text=' + et + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on Twitter" style="width:36px;height:36px;border-radius:50%;background:#000;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>';
    html += '<a href="https://api.whatsapp.com/send?text=' + et + '%20' + eu + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on WhatsApp" style="width:36px;height:36px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>';
    html += '<button class="social-share-btn" title="Copy Link" onclick="Utils.copyToClipboard(\'' + url.replace(/'/g, "\\'") + '\')" style="width:36px;height:36px;border-radius:50%;background:var(--glass-bg, rgba(255,255,255,0.1));border:1px solid var(--glass-border, rgba(255,255,255,0.15));display:flex;align-items:center;justify-content:center;color:var(--text);cursor:pointer;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg></button>';
    html += '</div>';
    target.innerHTML = html;
  },
};

// ── Products Listing Page Init ───────────────────────────────────────
function initProductListing() {
  var container = document.getElementById('productGridContainer');
  if (!container) return;

  var params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  if (!params.get('category') && !params.get('q')) {
    params = new URLSearchParams(window.location.search);
  }
  var category = params.get('category');
  var search = params.get('q');
  var url = '/api/products';
  if (search) url = '/api/products/search?q=' + encodeURIComponent(search);
  else if (category) url = '/api/products?category_id=' + encodeURIComponent(category);

  container.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">Loading products...</div>';

  var token = localStorage.getItem('br_token');
  var headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = 'Bearer ' + token;

  fetch(url, { headers: headers })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      var products = data.data && data.data.products ? data.data.products : (Array.isArray(data.data) ? data.data : (data.products || data.data || []));
      if (!products.length) {
        container.innerHTML = '<div style="text-align:center;padding:60px 20px;"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1" style="margin-bottom:16px;"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg><h3 style="margin:0 0 8px;color:var(--text);">No products found</h3><p style="color:var(--text-muted);font-size:14px;">Try adjusting your filters or browse our categories.</p></div>';
        return;
      }
      container.innerHTML = '';
      container.style.display = 'grid';
      products.forEach(function (p) {
        var img = (p.images && p.images[0] && (p.images[0].url || p.images[0])) || p.image || p.thumbnail || 'https://placehold.co/400x400/1a1a1a/e6485a?text=Product';
        var name = p.name || 'Product';
        var price = p.price || 0;
        var compare = p.compare_price || p.comparePrice || 0;
        var rating = p.average_rating || p.rating || 0;
        var reviews = p.review_count || p.reviewCount || 0;
        var stock = p.stock_quantity !== undefined ? p.stock_quantity : (p.stockQuantity !== undefined ? p.stockQuantity : (p.stock !== undefined ? p.stock : -1));
        var card = document.createElement('div');
        card.className = 'product-card';
        card.style.cssText = 'background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-lg);overflow:hidden;transition:transform 0.2s,box-shadow 0.2s;cursor:pointer;position:relative;';
        card.onclick = function () { window.location.hash = '#product?id=' + p.id; };
        var badge = (stock === 0) ? '<div style="position:absolute;top:8px;left:8px;background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff;font-size:11px;font-weight:700;padding:3px 8px;border-radius:var(--radius-sm);z-index:2;">Stock Out</div>' : (compare > price ? '<div style="position:absolute;top:8px;left:8px;background:linear-gradient(135deg,#e6485a,#d4af37);color:#fff;font-size:11px;font-weight:700;padding:3px 8px;border-radius:var(--radius-sm);z-index:2;">-' + Math.round((1 - price/compare) * 100) + '%</div>' : '');
        var stars = '';
        for (var i = 1; i <= 5; i++) stars += '<svg width="12" height="12" viewBox="0 0 24 24" fill="' + (i <= Math.round(rating) ? '#f59e0b' : 'var(--border)') + '" stroke="#f59e0b" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
        card.innerHTML = badge +
          '<div style="position:relative;width:100%;padding-top:100%;background:var(--glass-bg,rgba(255,255,255,0.05));"><img src="' + img + '" alt="' + name.replace(/"/g,'&quot;') + '" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;" loading="lazy"></div>' +
          '<div style="padding:12px 14px 14px;"><p class="text-sm font-medium" style="color:var(--text);margin:0 0 4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.3;">' + name.replace(/</g,'&lt;') + '</p>' +
          '<div style="display:flex;align-items:center;gap:4px;margin-bottom:6px;">' + stars + '<span style="font-size:11px;color:var(--text-muted);margin-left:2px;">(' + reviews + ')</span></div>' +
          '<div style="display:flex;align-items:center;gap:6px;"><span style="font-size:15px;font-weight:700;color:var(--text);">\u09F3' + Number(price).toLocaleString() + '</span>' +
          (compare > price ? '<span style="font-size:12px;color:var(--text-muted);text-decoration:line-through;">\u09F3' + Number(compare).toLocaleString() + '</span>' : '') + '</div>' +
          '<button class="btn btn-primary btn-sm w-full" style="margin-top:10px;font-size:12px;" onclick="event.stopPropagation();(function(){ var pid=' + p.id + '; Cart.addItem(pid); })()">' + (stock === 0 ? 'Notify Me' : 'Add to Cart') + '</button></div>';
        container.appendChild(card);
      });
    })
    .catch(function () {
      container.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">Failed to load products. Please refresh the page.</div>';
    });
}

// ── Categories Page Init ─────────────────────────────────────────────
function initCategoryPage() {
  function buildTree(categories) {
    var tree = document.getElementById('categoryTree');
    if (!tree) return;
    tree.innerHTML = '<div class="category-tree-title">Browse Categories</div>';
    var allLink = document.createElement('a');
    allLink.href = '#categories';
    allLink.className = 'category-tree-item active';
    allLink.dataset.cat = 'all';
    allLink.innerHTML = '<span class="category-tree-item-left"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>All Categories</span><span class="category-tree-item-count">' + categories.length + '</span>';
    tree.appendChild(allLink);
    categories.forEach(function (cat) {
      var hasChildren = cat.children && cat.children.length;
      var item = document.createElement('div');
      item.className = 'category-tree-item';
      item.dataset.cat = cat.slug || cat.id;
      if (hasChildren) {
        item.onclick = function () { this.classList.toggle('expanded'); };
      } else {
        item.onclick = function () { window.location.hash = '#products?category=' + (cat.slug || cat.id); };
      }
      var left = document.createElement('span');
      left.className = 'category-tree-item-left';
      left.innerHTML = (cat.icon ? '<span>' + cat.icon + '</span> ' : '') + (cat.name || 'Category');
      if (hasChildren) {
        var chevron = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        chevron.setAttribute('class', 'category-tree-toggle');
        chevron.setAttribute('viewBox', '0 0 24 24');
        chevron.setAttribute('fill', 'none');
        chevron.setAttribute('stroke', 'currentColor');
        chevron.setAttribute('stroke-width', '2');
        chevron.innerHTML = '<path d="m9 18 6-6-6-6"/>';
        left.appendChild(chevron);
      }
      item.appendChild(left);
      var count = document.createElement('span');
      count.className = 'category-tree-item-count';
      count.textContent = cat.product_count || cat.count || cat.children_count || 0;
      item.appendChild(count);
      tree.appendChild(item);
      if (hasChildren) {
        var childContainer = document.createElement('div');
        childContainer.className = 'category-tree-children';
        cat.children.forEach(function (child) {
          var a = document.createElement('a');
          a.href = '#products?category=' + (cat.slug || cat.id) + (child.slug ? '&sub=' + child.slug : '');
          a.className = 'category-tree-item';
          a.innerHTML = '<span class="category-tree-item-left">' + (child.name || '') + '</span><span class="category-tree-item-count">' + (child.product_count || child.count || 0) + '</span>';
          childContainer.appendChild(a);
        });
        tree.appendChild(childContainer);
      }
    });
  }

  function buildGrid(categories) {
    var grid = document.getElementById('subcategoryGrid');
    if (!grid) return;
    grid.innerHTML = '';
    var countEl = document.getElementById('categoryCount');
    var catParam = (new URLSearchParams(window.location.hash.split('?')[1] || '')).get('cat') || (new URLSearchParams(window.location.search)).get('cat');
    var items = [];
    categories.forEach(function (cat) {
      if (catParam && String(cat.slug || cat.id) !== String(catParam)) return;
      if (cat.children && cat.children.length) {
        cat.children.forEach(function (child) {
          items.push({ parent: cat, child: child });
        });
      } else {
        items.push({ parent: null, child: cat });
      }
    });
    if (countEl) countEl.innerHTML = 'Showing <strong>' + items.length + '</strong> subcategories';
    items.forEach(function (item) {
      var child = item.child;
      var cat = item.parent || child;
      var img = child.image || cat.image || 'https://placehold.co/400x300/1a1a1a/dc143c?text=' + encodeURIComponent(child.name || 'C');
      var card = document.createElement('a');
      card.className = 'subcategory-card card-hover';
      card.href = '#products?category=' + (cat.slug || cat.id) + (item.parent ? '&sub=' + (child.slug || child.id) : '');
      card.innerHTML = '<div class="subcategory-card-image"><img src="' + img + '" alt="' + (child.name || '').replace(/"/g,'&quot;') + '" loading="lazy"></div><div class="subcategory-card-body"><div class="subcategory-card-title">' + (child.name || '').replace(/</g,'&lt;') + '</div><div class="subcategory-card-count">' + (child.product_count || child.count || 0) + ' products</div></div>';
      grid.appendChild(card);
    });
    if (typeof gsap !== 'undefined') {
      gsap.from('.subcategory-card', { y: 30, opacity: 0, duration: 0.5, stagger: 0.06, ease: 'power3.out', delay: 0.2 });
    }
  }

  var catParam = (new URLSearchParams(window.location.hash.split('?')[1] || '')).get('cat') || (new URLSearchParams(window.location.search)).get('cat');
  var heroTitle = document.getElementById('categoryHeroTitle');
  if (heroTitle && catParam) heroTitle.textContent = catParam.charAt(0).toUpperCase() + catParam.slice(1) + ' Category';

  fetch('/api/categories')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      var cats = data.data || data.categories || data || [];
      if (Array.isArray(cats)) {
        buildTree(cats);
        buildGrid(cats);
        if (catParam) {
          document.querySelectorAll('.category-tree-item').forEach(function (item) {
            if (item.dataset.cat === catParam) item.classList.add('active');
          });
        }
      }
    })
    .catch(function () {
      var grid = document.getElementById('subcategoryGrid');
      if (grid) grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">Failed to load categories. Please try again later.</p>';
    });

  // Mobile filter sheet
  var mobileFilterToggle = document.getElementById('mobileFilterToggle');
  var filterSheet = document.getElementById('filterSheet');
  var filterSheetOverlay = document.getElementById('filterSheetOverlay');
  if (mobileFilterToggle && filterSheet && filterSheetOverlay) {
    mobileFilterToggle.addEventListener('click', function () {
      var tree = document.getElementById('categoryTree');
      var mobileTree = document.getElementById('mobileCategoryTree');
      if (tree && mobileTree) {
        mobileTree.innerHTML = tree.innerHTML;
        mobileTree.querySelectorAll('.category-tree-item[onclick]').forEach(function (el) {
          el.onclick = function () { this.classList.toggle('expanded'); };
        });
      }
      filterSheet.classList.add('active');
      filterSheetOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
    filterSheetOverlay.addEventListener('click', function () {
      filterSheet.classList.remove('active');
      filterSheetOverlay.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  // Sort
  var sortSelect = document.getElementById('categorySort');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      var grid = document.getElementById('subcategoryGrid');
      if (!grid) return;
      var cards = Array.from(grid.children);
      cards.sort(function (a, b) {
        if (sortSelect.value === 'alpha') return a.querySelector('.subcategory-card-title').textContent.localeCompare(b.querySelector('.subcategory-card-title').textContent);
        if (sortSelect.value === 'count-high') {
          var getNum = function (el) { return parseInt(el.querySelector('.subcategory-card-count').textContent); };
          return getNum(b) - getNum(a);
        }
        return 0;
      });
      cards.forEach(function (card) { grid.appendChild(card); });
    });
  }
}

// ── Delivery charge calculator (mirrors backend) ─────────────────────
function calcDeliveryCharge(subtotal, district) {
  var insideDhaka = district && district.toLowerCase().indexOf('dhaka') > -1;
  if (insideDhaka) {
    if (subtotal <= 3000) return 100;
    if (subtotal <= 6000) return 120;
    return 120 + Math.ceil((subtotal - 6000) / 3000) * 20;
  }
  if (subtotal <= 3000) return 150;
  if (subtotal <= 7000) return 170;
  if (subtotal <= 12000) return 250;
  return 250 + Math.ceil((subtotal - 12000) / 5000) * 100;
}

// ── Checkout Page Init ───────────────────────────────────────────────
function initCheckout() {
  var container = document.getElementById('page-checkout');
  if (!container) return;

  // Render cart items from Cart module
  var items = Cart.items || [];
  var itemsContainer = container.querySelector('.flex.flex-col.gap-4');
  var summaryItems = container.querySelector('.cart-summary .flex.flex-col.gap-4');
  var subtotalRow = container.querySelector('.cart-summary-row:first-child span:last-child');
  var shippingRow = container.querySelector('.cart-summary-row:nth-child(2)');
  var taxRow = container.querySelector('.cart-summary-row:nth-child(3)');
  var totalRow = container.querySelector('.cart-summary-total span:last-child');
  var shippingDisplay = container.querySelector('#step-shipping-method .payment-method-desc');

  function updateSummary(district) {
    var subtotal = items.reduce(function (s, i) { return s + (i.price || 0) * (i.quantity || 1); }, 0);
    var deliveryCharge = calcDeliveryCharge(subtotal, district);
    var serviceCharge = 5;
    var total = subtotal + deliveryCharge + serviceCharge;

    if (subtotalRow) subtotalRow.textContent = '\u09F3' + subtotal.toLocaleString();
    if (shippingRow) {
      var label = district && district.toLowerCase().indexOf('dhaka') > -1 ? 'Inside Dhaka' : 'Outside Dhaka';
      shippingRow.innerHTML = '<span>Shipping <span style="font-size:var(--text-xs);color:var(--text-muted)">(' + label + ')</span></span><span style="font-weight:var(--weight-medium);color:var(--text);">\u09F3' + deliveryCharge.toLocaleString() + '</span>';
    }
    if (taxRow) taxRow.innerHTML = '<span>Service Charge</span><span style="color:var(--text);">\u09F3' + serviceCharge.toLocaleString() + '</span>';
    if (totalRow) totalRow.textContent = '\u09F3' + total.toLocaleString();
    if (shippingDisplay) {
      shippingDisplay.textContent = '3-5 business days \u2014 \u09F3' + deliveryCharge.toLocaleString() + ' (' + (district && district.toLowerCase().indexOf('dhaka') > -1 ? 'Inside Dhaka' : 'Outside Dhaka') + ')';
    }
  }

  // Render item rows
  if (items.length > 0 && itemsContainer) {
    var itemHtml = items.map(function (item) {
      var name = item.name || item.product?.name || 'Product';
      var qty = item.quantity || 1;
      var price = item.price || item.product?.price || 0;
      var img = item.image || item.product?.images?.[0] || 'https://placehold.co/60x60/1a1a1a/e6485a?text=Item';
      var variant = item.variantId ? 'Variant' : '';
      return '<div class="flex items-center gap-4"><img src="' + img + '" alt="' + name + '" style="width:60px;height:60px;border-radius:var(--radius-md);object-fit:cover;flex-shrink:0;"><div class="flex-1"><p class="text-sm font-semibold" style="color:var(--text);margin:0;">' + name + '</p><p class="text-xs text-muted" style="margin:2px 0 0;">' + (variant ? variant + ' \u00D7 ' + qty : '\u00D7 ' + qty) + '</p></div><span class="text-sm font-semibold" style="color:var(--text);">\u09F3' + (price * qty).toLocaleString() + '</span></div>';
    }).join('');
    itemsContainer.innerHTML = itemHtml;
  }
  if (summaryItems) {
    var sumHtml = items.map(function (item) {
      var name = item.name || item.product?.name || 'Product';
      var qty = item.quantity || 1;
      var price = item.price || item.product?.price || 0;
      var img = item.image || item.product?.images?.[0] || 'https://placehold.co/48x48/1a1a1a/e6485a?text=Item';
      return '<div class="flex items-center gap-3"><img src="' + img + '" alt="' + name + '" style="width:48px;height:48px;border-radius:var(--radius-sm);object-fit:cover;flex-shrink:0;"><div class="flex-1 min-w-0"><p class="text-xs font-semibold truncate" style="color:var(--text);margin:0;">' + name + '</p><p class="text-xs text-muted" style="margin:0;">\u00D7 ' + qty + '</p></div><span class="text-xs font-semibold" style="color:var(--text);">\u09F3' + (price * qty).toLocaleString() + '</span></div>';
    }).join('');
    summaryItems.innerHTML = sumHtml;
  }

  // Update summary on district change
  var districtSelect = document.getElementById('checkout-district') || container.querySelector('select[id*="district"], select[aria-label*="District"]');
  if (districtSelect) {
    if (districtSelect.value) updateSummary(districtSelect.value);
    districtSelect.addEventListener('change', function () { updateSummary(this.value); });
  } else {
    updateSummary('');
  }

  // Wire up district->delivery charge in cart.routes / orders.routes already handle backend
  // Set up payment method selection
  container.querySelectorAll('.payment-method').forEach(function (m) {
    m.addEventListener('click', function () {
      container.querySelectorAll('.payment-method').forEach(function (p) { p.classList.remove('active'); });
      this.classList.add('active');
    });
  });

  // Shipping method selection
  container.querySelectorAll('#step-shipping-method .payment-method').forEach(function (m) {
    m.addEventListener('click', function () {
      container.querySelectorAll('#step-shipping-method .payment-method').forEach(function (p) { p.classList.remove('active'); });
      this.classList.add('active');
    });
  });
}

function submitOrder() {
  var btn = document.getElementById('placeOrderBtn');
  var text = document.getElementById('placeOrderText');
  var errEl = document.getElementById('checkoutError');
  if (!errEl) return;
  errEl.style.display = 'none';

  var name = document.getElementById('checkout-name')?.value?.trim();
  var phone = document.getElementById('checkout-phone')?.value?.trim();
  var email = document.getElementById('checkout-email')?.value?.trim();
  var division = document.getElementById('checkout-division')?.value;
  var district = document.getElementById('checkout-district')?.value;
  var upazila = document.getElementById('checkout-upazila')?.value;
  var addressLine1 = document.getElementById('checkout-address')?.value?.trim() || document.querySelector('[placeholder*="House"]')?.value?.trim();
  var union = document.getElementById('checkout-union')?.value?.trim();

  if (!name || !phone || !division || !district || !addressLine1) {
    errEl.textContent = 'Please fill in all required fields (Name, Phone, Division, District, Address).';
    errEl.style.display = 'block';
    return;
  }

  var paymentMethod = 'cod';
  var methods = document.querySelectorAll('.payment-methods .payment-method');
  methods.forEach(function (m, idx) {
    if (m.classList.contains('active')) {
      var names = ['cod', 'bkash', 'nagad', 'rocket', 'sslcommerz', 'stripe'];
      paymentMethod = names[idx] || 'cod';
    }
  });

  var shippingAddress = {
    name: name,
    phone: phone,
    address: addressLine1,
    city: district,
    division: division,
    district: district,
    upazila: upazila || '',
    union: union || '',
    postal_code: '',
  };

  btn.disabled = true;
  text.textContent = 'Placing Order...';

  var token = localStorage.getItem('br_token');
  var headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = 'Bearer ' + token;

  fetch('/api/orders', {
    method: 'POST',
    headers: headers,
    body: JSON.stringify({
      shipping_address: shippingAddress,
      payment_method: paymentMethod,
      notes: '',
    }),
  }).then(function (r) { return r.json(); }).then(function (data) {
    if (data.success && data.data && data.data.order) {
      window.location.hash = '#order-success?order=' + encodeURIComponent(data.data.order.order_number || data.data.order.id);
    } else {
      errEl.textContent = data.message || 'Failed to place order. Please try again.';
      errEl.style.display = 'block';
      btn.disabled = false;
      text.textContent = 'Place Order';
    }
  }).catch(function () {
    errEl.textContent = 'Network error. Please check your connection.';
    errEl.style.display = 'block';
    btn.disabled = false;
    text.textContent = 'Place Order';
  });
}

// ── Product Detail Page Init ──────────────────────────────────────────
function initProductDetail() {
  var hash = window.location.hash;
  var qIdx = hash.indexOf('?');
  var params = qIdx > -1 ? new URLSearchParams(hash.substring(qIdx)) : new URLSearchParams();
  var id = params.get('id');
  if (!id) { id = new URLSearchParams(window.location.search).get('id'); }
  if (!id) return;

  var container = document.getElementById('page-product');
  if (!container) return;

  fetch('/api/products/' + id).then(function (r) { return r.json(); }).then(function (json) {
    if (!json.success || !json.data || !json.data.product) return;
    var p = json.data.product;
    var images = p.images || [];
    var thumbUrl = (images.find(function (i) { return i.is_primary; }) || images[0] || {}).url || p.thumbnail || 'https://placehold.co/800x800/1a1a1a/e6485a?text=Product';

    document.title = (p.name || 'Product') + ' | Bangalirhaat';

    var mainImg = document.getElementById('main-product-img');
    if (mainImg) { mainImg.src = thumbUrl; mainImg.alt = p.name; }

    var thumbContainer = container.querySelector('.product-gallery-thumbnails');
    if (thumbContainer && images.length > 1) {
      thumbContainer.innerHTML = images.map(function (img, i) {
        return '<button class="product-gallery-thumb' + (i === 0 ? ' active' : '') + '" role="option" aria-selected="' + (i === 0) + '"><img src="' + (img.url || thumbUrl) + '" alt="' + (img.alt_text || p.name) + '"></button>';
      }).join('');
      thumbContainer.querySelectorAll('.product-gallery-thumb').forEach(function (btn, idx) {
        btn.addEventListener('click', function () {
          thumbContainer.querySelectorAll('.product-gallery-thumb').forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          if (mainImg && images[idx]) mainImg.src = images[idx].url;
        });
      });
    }

    var brand = container.querySelector('.product-info-brand');
    if (brand) brand.textContent = p.brand_name || 'Bangalirhaat';
    var title = container.querySelector('.product-info-title');
    if (title) title.textContent = p.name;

    var ratingStars = container.querySelector('.product-info-rating .star-rating');
    if (ratingStars) {
      var avg = p.average_rating || p.review_count || 0;
      var rating = p.average_rating || 0;
      var stars = '';
      for (var s = 1; s <= 5; s++) stars += '<span class="star' + (s <= Math.round(rating) ? ' filled' : '') + '">&#9733;</span>';
      ratingStars.innerHTML = stars;
    }
    var ratingText = container.querySelector('.product-info-rating .text-sm.text-secondary');
    if (ratingText) ratingText.textContent = (p.average_rating || 0).toFixed(1);
    var reviewLink = container.querySelector('.product-info-rating a');
    if (reviewLink) reviewLink.textContent = (p.review_count || 0) + ' Reviews';

    var priceCurrent = container.querySelector('.product-info-price-current');
    if (priceCurrent) priceCurrent.textContent = '\u09F3' + Number(p.price).toLocaleString();
    var priceOrig = container.querySelector('.product-info-price-original');
    if (priceOrig) {
      if (p.compare_price && p.compare_price > p.price) {
        priceOrig.textContent = '\u09F3' + Number(p.compare_price).toLocaleString();
        priceOrig.style.display = '';
      } else { priceOrig.style.display = 'none'; }
    }
    var priceDisc = container.querySelector('.product-info-price-discount');
    if (priceDisc) {
      if (p.compare_price && p.compare_price > p.price) {
        var disc = Math.round((1 - p.price / p.compare_price) * 100);
        priceDisc.textContent = 'Save ' + disc + '%';
        priceDisc.style.display = '';
      } else { priceDisc.style.display = 'none'; }
    }

    var skuEl = container.querySelector('.product-info-price + .flex span:first-child strong');
    if (skuEl) skuEl.textContent = p.sku || 'N/A';

    var desc = container.querySelector('.product-info-description');
    if (desc) desc.textContent = p.description || '';

    var stockQty = p.stock_quantity !== undefined ? p.stock_quantity : (p.stock || 0);
    var outOfStock = stockQty <= 0;
    var stockBadge = container.querySelector('.flex.items-center.gap-2 .badge');
    var stockText = container.querySelector('.flex.items-center.gap-2 .text-xs');
    var addBtn = container.querySelector('.product-add-row .btn-primary');
    if (stockBadge) {
      stockBadge.className = 'badge ' + (outOfStock ? 'badge-danger' : 'badge-success') + ' badge-dot';
      stockBadge.textContent = outOfStock ? 'Out of Stock' : 'In Stock';
    }
    if (stockText) {
      if (outOfStock) stockText.textContent = 'This product is currently unavailable';
      else stockText.textContent = stockQty > 0 && stockQty <= 20 ? 'Only ' + stockQty + ' left — order soon!' : '';
    }
    if (addBtn && outOfStock) {
      addBtn.disabled = true;
      addBtn.className = 'btn btn-lg flex-1';
      addBtn.style.cssText = 'background:var(--muted,#e2e8f0);color:var(--text-muted,#94a3b8);cursor:not-allowed;border:none;opacity:0.7;';
      addBtn.innerHTML = 'Out of Stock';
    }
    var galleryMain = container.querySelector('.product-gallery-main');
    if (galleryMain && outOfStock) {
      galleryMain.style.position = 'relative';
      var obadge = document.createElement('div');
      obadge.className = 'product-detail-stockout-badge';
      obadge.innerHTML = '<span>Stock Out</span>';
      galleryMain.appendChild(obadge);
      if (mainImg) mainImg.style.opacity = '0.5';
    }

    var colorLabel = container.querySelector('.color-selector-label span');
    if (p.variants && p.variants.length > 0) {
      var colors = [];
      p.variants.forEach(function (v) { if (v.color && colors.indexOf(v.color) < 0) colors.push(v.color); });
      if (colors.length > 0 && colorLabel) colorLabel.textContent = colors[0];
    }

    var stickyPrice = container.querySelector('.product-sticky-bar .price span');
    if (stickyPrice) stickyPrice.textContent = '\u09F3' + Number(p.price).toLocaleString();

    // ── Quantity selector ──
    container.querySelectorAll('.quantity-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var val = container.querySelector('.quantity-value');
        if (!val) return;
        var q = parseInt(val.textContent) || 1;
        if (btn.textContent.trim() === '+') {
          q = Math.min(q + 1, 99);
        } else {
          q = Math.max(1, q - 1);
        }
        val.textContent = q;
      });
    });

    // ── Color selector ──
    container.querySelectorAll('.color-option').forEach(function (opt) {
      opt.addEventListener('click', function () {
        container.querySelectorAll('.color-option').forEach(function (o) { o.classList.remove('active'); o.setAttribute('aria-pressed', 'false'); });
        this.classList.add('active');
        this.setAttribute('aria-pressed', 'true');
        if (colorLabel) colorLabel.textContent = this.getAttribute('aria-label') || '';
      });
    });

    // ── Wishlist button ──
    var wishlistBtn = container.querySelector('.btn-outline svg[viewBox*="12 2v20"]') ? container.querySelector('.btn-outline svg[viewBox*="12 2v20"]').closest('button') : null;
    if (!wishlistBtn) {
      container.querySelectorAll('.btn-outline').forEach(function (b) {
        if (b.innerHTML.indexOf('Wishlist') > -1 || b.innerHTML.indexOf('12 2v20') > -1) wishlistBtn = b;
      });
    }
    if (wishlistBtn && p.id) {
      var isFav = Wishlist.items.some(function (i) { return String(i.product_id || i.productId || i.id || i) === String(p.id); });
      wishlistBtn.innerHTML = (isFav ? '❤️' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>') + ' ' + (isFav ? 'In Wishlist' : 'Wishlist');
      wishlistBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (isFav) {
          Wishlist.remove(p.id).then(function () {
            isFav = false;
            wishlistBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg> Wishlist';
            Toast.info('Removed from wishlist');
          });
        } else {
          Wishlist.add(p.id).then(function () {
            isFav = true;
            wishlistBtn.innerHTML = '❤️ In Wishlist';
            Toast.success('Added to wishlist');
          });
        }
      });
    }

    // ── Blouse option ──
    var blouseOption = document.getElementById('blouseOption');
    var blouseBtn = document.getElementById('blouseToggleBtn');
    if (blouseOption && blouseBtn) {
      var catName = (p.category_name || p.category || '').toLowerCase();
      var prodName = (p.name || '').toLowerCase();
      if (catName.indexOf('saree') > -1 || catName.indexOf('shari') > -1 || catName.indexOf('sharee') > -1 || prodName.indexOf('saree') > -1 || prodName.indexOf('shari') > -1) {
        blouseOption.style.display = '';
      }
      blouseBtn._selected = false;
      blouseBtn.addEventListener('click', function () {
        this._selected = !this._selected;
        this.classList.toggle('active', this._selected);
        this.textContent = this._selected ? '✓ Blouse Added (৳100)' : '+ Add Blouse (৳100)';
        this.setAttribute('aria-checked', this._selected);
      });
    }

    // ── Make Offer button ──
    var offerBtn = document.getElementById('makeOfferBtn');
    if (offerBtn && p.id) {
      offerBtn.addEventListener('click', function (e) {
        e.preventDefault();
        var token = localStorage.getItem('token') || localStorage.getItem('adminToken');
        if (!token) { alert('Please login to make an offer'); window.location.hash = '#login'; return; }
        var modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = '<div class="modal modal-sm"><div class="modal-header"><h3>Make an Offer \u2014 \u09A6\u09B0\u0995\u09B7\u0995\u09B7\u09BF</h3><button class="modal-close" onclick="this.closest(\'.modal-overlay\').remove()">&times;</button></div><div class="modal-body"><p style="font-size:var(--text-sm);color:var(--text-muted);margin-bottom:var(--space-4);">Current price: <strong style="color:var(--text);">\u09F3' + Number(p.price).toLocaleString() + '</strong></p><div class="form-group" style="margin-bottom:var(--space-3);"><label class="form-label">Your Offer Price (\u09F3)</label><input class="form-input" type="number" id="offerPrice" min="1" step="0.01" placeholder="Enter your price" style="font-size:var(--text-lg);font-weight:var(--weight-bold);"></div><div class="form-group" style="margin-bottom:var(--space-4);"><label class="form-label">Note (optional)</label><textarea class="form-input" id="offerNote" rows="2" placeholder="Add a note for the seller..."></textarea></div><div style="font-size:var(--text-xs);color:var(--text-muted);margin-bottom:var(--space-4);">Your offer will be reviewed by the seller within 24 hours.</div><button class="btn btn-primary w-full" id="submitOfferBtn">Submit Offer</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function (ev) { if (ev.target === modal) modal.remove(); });
        document.getElementById('submitOfferBtn').addEventListener('click', async function () {
          var price = parseFloat(document.getElementById('offerPrice').value);
          var note = document.getElementById('offerNote').value;
          if (!price || price <= 0) { alert('Please enter a valid offer price'); return; }
          if (price >= p.price) { alert('Your offer must be lower than \u09F3' + Number(p.price).toLocaleString()); return; }
          this.disabled = true; this.textContent = 'Submitting...';
          try {
            var r = await fetch('/api/bargaining/offers', {
              method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
              body: JSON.stringify({ product_id: p.id, offered_price: price, buyer_note: note })
            });
            var j = await r.json();
            if (j.success) { modal.remove(); alert('\u2705 ' + j.message); }
            else { alert('\u274C ' + (j.message || 'Failed to submit offer')); this.disabled = false; this.textContent = 'Submit Offer'; }
          } catch (e) { alert('Error submitting offer'); this.disabled = false; this.textContent = 'Submit Offer'; }
        });
      });
    }

    // ── Add to Cart (blouse-aware) ──
    function handleAddToCart(qtyEl) {
      var qty = 1;
      if (qtyEl) qty = parseInt(qtyEl.textContent) || 1;
      var qtyFromSelector = container.querySelector('.quantity-value');
      if (qtyFromSelector) qty = parseInt(qtyFromSelector.textContent) || 1;
      Cart.addItem(p.id || p._id, qty);
      if (blouseBtn && blouseBtn._selected) {
        // Add blouse addon as separate cart item
        if (!Auth.isAuthenticated()) {
          var local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
          local.push({
            productId: 'blouse_' + (p.id || p._id),
            variantId: null,
            quantity: qty,
            price: 100,
            name: 'Blouse for ' + p.name,
            image: thumbUrl
          });
          localStorage.setItem('br_guest_cart', JSON.stringify(local));
          Cart.items = local;
          Cart.count = local.reduce(function (s, i) { return s + i.quantity; }, 0);
          Cart.total = local.reduce(function (s, i) { return s + (i.price || 0) * i.quantity; }, 0);
          Cart._updateUI();
          Toast.success('Blouse added to cart!');
        } else {
          Toast.info('Blouse addon is only available for guest checkout currently.');
        }
      }
    }

    var addCartBtns = container.querySelectorAll('.product-add-row .btn-primary, .product-sticky-bar .btn-primary');
    addCartBtns.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        if (outOfStock) return;
        handleAddToCart();
      });
    });
  }).catch(function (e) { console.error('Product detail init failed:', e); });
}

// ── Global Newsletter Handler ──────────────────────────────────────────
document.addEventListener('click', function (e) {
  var btn = e.target.closest('button');
  if (!btn) return;
  var section = btn.closest('[aria-label="Newsletter signup"]') || btn.closest('section');
  if (!section) return;
  if (btn.textContent.trim() !== 'Subscribe') return;
  var input = section.querySelector('input[type="email"]');
  if (!input || !input.value.trim()) { alert('Please enter your email address.'); return; }
  var email = input.value.trim();
  var origHTML = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = 'Subscribing...';
  fetch('/api/newsletter/subscribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email }),
  }).then(function (r) { return r.json(); }).then(function (data) {
    if (data.success) {
      btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:-2px;margin-right:4px;"><polyline points="20,6 9,17 4,12"/></svg> Subscribed';
      input.value = '';
      setTimeout(function () { btn.innerHTML = origHTML; btn.disabled = false; }, 3000);
    } else {
      alert(data.message || 'Subscription failed.');
      btn.innerHTML = origHTML;
      btn.disabled = false;
    }
  }).catch(function () {
    alert('Network error. Please try again.');
    btn.innerHTML = origHTML;
    btn.disabled = false;
  });
});

// ── Admin Panel ── Bangalirhaat ──────────────────────────────────────────────
const AdminAPI = {
  BASE_URL: '/api/admin',
  token: null,
  async request(method, path, body) {
    const opts = { method, headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.token}` } };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`${this.BASE_URL}${path}`, opts);
    const data = await res.json();
    if (!data.success && res.status >= 400) throw new Error(data.message || 'Request failed');
    return data;
  },
  get(p) { return this.request('GET', p); },
  post(p, b) { return this.request('POST', p, b); },
  put(p, b) { return this.request('PUT', p, b); },
  del(p) { return this.request('DELETE', p); },
};

// ── Admin Auth ──────────────────────────────────────────────────────────────
const AdminAuth = {
  async login(email, password) {
    const res = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const data = await res.json();
    if (data.success) { AdminAPI.token = data.data.accessToken; localStorage.setItem('adminToken', data.data.accessToken); localStorage.setItem('adminUser', JSON.stringify(data.data.user)); }
    return data;
  },
  async logout() {
    await fetch('/api/auth/logout', { method: 'POST', headers: { 'Authorization': `Bearer ${AdminAPI.token}` } });
    AdminAPI.token = null; localStorage.removeItem('adminToken'); localStorage.removeItem('adminUser');
    if (!document.getElementById('page-login')) showLoginPage();
  },
  checkAuth() {
    const token = localStorage.getItem('adminToken');
    const user = JSON.parse(localStorage.getItem('adminUser') || 'null');
    if (token && user && (user.role === 'admin' || user.role === 'super_admin')) {
      AdminAPI.token = token; return user;
    }
    return null;
  }
};

// ── Helper ──────────────────────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }
function qs(s, p) { return (p || document).querySelector(s); }
function qsa(s, p) { return (p || document).querySelectorAll(s); }
function esc(str) { const d = document.createElement('div'); d.textContent = str; return d.innerHTML; }
function dateStr(d) { return new Date(d).toLocaleDateString('en-BD', { day: '2-digit', month: 'short', year: 'numeric' }); }
function timeAgo(d) { const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000); if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + 'm ago'; if (s < 86400) return Math.floor(s / 3600) + 'h ago'; return Math.floor(s / 86400) + 'd ago'; }
function nf(num) { return new Intl.NumberFormat('en-IN').format(num || 0); }
function currency(num) { return '৳' + nf(num); }
function showToast(msg, type = 'success') { const c = $('toastContainer'); if (!c) return; const t = document.createElement('div'); t.className = `toast toast-${type}`; t.innerHTML = `<div class="toast-content">${esc(msg)}</div><button class="toast-close" onclick="this.parentElement.remove()">&times;</button>`; c.appendChild(t); setTimeout(() => t.remove(), 4000); }
function showConfirm(title, msg) { return new Promise(resolve => { const d = $('confirmDialog'); $('confirmTitle').textContent = title; $('confirmMessage').textContent = msg; d.classList.add('active'); $('confirmAction').onclick = () => { d.classList.remove('active'); resolve(true); }; qs('.modal-close', d).onclick = () => { d.classList.remove('active'); resolve(false); }; }); }
function loading(btn, state) { if (!btn) return; if (state) { btn._orig = btn.innerHTML; btn.innerHTML = '<span class="spinner-sm"></span> Loading...'; btn.disabled = true; } else { btn.innerHTML = btn._orig || btn.innerHTML; btn.disabled = false; } }
function pagination(total, page, limit, fn) {
  const pages = Math.ceil(total / limit);
  if (pages <= 1) return '';
  let html = '<div class="pagination">';
  html += `<button class="page-btn" onclick="${fn}(${page - 1})" ${page <= 1 ? 'disabled' : ''}>‹</button>`;
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) {
    html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="${fn}(${i})">${i}</button>`;
  }
  html += `<button class="page-btn" onclick="${fn}(${page + 1})" ${page >= pages ? 'disabled' : ''}>›</button>`;
  html += '</div>';
  return html;
}

// ── Page Router ─────────────────────────────────────────────────────────────
let currentPage = 'dashboard-overview';
const pageCache = {};

function navigateTo(page) {
  currentPage = page;
  qsa('.admin-nav-item').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  qsa('.admin-page').forEach(el => el.classList.remove('active'));
  let target = $(`page-${page}`);
  if (!target) {
    target = document.createElement('div');
    target.id = `page-${page}`;
    target.className = 'admin-page';
    $('adminContent').appendChild(target);
  }
  target.classList.add('active');
  if (!pageCache[page]) { pageCache[page] = true; initPage(page); }
}

function initPage(page) {
  const handlers = {
    'dashboard-overview': initDashboard,
    'orders-all': () => initOrdersList('all'),
    'orders-pending': () => initOrdersList('pending'),
    'orders-processing': () => initOrdersList('processing'),
    'orders-shipped': () => initOrdersList('shipped'),
    'orders-delivered': () => initOrdersList('delivered'),
    'orders-returns': () => initOrdersList('returned'),
    'orders-cancelled': () => initOrdersList('cancelled'),
    'products': initProducts,
    'add-product': initAddProduct,
    'categories': initCategories,
    'brands': initBrands,
    'low-stock': initLowStock,
    'shipment': initShipments,
    'bulk-courier-send': initBulkCourierSend,
    'invoice-print': initInvoicePrint,
    'invoice-bulk-print': initBulkInvoicePrint,
    'delivery': initDelivery,
    'delivery-zones': initDeliveryZones,
    'settings-courier': initCourierSettings,
    'customers-all': () => initCustomers('all'),
    'customers-vip': () => initCustomers('vip'),
    'customers-blacklist': () => initCustomers('blacklist'),
    'marketing-coupons': initCoupons,
    'marketing-campaigns': initCampaigns,
    'flash-sales': initFlashSales,
    'settings-company': initCompanySettings,
    'settings-invoice': initInvoiceSettings,
    'settings-theme': initThemeSettings,
    'settings-analytics': initAnalyticsSettings,
    'settings-payment': initPaymentSettings,
    'settings-tax': initTaxSettings,
    'settings-email-templates': initEmailTemplates,
    'abandoned-cart': initAbandonedCart,
    'banners': initBanners,
    'reviews': initAdminReviews,
    'media': initMedia,
    'staff': initStaff,
    'audit-logs': initAuditLogs,
    'login-history': initLoginHistory,
    'expenses': initExpenses,
    'income': initFinanceOverview,
    'invoices': () => initOrdersList('delivered'),
    'finance-overview': initFinanceOverview,
    'report-daily': () => initReports('daily'),
    'report-weekly': () => initReports('weekly'),
    'report-monthly': () => initReports('monthly'),
    'report-yearly': () => initReports('yearly'),
    'report-top-products': initTopProductsReport,
    'report-top-customers': initTopCustomersReport,
  };
  if (handlers[page]) handlers[page]();
}

// ── DASHBOARD ───────────────────────────────────────────────────────────────
async function initDashboard() {
  try {
    const res = await AdminAPI.get('/dashboard');
    const d = res.data;
    $('statRevenue').textContent = currency(d.today_revenue);
    $('statOrders').textContent = nf(d.today_orders);
    if ($('statCustomers')) $('statCustomers').textContent = nf(d.new_customers_today);
    if ($('statPending')) $('statPending').textContent = nf(d.pending_orders);
    // Recent orders
    if ($('recentOrdersBody')) {
      var sb = { pending: 'badge-warning', confirmed: 'badge-info', processing: 'badge-info', shipped: 'badge-primary', delivered: 'badge-success', cancelled: 'badge-danger', returned: 'badge-secondary' };
      var recentOrders = d.recent_orders || [];
      $('recentOrdersBody').innerHTML = recentOrders.length ? recentOrders.map(function(o) {
        return '<tr><td style="font-weight:var(--weight-semibold);">#' + esc(o.order_number) + '</td><td>' + esc(o.customer_name || 'N/A') + '</td><td style="text-align:right;font-weight:var(--weight-semibold);">' + currency(o.total) + '</td><td><span class="badge ' + (sb[o.status] || 'badge-secondary') + ' badge-dot">' + esc(o.status) + '</span></td><td style="color:var(--text-muted);">' + dateStr(o.created_at) + '</td></tr>';
      }).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No recent orders</td></tr>';
    }
    // Top products
    if ($('topProductsList')) {
      var top = d.top_products || [];
      $('topProductsList').innerHTML = top.length ? top.map(function(p, i) {
        var border = i < top.length - 1 ? 'border-bottom:1px solid var(--divider);' : '';
        return '<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) 0;' + border + '"><span style="font-size:var(--text-sm);font-weight:var(--weight-semibold);min-width:24px;">' + (i + 1) + '</span><div style="flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);">' + esc(p.name || p.product_name || 'Product') + '</div><div style="font-size:var(--text-xs);color:var(--text-muted);">' + (p.quantity_sold || p.total_sold || 0) + ' sold</div></div><div style="font-size:var(--text-sm);font-weight:var(--weight-bold);">' + currency(p.revenue || p.total_revenue || 0) + '</div></div>';
      }).join('') : '<p style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">No product data yet</p>';
    }
    // Low stock alerts
    if ($('lowStockList')) {
      var low = d.low_stock_products || [];
      $('lowStockList').innerHTML = low.length ? low.map(function(p, i) {
        var level = p.stock_quantity <= 2 ? 'danger' : p.stock_quantity <= 5 ? 'warning' : 'info';
        var label = p.stock_quantity <= 2 ? 'Critical' : p.stock_quantity <= 5 ? 'Low' : 'Watch';
        var dotColor = level === 'danger' ? 'var(--color-danger)' : level === 'warning' ? 'var(--color-warning)' : 'var(--color-info)';
        var border = i < low.length - 1 ? 'border-bottom:1px solid var(--divider);' : '';
        return '<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) 0;' + border + '"><div style="width:8px;height:8px;border-radius:50%;background:' + dotColor + ';flex-shrink:0;"></div><div style="flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);">' + esc(p.name) + '</div><div style="font-size:var(--text-xs);color:var(--text-muted);">' + p.stock_quantity + ' remaining</div></div><span class="badge badge-' + level + '">' + label + '</span></div>';
      }).join('') : '<p style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">All products sufficiently stocked</p>';
    }
  } catch (e) { console.error('Dashboard load error:', e); }
}

// ── ORDERS ──────────────────────────────────────────────────────────────────
function renderOrderRow(o) {
  const statusBadge = { pending: 'badge-warning', confirmed: 'badge-info', processing: 'badge-info', shipped: 'badge-primary', delivered: 'badge-success', cancelled: 'badge-danger', returned: 'badge-secondary' };
  return `<tr>
    <td style="font-weight:var(--weight-semibold);">#${esc(o.order_number)}</td>
    <td>${esc(o.customer_name || 'N/A')}</td>
    <td style="text-align:right;font-weight:var(--weight-semibold);">${currency(o.total)}</td>
    <td><span class="badge ${statusBadge[o.status] || 'badge-secondary'} badge-dot">${esc(o.status)}</span></td>
    <td style="color:var(--text-muted);font-size:var(--text-xs);">${dateStr(o.created_at)}</td>
    <td>
      <div class="admin-actions">
        <button class="btn btn-sm btn-ghost" onclick="viewOrder(${o.id})">View</button>
        <button class="btn btn-sm btn-ghost" onclick="editOrderStatus(${o.id})">Status</button>
      </div>
    </td>
  </tr>`;
}

async function initOrdersList(status) {
  const el = $(`page-orders-${status}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${status.charAt(0).toUpperCase() + status.slice(1)} Orders</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover" id="ordersTable${status}"><thead><tr><th>Order #</th><th>Customer</th><th style="text-align:right;">Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="ordersBody${status}"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div><div id="ordersPagination${status}" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadOrdersPage(status, 1);
}

async function loadOrdersPage(status, page) {
  const params = new URLSearchParams({ limit: '15', page: String(page) });
  if (status !== 'all') params.set('status', status === 'processing' ? 'confirmed' : status);
  try {
    const res = await AdminAPI.get(`/orders?${params}`);
    const tbody = $(`ordersBody${status}`);
    if (!tbody) return;
    tbody.innerHTML = res.data.items.length ? res.data.items.map(renderOrderRow).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No orders found</td></tr>';
    const pag = $(`ordersPagination${status}`);
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, `loadOrdersPage('${status}', `);
  } catch (e) { console.error(e); }
}

async function viewOrder(id) {
  try {
    const res = await AdminAPI.get(`/orders/${id}`);
    const o = res.data.order;
    const items = o.items.map(i => `<tr><td>${esc(i.product_name)}</td><td>${i.quantity}</td><td style="text-align:right;">${currency(i.price)}</td><td style="text-align:right;">${currency(i.total)}</td></tr>`).join('');
    showModal(`Order #${o.order_number}`, `<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);margin-bottom:var(--space-4);">
      <div><strong>Status:</strong> ${o.status}</div><div><strong>Payment:</strong> ${o.payment_status}</div>
      <div><strong>Method:</strong> ${o.payment_method || 'N/A'}</div><div><strong>Total:</strong> ${currency(o.total)}</div>
    </div><table class="table"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${items}</tbody></table>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function editOrderStatus(id) {
  const statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned'];
  const opts = statuses.map(s => `<option value="${s}">${s}</option>`).join('');
  showModal('Update Order Status', `<form id="statusForm" onsubmit="updateOrderStatus(${id}, this);return false">
    <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status" required>${opts}</select></div>
    <div class="form-group"><label class="form-label">Note (optional)</label><textarea class="form-input" name="note" rows="2"></textarea></div>
    <button type="submit" class="btn btn-primary w-full" id="statusBtn">Update Status</button>
  </form>`);
}

async function updateOrderStatus(id, form) {
  const btn = $('statusBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    await AdminAPI.put(`/orders/${id}/status`, { status: fd.get('status'), note: fd.get('note') || null });
    showToast('Order status updated');
    document.querySelector('.modal-overlay.active')?.classList.remove('active');
    loadOrdersPage(currentPage.replace('orders-', ''), 1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── PRODUCTS ────────────────────────────────────────────────────────────────
async function initProducts() {
  const el = $('page-products');
  el.innerHTML = `<div class="admin-page-header"><h1>Products</h1><button class="btn btn-primary" onclick="navigateTo('add-product')">+ Add Product</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>SKU</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody id="productsBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div><div id="productsPagination" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadProductsPage(1);
}

async function loadProductsPage(page) {
  try {
    const res = await AdminAPI.get(`/products?limit=15&page=${page}`);
    const tbody = $('productsBody');
    tbody.innerHTML = res.data.items.map(p => `<tr>
      <td><div style="display:flex;align-items:center;gap:var(--space-3);"><div style="width:40px;height:40px;border-radius:var(--radius);background:var(--surface-secondary);overflow:hidden;"><img src="${p.thumbnail || ''}" alt="" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'"></div><div><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(p.category_name || '')}</div></div></div></td>
      <td style="font-size:var(--text-xs);">${esc(p.sku || '-')}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(p.price)}</td>
      <td><span class="${p.stock_quantity < p.low_stock_threshold ? 'badge badge-danger' : 'badge badge-success'}">${p.stock_quantity}</span></td>
      <td><span class="badge ${p.is_active ? 'badge-success' : 'badge-secondary'}">${p.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="editProduct(${p.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteProduct(${p.id},'${esc(p.name)}')">Delete</button></div></td>
    </tr>`).join('');
    const pag = $('productsPagination');
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, 'loadProductsPage');
  } catch (e) { showToast(e.message, 'error'); }
}

async function initAddProduct() {
  const cats = await AdminAPI.get('/categories');
  const catOpts = cats.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  const brands = await AdminAPI.get('/brands');
  const brandOpts = [{ id: '', name: 'None' }, ...brands.data.items].map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('');

  $('page-add-product').innerHTML = `<div class="admin-page-header"><h1>Add Product</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form id="addProductForm" onsubmit="saveProduct(this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Product Name *</label><input class="form-input" name="name" required></div>
      <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" placeholder="Leave blank for auto-generate"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Category *</label><select class="form-select" name="category_id" required>${catOpts}</select></div>
      <div class="form-group"><label class="form-label">Brand</label><select class="form-select" name="brand_id">${brandOpts}</select></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Price *</label><input class="form-input" name="price" type="number" step="0.01" required></div>
      <div class="form-group"><label class="form-label">Compare Price</label><input class="form-input" name="compare_price" type="number" step="0.01"></div>
      <div class="form-group"><label class="form-label">SKU</label><input class="form-input" name="sku"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Stock Quantity</label><input class="form-input" name="stock_quantity" type="number" value="0"></div>
      <div class="form-group"><label class="form-label">Low Stock Threshold</label><input class="form-input" name="low_stock_threshold" type="number" value="5"></div></div>
      <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="4"></textarea></div>
      <div class="form-group"><label class="form-label">Short Description</label><textarea class="form-input" name="short_description" rows="2"></textarea></div>
      <div class="form-row"><div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_featured" value="1"> Featured Product</label></div>
      <div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_active" value="1" checked> Active</label></div></div>
      <button type="submit" class="btn btn-primary" id="saveProductBtn">Save Product</button>
    </form>
  </div></div>`;
}

async function saveProduct(form) {
  const btn = $('saveProductBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());
    data.price = parseFloat(data.price) || 0;
    data.compare_price = data.compare_price ? parseFloat(data.compare_price) : null;
    data.category_id = parseInt(data.category_id);
    data.brand_id = data.brand_id ? parseInt(data.brand_id) : null;
    data.stock_quantity = parseInt(data.stock_quantity) || 0;
    data.is_featured = data.is_featured ? 1 : 0;
    data.is_active = data.is_active ? 1 : 0;
    await AdminAPI.post('/products', data);
    showToast('Product created successfully');
    navigateTo('products');
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

async function deleteProduct(id, name) {
  if (!await showConfirm('Delete Product', `Are you sure you want to delete "${name}"?`)) return;
  try { await AdminAPI.del(`/products/${id}`); showToast('Product deleted'); loadProductsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function editProduct(id) {
  try {
    const res = await AdminAPI.get(`/products/${id}`);
    const p = res.data.product;
    const cats = await AdminAPI.get('/categories');
    const catOpts = cats.data.items.map(c => `<option value="${c.id}" ${c.id === p.category_id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
    const brands = await AdminAPI.get('/brands');
    const brandOpts = [{ id: '', name: 'None' }, ...brands.data.items].map(b => `<option value="${b.id}" ${b.id === p.brand_id ? 'selected' : ''}>${esc(b.name)}</option>`).join('');

    showModal('Edit Product', `<form id="editProductForm" onsubmit="updateProduct(${id}, this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Product Name *</label><input class="form-input" name="name" value="${esc(p.name)}" required></div>
      <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" value="${esc(p.slug)}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Category *</label><select class="form-select" name="category_id" required>${catOpts}</select></div>
      <div class="form-group"><label class="form-label">Brand</label><select class="form-select" name="brand_id">${brandOpts}</select></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Price *</label><input class="form-input" name="price" type="number" step="0.01" value="${p.price}" required></div>
      <div class="form-group"><label class="form-label">Compare Price</label><input class="form-input" name="compare_price" type="number" step="0.01" value="${p.compare_price || ''}"></div>
      <div class="form-group"><label class="form-label">SKU</label><input class="form-input" name="sku" value="${esc(p.sku || '')}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Stock Quantity</label><input class="form-input" name="stock_quantity" type="number" value="${p.stock_quantity || 0}"></div>
      <div class="form-group"><label class="form-label">Low Stock Threshold</label><input class="form-input" name="low_stock_threshold" type="number" value="${p.low_stock_threshold || 5}"></div></div>
      <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="4">${esc(p.description || '')}</textarea></div>
      <div class="form-row"><div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_featured" value="1" ${p.is_featured ? 'checked' : ''}> Featured</label></div>
      <div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_active" value="1" ${p.is_active ? 'checked' : ''}> Active</label></div></div>
      <button type="submit" class="btn btn-primary w-full" id="editProductBtn">Update Product</button>
    </form>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateProduct(id, form) {
  const btn = $('editProductBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());
    data.price = parseFloat(data.price) || 0;
    data.compare_price = data.compare_price ? parseFloat(data.compare_price) : null;
    data.category_id = parseInt(data.category_id);
    data.brand_id = data.brand_id ? parseInt(data.brand_id) : null;
    data.stock_quantity = parseInt(data.stock_quantity) || 0;
    data.is_featured = data.is_featured ? 1 : 0;
    data.is_active = data.is_active ? 1 : 0;
    await AdminAPI.put(`/products/${id}`, data);
    showToast('Product updated successfully');
    qs('.modal-overlay.active')?.classList.remove('active');
    loadProductsPage(1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── CATEGORIES ──────────────────────────────────────────────────────────────
async function initCategories() {
  const el = $('page-categories');
  el.innerHTML = `<div class="admin-page-header"><h1>Categories</h1><button class="btn btn-primary" onclick="showAddCategory()">+ Add Category</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Image</th><th>Name</th><th>Slug</th><th>Order</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody id="categoriesBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/categories');
    $('categoriesBody').innerHTML = res.data.items.map(c => `<tr>
      <td>${c.image ? `<img src="${esc(c.image)}" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:var(--radius-sm);display:block;">` : `<div style="width:48px;height:48px;border-radius:var(--radius-sm);background:var(--glass-bg);display:flex;align-items:center;justify-content:center;font-size:20px;">📁</div>`}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.name)}${c.parent_name ? `<br><span style="font-size:var(--text-xs);color:var(--text-muted);">Parent: ${esc(c.parent_name)}</span>` : ''}</div></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${esc(c.slug)}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);text-align:center;">${c.sort_order}</td>
      <td style="text-align:center;">${c.product_count || 0}</td>
      <td><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditCategory(${c.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteCategory(${c.id},'${esc(c.name)}')">Delete</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

async function showAddCategory() {
  const parents = await fetchParentCategories();
  const parentOpts = '<option value="">None (top level)</option>' + parents.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  showModal('Add Category', `<form id="catForm" onsubmit="saveCategory(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" id="catName" required></div>
    <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" id="catSlug" placeholder="Auto-generated from name"></div>
    <div class="form-group"><label class="form-label">Image URL</label><input class="form-input" name="image" id="catImage" placeholder="https://example.com/image.jpg">
      <div id="catImagePreview" style="margin-top:8px;display:none;"><img src="" alt="" style="max-width:120px;max-height:80px;border-radius:var(--radius-sm);border:1px solid var(--border);"></div>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3"></textarea></div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Parent Category</label><select class="form-input" name="parent_id">${parentOpts}</select></div>
      <div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="0" min="0"></div>
    </div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Meta Title</label><input class="form-input" name="meta_title"></div>
      <div class="form-group"><label class="form-label">Meta Description</label><input class="form-input" name="meta_description"></div>
    </div>
    <div class="form-group" style="display:flex;align-items:center;gap:var(--space-2);"><input type="checkbox" name="is_active" id="catActive" checked value="1" style="width:18px;height:18px;"><label for="catActive" style="margin:0;">Active</label></div>
    <button type="submit" class="btn btn-primary w-full">Save Category</button>
  </form>`);
  const imgInput = $('catImage');
  const preview = $('catImagePreview');
  if (imgInput) imgInput.addEventListener('input', () => { if (imgInput.value) { preview.style.display = 'block'; preview.querySelector('img').src = imgInput.value; } else { preview.style.display = 'none'; } });
  const nameInput = $('catName');
  const slugInput = $('catSlug');
  if (nameInput && slugInput) nameInput.addEventListener('input', () => { if (!slugInput.dataset.touched) slugInput.value = nameInput.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); });
  if (slugInput) slugInput.addEventListener('input', () => slugInput.dataset.touched = '1');
}

async function showEditCategory(id) {
  const [parents, catRes] = await Promise.all([fetchParentCategories(), AdminAPI.get('/categories')]);
  const cat = (catRes.data.items || []).find(c => c.id === id);
  if (!cat) { showToast('Category not found', 'error'); return; }
  const parentOpts = '<option value="">None (top level)</option>' + parents.filter(p => p.id !== id).map(p => `<option value="${p.id}"${p.id === cat.parent_id ? ' selected' : ''}>${esc(p.name)}</option>`).join('');
  showModal('Edit Category', `<form id="catForm" onsubmit="saveCategory(this,${id});return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" id="catName" value="${esc(cat.name)}" required></div>
    <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" id="catSlug" value="${esc(cat.slug || '')}"></div>
    <div class="form-group"><label class="form-label">Image URL</label><input class="form-input" name="image" id="catImage" value="${esc(cat.image || '')}" placeholder="https://example.com/image.jpg">
      <div id="catImagePreview" style="margin-top:8px;${cat.image ? '' : 'display:none;'}"><img src="${esc(cat.image || '')}" alt="" style="max-width:120px;max-height:80px;border-radius:var(--radius-sm);border:1px solid var(--border);"></div>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3">${esc(cat.description || '')}</textarea></div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Parent Category</label><select class="form-input" name="parent_id">${parentOpts}</select></div>
      <div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="${cat.sort_order}" min="0"></div>
    </div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Meta Title</label><input class="form-input" name="meta_title" value="${esc(cat.meta_title || '')}"></div>
      <div class="form-group"><label class="form-label">Meta Description</label><input class="form-input" name="meta_description" value="${esc(cat.meta_description || '')}"></div>
    </div>
    <div class="form-group" style="display:flex;align-items:center;gap:var(--space-2);"><input type="checkbox" name="is_active" id="catActive" value="1"${cat.is_active ? ' checked' : ''} style="width:18px;height:18px;"><label for="catActive" style="margin:0;">Active</label></div>
    <button type="submit" class="btn btn-primary w-full">Update Category</button>
  </form>`);
  const imgInput = $('catImage');
  const preview = $('catImagePreview');
  if (imgInput && preview) imgInput.addEventListener('input', () => { if (imgInput.value) { preview.style.display = 'block'; preview.querySelector('img').src = imgInput.value; } else { preview.style.display = 'none'; } });
}

async function fetchParentCategories() {
  try {
    const res = await AdminAPI.get('/categories');
    return (res.data.items || []).filter(c => !c.parent_id);
  } catch { return []; }
}

async function saveCategory(form, id) {
  const fd = new FormData(form);
  const data = Object.fromEntries(fd);
  if (data.is_active === '1') data.is_active = 1; else data.is_active = 0;
  if (!data.parent_id) data.parent_id = null;
  if (!data.image) data.image = null;
  if (data.sort_order) data.sort_order = parseInt(data.sort_order);
  try {
    if (id) { await AdminAPI.put('/categories/' + id, data); showToast('Category updated'); }
    else { await AdminAPI.post('/categories', data); showToast('Category created'); }
    qs('.modal-overlay.active')?.classList.remove('active');
    initCategories();
  } catch (e) { showToast(e.message, 'error'); }
}

async function deleteCategory(id, name) {
  if (!confirm(`Delete category "${name}"?\nThis cannot be undone. Categories with subcategories or products cannot be deleted.`)) return;
  try {
    await AdminAPI.del('/categories/' + id);
    showToast('Category deleted');
    initCategories();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BRANDS ──────────────────────────────────────────────────────────────────
async function initBrands() {
  const el = $('page-brands');
  el.innerHTML = `<div class="admin-page-header"><h1>Brands</h1><button class="btn btn-primary" onclick="showAddBrand()">+ Add Brand</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody id="brandsBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/brands');
    $('brandsBody').innerHTML = res.data.items.map(b => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(b.name)}</div></td>
      <td>${b.product_count || 0}</td>
      <td><span class="badge ${b.is_active ? 'badge-success' : 'badge-secondary'}">${b.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditBrand(${b.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteBrand(${b.id})">Delete</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddBrand() {
  showModal('Add Brand', `<form id="brandForm" onsubmit="saveBrand(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveBrand(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/brands', Object.fromEntries(fd)); showToast('Brand created'); qs('.modal-overlay.active')?.classList.remove('active'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── LOW STOCK ───────────────────────────────────────────────────────────────
async function initLowStock() {
  const el = $('page-low-stock');
  el.innerHTML = `<div class="admin-page-header"><h1>Low Stock Products</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>Stock</th><th>Threshold</th><th>Status</th></tr></thead><tbody id="lowStockBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/inventory/low-stock');
    $('lowStockBody').innerHTML = res.data.items.map(p => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(p.sku || '')}</div></td>
      <td><span class="badge ${p.stock_quantity === 0 ? 'badge-danger' : 'badge-warning'}">${p.stock_quantity}</span></td>
      <td>${p.low_stock_threshold}</td>
      <td><span class="badge ${p.stock_quantity === 0 ? 'badge-danger' : 'badge-warning'}">${p.stock_quantity === 0 ? 'Out of Stock' : 'Low Stock'}</span></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── CUSTOMERS ────────────────────────────────────────────────────────────────
async function initCustomers(type) {
  const el = $(`page-customers-${type}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${type === 'all' ? 'All' : type === 'vip' ? 'VIP' : 'Blacklisted'} Customers</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Customer</th><th>Email</th><th>Phone</th><th>Orders</th><th>Spent</th><th>Actions</th></tr></thead><tbody id="customersBody${type}"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get(`/customers?${type === 'vip' ? 'vip=1' : type === 'blacklist' ? 'blacklisted=1' : ''}`);
    $(`customersBody${type}`).innerHTML = (res.data.items || []).map(c => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.first_name + ' ' + c.last_name)}</div></td>
      <td style="font-size:var(--text-xs);">${esc(c.email)}</td>
      <td>${c.phone || '-'}</td>
      <td>${c.total_orders || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.total_spent || 0)}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="viewCustomer(${c.id})">View</button></div></td>
    </tr>`).join('') || '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No customers found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── SHIPMENTS ────────────────────────────────────────────────────────────────
async function initShipments() {
  const el = $('page-shipment');
  el.innerHTML = `<div class="admin-page-header"><h1>Shipments</h1>
    <div style="display:flex;gap:var(--space-3);">
      <select class="form-select" id="shipmentFilter" style="width:auto;min-width:140px;" onchange="loadShipmentsPage(1)">
        <option value="">All Status</option><option value="pending">Pending</option><option value="in_transit">In Transit</option><option value="delivered">Delivered</option><option value="returned">Returned</option><option value="cancelled">Cancelled</option>
      </select>
      <button class="btn btn-primary" onclick="showCreateShipment()">+ New Shipment</button>
      <button class="btn btn-outline" onclick="syncShipments()">Sync Tracking</button>
    </div>
  </div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Consignment ID</th><th>Order</th><th>Courier</th><th>Tracking</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="shipmentsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>
  <div id="shipmentsPagination" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadShipmentsPage(1);
}

async function loadShipmentsPage(page) {
  try {
    const status = ($('shipmentFilter')?.value || '');
    const params = new URLSearchParams({ limit: '15', page: String(page) });
    if (status) params.set('status', status);
    const res = await AdminAPI.get(`/shipments?${params}`);
    const tbody = $('shipmentsBody');
    const statusBadge = { pending: 'badge-warning', confirmed: 'badge-info', picked: 'badge-primary', in_transit: 'badge-info', out_for_delivery: 'badge-primary', delivered: 'badge-success', returned: 'badge-secondary', cancelled: 'badge-danger' };
    tbody.innerHTML = res.data.items.map(s => `<tr>
      <td style="font-weight:var(--weight-bold);font-size:var(--text-sm);letter-spacing:0.05em;">${esc(s.consignment_id || '-')}</td>
      <td><a href="#" onclick="viewOrder(${s.order_id});return false" style="font-weight:var(--weight-semibold);">#${esc(s.order_number)}</a></td>
      <td style="font-size:var(--text-xs);">${esc(s.courier_name)}</td>
      <td style="font-size:var(--text-xs);">${esc(s.tracking_number || '-')}</td>
      <td><span class="badge ${statusBadge[s.status] || 'badge-secondary'} badge-dot">${esc(s.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(s.created_at)}</td>
      <td><div class="admin-actions">
        <button class="btn btn-sm btn-ghost" onclick="trackShipment(${s.id})">Track</button>
        <button class="btn btn-sm btn-ghost" onclick="editShipment(${s.id})">Edit</button>
        <button class="btn btn-sm btn-danger-ghost" onclick="deleteShipment(${s.id})">Delete</button>
      </div></td>
    </tr>`).join('') || '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">No shipments found</td></tr>';
    const pag = $('shipmentsPagination');
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, 'loadShipmentsPage');
  } catch (e) { showToast(e.message, 'error'); }
}

async function showCreateShipment() {
  try {
    const orders = await AdminAPI.get('/orders?limit=50&status=pending');
    const couriers = await AdminAPI.get('/couriers');
    const orderOpts = orders.data.items.map(o => `<option value="${o.id}">#${o.order_number} - ${currency(o.total)}</option>`).join('');
    const courierOpts = couriers.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    showModal('Create Shipment', `<form id="createShipmentForm" onsubmit="createShipment(this);return false">
      <div class="form-group"><label class="form-label">Order *</label><select class="form-select" name="order_id" required>${orderOpts}</select></div>
      <div class="form-group"><label class="form-label">Courier *</label><select class="form-select" name="courier_id" required>${courierOpts}</select></div>
      <button type="submit" class="btn btn-primary w-full" id="createShipBtn">Create Shipment</button>
    </form>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function createShipment(form) {
  const btn = $('createShipBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    await AdminAPI.post('/shipments', { order_id: parseInt(fd.get('order_id')), courier_id: parseInt(fd.get('courier_id')) });
    showToast('Shipment created via courier API');
    qs('.modal-overlay.active')?.classList.remove('active');
    loadShipmentsPage(1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

async function trackShipment(id) {
  try {
    const res = await AdminAPI.post(`/shipments/${id}/track`);
    const t = res.data.tracking;
    showModal('Tracking Details', `<div style="display:grid;gap:var(--space-3);">
      <div><strong>Status:</strong> ${esc(t.status)}</div>
      <div><strong>Location:</strong> ${esc(t.currentLocation || 'N/A')}</div>
      <div><strong>Events:</strong></div>
      ${(t.events || []).length ? t.events.map(e => `<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2) 0;border-bottom:1px solid var(--divider);"><span style="width:8px;height:8px;border-radius:50%;background:var(--primary);"></span><div><div style="font-size:var(--text-sm);">${esc(e.status || e.message || 'Update')}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${e.timestamp || e.time || ''}</div></div></div>`).join('') : '<div style="color:var(--text-muted);font-size:var(--text-sm);">No tracking events available</div>'}
    </div>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function editShipment(id) {
  showModal('Edit Shipment', `<form id="editShipForm" onsubmit="updateShipment(${id}, this);return false">
    <div class="form-group"><label class="form-label">Status</label>
    <select class="form-select" name="status"><option value="">Keep current</option><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="in_transit">In Transit</option><option value="delivered">Delivered</option><option value="cancelled">Cancelled</option><option value="returned">Returned</option></select></div>
    <div class="form-group"><label class="form-label">Tracking Number</label><input class="form-input" name="tracking_number"></div>
    <div class="form-group"><label class="form-label">Consignment ID</label><input class="form-input" name="consignment_id"></div>
    <button type="submit" class="btn btn-primary w-full">Update</button>
  </form>`);
}

async function updateShipment(id, form) {
  const fd = new FormData(form);
  const data = {};
  if (fd.get('status')) data.status = fd.get('status');
  if (fd.get('tracking_number')) data.tracking_number = fd.get('tracking_number');
  if (fd.get('consignment_id')) data.consignment_id = fd.get('consignment_id');
  try { await AdminAPI.put(`/shipments/${id}`, data); showToast('Shipment updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadShipmentsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteShipment(id) {
  if (!await showConfirm('Delete Shipment', 'Are you sure?')) return;
  try { await AdminAPI.del(`/shipments/${id}`); showToast('Shipment deleted'); loadShipmentsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function syncShipments() {
  try {
    const res = await AdminAPI.post('/sync');
    showToast(res.message || 'Sync complete');
    loadShipmentsPage(1);
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BULK COURIER SEND ───────────────────────────────────────────────────────
async function initBulkCourierSend() {
  const el = $('page-bulk-courier-send');
  try {
    const orders = await AdminAPI.get('/orders?limit=100&status=pending');
    const couriers = await AdminAPI.get('/couriers');
    const orderRows = orders.data.items.map(o => `<tr>
      <td><label class="form-checkbox"><input type="checkbox" class="bulk-order" value="${o.id}"> #${esc(o.order_number)}</label></td>
      <td>${esc(o.customer_name || 'N/A')}</td>
      <td style="text-align:right;">${currency(o.total)}</td>
      <td>${o.payment_method || '-'}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(o.created_at)}</td>
    </tr>`).join('');
    const courierOpts = couriers.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');

    el.innerHTML = `<div class="admin-page-header"><h1>Bulk Courier Send</h1></div>
    <div class="admin-card"><div class="admin-card-body">
      <div style="display:flex;align-items:center;gap:var(--space-4);margin-bottom:var(--space-4);flex-wrap:wrap;">
        <div class="form-group" style="margin-bottom:0;"><label class="form-label">Courier</label><select class="form-select" id="bulkCourierId">${courierOpts}</select></div>
        <button class="btn btn-primary" onclick="executeBulkSend()" id="bulkSendBtn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg> Send Selected to Courier</button>
        <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-order').forEach(c=>c.checked=true)">Select All</button>
        <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-order').forEach(c=>c.checked=false)">Deselect All</button>
      </div>
      <div class="table-wrapper"><table class="table table-hover"><thead><tr><th style="width:40px;"></th><th>Order #</th><th>Customer</th><th style="text-align:right;">Total</th><th>Payment</th><th>Date</th></tr></thead><tbody>${orderRows}</tbody></table></div>
    </div></div>
    <div class="admin-card" id="bulkResultsCard" style="display:none;"><div class="admin-card-header"><h3>Bulk Send Results</h3></div><div class="admin-card-body" id="bulkResultsBody"></div></div>`;
  } catch (e) { showToast(e.message, 'error'); }
}

async function executeBulkSend() {
  const checked = [...document.querySelectorAll('.bulk-order:checked')].map(c => parseInt(c.value));
  if (!checked.length) { showToast('Select at least one order', 'error'); return; }
  const courierId = parseInt($('bulkCourierId').value);
  if (!courierId) { showToast('Select a courier', 'error'); return; }
  if (!await showConfirm('Bulk Send', `Send ${checked.length} order(s) to courier?`)) return;

  const btn = $('bulkSendBtn'); loading(btn, true);
  try {
    const res = await AdminAPI.post('/bulk-send', { order_ids: checked, courier_id: courierId });
    const results = res.data;
    const card = $('bulkResultsCard'); card.style.display = 'block';
    $('bulkResultsBody').innerHTML = `<div style="margin-bottom:var(--space-3);">
      <span class="badge badge-success">${results.success.length} Succeeded</span>
      <span class="badge badge-danger">${results.failed.length} Failed</span>
    </div>
    ${results.success.length ? `<h4 style="font-size:var(--text-sm);font-weight:var(--weight-semibold);margin-bottom:var(--space-2);">Success</h4>
    <div style="font-size:var(--text-sm);">${results.success.map(s => `<div style="padding:var(--space-2) 0;"># Order ${s.order_id} → Consignment: <strong>${s.consignment_id}</strong> (Shipment #${s.shipment_id})</div>`).join('')}</div>` : ''}
    ${results.failed.length ? `<h4 style="font-size:var(--text-sm);font-weight:var(--weight-semibold);margin-top:var(--space-3);margin-bottom:var(--space-2);color:var(--color-danger);">Failed</h4>
    <div style="font-size:var(--text-sm);">${results.failed.map(f => `<div style="padding:var(--space-2) 0;color:var(--color-danger);">Order ${f.order_id}: ${esc(f.error)}</div>`).join('')}</div>` : ''}`;
    showToast(res.message || 'Bulk send complete');
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── INVOICE PRINT ────────────────────────────────────────────────────────────
async function initInvoicePrint() {
  const el = $('page-invoice-print');
  el.innerHTML = `<div class="admin-page-header"><h1>Invoice Print</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <div class="form-row">
      <div class="form-group"><label class="form-label">Enter Order Number or ID</label>
        <div style="display:flex;gap:var(--space-3);">
          <input class="form-input" id="invoiceOrderInput" placeholder="e.g. BH-20250001 or Order ID" style="flex:1;min-height:44px;">
          <button class="btn btn-primary" onclick="loadInvoice()" id="loadInvoiceBtn" style="min-height:44px;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg> Load Invoice</button>
        </div>
      </div>
    </div>
    <div id="invoicePreview" style="display:none;"></div>
  </div></div>`;
}

async function loadInvoice() {
  const input = $('invoiceOrderInput').value.trim();
  if (!input) { showToast('Enter order number or ID', 'error'); return; }
  const btn = $('loadInvoiceBtn'); loading(btn, true);
  const el = $('invoicePreview');

  try {
    const orderId = /^\d+$/.test(input) ? parseInt(input) : null;
    let orderData;
    if (orderId) {
      const res = await AdminAPI.get(`/orders/${orderId}`);
      orderData = { order: res.data.order, customer: res.data.order, items: res.data.order.items || [] };
    } else {
      const res = await AdminAPI.get(`/orders?search=${encodeURIComponent(input)}`);
      if (!res.data.items.length) throw new Error('Order not found');
      const o = res.data.items[0];
      const detail = await AdminAPI.get(`/orders/${o.id}`);
      orderData = { order: detail.data.order, customer: detail.data.order, items: detail.data.order.items || [] };
    }

    // Fetch invoice data with consignment info
    let invoiceData = { courier: { consignment_id: '', tracking_number: '', name: '' } };
    try {
      const inv = await AdminAPI.get(`/invoice/${orderData.order.id}`);
      invoiceData = inv.data;
    } catch (e) { /* no invoice data available */ }

    const o = orderData.order;
    const consignmentId = (invoiceData.courier?.consignment_id || '').toString();
    const consignmentFormatted = consignmentId.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3') || consignmentId;
    const courierName = invoiceData.courier?.name || 'Steadfast';

    // Status color map
    const statusColors = {
      pending: '#fef3cd', confirmed: '#d1ecf1', packaging: '#cce5ff',
      ready_to_ship: '#d4edda', courier_sent: '#d4edda', in_transit: '#fff3cd',
      delivered: '#d4edda', cancelled: '#f8d7da', returned: '#f8d7da', exchanged: '#cce5ff'
    };
    const statusTextColors = {
      pending: '#856404', confirmed: '#0c5460', packaging: '#004085',
      ready_to_ship: '#155724', courier_sent: '#155724', in_transit: '#856404',
      delivered: '#155724', cancelled: '#721c24', returned: '#721c24', exchanged: '#004085'
    };
    const statusLabel = o.status === 'ready_to_ship' ? 'Ready to Ship' : o.status === 'courier_sent' ? 'Sent to Courier' : o.status.charAt(0).toUpperCase() + o.status.slice(1).replace(/_/g, ' ');

    // Build status timeline
    const statusTimeline = (o.status_history || []).slice(0, 5).map(s => {
      const label = s.status === 'ready_to_ship' ? 'Ready to Ship' : s.status === 'courier_sent' ? 'Sent to Courier' : s.status.charAt(0).toUpperCase() + s.status.slice(1).replace(/_/g, ' ');
      const sc = statusColors[s.status] || '#f5f5f5';
      return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
        <div style="width:10px;height:10px;border-radius:50%;background:${sc === '#d4edda' ? '#28a745' : sc === '#fef3cd' ? '#ffc107' : sc === '#d1ecf1' ? '#17a2b8' : sc === '#cce5ff' ? '#007bff' : '#6c757d'};flex-shrink:0;"></div>
        <div style="flex:1;"><span style="font-size:12px;font-weight:600;color:#333;">${esc(label)}</span><span style="font-size:11px;color:#999;margin-left:8px;">${s.created_at ? dateStr(s.created_at) : ''}</span></div>
        ${s.note ? `<span style="font-size:11px;color:#888;">${esc(s.note)}</span>` : ''}
      </div>`;
    }).join('') || '<div style="font-size:12px;color:#999;">No status updates recorded.</div>';

    // Build payment info
    const paymentRef = o.payment_reference || (o.payments && o.payments[0]?.reference) || '';
    const pmtMethod = o.payment_method || (o.payments && o.payments[0]?.method) || 'N/A';
    const pmtStatus = o.payment_status || 'pending';

    // Build items table
    const items = orderData.items.map((i, idx) => {
      const variant = i.variant_id ? ` (${i.product_sku || 'N/A'})` : ` (${i.product_sku || 'N/A'})`;
      return `<tr${idx % 2 !== 0 ? ' style="background:#f9f9f9;"' : ''}>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;font-size:13px;color:#222;">
          <span style="font-weight:500;">${++idx}. ${esc(i.product_name)}</span>
          <span style="font-size:11px;color:#999;display:block;">SKU: ${esc(i.product_sku || 'N/A')}</span>
        </td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:center;font-size:13px;color:#333;">${i.quantity}</td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:right;font-size:13px;color:#555;">${currency(i.price)}</td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:right;font-size:13px;font-weight:600;color:#222;">${currency(i.total)}</td>
      </tr>`;
    }).join('');

    // Shipping address text
    const sa = invoiceData.shipping_address || {};
    const addrParts = [sa.address, sa.line1, sa.line2, sa.city, sa.state, sa.zip, sa.country].filter(Boolean);
    const shipAddr = addrParts.join(', ') || esc(o.shipping_address?.address || o.shipping_address?.line1 || '');

    el.style.display = 'block';
    el.innerHTML = `<div style="background:#fff;color:#222;font-family:'Inter','Segoe UI',sans-serif;max-width:800px;margin:0 auto;border-radius:16px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.12);" id="printArea">

      <!-- ═══ TOP BRAND BAR ═══ -->
      <div style="background:linear-gradient(135deg,#dc143c,#b01030);padding:22px 32px;display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:36px;height:36px;background:rgba(255,255,255,0.2);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:#fff;font-family:sans-serif;">B</div>
            <div>
              <h1 style="margin:0;font-size:24px;font-weight:800;color:#fff;letter-spacing:1px;">বাঙালিরহাট</h1>
              <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">Premium Bangladeshi E-Commerce</p>
            </div>
          </div>
        </div>
        <div style="text-align:right;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.85);">Gulshan 2, Dhaka, Bangladesh</p>
          <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">support@bangalirhaat.com</p>
          <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">+880 1700-000000</p>
        </div>
      </div>

      <!-- ═══ INVOICE INFO + STATUS ═══ -->
      <div style="display:flex;justify-content:space-between;align-items:stretch;padding:20px 32px;background:#fafafa;border-bottom:1px solid #eee;">
        <div style="flex:1;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
            <p style="margin:0;font-size:11px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Invoice</p>
            <span style="display:inline-block;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:600;background:${statusColors[o.status] || '#f5f5f5'};color:${statusTextColors[o.status] || '#666'};">${esc(statusLabel)}</span>
          </div>
          <h2 style="margin:0;font-size:20px;font-weight:700;color:#222;">${esc(o.order_number)}</h2>
          <div style="display:flex;gap:24px;margin-top:8px;flex-wrap:wrap;">
            <div><span style="font-size:12px;color:#999;">Date:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.created_at)}</span></div>
            <div><span style="font-size:12px;color:#999;">Items:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${orderData.items.length}</span></div>
            ${o.shipped_at ? `<div><span style="font-size:12px;color:#999;">Shipped:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.shipped_at)}</span></div>` : ''}
            ${o.delivered_at ? `<div><span style="font-size:12px;color:#999;">Delivered:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.delivered_at)}</span></div>` : ''}
          </div>
        </div>
        ${consignmentId ? `<div style="background:#111;border-radius:10px;padding:12px 22px;text-align:center;display:flex;flex-direction:column;justify-content:center;min-width:200px;">
          <p style="margin:0 0 4px;font-size:9px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:1.5px;">Steadfast Consignment</p>
          <p style="margin:0;font-size:28px;font-weight:900;letter-spacing:6px;color:#fff;font-family:'Courier New',monospace;">${esc(consignmentFormatted)}</p>
          ${invoiceData.courier?.tracking_number ? `<p style="margin:4px 0 0;font-size:10px;color:rgba(255,255,255,0.4);">Tracking: ${esc(invoiceData.courier.tracking_number)}</p>` : ''}
        </div>` : ''}
      </div>

      <!-- ═══ CUSTOMER & SHIPPING ═══ -->
      <div style="display:flex;padding:18px 32px;border-bottom:1px solid #eee;gap:40px;">
        <div style="flex:1;">
          <p style="margin:0 0 6px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Bill To</p>
          <p style="margin:0;font-size:15px;font-weight:600;color:#222;">${esc(invoiceData.customer?.name || orderData.customer?.customer_name || 'N/A')}</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">${esc(invoiceData.customer?.phone || '')}</p>
          <p style="margin:2px 0 0;font-size:13px;color:#555;">${esc(invoiceData.customer?.email || o.customer_email || '')}</p>
        </div>
        <div style="flex:1;">
          <p style="margin:0 0 6px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Shipping Address</p>
          <p style="margin:0;font-size:13px;color:#555;">${shipAddr || 'N/A'}</p>
          ${o.notes ? `<p style="margin:6px 0 0;font-size:12px;color:#888;font-style:italic;">📝 ${esc(o.notes)}</p>` : ''}
        </div>
      </div>

      <!-- ═══ PAYMENT INFO ═══ -->
      <div style="display:flex;padding:14px 32px;border-bottom:1px solid #eee;gap:40px;background:#fcfcfc;">
        <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
          <div><span style="font-size:12px;color:#999;">Method:</span><span style="font-size:13px;color:#333;font-weight:500;margin-left:4px;">${esc(pmtMethod)}</span></div>
          <div><span style="font-size:12px;color:#999;">Status:</span><span style="display:inline-block;margin-left:4px;padding:1px 8px;border-radius:99px;font-size:11px;font-weight:600;background:${pmtStatus === 'paid' ? '#d4edda' : pmtStatus === 'pending' ? '#fef3cd' : '#f8d7da'};color:${pmtStatus === 'paid' ? '#155724' : pmtStatus === 'pending' ? '#856404' : '#721c24'};">${esc(pmtStatus)}</span></div>
          ${paymentRef ? `<div><span style="font-size:12px;color:#999;">Reference:</span><span style="font-size:13px;color:#333;font-weight:500;margin-left:4px;">${esc(paymentRef)}</span></div>` : ''}
        </div>
      </div>

      <!-- ═══ PRODUCTS TABLE ═══ -->
      <div style="padding:18px 32px;">
        <p style="margin:0 0 10px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Order Items <span style="font-weight:400;color:#bbb;">(${orderData.items.length} item${orderData.items.length > 1 ? 's' : ''})</span></p>
        <table style="width:100%;border-collapse:collapse;">
          <thead><tr style="background:#dc143c;color:#fff;">
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:left;">Product</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:center;width:55px;">Qty</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:right;width:95px;">Price</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:right;width:95px;">Total</th>
          </tr></thead>
          <tbody>${items || '<tr><td colspan="4" style="padding:16px;text-align:center;color:#999;font-size:13px;">No items found.</td></tr>'}</tbody>
        </table>
      </div>

      <!-- ═══ TOTALS ═══ -->
      <div style="padding:8px 32px 18px;display:flex;justify-content:flex-end;">
        <div style="min-width:280px;">
          <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Subtotal</span><span style="font-weight:500;">${currency(o.subtotal)}</span></div>
          ${o.discount ? `<div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#e53e3e;"><span>Discount</span><span style="font-weight:500;">-${currency(o.discount)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Shipping</span><span style="font-weight:500;">${currency(o.shipping_cost)}</span></div>
          ${o.tax ? `<div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Tax</span><span style="font-weight:500;">${currency(o.tax)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between;padding:9px 0 0;margin-top:5px;border-top:2px solid #222;font-size:20px;font-weight:700;color:#222;"><span>Total</span><span>${currency(o.total)}</span></div>
          ${o.delivery_charge ? `<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:12px;color:#888;"><span>Delivery Charge</span><span>${currency(o.delivery_charge)}</span></div>` : ''}
        </div>
      </div>

      <!-- ═══ STATUS TIMELINE ═══ -->
      ${(o.status_history && o.status_history.length > 0) ? `
      <div style="padding:16px 32px;border-top:1px solid #eee;background:#fcfcfc;">
        <p style="margin:0 0 10px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Order Timeline</p>
        <div style="padding-left:4px;">${statusTimeline}</div>
      </div>` : ''}

      <!-- ═══ FOOTER ═══ -->
      <div style="background:#fafafa;padding:14px 32px;text-align:center;border-top:1px solid #eee;">
        <p style="margin:0;font-size:12px;color:#999;">Thank you for shopping at Bangalirhaat! ❤️</p>
        <p style="margin:4px 0 0;font-size:11px;color:#bbb;">This is a computer-generated invoice. No signature required.</p>
      </div>

      <!-- ═══ PRINT BUTTON ═══ -->
      <div style="text-align:center;padding:18px 32px;">
        <button class="btn btn-primary" onclick="window.print()" style="padding:10px 36px;font-size:14px;border-radius:8px;">🖨️ Print Invoice</button>
      </div>
    </div>`;
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── BULK INVOICE PRINT ──────────────────────────────────────────────────────
async function initBulkInvoicePrint() {
  const el = $('page-invoice-bulk-print');
  el.innerHTML = `<div class="admin-page-header"><h1>Bulk Invoice Print</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <div style="margin-bottom:var(--space-4);">
      <label class="form-label">Select Orders</label>
      <div id="bulkInvoiceOrders"><div style="text-align:center;padding:20px;color:var(--text-muted);">Loading orders...</div></div>
    </div>
    <div style="display:flex;gap:var(--space-3);flex-wrap:wrap;">
      <button class="btn btn-primary" id="printSelectedInvoices" onclick="printSelectedInvoices()" disabled>🖨️ Print Selected (0)</button>
      <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-inv-order').forEach(c=>c.checked=true);updateBulkInvoiceCount()">Select All</button>
      <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-inv-order').forEach(c=>c.checked=false);updateBulkInvoiceCount()">Deselect All</button>
    </div>
  </div></div>`;

  try {
    const res = await AdminAPI.get('/orders?limit=50');
    const html = res.data.items.map(o => `<tr>
      <td><label class="form-checkbox"><input type="checkbox" class="bulk-inv-order" value="${o.id}" onchange="updateBulkInvoiceCount()"> #${esc(o.order_number)}</label></td>
      <td>${esc(o.customer_name || 'N/A')}</td>
      <td style="text-align:right;">${currency(o.total)}</td>
      <td><span class="badge ${o.status === 'delivered' ? 'badge-success' : 'badge-warning'}">${esc(o.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(o.created_at)}</td>
    </tr>`).join('');
    $('bulkInvoiceOrders').innerHTML = `<div class="table-wrapper"><table class="table table-hover"><thead><tr><th style="width:40px;"></th><th>Order #</th><th>Customer</th><th style="text-align:right;">Total</th><th>Status</th><th>Date</th></tr></thead><tbody>${html}</tbody></table></div>`;
  } catch (e) { showToast(e.message, 'error'); }
}

function updateBulkInvoiceCount() {
  const count = document.querySelectorAll('.bulk-inv-order:checked').length;
  const btn = $('printSelectedInvoices');
  btn.textContent = `🖨️ Print Selected (${count})`;
  btn.disabled = count === 0;
}

async function printSelectedInvoices() {
  const checked = [...document.querySelectorAll('.bulk-inv-order:checked')].map(c => parseInt(c.value));
  if (!checked.length) return;
  showToast(`Loading ${checked.length} invoices for printing...`);

  try {
    const orders = [];
    for (const id of checked) {
      try {
        const o = await AdminAPI.get(`/orders/${id}`);
        let inv = { courier: { consignment_id: '', tracking_number: '', name: '' } };
        try { inv = await AdminAPI.get(`/invoice/${id}`); } catch (e) {}
        orders.push({ ...o.data.order, items: o.data.order.items || [], invoice: inv.data || inv });
      } catch (e) { console.error('Failed to load order', id, e); }
    }

    const printWin = window.open('', '_blank', 'width=900,height=700');
    printWin.document.write(`<html><head><title>Invoices - Bangalirhaat</title><style>
      @page { margin: 8mm; }
      body { font-family: 'Inter','Segoe UI',sans-serif; font-size: 12px; color: #222; margin:0; padding:0; }
      .invoice-page { page-break-after: always; max-width: 800px; margin: 16px auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.1); }
      .invoice-page:last-child { page-break-after: avoid; }
      .brand-bar { background:linear-gradient(135deg,#dc143c,#b01030); padding:18px 28px; display:flex; justify-content:space-between; align-items:center; }
      .brand-bar h1 { margin:0; font-size:22px; font-weight:800; color:#fff; letter-spacing:1px; }
      .brand-bar p { margin:2px 0 0; font-size:11px; color:rgba(255,255,255,0.85); }
      .info-row { display:flex; justify-content:space-between; align-items:stretch; padding:16px 28px; background:#fafafa; border-bottom:1px solid #eee; }
      .consignment-box { background:#111; border-radius:8px; padding:10px 18px; text-align:center; display:flex; flex-direction:column; justify-content:center; }
      .consignment-box .label { margin:0 0 3px; font-size:9px; font-weight:600; color:rgba(255,255,255,0.5); text-transform:uppercase; letter-spacing:1.5px; }
      .consignment-box .id { margin:0; font-size:24px; font-weight:900; letter-spacing:5px; color:#fff; font-family:'Courier New',monospace; }
      .section { padding:14px 28px; border-bottom:1px solid #eee; }
      .section-title { margin:0 0 8px; font-size:10px; font-weight:600; color:#999; text-transform:uppercase; letter-spacing:1px; }
      .customer-row { display:flex; padding:14px 28px; border-bottom:1px solid #eee; gap:32px; }
      .customer-col { flex:1; }
      .customer-col .label { font-size:10px; font-weight:600; color:#999; text-transform:uppercase; letter-spacing:1px; margin:0 0 5px; }
      table { width:100%; border-collapse:collapse; }
      th { background:#dc143c; color:#fff; padding:7px 10px; font-size:11px; font-weight:600; text-align:left; }
      td { padding:7px 10px; font-size:12px; border:1px solid #e0e0e0; }
      tr:nth-child(even) { background:#f9f9f9; }
      .sku { font-size:10px; color:#999; display:block; }
      .totals { min-width:250px; margin-left:auto; }
      .totals .row { display:flex; justify-content:space-between; padding:4px 0; font-size:13px; color:#555; }
      .totals .total { padding:8px 0 0; margin-top:4px; border-top:2px solid #222; font-size:17px; font-weight:700; color:#222; }
      .footer-bar { background:#fafafa; padding:12px 28px; text-align:center; border-top:1px solid #eee; }
      .footer-bar p { margin:0; font-size:11px; color:#999; }
    </style></head><body>`);

    for (const o of orders) {
      const cid = (o.invoice?.courier?.consignment_id || '').toString();
      const cidFormatted = cid.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3') || cid;
      const customer = o.invoice?.customer || {};
      const shipAddr = o.shipping_address ? (typeof o.shipping_address === 'string' ? JSON.parse(o.shipping_address) : o.shipping_address) : {};
      const addrParts = [shipAddr.address, shipAddr.line1, shipAddr.line2, shipAddr.city, shipAddr.state, shipAddr.zip, shipAddr.country].filter(Boolean);
      const addrText = addrParts.join(', ') || `${shipAddr.city || ''} ${shipAddr.zip || ''}`.trim() || 'N/A';

      const items = (o.items || []).map((i, idx) => {
        return `<tr${idx % 2 !== 0 ? ' style="background:#f9f9f9;"' : ''}>
          <td><span style="font-weight:500;">${++idx}. ${esc(i.product_name)}</span><span class="sku">SKU: ${esc(i.product_sku || 'N/A')}</span></td>
          <td style="text-align:center;">${i.quantity}</td>
          <td style="text-align:right;color:#555;">${currency(i.price)}</td>
          <td style="text-align:right;font-weight:600;">${currency(i.total)}</td>
        </tr>`;
      }).join('');
      printWin.document.write(`<div class="invoice-page">
        <div class="brand-bar">
          <div><h1>বাঙালিরহাট</h1><p>Premium Bangladeshi E-Commerce</p></div>
          <div style="text-align:right;"><p>Gulshan 2, Dhaka, Bangladesh</p><p>support@bangalirhaat.com | +880 1700-000000</p></div>
        </div>
        <div class="info-row">
          <div>
            <p style="margin:0 0 2px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Invoice</p>
            <p style="margin:0;font-size:17px;font-weight:700;">${esc(o.order_number)}</p>
            <p style="margin:4px 0 0;font-size:12px;color:#666;">${dateStr(o.created_at)} | ${o.items ? o.items.length + ' item(s)' : ''}</p>
          </div>
          ${cid ? `<div class="consignment-box"><p class="label">Steadfast Consignment</p><p class="id">${esc(cidFormatted)}</p></div>` : ''}
        </div>
        <div class="customer-row">
          <div class="customer-col">
            <p class="label">Customer</p>
            <p style="margin:0;font-size:14px;font-weight:600;color:#222;">${esc(customer.name || o.customer_name || 'N/A')}</p>
            <p style="margin:2px 0 0;font-size:12px;color:#555;">${esc(customer.phone || o.customer_phone || '')}</p>
            <p style="margin:2px 0 0;font-size:12px;color:#555;">${esc(customer.email || o.customer_email || '')}</p>
          </div>
          <div class="customer-col">
            <p class="label">Shipping Address</p>
            <p style="margin:0;font-size:12px;color:#555;">${esc(addrText)}</p>
          </div>
        </div>
        <div class="section">
          <p class="section-title">Order Items</p>
          <table><thead><tr><th>Product</th><th style="text-align:center;width:50px;">Qty</th><th style="text-align:right;width:85px;">Price</th><th style="text-align:right;width:85px;">Total</th></tr></thead><tbody>${items || '<tr><td colspan="4" style="text-align:center;color:#999;">No items</td></tr>'}</tbody></table>
        </div>
        <div style="padding:10px 28px 16px;display:flex;justify-content:flex-end;">
          <div class="totals">
            <div class="row"><span>Subtotal</span><span style="font-weight:500;">${currency(o.subtotal)}</span></div>
            ${o.discount ? `<div class="row" style="color:#e53e3e;"><span>Discount</span><span style="font-weight:500;">-${currency(o.discount)}</span></div>` : ''}
            <div class="row"><span>Shipping</span><span style="font-weight:500;">${currency(o.shipping_cost)}</span></div>
            ${o.tax ? `<div class="row"><span>Tax</span><span style="font-weight:500;">${currency(o.tax)}</span></div>` : ''}
            <div class="total"><span>Total</span><span>${currency(o.total)}</span></div>
          </div>
        </div>
        <div class="footer-bar"><p>Thank you for shopping at Bangalirhaat! ❤️</p></div>
      </div>`);
    }
    printWin.document.write('</body></html>');
    printWin.document.close();
    setTimeout(() => { printWin.print(); }, 500);
  } catch (e) { showToast(e.message, 'error'); }
}

// ── DELIVERY ─────────────────────────────────────────────────────────────────
async function initDelivery() {
  const el = $('page-delivery');
  el.innerHTML = `<div class="admin-page-header"><h1>Delivery Management</h1></div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(4,1fr);">
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">In Transit</div><div class="admin-stat-value" id="delInTransit">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Out for Delivery</div><div class="admin-stat-value" id="delOutFor">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Delivered Today</div><div class="admin-stat-value" id="delToday">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Returned</div><div class="admin-stat-value" id="delReturned">-</div></div></div>
  </div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Order</th><th>Courier</th><th>Consignment</th><th>Status</th><th>Actions</th></tr></thead><tbody><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/shipments?limit=20');
    const s = res.data.items;
    if ($('delInTransit')) $('delInTransit').textContent = s.filter(x => x.status === 'in_transit').length;
    if ($('delOutFor')) $('delOutFor').textContent = s.filter(x => x.status === 'out_for_delivery').length;
    if ($('delToday')) $('delToday').textContent = s.filter(x => x.status === 'delivered').length;
    if ($('delReturned')) $('delReturned').textContent = s.filter(x => x.status === 'returned').length;
  } catch (e) { /* ignore */ }
}

// ── DELIVERY ZONES ──────────────────────────────────────────────────────────
function initDeliveryZones() {
  $('page-delivery-zones').innerHTML = `<div class="admin-page-header"><h1>Delivery Zones</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <p style="color:var(--text-muted);margin-bottom:var(--space-4);">Manage delivery zones and shipping rates.</p>
    <div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Zone</th><th>Inside Dhaka</th><th>Outside Dhaka</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <tr><td>Dhaka Metro</td><td>৳60</td><td>-</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
      <tr><td>Chattogram</td><td>৳100</td><td>৳130</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
      <tr><td>Other Divisions</td><td>৳120</td><td>৳150</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
    </tbody></table></div>
    <button class="btn btn-primary" style="margin-top:var(--space-4);">+ Add Zone</button>
  </div></div>`;
}

// ── COURIER SETTINGS ────────────────────────────────────────────────────────
async function initCourierSettings() {
  const el = $('page-settings-courier');
  try {
    const couriers = await AdminAPI.get('/couriers');
    const cards = couriers.data.items.map(c => `<div class="admin-card">
      <div class="admin-card-header"><h3>${esc(c.name)}</h3><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></div>
      <div class="admin-card-body">
        <form onsubmit="updateCourier(${c.id}, this);return false">
          <div class="form-row">
            <div class="form-group"><label class="form-label">API Key</label><input class="form-input" name="api_key" value="${esc(c.api_key || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
            <div class="form-group"><label class="form-label">API Secret</label><input class="form-input" name="api_secret" type="password" value="${esc(c.api_secret || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
          </div>
          <div class="form-group"><label class="form-label">API URL</label><input class="form-input" name="api_url" value="${esc(c.api_url || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
          <div class="form-group"><label class="form-label">Shipments: ${c.total_shipments || 0} total, ${c.active_shipments || 0} active</label></div>
          <div style="display:flex;gap:var(--space-3);">
            <button type="submit" class="btn btn-primary">Save</button>
            ${c.slug?.includes('steadfast') ? `<button type="button" class="btn btn-outline" onclick="checkSteadfastBalance()">Check Balance</button>` : ''}
          </div>
        </form>
      </div>
    </div>`).join('');
    el.innerHTML = `<div class="admin-page-header"><h1>Courier Settings</h1></div>${cards}`;
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateCourier(id, form) {
  const fd = new FormData(form);
  try {
    await AdminAPI.put(`/couriers/${id}`, Object.fromEntries(fd));
    showToast('Courier settings saved');
  } catch (e) { showToast(e.message, 'error'); }
}

async function checkSteadfastBalance() {
  try { const res = await AdminAPI.get('/steadfast/balance'); showModal('SteadFast Balance', `<pre>${JSON.stringify(res.data, null, 2)}</pre>`); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── COUPONS ──────────────────────────────────────────────────────────────────
async function initCoupons() {
  const el = $('page-marketing-coupons');
  el.innerHTML = `<div class="admin-page-header"><h1>Coupons</h1><button class="btn btn-primary" onclick="showAddCoupon()">+ Add Coupon</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Used</th><th>Status</th><th>Actions</th></tr></thead><tbody id="couponsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/marketing/coupons');
    $('couponsBody').innerHTML = res.data.items.map(c => `<tr>
      <td style="font-weight:var(--weight-bold);font-family:monospace;">${esc(c.code)}</td>
      <td>${c.type}</td>
      <td>${c.type === 'percentage' ? c.value + '%' : c.type === 'fixed' ? currency(c.value) : 'Free Shipping'}</td>
      <td>${currency(c.minimum_order)}</td>
      <td>${c.used_count || 0}${c.usage_limit ? '/' + c.usage_limit : ''}</td>
      <td><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditCoupon(${c.id})">Edit</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddCoupon() {
  showModal('Add Coupon', `<form id="couponForm" onsubmit="saveCoupon(this);return false">
    <div class="form-group"><label class="form-label">Code *</label><input class="form-input" name="code" required style="text-transform:uppercase;"></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Type</label><select class="form-select" name="type"><option value="percentage">Percentage</option><option value="fixed">Fixed</option><option value="free_shipping">Free Shipping</option></select></div>
    <div class="form-group"><label class="form-label">Value</label><input class="form-input" name="value" type="number" step="0.01"></div></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Min Order</label><input class="form-input" name="minimum_order" type="number" value="0"></div>
    <div class="form-group"><label class="form-label">Usage Limit</label><input class="form-input" name="usage_limit" type="number" placeholder="Unlimited"></div></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveCoupon(form) {
  const fd = new FormData(form);
  try {     await AdminAPI.post('/marketing/coupons', Object.fromEntries(fd)); showToast('Coupon created'); qs('.modal-overlay.active')?.classList.remove('active'); initCoupons(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── CAMPAIGNS ────────────────────────────────────────────────────────────────
async function initCampaigns() {
  const el = $('page-marketing-campaigns');
  el.innerHTML = `<div class="admin-page-header"><h1>Campaigns</h1><button class="btn btn-primary" onclick="showAddCampaign()">+ New Campaign</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Type</th><th>Subject</th><th>Status</th><th>Scheduled</th><th>Actions</th></tr></thead><tbody id="campaignsBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/marketing/campaigns');
    $('campaignsBody').innerHTML = (res.data.items || []).map(c => `<tr>
      <td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.name)}</td>
      <td><span class="badge badge-info">${esc(c.type)}</span></td>
      <td style="font-size:var(--text-xs);">${esc(c.subject || '-')}</td>
      <td><span class="badge ${c.status === 'sent' ? 'badge-success' : c.status === 'draft' ? 'badge-secondary' : 'badge-warning'}">${esc(c.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${c.scheduled_at ? dateStr(c.scheduled_at) : '-'}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast('View campaign: implement')">View</button></div></td>
    </tr>`).join('') || '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No campaigns</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddCampaign() {
  showModal('New Campaign', `<form id="campaignForm" onsubmit="saveCampaign(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Type</label><select class="form-select" name="type"><option value="email">Email</option><option value="sms">SMS</option><option value="push">Push</option></select></div>
    <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status"><option value="draft">Draft</option><option value="active">Active</option></select></div></div>
    <div class="form-group"><label class="form-label">Subject</label><input class="form-input" name="subject"></div>
    <div class="form-group"><label class="form-label">Content *</label><textarea class="form-input" name="content" rows="4" required></textarea></div>
    <button type="submit" class="btn btn-primary w-full">Save Campaign</button>
  </form>`);
}

async function saveCampaign(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/marketing/campaigns', Object.fromEntries(fd)); showToast('Campaign created'); qs('.modal-overlay.active')?.classList.remove('active'); initCampaigns(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FLASH SALES ─────────────────────────────────────────────────────────────
async function initFlashSales() {
  const el = $('page-flash-sales');
  el.innerHTML = `<div class="admin-page-header"><h1>Flash Sales</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product ID</th><th>Discount</th><th>Start</th><th>End</th><th>Status</th></tr></thead><tbody id="flashSalesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/products?limit=50&is_featured=1');
    $('flashSalesBody').innerHTML = res.data.items.map(p => `<tr>
      <td>${p.id}</td>
      <td><span class="badge badge-danger">${p.compare_price ? Math.round((1 - p.price / p.compare_price) * 100) + '%' : 'N/A'}</span></td>
      <td style="font-size:var(--text-xs);">-</td>
      <td style="font-size:var(--text-xs);">-</td>
      <td><span class="badge badge-success">Active</span></td>
    </tr>`).join('') || '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No flash sales active</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── FINANCE ──────────────────────────────────────────────────────────────────
async function initFinanceOverview() {
  const el = $('page-finance-overview');
  el.innerHTML = `<div class="admin-page-header"><h1>Finance Overview</h1></div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(4,1fr);">
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Total Revenue</div><div class="admin-stat-value" id="finRevenue">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Paid Orders</div><div class="admin-stat-value" id="finPaid">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Pending Payments</div><div class="admin-stat-value" id="finPending">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Avg Order Value</div><div class="admin-stat-value" id="finAvg">-</div></div></div>
  </div>`;
  // Load from analytics endpoint
  try {
    const res = await AdminAPI.get('/analytics?period=monthly');
    const items = res.data.items || [];
    const totalRev = items.reduce((s, i) => s + (i.total_revenue || 0), 0);
    const totalOrders = items.reduce((s, i) => s + (i.total_orders || 0), 0);
    if ($('finRevenue')) $('finRevenue').textContent = currency(totalRev);
    if ($('finAvg')) $('finAvg').textContent = totalOrders ? currency(totalRev / totalOrders) : '৳0';
  } catch (e) { /* ignore */ }
}

// ── REPORTS ──────────────────────────────────────────────────────────────────
async function initReports(period) {
  const el = $(`page-report-${period}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${period.charAt(0).toUpperCase() + period.slice(1)} Report</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <canvas id="reportChart${period}" style="max-height:400px;"></canvas>
  </div></div>`;
  try {
    const res = await AdminAPI.get(`/analytics?period=${period}`);
    const data = res.data.items || [];
    if (window.Chart) {
      new Chart(document.getElementById(`reportChart${period}`), {
        type: 'line',
        data: {
          labels: data.map(d => d.period).reverse(),
          datasets: [
            { label: 'Revenue', data: data.map(d => d.total_revenue).reverse(), borderColor: '#dc143c', tension: 0.4, fill: false },
            { label: 'Orders', data: data.map(d => d.total_orders).reverse(), borderColor: '#2563eb', tension: 0.4, fill: false, yAxisID: 'y1' },
          ]
        },
        options: { responsive: true, interaction: { mode: 'index', intersect: false }, scales: { y1: { position: 'right', grid: { drawOnChartArea: false } } } }
      });
    }
  } catch (e) { /* ignore */ }
}

// ── TOP PRODUCTS REPORT ──────────────────────────────────────────────────────
async function initTopProductsReport() {
  const el = $('page-report-top-products');
  el.innerHTML = `<div class="admin-page-header"><h1>Top Products</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>#</th><th>Product</th><th>Category</th><th>Sold</th><th>Revenue</th></tr></thead><tbody id="topProdBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/products?limit=20&sort=popular');
    $('topProdBody').innerHTML = res.data.items.map((p, i) => `<tr>
      <td>${i + 1}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div></td>
      <td style="font-size:var(--text-xs);">${esc(p.category_name || '')}</td>
      <td>${p.total_sold || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency((p.total_sold || 0) * p.price)}</td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── TOP CUSTOMERS REPORT ─────────────────────────────────────────────────────
async function initTopCustomersReport() {
  const el = $('page-report-top-customers');
  el.innerHTML = `<div class="admin-page-header"><h1>Top Customers</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>#</th><th>Customer</th><th>Orders</th><th>Total Spent</th></tr></thead><tbody id="topCustBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/customers');
    const sorted = (res.data.items || []).sort((a, b) => (b.total_spent || 0) - (a.total_spent || 0)).slice(0, 20);
    $('topCustBody').innerHTML = sorted.map((c, i) => `<tr>
      <td>${i + 1}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.first_name + ' ' + c.last_name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(c.email)}</div></td>
      <td>${c.total_orders || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.total_spent || 0)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No data</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── EXPENSES ─────────────────────────────────────────────────────────────────
function initExpenses() {
  $('page-expenses').innerHTML = `<div class="admin-page-header"><h1>Expenses</h1><button class="btn btn-primary" onclick="showAddExpense()">+ Add Expense</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Category</th><th>Description</th><th>Amount</th><th>Date</th><th>Actions</th></tr></thead><tbody id="expensesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  loadExpenses(1);
}

async function loadExpenses(page) {
  try {
    const res = await AdminAPI.get(`/finance/expenses?limit=15&page=${page}`);
    const items = res.data?.items || [];
    const tbody = $('expensesBody');
    tbody.innerHTML = items.length ? items.map(e => `<tr>
      <td><span class="badge badge-secondary">${esc(e.category)}</span></td>
      <td style="font-size:var(--text-sm);">${esc(e.description || '-')}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(e.amount)}</td>
      <td style="font-size:var(--text-xs);">${dateStr(e.date)}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast('Edit: implement')">Edit</button></div></td>
    </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No expenses found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddExpense() {
  showModal('Add Expense', `<form id="expenseForm" onsubmit="saveExpense(this);return false">
    <div class="form-group"><label class="form-label">Category *</label>
    <select class="form-select" name="category" required><option>Utilities</option><option>Rent</option><option>Salary</option><option>Marketing</option><option>Shipping</option><option>Office</option><option>Other</option></select></div>
    <div class="form-group"><label class="form-label">Description</label><input class="form-input" name="description"></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Amount *</label><input class="form-input" name="amount" type="number" step="0.01" required></div>
    <div class="form-group"><label class="form-label">Date</label><input class="form-input" name="date" type="date"></div></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveExpense(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/finance/expenses', Object.fromEntries(fd)); showToast('Expense saved'); qs('.modal-overlay.active')?.classList.remove('active'); loadExpenses(1); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── SETTINGS ─────────────────────────────────────────────────────────────────
function initCompanySettings() {
  $('page-settings-company').innerHTML = `<div class="admin-page-header"><h1>Company Settings</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form onsubmit="saveCompanySettings(this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Site Name</label><input class="form-input" name="site_name" value="Bangalirhaat"></div>
      <div class="form-group"><label class="form-label">Email</label><input class="form-input" name="email" value="support@bangalirhaat.com"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone" value="09612-345678"></div>
      <div class="form-group"><label class="form-label">Currency</label><select class="form-select" name="currency"><option value="BDT" selected>BDT (৳)</option></select></div></div>
      <div class="form-group"><label class="form-label">Address</label><textarea class="form-input" name="address" rows="2">Gulshan 2, Dhaka, Bangladesh</textarea></div>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div></div>`;
}

async function saveCompanySettings(form) {
  const fd = new FormData(form);
  const entries = Object.fromEntries(fd);
  const settings = Object.entries(entries).map(([key, value]) => ({ key, value }));
  try { await AdminAPI.put('/settings', { settings }); showToast('Settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

function initInvoiceSettings() {
  $('page-settings-invoice').innerHTML = `<div class="admin-page-header"><h1>Invoice Settings</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form onsubmit="saveInvoiceSettings(this);return false">
      <div class="form-group"><label class="form-label">Invoice Prefix</label><input class="form-input" name="invoice_prefix" value="BH-" style="font-family:monospace;"></div>
      <div class="form-group"><label class="form-label">Footer Text</label><textarea class="form-input" name="invoice_footer" rows="2">Thank you for shopping at Bangalirhaat!</textarea></div>
      <div class="form-group"><label class="form-label">Show Consignment ID</label><div><label class="form-checkbox"><input type="checkbox" checked> Yes, show 9-digit consignment ID on invoice</label></div></div>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div></div>`;
}

async function saveInvoiceSettings(form) {
  const fd = new FormData(form);
  const entries = Object.fromEntries(fd);
  const settings = Object.entries(entries).map(([key, value]) => ({ key, value }));
  try { await AdminAPI.put('/settings', { settings }); showToast('Invoice settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── ANALYTICS / PIXEL SETTINGS ────────────────────────────────────────────────
async function initAnalyticsSettings() {
  const el = $('page-settings-analytics');
  let fbVal = '', gaVal = '', hjVal = '';
  try {
    const res = await AdminAPI.get('/settings/analytics');
    if (res.success && res.data) {
      fbVal = res.data.fb_pixel_id || res.data.fbPixelId || '';
      gaVal = res.data.ga4_id || res.data.ga4Id || '';
      hjVal = res.data.hotjar_id || res.data.hotjarId || '';
    }
  } catch {}
  el.innerHTML = `<div class="admin-page-header"><h1>Tracking &amp; Pixel Settings</h1></div>
  <div class="admin-form-section">
    <div class="admin-form-header">Facebook Pixel</div>
    <div class="admin-form-body">
      <form id="analyticsForm" onsubmit="saveAnalyticsSettings(this);return false">
        <div class="admin-form-grid">
          <div class="form-group"><label class="form-label">Facebook Pixel ID</label><input class="form-input" name="fb_pixel_id" value="${esc(fbVal)}" placeholder="e.g. 123456789012345"></div>
          <div class="form-group"><label class="form-label">GA4 Measurement ID</label><input class="form-input" name="ga4_id" value="${esc(gaVal)}" placeholder="e.g. G-XXXXXXXXXX"></div>
          <div class="form-group"><label class="form-label">Hotjar Site ID</label><input class="form-input" name="hotjar_id" value="${esc(hjVal)}" placeholder="e.g. 1234567"></div>
        </div>
        <div style="margin-top:var(--space-4);"><button type="submit" class="btn btn-primary">Save Tracking Settings</button></div>
      </form>
    </div>
  </div>
  <div class="admin-card"><div class="admin-card-header"><h3>📘 How to get your Pixel ID</h3></div><div class="admin-card-body" style="font-size:var(--text-sm);color:var(--text-secondary);line-height:1.7;">
    <p><strong>Facebook Pixel:</strong> Go to Meta Events Manager → Data Sources → Add → Web → Create pixel. Copy the Pixel ID (15 digits).</p>
    <p><strong>GA4:</strong> Go to Google Analytics → Admin → Data Streams → Your stream → Copy Measurement ID (starts with G-).</p>
    <p><strong>Hotjar:</strong> Go to Hotjar → Sites → Add site → Copy Site ID.</p>
    <p style="margin-top:var(--space-2);color:var(--text-muted);">After saving, refresh the website for changes to take effect.</p>
  </div></div>`;
}
async function saveAnalyticsSettings(form) {
  const fd = new FormData(form);
  const settings = [];
  for (const [key, value] of fd.entries()) {
    settings.push({ key, value: value || '', group: 'analytics' });
  }
  try { await AdminAPI.put('/settings', { settings }); showToast('Tracking settings saved! Refresh website.'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── AUDIT LOGS ───────────────────────────────────────────────────────────────
async function initAuditLogs() {
  const el = $('page-audit-logs');
  el.innerHTML = `<div class="admin-page-header"><h1>Audit Logs</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>User</th><th>Action</th><th>Entity</th><th>Time</th></tr></thead><tbody id="auditBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/security/audit-logs?limit=20');
    $('auditBody').innerHTML = (res.data.items || []).map(l => `<tr>
      <td style="font-size:var(--text-sm);">${esc(l.user_name || 'System')}</td>
      <td><span class="badge badge-secondary">${esc(l.action)}</span></td>
      <td style="font-size:var(--text-xs);">${esc(l.entity)} #${l.entity_id || ''}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(l.created_at)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No audit logs</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── LOGIN HISTORY ────────────────────────────────────────────────────────────
async function initLoginHistory() {
  const el = $('page-login-history');
  el.innerHTML = `<div class="admin-page-header"><h1>Login History</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>User</th><th>IP</th><th>Status</th><th>Time</th></tr></thead><tbody id="loginHistBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/security/login-history?limit=20');
    $('loginHistBody').innerHTML = (res.data.items || []).map(l => `<tr>
      <td style="font-size:var(--text-sm);">${esc(l.user_name || 'N/A')}</td>
      <td style="font-family:monospace;font-size:var(--text-xs);">${l.ip_address || '-'}</td>
      <td><span class="badge ${l.status === 'success' ? 'badge-success' : 'badge-danger'}">${l.status}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(l.created_at)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No login history</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── MODAL ────────────────────────────────────────────────────────────────────
function showModal(title, body) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay active';
  overlay.innerHTML = `<div class="modal modal-lg"><div class="modal-header"><h3>${esc(title)}</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button></div><div class="modal-body">${body}</div></div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
}

// ── ABANDONED CART ────────────────────────────────────────────────────────────
async function initAbandonedCart() {
  const el = $('page-abandoned-cart');
  el.innerHTML = `<div class="admin-page-header"><h1>Abandoned Cart Recovery</h1>
    <div style="display:flex;gap:var(--space-3);">
      <button class="btn btn-primary" onclick="processAbandonedCarts()">⚡ Process Now</button>
      <button class="btn btn-outline" onclick="initAbandonedCart()">🔄 Refresh</button>
    </div>
  </div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(3,1fr);" id="abandonedStats"></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Customer</th><th>Email</th><th>Items</th><th>Cart Total</th><th>Last Active</th></tr></thead><tbody id="abandonedCartBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const [statsRes, cartsRes] = await Promise.all([
      AdminAPI.get('/cart/recovery/stats'),
      AdminAPI.get('/cart/recovery/abandoned?hours=24')
    ]);
    const s = statsRes.data;
    if ($('abandonedStats')) $('abandonedStats').innerHTML = `
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Abandoned (24h)</div><div class="admin-stat-value">${s.total_abandoned}</div></div></div>
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Total Recovered</div><div class="admin-stat-value">${s.total_recovered}</div></div></div>
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Sent Today</div><div class="admin-stat-value">${s.today_sent}</div></div></div>`;
    $('abandonedCartBody').innerHTML = (cartsRes.data.items || []).length ? cartsRes.data.items.map(c => `<tr>
      <td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.customer_name)}</td>
      <td style="font-size:var(--text-xs);">${esc(c.email)}</td>
      <td>${c.item_count}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.cart_total || 0)}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(c.updated_at)}</td>
    </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No abandoned carts found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function processAbandonedCarts() {
  if (!await showConfirm('Process Abandoned Carts', 'Send recovery emails to all abandoned carts?')) return;
  try {
    const res = await AdminAPI.post('/cart/recovery/process', { hours: 24 });
    showToast(res.message || 'Processing complete');
    initAbandonedCart();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const user = AdminAuth.checkAuth();
  if (!user) { showLoginPage(); return; }

  // Load admin user info
  const avatarBtn = $('adminAvatarBtn');
  if (avatarBtn) avatarBtn.textContent = (user.first_name?.[0] || 'A').toUpperCase();

  // Sidebar nav
  qsa('.admin-nav-item').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(el.dataset.page);
    });
  });

  // Sidebar toggle
  const toggleBtn = $('toggleSidebar');
  const sidebar = $('adminSidebar');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
    });
  }

  // Notification toggle
  const notifBtn = qs('.notification-dot');
  const notifDropdown = $('notifDropdown');
  if (notifBtn && notifDropdown) {
    notifBtn.addEventListener('click', e => {
      e.stopPropagation();
      notifDropdown.classList.toggle('visible');
    });
    document.addEventListener('click', () => notifDropdown.classList.remove('visible'));
  }

  // Avatar dropdown
  const avatarToggle = $('adminAvatarDropdown');
  const avatarDropdown = $('avatarDropdown');
  if (avatarToggle && avatarDropdown) {
    qs('.admin-avatar', avatarToggle)?.addEventListener('click', e => {
      e.stopPropagation();
      avatarDropdown.classList.toggle('visible');
    });
    document.addEventListener('click', () => avatarDropdown.classList.remove('visible'));
  }

  // Logout
  const logoutBtn = $('adminLogoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => AdminAuth.logout());

  // Theme toggle
  const themeBtn = $('adminThemeToggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const html = document.documentElement;
      const isDark = html.getAttribute('data-theme') === 'dark';
      html.setAttribute('data-theme', isDark ? 'light' : 'dark');
      qs('.icon-sun', themeBtn).style.display = isDark ? '' : 'none';
      qs('.icon-moon', themeBtn).style.display = isDark ? 'none' : '';
      localStorage.setItem('adminTheme', isDark ? 'light' : 'dark');
    });
    const savedTheme = localStorage.getItem('adminTheme');
    if (savedTheme) document.documentElement.setAttribute('data-theme', savedTheme);
  }

  // Admin search with Ctrl+K
  const searchInput = $('adminSearch');
  if (searchInput) {
    document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); searchInput.focus(); } });
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.toLowerCase();
      qsa('.admin-nav-item').forEach(el => {
        el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }

  // Navigate to initial page (from URL hash or default)
  const hashPage = location.hash.slice(1) || 'dashboard-overview';
  navigateTo(hashPage);
});

function showLoginPage() {
  document.body.innerHTML = `<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg,#0a0a0f);padding:20px;">
    <div style="background:var(--surface,#1a1a2e);padding:40px;border-radius:16px;width:100%;max-width:400px;box-shadow:0 25px 50px rgba(0,0,0,0.3);border:1px solid var(--border,#2d2d44);">
      <div style="text-align:center;margin-bottom:32px;">
        <div style="font-size:36px;margin-bottom:8px;">&#9971;</div>
        <h1 style="font-size:22px;font-weight:700;margin:0 0 4px;color:var(--text,#e2e8f0);">Admin Login</h1>
        <p style="margin:0;color:var(--text-muted,#94a3b8);font-size:14px;">Bangalirhaat</p>
      </div>
      <form id="loginForm" onsubmit="handleLogin(this);return false">
        <div class="form-group"><label class="form-label" style="color:var(--text-secondary,#cbd5e1);">Email</label>
          <input class="form-input" type="email" name="email" value="admin@bangalirhaat.com" required style="min-height:46px;font-size:15px;"></div>
        <div class="form-group" style="margin-bottom:24px;"><label class="form-label" style="color:var(--text-secondary,#cbd5e1);">Password</label>
          <input class="form-input" type="password" name="password" value="Admin@123" required style="min-height:46px;font-size:15px;"></div>
        <button type="submit" class="btn btn-primary w-full" id="loginBtn" style="min-height:48px;font-size:15px;">Sign In</button>
        <p style="text-align:center;margin-top:16px;font-size:12px;color:var(--text-muted,#64748b);">Default: admin@bangalirhaat.com / Admin@123</p>
      </form>
    </div>
  </div>`;
}

async function handleLogin(form) {
  const btn = $('loginBtn'); loading(btn, true);
  const fd = new FormData(form);
  try {
    const res = await AdminAuth.login(fd.get('email'), fd.get('password'));
    if (res.success) { location.reload(); }
    else showToast(res.message || 'Login failed', 'error');
  } catch (e) { showToast(e.message || 'Login failed', 'error'); } finally { loading(btn, false); }
}

// ── MEDIA LIBRARY ────────────────────────────────────────────────────────────
async function initMedia() {
  const el = $('page-media');
  el.innerHTML = '<div class="admin-page-header"><h1>Media Library</h1><button class="btn btn-primary" onclick="document.getElementById(\'mediaUploadInput\').click()">+ Upload Files</button></div>' +
    '<input type="file" id="mediaUploadInput" multiple accept="image/*,.pdf,.doc,.docx" style="display:none;" onchange="uploadMediaFiles(this)">' +
    '<div class="admin-card"><div class="admin-card-body"><div id="mediaGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:var(--space-3);"><p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">Loading...</p></div></div></div>';
  await loadMedia();
}

async function loadMedia() {
  try {
    const res = await AdminAPI.get('/media');
    const items = res.data?.data || res.data?.items || res.data || [];
    const grid = $('mediaGrid');
    if (!grid) return;
    grid.innerHTML = items.length ? items.map(function (f) {
      var isImg = f.mime_type && f.mime_type.startsWith('image/');
      return '<div style="position:relative;border:1px solid var(--card-border);border-radius:var(--radius);overflow:hidden;background:var(--card);">' +
        (isImg ? '<img src="' + esc(f.url) + '" alt="' + esc(f.alt_text || f.original_name) + '" style="width:100%;height:120px;object-fit:cover;display:block;cursor:pointer;" onclick="window.open(\'' + esc(f.url) + '\',\'_blank\')">' :
          '<div style="width:100%;height:120px;display:flex;align-items:center;justify-content:center;background:var(--surface-secondary);font-size:32px;">📄</div>') +
        '<div style="padding:6px 8px;font-size:11px;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(f.original_name || f.filename) + '</div>' +
        '<button class="btn btn-sm btn-danger-ghost" style="position:absolute;top:4px;right:4px;padding:2px 6px;font-size:12px;border-radius:4px;" onclick="deleteMediaFile(' + f.id + ')">&times;</button></div>';
    }).join('') : '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">No files uploaded yet</p>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function uploadMediaFiles(input) {
  var files = input.files;
  if (!files.length) return;
  var formData = new FormData();
  for (var i = 0; i < files.length; i++) formData.append('files', files[i]);
  try {
    await AdminAPI.post('/media/upload', formData);
    showToast(files.length + ' file(s) uploaded');
    input.value = '';
    await loadMedia();
  } catch (e) { showToast(e.message, 'error'); }
}

async function deleteMediaFile(id) {
  if (!await showConfirm('Delete File', 'Are you sure?')) return;
  try {
    await AdminAPI.del('/media/' + id);
    showToast('File deleted');
    await loadMedia();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BANNERS ──────────────────────────────────────────────────────────────────
async function initBanners() {
  const el = $('page-banners');
  el.innerHTML = '<div class="admin-page-header"><h1>Banners</h1><button class="btn btn-primary" onclick="showAddBanner()">+ Add Banner</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Image</th><th>Title</th><th>Position</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead><tbody id="bannersBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadBanners();
}

async function loadBanners() {
  try {
    const res = await AdminAPI.get('/banners/admin/all');
    const items = res.data?.data || res.data?.items || res.data?.banners || [];
    $('bannersBody').innerHTML = items.length ? items.map(function (b) {
      return '<tr><td>' + (b.image_url ? '<img src="' + esc(b.image_url) + '" alt="" style="width:64px;height:40px;object-fit:cover;border-radius:var(--radius-sm);display:block;">' : '<div style="width:64px;height:40px;background:var(--glass-bg);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:18px;">🖼</div>') + '</td>' +
        '<td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(b.title) + '</div>' + (b.subtitle ? '<div style="font-size:var(--text-xs);color:var(--text-muted);">' + esc(b.subtitle) + '</div>' : '') + '</td>' +
        '<td><span class="badge badge-info">' + esc(b.position) + '</span></td>' +
        '<td style="text-align:center;">' + (b.sort_order || 0) + '</td>' +
        '<td><span class="badge ' + (b.is_active ? 'badge-success' : 'badge-secondary') + '">' + (b.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditBanner(' + b.id + ')">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteBanner(' + b.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No banners found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddBanner() {
  showModal('Add Banner', '<form id="bannerForm" onsubmit="saveBanner(this);return false">' +
    '<div class="form-group"><label class="form-label">Title *</label><input class="form-input" name="title" required></div>' +
    '<div class="form-group"><label class="form-label">Subtitle</label><input class="form-input" name="subtitle"></div>' +
    '<div class="form-group"><label class="form-label">Image URL *</label><input class="form-input" name="image_url" placeholder="https://..." required oninput="document.getElementById(\'bannerPreview\').src=this.value;document.getElementById(\'bannerPreview\').style.display=this.value?\'block\':\'none\'"><img id="bannerPreview" style="max-width:200px;max-height:80px;margin-top:6px;border-radius:var(--radius-sm);display:none;object-fit:cover;"></div>' +
    '<div class="form-group"><label class="form-label">Link URL</label><input class="form-input" name="link_url" placeholder="https://..."></div>' +
    '<div class="form-group"><label class="form-label">Link Text</label><input class="form-input" name="link_text" value="Shop Now"></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Position</label><select class="form-input" name="position"><option value="hero">Hero</option><option value="promo">Promo</option><option value="featured">Featured</option><option value="sidebar">Sidebar</option></select></div>' +
    '<div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="0"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">BG Color</label><input class="form-input" name="bg_color" type="color" value="#1a1a2e"></div>' +
    '<div class="form-group"><label class="form-label">Text Color</label><input class="form-input" name="text_color" type="color" value="#ffffff"></div></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Banner</button></form>');
}

async function saveBanner(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  data.sort_order = parseInt(data.sort_order) || 0;
  try { await AdminAPI.post('/banners', data); showToast('Banner created'); qs('.modal-overlay.active')?.classList.remove('active'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditBanner(id) {
  try {
    var res = await AdminAPI.get('/banners/admin/all');
    var items = res.data?.data || res.data?.items || res.data?.banners || [];
    var b = items.find(function (x) { return x.id === id; });
    if (!b) { showToast('Banner not found', 'error'); return; }
    showModal('Edit Banner', '<form id="bannerForm" onsubmit="updateBanner(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Title *</label><input class="form-input" name="title" value="' + esc(b.title) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Subtitle</label><input class="form-input" name="subtitle" value="' + esc(b.subtitle || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Image URL *</label><input class="form-input" name="image_url" value="' + esc(b.image_url) + '" required oninput="document.getElementById(\'bannerPreview\').src=this.value;document.getElementById(\'bannerPreview\').style.display=this.value?\'block\':\'none\'"><img id="bannerPreview" src="' + esc(b.image_url) + '" style="max-width:200px;max-height:80px;margin-top:6px;border-radius:var(--radius-sm);display:block;object-fit:cover;"></div>' +
      '<div class="form-group"><label class="form-label">Link URL</label><input class="form-input" name="link_url" value="' + esc(b.link_url || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Link Text</label><input class="form-input" name="link_text" value="' + esc(b.link_text || 'Shop Now') + '"></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Position</label><select class="form-input" name="position"><option value="hero"' + (b.position === 'hero' ? ' selected' : '') + '>Hero</option><option value="promo"' + (b.position === 'promo' ? ' selected' : '') + '>Promo</option><option value="featured"' + (b.position === 'featured' ? ' selected' : '') + '>Featured</option><option value="sidebar"' + (b.position === 'sidebar' ? ' selected' : '') + '>Sidebar</option></select></div>' +
      '<div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="' + (b.sort_order || 0) + '"></div></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (b.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Banner</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateBanner(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  data.sort_order = parseInt(data.sort_order) || 0;
  try { await AdminAPI.put('/banners/' + id, data); showToast('Banner updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteBanner(id) {
  if (!await showConfirm('Delete Banner', 'Are you sure?')) return;
  try { await AdminAPI.del('/banners/' + id); showToast('Banner deleted'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── REVIEWS (ADMIN MODERATION) ───────────────────────────────────────────────
async function initAdminReviews() {
  var el = $('page-reviews');
  el.innerHTML = '<div class="admin-page-header"><h1>Reviews</h1><div style="display:flex;gap:8px;"><button class="btn btn-sm ' + (window._reviewFilter === 'pending' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'pending\';initAdminReviews()">Pending</button><button class="btn btn-sm ' + (window._reviewFilter === 'approved' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'approved\';initAdminReviews()">Approved</button><button class="btn btn-sm ' + (!window._reviewFilter || window._reviewFilter === 'all' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'all\';initAdminReviews()">All</button></div></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="reviewsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  try {
    var status = window._reviewFilter || 'all';
    var res = await AdminAPI.get('/reviews?status=' + status + '&limit=50');
    var items = res.data?.data?.items || res.data?.items || [];
    $('reviewsBody').innerHTML = items.length ? items.map(function (r) {
      var stars = ''; for (var s = 0; s < 5; s++) stars += '<svg width="14" height="14" viewBox="0 0 24 24" fill="' + (s < r.rating ? '#f59e0b' : '#333') + '" stroke="' + (s < r.rating ? '#f59e0b' : '#555') + '" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
      return '<tr><td style="font-size:var(--text-sm);font-weight:var(--weight-medium);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(r.product_name) + '</td>' +
        '<td style="font-size:var(--text-sm);">' + esc(r.user_name || 'N/A') + '</td>' +
        '<td>' + stars + '</td>' +
        '<td style="font-size:var(--text-sm);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-secondary);">' + esc(r.comment || r.title || '-') + '</td>' +
        '<td><span class="badge ' + (r.is_approved ? 'badge-success' : 'badge-warning') + '">' + (r.is_approved ? 'Approved' : 'Pending') + '</span></td>' +
        '<td style="font-size:var(--text-xs);color:var(--text-muted);">' + dateStr(r.created_at) + '</td>' +
        '<td><div class="admin-actions">' +
        (!r.is_approved ? '<button class="btn btn-sm btn-success-ghost" onclick="approveReview(' + r.id + ',1)">Approve</button>' : '<button class="btn btn-sm btn-ghost" onclick="approveReview(' + r.id + ',0)">Reject</button>') +
        '<button class="btn btn-sm btn-danger-ghost" onclick="deleteReview(' + r.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">No reviews found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function approveReview(id, approved) {
  try { await AdminAPI.put('/reviews/' + id + '/approve', { approved: approved }); showToast(approved ? 'Review approved' : 'Review rejected'); initAdminReviews(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteReview(id) {
  if (!await showConfirm('Delete Review', 'Delete this review permanently?')) return;
  try { await AdminAPI.del('/reviews/' + id); showToast('Review deleted'); initAdminReviews(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── PAYMENT GATEWAY SETTINGS ─────────────────────────────────────────────────
async function initPaymentSettings() {
  var el = $('page-settings-payment');
  el.innerHTML = '<div class="admin-page-header"><h1>Payment Gateway Settings</h1></div><div class="admin-card"><div class="admin-card-body"><p style="color:var(--text-muted);margin-bottom:var(--space-4);">Configure payment gateways for your store.</p><form id="paymentForm" onsubmit="savePaymentSettings(this);return false"><div id="paymentFormFields">Loading...</div><button type="submit" class="btn btn-primary">Save Settings</button></form></div></div>';
  try {
    var res = await AdminAPI.get('/payment-methods');
    var cfg = res.data?.data?.config || res.data?.config || {};
    $('paymentFormFields').innerHTML =
      '<div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="cod_enabled" value="1" ' + (cfg.cod_enabled === '1' ? 'checked' : '') + '> Cash on Delivery (COD)</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="bkash_enabled" value="1" ' + (cfg.bkash_enabled === '1' ? 'checked' : '') + '> bKash</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="nagad_enabled" value="1" ' + (cfg.nagad_enabled === '1' ? 'checked' : '') + '> Nagad</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="rocket_enabled" value="1" ' + (cfg.rocket_enabled === '1' ? 'checked' : '') + '> Rocket</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="sslcommerz_enabled" value="1" ' + (cfg.sslcommerz_enabled === '1' ? 'checked' : '') + '> SSLCommerz</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="stripe_enabled" value="1" ' + (cfg.stripe_enabled === '1' ? 'checked' : '') + '> Stripe</label></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>bKash / Nagad / Rocket</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">bKash Number</label><input class="form-input" name="bkash_number" value="' + esc(cfg.bkash_number || '') + '" placeholder="01XXXXXXXXX"></div>' +
      '<div class="form-group"><label class="form-label">Nagad Number</label><input class="form-input" name="nagad_number" value="' + esc(cfg.nagad_number || '') + '" placeholder="01XXXXXXXXX"></div>' +
      '<div class="form-group"><label class="form-label">Rocket Number</label><input class="form-input" name="rocket_number" value="' + esc(cfg.rocket_number || '') + '" placeholder="01XXXXXXXXX"></div></div></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>SSLCommerz</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">Store ID</label><input class="form-input" name="sslcommerz_store_id" value="' + esc(cfg.sslcommerz_store_id || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Store Password</label><input class="form-input" name="sslcommerz_store_pass" type="password" value="' + esc(cfg.sslcommerz_store_pass || '') + '"></div></div></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>Stripe</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">Publishable Key</label><input class="form-input" name="stripe_publishable_key" value="' + esc(cfg.stripe_publishable_key || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Secret Key</label><input class="form-input" name="stripe_secret_key" type="password" value="' + esc(cfg.stripe_secret_key || '') + '"></div></div></div></div>';
  } catch (e) { $('paymentFormFields').innerHTML = '<p style="color:var(--text-muted);">Error loading settings</p>'; }
}

async function savePaymentSettings() {
  var form = $('paymentForm');
  var fd = new FormData(form);
  var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  ['cod_enabled','bkash_enabled','nagad_enabled','rocket_enabled','sslcommerz_enabled','stripe_enabled'].forEach(function (k) { if (data[k] !== '1') data[k] = '0'; });
  try { await AdminAPI.put('/payment-methods', data); showToast('Payment settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── TAX / VAT SETTINGS ───────────────────────────────────────────────────────
async function initTaxSettings() {
  var el = $('page-settings-tax');
  el.innerHTML = '<div class="admin-page-header"><h1>Tax / VAT Settings</h1></div><div class="admin-card"><div class="admin-card-body"><form id="taxForm" onsubmit="saveTaxSettings(this);return false"><div class="admin-form-grid">' +
    '<div class="form-group"><label class="form-label">VAT Rate (%)</label><input class="form-input" name="vat_rate" id="taxVatRate" type="number" step="0.01" value="5"></div>' +
    '<div class="form-group"><label class="form-label">Tax Name / Label</label><input class="form-input" name="tax_name" id="taxName" value="VAT"></div></div>' +
    '<div class="form-group"><label class="form-label">VAT Registration No.</label><input class="form-input" name="vat_registration_no" id="taxRegNo"></div>' +
    '<div class="form-group"><div class="form-checkbox"><input type="checkbox" name="tax_included" id="taxIncluded" value="1"> Prices include tax (inclusive pricing)</div></div>' +
    '<button type="submit" class="btn btn-primary">Save Settings</button></form></div></div>';
  try {
    var res = await AdminAPI.get('/tax-settings');
    var cfg = res.data?.data || res.data || {};
    if ($('taxVatRate')) $('taxVatRate').value = cfg.vat_rate || '5';
    if ($('taxName')) $('taxName').value = cfg.tax_name || 'VAT';
    if ($('taxRegNo')) $('taxRegNo').value = cfg.vat_registration_no || '';
    if ($('taxIncluded')) $('taxIncluded').checked = cfg.tax_included === '1';
  } catch (e) { /* ignore */ }
}

async function saveTaxSettings(form) {
  var fd = new FormData(form);
  var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  if (data.tax_included !== '1') data.tax_included = '0';
  try { await AdminAPI.put('/tax-settings', data); showToast('Tax settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── EMAIL TEMPLATES ──────────────────────────────────────────────────────────
async function initEmailTemplates() {
  var el = $('page-settings-email-templates');
  el.innerHTML = '<div class="admin-page-header"><h1>Email Templates</h1><button class="btn btn-primary" onclick="showAddEmailTemplate()">+ Add Template</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Slug</th><th>Type</th><th>Subject</th><th>Status</th><th>Actions</th></tr></thead><tbody id="emailTemplatesBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadEmailTemplates();
}

async function loadEmailTemplates() {
  try {
    var res = await AdminAPI.get('/email-templates');
    var items = res.data?.data?.items || res.data?.data || res.data?.items || res.data || [];
    if (!Array.isArray(items)) items = [];
    $('emailTemplatesBody').innerHTML = items.length ? items.map(function (t) {
      return '<tr><td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(t.name) + '</td>' +
        '<td style="font-size:var(--text-xs);font-family:monospace;color:var(--text-muted);">' + esc(t.slug) + '</td>' +
        '<td><span class="badge badge-info">' + esc(t.type) + '</span></td>' +
        '<td style="font-size:var(--text-sm);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-secondary);">' + esc(t.subject) + '</td>' +
        '<td><span class="badge ' + (t.is_active ? 'badge-success' : 'badge-secondary') + '">' + (t.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditEmailTemplate(' + t.id + ')">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteEmailTemplate(' + t.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No templates found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddEmailTemplate() {
  showModal('Add Email Template', '<form id="emailTemplateForm" onsubmit="saveEmailTemplate(this);return false">' +
    '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>' +
    '<div class="form-group"><label class="form-label">Subject *</label><input class="form-input" name="subject" required></div>' +
    '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="email">Email</option><option value="sms">SMS</option></select></div>' +
    '<div class="form-group"><label class="form-label">Body *<br><small style="color:var(--text-muted);">Use {variable_name} for placeholders</small></label><textarea class="form-input" name="body" rows="8" required></textarea></div>' +
    '<div class="form-group"><label class="form-label">Variables (comma-separated)</label><input class="form-input" name="variables" placeholder="e.g. order_number, customer_name, total"></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Template</button></form>');
}

async function saveEmailTemplate(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.post('/email-templates', data); showToast('Template created'); qs('.modal-overlay.active')?.classList.remove('active'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditEmailTemplate(id) {
  try {
    var res = await AdminAPI.get('/email-templates');
    var items = res.data?.data?.items || res.data?.data || res.data?.items || res.data || [];
    if (!Array.isArray(items)) items = [];
    var t = items.find(function (x) { return x.id === id; });
    if (!t) { showToast('Template not found', 'error'); return; }
    showModal('Edit Email Template', '<form id="emailTemplateForm" onsubmit="updateEmailTemplate(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" value="' + esc(t.name) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Subject *</label><input class="form-input" name="subject" value="' + esc(t.subject) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="email"' + (t.type === 'email' ? ' selected' : '') + '>Email</option><option value="sms"' + (t.type === 'sms' ? ' selected' : '') + '>SMS</option></select></div>' +
      '<div class="form-group"><label class="form-label">Body *</label><textarea class="form-input" name="body" rows="8" required>' + esc(t.body) + '</textarea></div>' +
      '<div class="form-group"><label class="form-label">Variables</label><input class="form-input" name="variables" value="' + esc(t.variables || '') + '"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (t.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Template</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateEmailTemplate(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/email-templates/' + id, data); showToast('Template updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteEmailTemplate(id) {
  if (!await showConfirm('Delete Template', 'Are you sure?')) return;
  try { await AdminAPI.del('/email-templates/' + id); showToast('Template deleted'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── STAFF MANAGEMENT ─────────────────────────────────────────────────────────
async function initStaff() {
  var el = $('page-staff');
  el.innerHTML = '<div class="admin-page-header"><h1>Staff Management</h1><button class="btn btn-primary" onclick="showAddStaff()">+ Add Staff</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead><tbody id="staffBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadStaff();
}

async function loadStaff() {
  try {
    var res = await AdminAPI.get('/staff');
    var items = res.data?.data?.items || res.data?.items || [];
    $('staffBody').innerHTML = items.length ? items.map(function (u) {
      var roleBadge = { super_admin: 'badge-danger', admin: 'badge-primary', moderator: 'badge-warning', staff: 'badge-info' };
      return '<tr><td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(u.first_name + ' ' + (u.last_name || '')) + '</div></td>' +
        '<td style="font-size:var(--text-xs);">' + esc(u.email) + '</td>' +
        '<td>' + esc(u.phone || '-') + '</td>' +
        '<td><span class="badge ' + (roleBadge[u.role] || 'badge-secondary') + '">' + esc(u.role) + '</span></td>' +
        '<td><span class="badge ' + (u.is_active ? 'badge-success' : 'badge-secondary') + '">' + (u.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions">' +
        '<button class="btn btn-sm btn-ghost" onclick="showEditStaff(' + u.id + ')">Edit</button>' +
        (u.role !== 'super_admin' ? '<button class="btn btn-sm btn-danger-ghost" onclick="deleteStaff(' + u.id + ')">Delete</button>' : '') +
        '</div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No staff found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddStaff() {
  showModal('Add Staff', '<form id="staffForm" onsubmit="saveStaff(this);return false">' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">First Name *</label><input class="form-input" name="first_name" required></div>' +
    '<div class="form-group"><label class="form-label">Last Name</label><input class="form-input" name="last_name"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Email *</label><input class="form-input" name="email" type="email" required></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Password *</label><input class="form-input" name="password" type="password" required minlength="6"></div>' +
    '<div class="form-group"><label class="form-label">Role</label><select class="form-input" name="role"><option value="staff">Staff</option><option value="moderator">Moderator</option><option value="admin">Admin</option></select></div></div>' +
    '<button type="submit" class="btn btn-primary w-full">Add Staff</button></form>');
}

async function saveStaff(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  try { await AdminAPI.post('/staff', data); showToast('Staff added'); qs('.modal-overlay.active')?.classList.remove('active'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditStaff(id) {
  try {
    var res = await AdminAPI.get('/staff');
    var items = res.data?.data?.items || res.data?.items || [];
    var u = items.find(function (x) { return x.id === id; });
    if (!u) { showToast('Staff not found', 'error'); return; }
    showModal('Edit Staff', '<form id="staffForm" onsubmit="updateStaff(' + id + ',this);return false">' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">First Name</label><input class="form-input" name="first_name" value="' + esc(u.first_name) + '"></div>' +
      '<div class="form-group"><label class="form-label">Last Name</label><input class="form-input" name="last_name" value="' + esc(u.last_name || '') + '"></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone" value="' + esc(u.phone || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Role</label><select class="form-input" name="role"><option value="staff"' + (u.role === 'staff' ? ' selected' : '') + '>Staff</option><option value="moderator"' + (u.role === 'moderator' ? ' selected' : '') + '>Moderator</option><option value="admin"' + (u.role === 'admin' ? ' selected' : '') + '>Admin</option></select></div></div>' +
      '<div class="form-group"><label class="form-label">New Password (leave blank to keep)</label><input class="form-input" name="password" type="password" minlength="6"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (u.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Staff</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateStaff(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  if (!data.password) delete data.password;
  try { await AdminAPI.put('/staff/' + id, data); showToast('Staff updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteStaff(id) {
  if (!await showConfirm('Delete Staff', 'Remove this staff member permanently?')) return;
  try { await AdminAPI.del('/staff/' + id); showToast('Staff deleted'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── THEME SETTINGS ────────────────────────────────────────────────────────────
function initThemeSettings() {
  var currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
  $('page-settings-theme').innerHTML = '<div class="admin-page-header"><h1>Theme Settings</h1></div>' +
    '<div class="admin-card"><div class="admin-card-body">' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);margin-bottom:var(--space-6);">' +
    '<div onclick="setAdminTheme(\'dark\')" style="cursor:pointer;padding:var(--space-4);border-radius:var(--radius-lg);border:2px solid ' + (currentTheme === 'dark' ? 'var(--primary)' : 'var(--card-border)') + ';background:#0f0f1a;color:#e2e8f0;text-align:center;"><div style="font-size:36px;margin-bottom:8px;">🌙</div><div style="font-weight:var(--weight-semibold);">Dark Mode</div><div style="font-size:var(--text-xs);color:#94a3b8;">Default theme</div></div>' +
    '<div onclick="setAdminTheme(\'light\')" style="cursor:pointer;padding:var(--space-4);border-radius:var(--radius-lg);border:2px solid ' + (currentTheme === 'light' ? 'var(--primary)' : 'var(--card-border)') + ';background:#ffffff;color:#1a1a2e;text-align:center;"><div style="font-size:36px;margin-bottom:8px;">☀️</div><div style="font-weight:var(--weight-semibold);">Light Mode</div><div style="font-size:var(--text-xs);color:#64748b;">Clean & bright</div></div></div>' +
    '<p style="color:var(--text-muted);font-size:var(--text-sm);">Theme settings are stored in your browser. More customization options coming soon.</p></div></div>';
}

function setAdminTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('adminTheme', theme);
  initThemeSettings();
  showToast('Theme set to ' + theme + ' mode');
}

// ── DELIVERY ZONES (dynamic) ──────────────────────────────────────────────────
async function initDeliveryZones() {
  var el = $('page-delivery-zones');
  el.innerHTML = '<div class="admin-page-header"><h1>Delivery Zones</h1><button class="btn btn-primary" onclick="showAddZone()">+ Add Zone</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Zone</th><th>Inside Dhaka</th><th>Outside Dhaka</th><th>Status</th><th>Actions</th></tr></thead><tbody id="zonesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  try {
    var res = await AdminAPI.get('/delivery/zones');
    var items = res.data?.data?.zones || res.data?.zones || res.data?.data || res.data || [];
    if (!Array.isArray(items)) items = [];
    $('zonesBody').innerHTML = items.length ? items.map(function (z) {
      return '<tr><td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(z.name || z.zone) + '</td>' +
        '<td>' + currency(z.inside_dhaka || z.dhaka_rate || 0) + '</td>' +
        '<td>' + currency(z.outside_dhaka || z.outside_rate || 0) + '</td>' +
        '<td><span class="badge ' + (z.is_active !== 0 ? 'badge-success' : 'badge-secondary') + '">' + ((z.is_active !== 0) ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast(\'Edit: implement\')">Edit</button></div></td></tr>';
    }).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No zones configured</td></tr>';
  } catch (e) {
    $('zonesBody').innerHTML = '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Could not load zones</td></tr>';
  }
}

function showAddZone() {
  showModal('Add Delivery Zone', '<form id="zoneForm" onsubmit="saveZone(this);return false">' +
    '<div class="form-group"><label class="form-label">Zone Name *</label><input class="form-input" name="name" required></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Inside Dhaka Rate</label><input class="form-input" name="inside_dhaka" type="number" step="0.01" value="60"></div>' +
    '<div class="form-group"><label class="form-label">Outside Dhaka Rate</label><input class="form-input" name="outside_dhaka" type="number" step="0.01" value="120"></div></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Zone</button></form>');
}

async function saveZone(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.inside_dhaka = parseFloat(data.inside_dhaka) || 0;
  data.outside_dhaka = parseFloat(data.outside_dhaka) || 0;
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.post('/delivery/zones', data); showToast('Zone created'); qs('.modal-overlay.active')?.classList.remove('active'); initDeliveryZones(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: BRANDS EDIT/DELETE ──────────────────────────────────────────────────
async function showEditBrand(id) {
  try {
    var res = await AdminAPI.get('/brands');
    var items = res.data?.items || [];
    var b = items.find(function (x) { return x.id === id; });
    if (!b) { showToast('Brand not found', 'error'); return; }
    showModal('Edit Brand', '<form id="brandEditForm" onsubmit="updateBrand(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" value="' + esc(b.name) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3">' + esc(b.description || '') + '</textarea></div>' +
      '<div class="form-group"><label class="form-label">Logo URL</label><input class="form-input" name="logo" value="' + esc(b.logo || '') + '"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (b.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Brand</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateBrand(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/brands/' + id, data); showToast('Brand updated'); qs('.modal-overlay.active')?.classList.remove('active'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteBrand(id) {
  if (!await showConfirm('Delete Brand', 'Permanently delete this brand?')) return;
  try { await AdminAPI.del('/brands/' + id); showToast('Brand deleted'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: COUPONS EDIT ────────────────────────────────────────────────────────
async function showEditCoupon(id) {
  try {
    var res = await AdminAPI.get('/marketing/coupons');
    var items = res.data?.items || [];
    var c = items.find(function (x) { return x.id === id; });
    if (!c) { showToast('Coupon not found', 'error'); return; }
    showModal('Edit Coupon', '<form id="couponEditForm" onsubmit="updateCoupon(' + id + ',this);return false">' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Code</label><input class="form-input" name="code" value="' + esc(c.code) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="percentage"' + (c.type === 'percentage' ? ' selected' : '') + '>Percentage</option><option value="fixed"' + (c.type === 'fixed' ? ' selected' : '') + '>Fixed</option><option value="free_shipping"' + (c.type === 'free_shipping' ? ' selected' : '') + '>Free Shipping</option></select></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Value</label><input class="form-input" name="value" type="number" step="0.01" value="' + c.value + '"></div>' +
      '<div class="form-group"><label class="form-label">Min Order</label><input class="form-input" name="minimum_order" type="number" step="0.01" value="' + c.minimum_order + '"></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Usage Limit</label><input class="form-input" name="usage_limit" type="number" value="' + (c.usage_limit || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Max Discount</label><input class="form-input" name="maximum_discount" type="number" step="0.01" value="' + (c.maximum_discount || '') + '"></div></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (c.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Coupon</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateCoupon(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.value = parseFloat(data.value) || 0;
  data.minimum_order = parseFloat(data.minimum_order) || 0;
  data.usage_limit = data.usage_limit ? parseInt(data.usage_limit) : null;
  data.maximum_discount = data.maximum_discount ? parseFloat(data.maximum_discount) : null;
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/marketing/coupons/' + id, data); showToast('Coupon updated'); qs('.modal-overlay.active')?.classList.remove('active'); initCoupons(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: CUSTOMER DETAIL VIEW ────────────────────────────────────────────────
async function viewCustomer(id) {
  try {
    var res = await AdminAPI.get('/customers');
    var items = res.data?.items || [];
    var c = items.find(function (x) { return x.id === id; });
    if (!c) { showToast('Customer not found', 'error'); return; }
    showModal('Customer Details: ' + esc(c.first_name + ' ' + c.last_name),
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);">' +
      '<div><strong>Name:</strong> ' + esc(c.first_name + ' ' + (c.last_name || '')) + '</div>' +
      '<div><strong>Email:</strong> ' + esc(c.email) + '</div>' +
      '<div><strong>Phone:</strong> ' + esc(c.phone || '-') + '</div>' +
      '<div><strong>Total Orders:</strong> ' + (c.total_orders || 0) + '</div>' +
      '<div><strong>Total Spent:</strong> ' + currency(c.total_spent || 0) + '</div>' +
      '<div><strong>VIP:</strong> ' + (c.is_vip ? 'Yes' : 'No') + '</div>' +
      '<div><strong>Registered:</strong> ' + dateStr(c.created_at) + '</div>' +
      '<div><strong>Last Order:</strong> ' + (c.last_order_at ? dateStr(c.last_order_at) : '-') + '</div></div>');
  } catch (e) { showToast(e.message, 'error'); }
}

/* ==========================================================================
   Bangalirhaat — GSAP Animation Controller
   Full animation system: ScrollTrigger, Lenis smooth scroll, hero entrance,
   parallax, magnetic buttons, custom cursor, text splitting, marquee, counters.
   ========================================================================== */

const BAnimation = {
  lenis: null,
  isInitialized: false,

  /* ========================================================================
     init — Bootstrap all animation systems
     ======================================================================== */
  init() {
    if (this.isInitialized) return;
    if (typeof gsap === 'undefined') {
      console.warn('[BAnimation] GSAP not loaded');
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    this.initLoadingAnimation();
    this.smoothScroll();
    this.initSmoothScroll();
    this.hero();
    this.scrollReveal();
    this.initStaggerReveal();
    this.parallax();
    this.initParallaxLayers();
    this.productCards();
    this.navbar();
    this.counterUp();
    this.magneticButton();
    this.initMagneticEffect();
    this.cursor();
    this.marquee();
    this.preload();
    this.initTextReveal();

    this.isInitialized = true;
  },

  /* ========================================================================
     smoothScroll — Lenis smooth scroll initialization
     ======================================================================== */
  smoothScroll() {
    if (typeof Lenis === 'undefined') return;

    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    this.lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const scrollAmount = e.key === 'ArrowDown' ? 300 : -300;
        this.lenis.scrollBy(scrollAmount);
      }
    });
  },

  /* ========================================================================
     hero — Hero section entrance animation
     ======================================================================== */
  hero() {
    const heroSection = document.querySelector('.hero-section');
    if (!heroSection) return;

    const tl = gsap.timeline({ delay: 0.3 });

    const tagline = heroSection.querySelector('.hero-section-content span:first-child, .hero-section-content .section-badge, [data-animate]:first-child');
    const title = heroSection.querySelector('.hero-3d-title, h1, .hero-title');
    const subtitle = heroSection.querySelector('.hero-subtitle, .hero-section-content p');
    const actions = heroSection.querySelector('.hero-actions, .hero-section-content .btn');
    const stats = heroSection.querySelector('.hero-stats');
    const floating = heroSection.querySelectorAll('.hero-floating');

    if (tagline) {
      tl.from(tagline, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      });
    }

    if (title) {
      const chars = title.querySelectorAll('.gradient-text, span');
      if (chars.length > 0) {
        tl.from(title, { y: 40, opacity: 0, duration: 0.01 }, '-=0.3');
        tl.from(chars, {
          y: 30,
          opacity: 0,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power3.out',
        }, '-=0.3');
      } else {
        tl.from(title, {
          y: 50,
          opacity: 0,
          duration: 0.8,
          ease: 'power3.out',
        }, '-=0.3');
      }
    }

    if (subtitle) {
      tl.from(subtitle, {
        y: 30,
        opacity: 0,
        duration: 0.7,
        ease: 'power3.out',
      }, '-=0.4');
    }

    if (actions) {
      tl.from(actions, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      }, '-=0.3');
    }

    if (stats) {
      tl.from(stats, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      }, '-=0.2');
    }

    if (floating.length > 0) {
      tl.from(floating, {
        scale: 0,
        opacity: 0,
        duration: 0.5,
        stagger: 0.15,
        ease: 'back.out(1.7)',
      }, '-=0.4');
    }

    floating.forEach((el) => {
      gsap.to(el, {
        y: -12,
        duration: 2 + Math.random() * 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: Math.random() * 2,
      });
    });
  },

  /* ========================================================================
     scrollReveal — All .reveal elements animate on scroll
     ======================================================================== */
  scrollReveal() {
    const revealElements = document.querySelectorAll(
      '.reveal, .reveal-up, .reveal-down, .reveal-left, .reveal-right, .reveal-scale, .reveal-fade, .stagger-children, .rotate-in, .rotate-out, .slide-in-left, .slide-in-right, .slide-in-up, .slide-in-down, .scale-in, .scale-out, .blur-in, .blur-out'
    );

    revealElements.forEach((el) => {
      const delay = parseFloat(el.dataset.delay) || 0;
      const duration = parseFloat(el.dataset.duration) || 0.8;

      ScrollTrigger.create({
        trigger: el,
        start: 'top 88%',
        once: true,
        onEnter: () => {
          gsap.to(el, {
            delay: delay,
            duration: duration,
            onStart: () => el.classList.add('revealed'),
          });
        },
      });
    });

    gsap.utils.toArray('.section-header').forEach((el) => {
      const children = el.children;
      if (!children || children.length === 0) return;

      gsap.from(Array.from(children), {
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.category-banner, .category-grid > *').forEach((el, i) => {
      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 88%',
          toggleActions: 'play none none none',
        },
        y: 40,
        opacity: 0,
        duration: 0.5,
        delay: i * 0.06,
        ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.review-card, .newsletter-card, .video-banner').forEach((el) => {
      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.7,
        ease: 'power3.out',
      });
    });
  },

  /* ========================================================================
     parallax — Parallax layers on scroll
     ======================================================================== */
  parallax() {
    gsap.utils.toArray('.parallax-layer').forEach((layer) => {
      const speed = parseFloat(layer.dataset.speed) || 0.3;
      const direction = layer.dataset.direction || 'y';

      const prop = { y: 0, x: 0 };

      gsap.to(prop, {
        y: direction === 'y' ? speed * -150 : 0,
        x: direction === 'x' ? speed * -100 : 0,
        ease: 'none',
        scrollTrigger: {
          trigger: layer.parentElement,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
        },
      });

      gsap.to(layer, {
        y: () => prop.y,
        x: () => prop.x,
        ease: 'none',
        scrollTrigger: {
          trigger: layer.parentElement,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
        },
      });
    });

    const heroBg = document.querySelector('.hero-section-bg');
    if (heroBg) {
      gsap.to(heroBg, {
        y: 200,
        ease: 'none',
        scrollTrigger: {
          trigger: '.hero-section',
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      });
    }

    gsap.utils.toArray('[data-parallax]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallax) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });
  },

  /* ========================================================================
     productCards — Staggered card entrance on scroll
     ======================================================================== */
  productCards() {
    const grids = gsap.utils.toArray('.product-grid');
    grids.forEach((grid) => {
      const cards = grid.children;
      if (!cards || cards.length === 0) return;

      gsap.from(Array.from(cards), {
        scrollTrigger: {
          trigger: grid,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 50,
        opacity: 0,
        duration: 0.5,
        stagger: {
          each: 0.08,
          from: 'start',
        },
        ease: 'power3.out',
      });
    });

    const swiperWrappers = gsap.utils.toArray('.swiper-wrapper');
    swiperWrappers.forEach((wrapper) => {
      const slides = wrapper.children;
      if (!slides || slides.length === 0) return;

      gsap.from(Array.from(slides), {
        scrollTrigger: {
          trigger: wrapper,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        x: 60,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        ease: 'power3.out',
      });
    });
  },

  /* ========================================================================
     navbar — Scroll-based navbar style change
     ======================================================================== */
  navbar() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;

    ScrollTrigger.create({
      start: 'top -80',
      end: 99999,
      toggleClass: { className: 'navbar-scrolled', targets: navbar },
    });

    const brandText = navbar.querySelector('.navbar-brand-text');
    if (brandText) {
      ScrollTrigger.create({
        start: 'top -120',
        end: 99999,
        onEnter: () => {
          gsap.to(brandText, { opacity: 1, duration: 0.3 });
        },
        onLeaveBack: () => {
          gsap.to(brandText, { opacity: 1, duration: 0.3 });
        },
      });
    }
  },

  /* ========================================================================
     counterUp — Animated number counters
     ======================================================================== */
  counterUp() {
    const counters = document.querySelectorAll('[data-counter]');

    counters.forEach((el) => {
      const target = parseInt(el.dataset.counter, 10);
      if (isNaN(target)) return;

      const formatNumber = (num) => {
        if (num >= 10000) {
          return (num / 1000).toFixed(num >= 100000 ? 0 : 1) + 'K+';
        }
        if (num >= 1000) {
          return (num / 1000).toFixed(1) + 'K+';
        }
        return num + '+';
      };

      const obj = { val: 0 };

      ScrollTrigger.create({
        trigger: el,
        start: 'top 90%',
        once: true,
        onEnter: () => {
          gsap.to(obj, {
            val: target,
            duration: 2,
            delay: 0.3,
            ease: 'power2.out',
            onUpdate() {
              el.textContent = formatNumber(Math.round(obj.val));
            },
          });
        },
      });
    });
  },

  /* ========================================================================
     magneticButton — Magnetic hover effect on buttons
     ======================================================================== */
  magneticButton() {
    const buttons = document.querySelectorAll('.magnetic-btn, .btn-primary, .btn-pill');

    buttons.forEach((btn) => {
      const strength = parseFloat(btn.dataset.magneticStrength) || 0.3;

      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        gsap.to(btn, {
          x: x * strength,
          y: y * strength,
          duration: 0.3,
          ease: 'power2.out',
        });
      });

      btn.addEventListener('mouseleave', () => {
        gsap.to(btn, {
          x: 0,
          y: 0,
          duration: 0.5,
          ease: 'elastic.out(1, 0.3)',
        });
      });
    });
  },

  /* ========================================================================
     cursor — Custom cursor follower
     ======================================================================== */
  cursor() {
    if (window.matchMedia('(pointer: coarse)').matches) return;

    let cursor = document.querySelector('.custom-cursor');
    let cursorDot = document.querySelector('.custom-cursor-dot');

    if (!cursor) {
      cursor = document.createElement('div');
      cursor.className = 'custom-cursor';
      document.body.appendChild(cursor);
    }

    if (!cursorDot) {
      cursorDot = document.createElement('div');
      cursorDot.className = 'custom-cursor-dot';
      document.body.appendChild(cursorDot);
    }

    Object.assign(cursor.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '40px',
      height: '40px',
      borderRadius: '50%',
      border: '1.5px solid rgba(220, 20, 60, 0.5)',
      pointerEvents: 'none',
      zIndex: '9999',
      transition: 'width 0.3s, height 0.3s, border-color 0.3s, background 0.3s',
      transform: 'translate(-50%, -50%)',
      willChange: 'transform',
      mixBlendMode: 'difference',
    });

    Object.assign(cursorDot.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: '#dc143c',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      willChange: 'transform',
    });

    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;
    let dotX = 0;
    let dotY = 0;

    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });

    const animateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.12;
      cursorY += (mouseY - cursorY) * 0.12;
      dotX += (mouseX - dotX) * 0.25;
      dotY += (mouseY - dotY) * 0.25;

      cursor.style.transform = `translate(${cursorX - 20}px, ${cursorY - 20}px)`;
      cursorDot.style.transform = `translate(${dotX - 3}px, ${dotY - 3}px)`;

      requestAnimationFrame(animateCursor);
    };

    animateCursor();

    document.body.addEventListener('mouseenter', (e) => {
      const t = e.target.closest('a, button, .product-card, .category-banner, [data-cursor-hover]');
      if (t) {
        cursor.style.width = '60px';
        cursor.style.height = '60px';
        cursor.style.borderColor = 'rgba(212, 175, 55, 0.6)';
        cursor.style.background = 'rgba(212, 175, 55, 0.05)';
        if (t.matches('a, button')) {
          cursor.style.mixBlendMode = 'normal';
          cursor.style.background = 'rgba(220, 20, 60, 0.08)';
        }
      }
    }, true);

    document.body.addEventListener('mouseleave', (e) => {
      const t = e.target.closest('a, button, .product-card, .category-banner, [data-cursor-hover]');
      if (t) {
        cursor.style.width = '40px';
        cursor.style.height = '40px';
        cursor.style.borderColor = 'rgba(220, 20, 60, 0.5)';
        cursor.style.background = 'transparent';
        cursor.style.mixBlendMode = 'difference';
      }
    }, true);
  },

  /* ========================================================================
     textSplit — Split text for per-character animation
     ======================================================================== */
  textSplit(element, options = {}) {
    if (!element || typeof SplitType === 'undefined') return null;

    const split = new SplitType(element, {
      types: options.types || 'chars, words',
      tagName: options.tagName || 'span',
    });

    if (split.chars) {
      gsap.from(split.chars, {
        scrollTrigger: {
          trigger: element,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 20,
        opacity: 0,
        duration: 0.5,
        stagger: 0.02,
        ease: 'power3.out',
      });
    }

    return split;
  },

  /* ========================================================================
     marquee — Infinite scroll marquee via GSAP
     ======================================================================== */
  marquee() {
    const marquees = document.querySelectorAll('.marquee-track, .marquee-content');

    marquees.forEach((track) => {
      const items = Array.from(track.children);
      if (items.length === 0) return;

      const totalWidth = Array.from(items).reduce((acc, item) => {
        return acc + item.offsetWidth + parseInt(getComputedStyle(track).gap || 0);
      }, 0);

      gsap.set(track, { width: totalWidth });

      gsap.to(track, {
        x: -totalWidth / 2,
        duration: parseFloat(track.dataset.speed) || 30,
        ease: 'none',
        repeat: -1,
        modifiers: {
          x: gsap.utils.unitize((x) => parseFloat(x) % (totalWidth / 2)),
        },
      });
    });
  },

  /* ========================================================================
     pageTransition — Page enter/exit animations
     ======================================================================== */
  pageTransition() {
    const transition = document.querySelector('.page-transition');
    if (transition) {
      gsap.from(transition, {
        y: 20,
        opacity: 0,
        duration: 0.5,
        ease: 'power3.out',
        delay: 0.1,
      });
    } else {
      gsap.from(document.body, { opacity: 0, duration: 0.4, ease: 'power2.out' });
    }

    document.querySelectorAll('a[href]').forEach((link) => {
      const href = link.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('javascript:') || link.target === '_blank') return;
      if (href === window.location.pathname) return;

      link.addEventListener('click', (e) => {
        e.preventDefault();

        var anim = gsap.to(document.body, {
          opacity: 0,
          duration: 0.2,
          ease: 'power2.in',
          onComplete: () => {
            window.location.href = href;
          },
        });

        setTimeout(function() {
          if (document.body.style.opacity === '0') {
            window.location.href = href;
          }
        }, 500);
      });
    });
  },

  /* ========================================================================
     preload — Preload critical above-the-fold assets
     ======================================================================== */
  preload() {
    const preloadImages = document.querySelectorAll('img[data-preload]');
    preloadImages.forEach((img) => {
      const src = img.dataset.preload || img.src;
      if (src) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
      }
    });

    const heroImage = document.querySelector('.hero-section-bg img');
    if (heroImage) {
      heroImage.loading = 'eager';
      heroImage.fetchPriority = 'high';
    }
  },

  /* ========================================================================
     initLoadingAnimation — Cinematic intro overlay with logo animation
     ======================================================================== */
  initLoadingAnimation() {
    const overlay = document.createElement('div');
    overlay.id = 'bng-loading-overlay';
    overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 10000;
      background: #0a0a0a; display: flex; flex-direction: column;
      align-items: center; justify-content: center; gap: 16px;
    `;

    const logo = document.createElement('div');
    logo.textContent = 'বাঙালিরহাট';
    logo.style.cssText = `
      font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 700;
      color: #dc143c; letter-spacing: 2px; opacity: 0;
      transform: scale(0.8); filter: blur(10px);
    `;

    const tagline = document.createElement('div');
    tagline.textContent = 'Authentic Bangladeshi Craft';
    tagline.style.cssText = `
      font-size: 0.95rem; color: rgba(255,255,255,0.6);
      letter-spacing: 4px; text-transform: uppercase; opacity: 0;
    `;

    overlay.appendChild(logo);
    overlay.appendChild(tagline);
    document.body.appendChild(overlay);

    const tl = gsap.timeline({
      onComplete: () => overlay.remove(),
    });

    tl.to(logo, {
      opacity: 1, scale: 1, filter: 'blur(0px)',
      duration: 0.8, ease: 'power3.out',
    })
    .to(tagline, {
      opacity: 1, duration: 0.5, ease: 'power2.out',
    }, '-=0.2')
    .to(overlay, {
      yPercent: -100, duration: 0.8, ease: 'power3.inOut',
      delay: 0.3,
    });
  },

  /* ========================================================================
     initSmoothScroll — Lenis smooth scroll initialization
     ======================================================================== */
  initSmoothScroll() {
    if (typeof Lenis === 'undefined') return null;

    if (this.lenis) return this.lenis;

    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });

    this.lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    return this.lenis;
  },

  /* ========================================================================
     initProductRotation — Drag-to-rotate product images
     ======================================================================== */
  initProductRotation(container) {
    if (!container) return;

    const imagesAttr = container.dataset.rotationImages;
    if (!imagesAttr) return;

    let images;
    try {
      images = JSON.parse(imagesAttr);
    } catch (e) {
      return;
    }
    if (!images || images.length === 0) return;

    const img = container.querySelector('img') || document.createElement('img');
    if (!container.contains(img)) container.appendChild(img);
    img.src = images[0];
    img.style.cssText = 'width:100%;height:100%;object-fit:contain;user-select:none;pointer-events:none;';

    let currentIndex = 0;
    let isDragging = false;
    let startX = 0;
    let accumulatedDelta = 0;
    const threshold = 40;

    const setImage = (idx) => {
      currentIndex = ((idx % images.length) + images.length) % images.length;
      img.src = images[currentIndex];
    };

    const onPointerDown = (e) => {
      isDragging = true;
      startX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      accumulatedDelta = 0;
      container.style.cursor = 'grabbing';
    };

    const onPointerMove = (e) => {
      if (!isDragging) return;
      const clientX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      const delta = clientX - startX;
      accumulatedDelta += delta;
      startX = clientX;

      if (Math.abs(accumulatedDelta) >= threshold) {
        const steps = Math.trunc(accumulatedDelta / threshold);
        setImage(currentIndex + steps);
        accumulatedDelta -= steps * threshold;
      }
    };

    const onPointerUp = () => {
      isDragging = false;
      container.style.cursor = 'grab';
    };

    container.style.cursor = 'grab';
    container.addEventListener('mousedown', onPointerDown);
    container.addEventListener('mousemove', onPointerMove);
    container.addEventListener('mouseup', onPointerUp);
    container.addEventListener('mouseleave', onPointerUp);
    container.addEventListener('touchstart', onPointerDown, { passive: true });
    container.addEventListener('touchmove', onPointerMove, { passive: true });
    container.addEventListener('touchend', onPointerUp);
  },

  /* ========================================================================
     animateCounter — Animate a number from 0 to target
     ======================================================================== */
  animateCounter(element, target, duration = 2) {
    if (!element) return;

    const suffix = element.dataset.suffix || '';
    const obj = { val: 0 };

    gsap.to(obj, {
      val: target,
      duration: duration,
      ease: 'power2.out',
      onUpdate() {
        element.textContent = Math.round(obj.val).toLocaleString() + suffix;
      },
    });
  },

  /* ========================================================================
     initStaggerReveal — Scroll-triggered staggered reveals
     ======================================================================== */
  initStaggerReveal() {
    const elements = document.querySelectorAll('[data-reveal]');

    elements.forEach((el) => {
      const direction = el.dataset.reveal || 'up';
      let fromVars = { opacity: 0, duration: 0.8, ease: 'power3.out' };

      switch (direction) {
        case 'left':
          fromVars.x = -60;
          break;
        case 'right':
          fromVars.x = 60;
          break;
        case 'scale':
          fromVars.scale = 0.85;
          break;
        case 'up':
        default:
          fromVars.y = 50;
          break;
      }

      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 88%',
          once: true,
        },
        ...fromVars,
      });
    });
  },

  /* ========================================================================
     initParallaxLayers — Data-attribute driven parallax
     ======================================================================== */
  initParallaxLayers() {
    gsap.utils.toArray('[data-parallax]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallax) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });

    gsap.utils.toArray('[data-parallax-y]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallaxY) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });
  },

  /* ========================================================================
     initMagneticEffect — Cursor-following magnetic pull on elements
     ======================================================================== */
  initMagneticEffect() {
    const elements = document.querySelectorAll('[data-magnetic]');

    elements.forEach((el) => {
      const strength = parseFloat(el.dataset.magnetic) || 0.3;

      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        gsap.to(el, {
          x: x * strength,
          y: y * strength,
          duration: 0.3,
          ease: 'power2.out',
        });
      });

      el.addEventListener('mouseleave', () => {
        gsap.to(el, {
          x: 0,
          y: 0,
          duration: 0.6,
          ease: 'elastic.out(1, 0.3)',
        });
      });
    });
  },

  /* ========================================================================
     initTextReveal — Per-character staggered text animation on scroll
     ======================================================================== */
  initTextReveal() {
    const elements = document.querySelectorAll('[data-text-reveal]');

    elements.forEach((el) => {
      if (typeof SplitType !== 'undefined') {
        const split = new SplitType(el, { types: 'chars', tagName: 'span' });
        if (split.chars) {
          gsap.from(split.chars, {
            scrollTrigger: {
              trigger: el,
              start: 'top 85%',
              once: true,
            },
            opacity: 0,
            y: 20,
            duration: 0.4,
            stagger: 0.025,
            ease: 'power3.out',
          });
        }
      } else {
        const text = el.textContent;
        el.textContent = '';
        const chars = text.split('');
        chars.forEach((char) => {
          const span = document.createElement('span');
          span.textContent = char === ' ' ? '\u00A0' : char;
          span.style.display = 'inline-block';
          el.appendChild(span);
        });

        gsap.from(el.children, {
          scrollTrigger: {
            trigger: el,
            start: 'top 85%',
            once: true,
          },
          opacity: 0,
          y: 20,
          duration: 0.4,
          stagger: 0.025,
          ease: 'power3.out',
        });
      }
    });
  },

  /* ========================================================================
     refresh — Recalculate ScrollTrigger positions (after DOM changes)
     ======================================================================== */
  refresh() {
    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.refresh();
    }
  },

  /* ========================================================================
     destroy — Clean up all animations
     ======================================================================== */
  destroy() {
    if (this.lenis) {
      this.lenis.destroy();
      this.lenis = null;
    }

    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    }

    const cursor = document.querySelector('.custom-cursor');
    const dot = document.querySelector('.custom-cursor-dot');
    if (cursor) cursor.remove();
    if (dot) dot.remove();

    this.isInitialized = false;
  },
};

/* ==========================================================================
   Bootstrap on DOM ready
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  BAnimation.init();

  if (typeof BAnimation.pageTransition === 'function') {
    BAnimation.pageTransition();
  }
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((reg) => {
        console.log('[SW] Registered:', reg.scope);

        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing;
          if (!newWorker) return;

          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'activated' && navigator.serviceWorker.controller) {
              if (typeof Toast !== 'undefined') {
                Toast.info('New version available! Refresh to update.');
              }
            }
          });
        });
      })
      .catch((err) => {
        console.warn('[SW] Registration failed:', err);
      });

    navigator.serviceWorker.addEventListener('message', (event) => {
      if (event.data?.type === 'CACHE_UPDATED') {
        console.log('[SW] Cache updated to version:', event.data.version);
      }
      if (event.data?.type === 'GET_TOKEN') {
        const token = localStorage.getItem('br_token') || '';
        event.ports[0].postMessage(token);
      }
      if (event.data?.type === 'SYNC_COMPLETE') {
        console.log('[SW] Sync complete for:', event.data.resource);
        if (typeof Toast !== 'undefined') {
          Toast.success(`${event.data.resource} synced successfully`);
        }
      }
    });
  });
}

/**
 * Bangalirhaat Analytics & Tracking Integration
 * GA4, Facebook Pixel, Hotjar, and custom event tracking
 */
const BAnalytics = {
  config: {
    ga4Id: null,
    fbPixelId: null,
    hotjarId: null,
    enabled: true,
  },

  _initialized: false,

  _resolveCategory(cat) {
    if (!cat) return '';
    if (typeof cat === 'string') return cat;
    return cat.name || cat.title || String(cat);
  },

  init() {
    if (this._initialized) return;
    this._initialized = true;
    this.loadConfig().then(() => {
      if (!this.config.enabled) return;
      this.initGA4();
      this.initFacebookPixel();
      this.initHotjar();
      this.trackPageView();
      this.trackScrollDepth();
      this.trackTimeOnPage();
      this.trackOutboundLinks();
      this.trackErrors();
    });
  },

  // ── GA4 ──────────────────────────────────────────────────────────────────
  initGA4() {
    if (!this.config.ga4Id) return;

    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${this.config.ga4Id}`;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', this.config.ga4Id, {
      send_page_view: false,
    });
  },

  // ── Facebook Pixel ───────────────────────────────────────────────────────
  initFacebookPixel() {
    if (!this.config.fbPixelId) return;

    window.fbq = window.fbq || function () {
      (window.fbq.q = window.fbq.q || []).push(arguments);
    };
    window._fbq = window.fbq;

    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://connect.facebook.net/en_US/fbevents.js';
    document.head.appendChild(script);

    window.fbq('init', this.config.fbPixelId);
    window.fbq('track', 'PageView');
  },

  // ── Hotjar ───────────────────────────────────────────────────────────────
  initHotjar() {
    if (!this.config.hotjarId) return;

    (function (h, o, t, j, a, r) {
      h.hj = h.hj || function () { (h.hj.q = h.hj.q || []).push(arguments); };
      h._hjSettings = { hjid: t, hjsv: j };
      a = o.createElement('head');
      r = o.getElementsByTagName('head')[0];
      a.async = 1;
      a.src = 'https://static.hotjar.com/c/hotjar-' + t + '.js?sv=' + j;
      r.appendChild(a);
    })(window, document, this.config.hotjarId, '0');
  },

  // ── E-commerce Tracking ──────────────────────────────────────────────────
  trackProductView(product) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      item_brand: product.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(product.category),
      item_variant: product.variant || '',
      currency: 'BDT',
    };

    this._ga4Event('view_item', { items: [item] });
    this._fbEvent('ViewContent', {
      content_ids: [product.id || product._id],
      content_name: product.name,
      content_type: 'product',
      value: product.price || 0,
      currency: 'BDT',
    });
  },

  trackAddToCart(product, quantity = 1) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      quantity,
      item_brand: product.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(product.category),
      currency: 'BDT',
    };

    this._ga4Event('add_to_cart', {
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      items: [item],
    });
    this._fbEvent('AddToCart', {
      content_ids: [product.id || product._id],
      content_name: product.name,
      content_type: 'product',
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      quantity,
    });
  },

  trackRemoveFromCart(product, quantity = 1) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      quantity,
      currency: 'BDT',
    };

    this._ga4Event('remove_from_cart', {
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      items: [item],
    });
  },

  trackPurchase(order) {
    if (!order) return;

    const items = (order.items || []).map((item) => ({
      item_id: item.productId || item.id || '',
      item_name: item.name || '',
      price: item.price || 0,
      quantity: item.quantity || 1,
      item_brand: item.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(item.category),
      currency: 'BDT',
    }));

    this._ga4Event('purchase', {
      transaction_id: order.id || order._id || order.orderId || '',
      value: order.total || order.totalAmount || 0,
      tax: order.tax || 0,
      shipping: order.shipping || 0,
      currency: 'BDT',
      items,
    });
    this._fbEvent('Purchase', {
      content_ids: items.map((i) => i.item_id),
      content_type: 'product',
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      num_items: items.length,
    });
  },

  trackSearch(query) {
    if (!query) return;

    this._ga4Event('search', {
      search_term: query,
    });
  },

  trackCategoryView(category, items = []) {
    if (!category) return;
    var catName = this._resolveCategory(category);

    const listItems = items.map((item) => ({
      item_id: item.id || item._id || '',
      item_name: item.name || '',
      price: item.price || 0,
      item_brand: item.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(item.category || catName),
      currency: 'BDT',
    }));

    this._ga4Event('view_item_list', {
      item_list_id: catName,
      item_list_name: catName,
      items: listItems,
    });
  },

  trackBeginCheckout(order) {
    if (!order) return;

    const items = (order.items || []).map((item) => ({
      item_id: item.productId || item.id || '',
      item_name: item.name || '',
      price: item.price || 0,
      quantity: item.quantity || 1,
      currency: 'BDT',
    }));

    this._ga4Event('begin_checkout', {
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      items,
    });
    this._fbEvent('InitiateCheckout', {
      content_ids: items.map(i => i.item_id),
      content_type: 'product',
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      num_items: items.length,
    });
  },

  trackAddPaymentInfo(order) {
    if (!order) return;
    this._ga4Event('add_payment_info', { currency: 'BDT', value: order.total || 0 });
    this._fbEvent('AddPaymentInfo', { currency: 'BDT', value: order.total || 0 });
  },

  // ── Engagement Tracking ──────────────────────────────────────────────────
  trackScrollDepth() {
    const depths = { 25: false, 50: false, 75: false, 100: false };
    const maxDepth = { value: 0 };

    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight <= 0) return;

      const percent = Math.round((scrollTop / docHeight) * 100);
      if (percent > maxDepth.value) maxDepth.value = percent;

      Object.keys(depths).forEach((depth) => {
        if (!depths[depth] && percent >= Number(depth)) {
          depths[depth] = true;
          this._ga4Event('scroll', {
            percent_scrolled: Number(depth),
            page_location: window.location.href,
          });
        }
      });
    }, { passive: true });

    window.addEventListener('beforeunload', () => {
      if (maxDepth.value > 0) {
        this._ga4Event('user_engagement', {
          engagement_time_msec: this._getEngagementTime(),
          max_scroll_percent: maxDepth.value,
        });
      }
    });
  },

  trackTimeOnPage() {
    const startTime = Date.now();

    window.addEventListener('beforeunload', () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      if (timeSpent > 5) {
        this._ga4Event('session_duration', {
          engagement_time_msec: timeSpent * 1000,
          page_location: window.location.href,
        });
      }
    });
  },

  trackClick(element, category, label) {
    if (!element || !category) return;

    this._ga4Event('select_content', {
      content_type: category,
      content_id: label || '',
    });
    this._trackGenericEvent('click', { category, label });
  },

  trackOutboundLinks() {
    document.addEventListener('click', (e) => {
      const link = e.target.closest('a[href]');
      if (!link) return;

      const href = link.href;
      if (href && href.startsWith('http') && !href.includes(window.location.hostname)) {
        this._ga4Event('click', {
          link_url: href,
          link_text: link.textContent?.trim().substring(0, 100),
        });
      }
    });
  },

  trackErrors() {
    window.addEventListener('error', (e) => {
      this._ga4Event('exception', {
        description: e.message || 'Unknown error',
        fatal: false,
      });
    });
  },

  // ── Conversion Tracking ──────────────────────────────────────────────────
  trackConversion(conversionType, value) {
    this._ga4Event('generate_lead', {
      value: value || 0,
      currency: 'BDT',
      conversion_type: conversionType,
    });
  },

  trackSignUp(method) {
    this._ga4Event('sign_up', { method: method || 'email' });
    this._fbEvent('CompleteRegistration', { method: method || 'email' });
  },

  trackLogin(method) {
    this._ga4Event('login', { method: method || 'email' });
  },

  trackWishlist(product) {
    if (!product) return;
    this._ga4Event('add_to_wishlist', {
      value: product.price || 0,
      currency: 'BDT',
      items: [{
        item_id: product.id || product._id || '',
        item_name: product.name || '',
        price: product.price || 0,
        currency: 'BDT',
      }],
    });
  },

  // ── Custom Events ────────────────────────────────────────────────────────
  trackEvent(eventName, params = {}) {
    this._ga4Event(eventName, params);
  },

  trackFBEvent(eventName, params = {}) {
    this._fbEvent(eventName, params);
  },

  // ── User Properties ──────────────────────────────────────────────────────
  setUserProperties(user) {
    if (!user || !window.gtag) return;

    const props = {};
    if (user.id) props.user_id = user.id;
    if (user.email) props.user_email = user.email;
    if (user.name) props.user_name = user.name;
    if (user.phone) props.phone = user.phone;
    if (user.city) props.city = user.city;

    window.gtag('set', 'user_properties', props);

    if (window.fbq) {
      window.fbq('trackCustom', 'SetUserProperties', {
        user_id: user.id,
        city: user.city,
      });
    }
  },

  clearUserProperties() {
    if (window.gtag) {
      window.gtag('set', 'user_properties', {
        user_id: null,
        user_email: null,
        user_name: null,
      });
    }
  },

  // ── Config ───────────────────────────────────────────────────────────────
  async loadConfig() {
    try {
      const res = await fetch('/api/settings/analytics');
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          this.config.ga4Id = json.data.ga4Id || json.data.ga4_id || null;
          this.config.fbPixelId = json.data.fbPixelId || json.data.fb_pixel_id || null;
          this.config.hotjarId = json.data.hotjarId || json.data.hotjar_id || null;
        }
      }
    } catch { /* settings API unavailable */ }
  },

  setConfig(key, value) {
    if (key in this.config) {
      this.config[key] = value;
    }
  },

  // ── Internal Helpers ─────────────────────────────────────────────────────
  _ga4Event(eventName, params = {}) {
    if (!window.gtag || !this.config.ga4Id) return;
    window.gtag('event', eventName, params);
  },

  _fbEvent(eventName, params = {}) {
    if (!window.fbq || !this.config.fbPixelId) return;
    window.fbq('track', eventName, params);
  },

  _trackGenericEvent(eventName, params = {}) {
    this._ga4Event(eventName, params);
  },

  _getEngagementTime() {
    return String(Math.round(performance.now()));
  },
};

// Auto-initialize on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => BAnalytics.init());
} else {
  BAnalytics.init();
}

window.BAnalytics = BAnalytics;

