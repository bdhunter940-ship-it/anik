/* ==========================================================================
   Bangalirhaat — GSAP Animation Controller
   Full animation system: ScrollTrigger, Lenis smooth scroll, hero entrance,
   parallax, magnetic buttons, custom cursor, text splitting, marquee, counters.
   ========================================================================== */

const BAnimation = {
  lenis: null,
  isInitialized: false,

  /* ========================================================================
     init — Bootstrap all animation systems
     ======================================================================== */
  init() {
    if (this.isInitialized) return;
    if (typeof gsap === 'undefined') {
      console.warn('[BAnimation] GSAP not loaded');
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    this.initLoadingAnimation();
    this.smoothScroll();
    this.initSmoothScroll();
    this.hero();
    this.scrollReveal();
    this.initStaggerReveal();
    this.parallax();
    this.initParallaxLayers();
    this.productCards();
    this.navbar();
    this.counterUp();
    this.magneticButton();
    this.initMagneticEffect();
    this.cursor();
    this.marquee();
    this.preload();
    this.initTextReveal();

    this.isInitialized = true;
  },

  /* ========================================================================
     smoothScroll — Lenis smooth scroll initialization
     ======================================================================== */
  smoothScroll() {
    if (typeof Lenis === 'undefined') return;

    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    this.lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const scrollAmount = e.key === 'ArrowDown' ? 300 : -300;
        this.lenis.scrollBy(scrollAmount);
      }
    });
  },

  /* ========================================================================
     hero — Hero section entrance animation
     ======================================================================== */
  hero() {
    const heroSection = document.querySelector('.hero-section');
    if (!heroSection) return;

    const tl = gsap.timeline({ delay: 0.3 });

    const tagline = heroSection.querySelector('.hero-section-content span:first-child, .hero-section-content .section-badge, [data-animate]:first-child');
    const title = heroSection.querySelector('.hero-3d-title, h1, .hero-title');
    const subtitle = heroSection.querySelector('.hero-subtitle, .hero-section-content p');
    const actions = heroSection.querySelector('.hero-actions, .hero-section-content .btn');
    const stats = heroSection.querySelector('.hero-stats');
    const floating = heroSection.querySelectorAll('.hero-floating');

    if (tagline) {
      tl.from(tagline, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      });
    }

    if (title) {
      const chars = title.querySelectorAll('.gradient-text, span');
      if (chars.length > 0) {
        tl.from(title, { y: 40, opacity: 0, duration: 0.01 }, '-=0.3');
        tl.from(chars, {
          y: 30,
          opacity: 0,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power3.out',
        }, '-=0.3');
      } else {
        tl.from(title, {
          y: 50,
          opacity: 0,
          duration: 0.8,
          ease: 'power3.out',
        }, '-=0.3');
      }
    }

    if (subtitle) {
      tl.from(subtitle, {
        y: 30,
        opacity: 0,
        duration: 0.7,
        ease: 'power3.out',
      }, '-=0.4');
    }

    if (actions) {
      tl.from(actions, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      }, '-=0.3');
    }

    if (stats) {
      tl.from(stats, {
        y: 20,
        opacity: 0,
        duration: 0.6,
        ease: 'power3.out',
      }, '-=0.2');
    }

    if (floating.length > 0) {
      tl.from(floating, {
        scale: 0,
        opacity: 0,
        duration: 0.5,
        stagger: 0.15,
        ease: 'back.out(1.7)',
      }, '-=0.4');
    }

    floating.forEach((el) => {
      gsap.to(el, {
        y: -12,
        duration: 2 + Math.random() * 2,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: Math.random() * 2,
      });
    });
  },

  /* ========================================================================
     scrollReveal — All .reveal elements animate on scroll
     ======================================================================== */
  scrollReveal() {
    const revealElements = document.querySelectorAll(
      '.reveal, .reveal-up, .reveal-down, .reveal-left, .reveal-right, .reveal-scale, .reveal-fade, .stagger-children, .rotate-in, .rotate-out, .slide-in-left, .slide-in-right, .slide-in-up, .slide-in-down, .scale-in, .scale-out, .blur-in, .blur-out'
    );

    revealElements.forEach((el) => {
      const delay = parseFloat(el.dataset.delay) || 0;
      const duration = parseFloat(el.dataset.duration) || 0.8;

      ScrollTrigger.create({
        trigger: el,
        start: 'top 88%',
        once: true,
        onEnter: () => {
          gsap.to(el, {
            delay: delay,
            duration: duration,
            onStart: () => el.classList.add('revealed'),
          });
        },
      });
    });

    gsap.utils.toArray('.section-header').forEach((el) => {
      const children = el.children;
      if (!children || children.length === 0) return;

      gsap.from(Array.from(children), {
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.category-banner, .category-grid > *').forEach((el, i) => {
      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 88%',
          toggleActions: 'play none none none',
        },
        y: 40,
        opacity: 0,
        duration: 0.5,
        delay: i * 0.06,
        ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.review-card, .newsletter-card, .video-banner').forEach((el) => {
      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 30,
        opacity: 0,
        duration: 0.7,
        ease: 'power3.out',
      });
    });
  },

  /* ========================================================================
     parallax — Parallax layers on scroll
     ======================================================================== */
  parallax() {
    gsap.utils.toArray('.parallax-layer').forEach((layer) => {
      const speed = parseFloat(layer.dataset.speed) || 0.3;
      const direction = layer.dataset.direction || 'y';

      const prop = { y: 0, x: 0 };

      gsap.to(prop, {
        y: direction === 'y' ? speed * -150 : 0,
        x: direction === 'x' ? speed * -100 : 0,
        ease: 'none',
        scrollTrigger: {
          trigger: layer.parentElement,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
        },
      });

      gsap.to(layer, {
        y: () => prop.y,
        x: () => prop.x,
        ease: 'none',
        scrollTrigger: {
          trigger: layer.parentElement,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1.5,
        },
      });
    });

    const heroBg = document.querySelector('.hero-section-bg');
    if (heroBg) {
      gsap.to(heroBg, {
        y: 200,
        ease: 'none',
        scrollTrigger: {
          trigger: '.hero-section',
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      });
    }

    gsap.utils.toArray('[data-parallax]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallax) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });
  },

  /* ========================================================================
     productCards — Staggered card entrance on scroll
     ======================================================================== */
  productCards() {
    const grids = gsap.utils.toArray('.product-grid');
    grids.forEach((grid) => {
      const cards = grid.children;
      if (!cards || cards.length === 0) return;

      gsap.from(Array.from(cards), {
        scrollTrigger: {
          trigger: grid,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 50,
        opacity: 0,
        duration: 0.5,
        stagger: {
          each: 0.08,
          from: 'start',
        },
        ease: 'power3.out',
      });
    });

    const swiperWrappers = gsap.utils.toArray('.swiper-wrapper');
    swiperWrappers.forEach((wrapper) => {
      const slides = wrapper.children;
      if (!slides || slides.length === 0) return;

      gsap.from(Array.from(slides), {
        scrollTrigger: {
          trigger: wrapper,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        x: 60,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        ease: 'power3.out',
      });
    });
  },

  /* ========================================================================
     navbar — Scroll-based navbar style change
     ======================================================================== */
  navbar() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;

    ScrollTrigger.create({
      start: 'top -80',
      end: 99999,
      toggleClass: { className: 'navbar-scrolled', targets: navbar },
    });

    const brandText = navbar.querySelector('.navbar-brand-text');
    if (brandText) {
      ScrollTrigger.create({
        start: 'top -120',
        end: 99999,
        onEnter: () => {
          gsap.to(brandText, { opacity: 1, duration: 0.3 });
        },
        onLeaveBack: () => {
          gsap.to(brandText, { opacity: 1, duration: 0.3 });
        },
      });
    }
  },

  /* ========================================================================
     counterUp — Animated number counters
     ======================================================================== */
  counterUp() {
    const counters = document.querySelectorAll('[data-counter]');

    counters.forEach((el) => {
      const target = parseInt(el.dataset.counter, 10);
      if (isNaN(target)) return;

      const formatNumber = (num) => {
        if (num >= 10000) {
          return (num / 1000).toFixed(num >= 100000 ? 0 : 1) + 'K+';
        }
        if (num >= 1000) {
          return (num / 1000).toFixed(1) + 'K+';
        }
        return num + '+';
      };

      const obj = { val: 0 };

      ScrollTrigger.create({
        trigger: el,
        start: 'top 90%',
        once: true,
        onEnter: () => {
          gsap.to(obj, {
            val: target,
            duration: 2,
            delay: 0.3,
            ease: 'power2.out',
            onUpdate() {
              el.textContent = formatNumber(Math.round(obj.val));
            },
          });
        },
      });
    });
  },

  /* ========================================================================
     magneticButton — Magnetic hover effect on buttons
     ======================================================================== */
  magneticButton() {
    const buttons = document.querySelectorAll('.magnetic-btn, .btn-primary, .btn-pill');

    buttons.forEach((btn) => {
      const strength = parseFloat(btn.dataset.magneticStrength) || 0.3;

      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        gsap.to(btn, {
          x: x * strength,
          y: y * strength,
          duration: 0.3,
          ease: 'power2.out',
        });
      });

      btn.addEventListener('mouseleave', () => {
        gsap.to(btn, {
          x: 0,
          y: 0,
          duration: 0.5,
          ease: 'elastic.out(1, 0.3)',
        });
      });
    });
  },

  /* ========================================================================
     cursor — Custom cursor follower
     ======================================================================== */
  cursor() {
    if (window.matchMedia('(pointer: coarse)').matches) return;

    let cursor = document.querySelector('.custom-cursor');
    let cursorDot = document.querySelector('.custom-cursor-dot');

    if (!cursor) {
      cursor = document.createElement('div');
      cursor.className = 'custom-cursor';
      document.body.appendChild(cursor);
    }

    if (!cursorDot) {
      cursorDot = document.createElement('div');
      cursorDot.className = 'custom-cursor-dot';
      document.body.appendChild(cursorDot);
    }

    Object.assign(cursor.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '40px',
      height: '40px',
      borderRadius: '50%',
      border: '1.5px solid rgba(220, 20, 60, 0.5)',
      pointerEvents: 'none',
      zIndex: '9999',
      transition: 'width 0.3s, height 0.3s, border-color 0.3s, background 0.3s',
      transform: 'translate(-50%, -50%)',
      willChange: 'transform',
      mixBlendMode: 'difference',
    });

    Object.assign(cursorDot.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: '#dc143c',
      pointerEvents: 'none',
      zIndex: '9999',
      transform: 'translate(-50%, -50%)',
      willChange: 'transform',
    });

    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;
    let dotX = 0;
    let dotY = 0;

    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });

    const animateCursor = () => {
      cursorX += (mouseX - cursorX) * 0.12;
      cursorY += (mouseY - cursorY) * 0.12;
      dotX += (mouseX - dotX) * 0.25;
      dotY += (mouseY - dotY) * 0.25;

      cursor.style.transform = `translate(${cursorX - 20}px, ${cursorY - 20}px)`;
      cursorDot.style.transform = `translate(${dotX - 3}px, ${dotY - 3}px)`;

      requestAnimationFrame(animateCursor);
    };

    animateCursor();

    document.body.addEventListener('mouseenter', (e) => {
      const t = e.target.closest('a, button, .product-card, .category-banner, [data-cursor-hover]');
      if (t) {
        cursor.style.width = '60px';
        cursor.style.height = '60px';
        cursor.style.borderColor = 'rgba(212, 175, 55, 0.6)';
        cursor.style.background = 'rgba(212, 175, 55, 0.05)';
        if (t.matches('a, button')) {
          cursor.style.mixBlendMode = 'normal';
          cursor.style.background = 'rgba(220, 20, 60, 0.08)';
        }
      }
    }, true);

    document.body.addEventListener('mouseleave', (e) => {
      const t = e.target.closest('a, button, .product-card, .category-banner, [data-cursor-hover]');
      if (t) {
        cursor.style.width = '40px';
        cursor.style.height = '40px';
        cursor.style.borderColor = 'rgba(220, 20, 60, 0.5)';
        cursor.style.background = 'transparent';
        cursor.style.mixBlendMode = 'difference';
      }
    }, true);
  },

  /* ========================================================================
     textSplit — Split text for per-character animation
     ======================================================================== */
  textSplit(element, options = {}) {
    if (!element || typeof SplitType === 'undefined') return null;

    const split = new SplitType(element, {
      types: options.types || 'chars, words',
      tagName: options.tagName || 'span',
    });

    if (split.chars) {
      gsap.from(split.chars, {
        scrollTrigger: {
          trigger: element,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
        y: 20,
        opacity: 0,
        duration: 0.5,
        stagger: 0.02,
        ease: 'power3.out',
      });
    }

    return split;
  },

  /* ========================================================================
     marquee — Infinite scroll marquee via GSAP
     ======================================================================== */
  marquee() {
    const marquees = document.querySelectorAll('.marquee-track, .marquee-content');

    marquees.forEach((track) => {
      const items = Array.from(track.children);
      if (items.length === 0) return;

      const totalWidth = Array.from(items).reduce((acc, item) => {
        return acc + item.offsetWidth + parseInt(getComputedStyle(track).gap || 0);
      }, 0);

      gsap.set(track, { width: totalWidth });

      gsap.to(track, {
        x: -totalWidth / 2,
        duration: parseFloat(track.dataset.speed) || 30,
        ease: 'none',
        repeat: -1,
        modifiers: {
          x: gsap.utils.unitize((x) => parseFloat(x) % (totalWidth / 2)),
        },
      });
    });
  },

  /* ========================================================================
     pageTransition — Page enter/exit animations
     ======================================================================== */
  pageTransition() {
    const transition = document.querySelector('.page-transition');
    if (transition) {
      gsap.from(transition, {
        y: 20,
        opacity: 0,
        duration: 0.5,
        ease: 'power3.out',
        delay: 0.1,
      });
    } else {
      gsap.from(document.body, { opacity: 0, duration: 0.4, ease: 'power2.out' });
    }

    document.querySelectorAll('a[href]').forEach((link) => {
      const href = link.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('javascript:') || link.target === '_blank') return;
      if (href === window.location.pathname) return;

      link.addEventListener('click', (e) => {
        e.preventDefault();

        var anim = gsap.to(document.body, {
          opacity: 0,
          duration: 0.2,
          ease: 'power2.in',
          onComplete: () => {
            window.location.href = href;
          },
        });

        setTimeout(function() {
          if (document.body.style.opacity === '0') {
            window.location.href = href;
          }
        }, 500);
      });
    });
  },

  /* ========================================================================
     preload — Preload critical above-the-fold assets
     ======================================================================== */
  preload() {
    const preloadImages = document.querySelectorAll('img[data-preload]');
    preloadImages.forEach((img) => {
      const src = img.dataset.preload || img.src;
      if (src) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
      }
    });

    const heroImage = document.querySelector('.hero-section-bg img');
    if (heroImage) {
      heroImage.loading = 'eager';
      heroImage.fetchPriority = 'high';
    }
  },

  /* ========================================================================
     initLoadingAnimation — Cinematic intro overlay with logo animation
     ======================================================================== */
  initLoadingAnimation() {
    const overlay = document.createElement('div');
    overlay.id = 'bng-loading-overlay';
    overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 10000;
      background: #0a0a0a; display: flex; flex-direction: column;
      align-items: center; justify-content: center; gap: 16px;
    `;

    const logo = document.createElement('div');
    logo.textContent = 'বাঙালিরহাট';
    logo.style.cssText = `
      font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 700;
      color: #dc143c; letter-spacing: 2px; opacity: 0;
      transform: scale(0.8); filter: blur(10px);
    `;

    const tagline = document.createElement('div');
    tagline.textContent = 'Authentic Bangladeshi Craft';
    tagline.style.cssText = `
      font-size: 0.95rem; color: rgba(255,255,255,0.6);
      letter-spacing: 4px; text-transform: uppercase; opacity: 0;
    `;

    overlay.appendChild(logo);
    overlay.appendChild(tagline);
    document.body.appendChild(overlay);

    const tl = gsap.timeline({
      onComplete: () => overlay.remove(),
    });

    tl.to(logo, {
      opacity: 1, scale: 1, filter: 'blur(0px)',
      duration: 0.8, ease: 'power3.out',
    })
    .to(tagline, {
      opacity: 1, duration: 0.5, ease: 'power2.out',
    }, '-=0.2')
    .to(overlay, {
      yPercent: -100, duration: 0.8, ease: 'power3.inOut',
      delay: 0.3,
    });
  },

  /* ========================================================================
     initSmoothScroll — Lenis smooth scroll initialization
     ======================================================================== */
  initSmoothScroll() {
    if (typeof Lenis === 'undefined') return null;

    if (this.lenis) return this.lenis;

    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });

    this.lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    return this.lenis;
  },

  /* ========================================================================
     initProductRotation — Drag-to-rotate product images
     ======================================================================== */
  initProductRotation(container) {
    if (!container) return;

    const imagesAttr = container.dataset.rotationImages;
    if (!imagesAttr) return;

    let images;
    try {
      images = JSON.parse(imagesAttr);
    } catch (e) {
      return;
    }
    if (!images || images.length === 0) return;

    const img = container.querySelector('img') || document.createElement('img');
    if (!container.contains(img)) container.appendChild(img);
    img.src = images[0];
    img.style.cssText = 'width:100%;height:100%;object-fit:contain;user-select:none;pointer-events:none;';

    let currentIndex = 0;
    let isDragging = false;
    let startX = 0;
    let accumulatedDelta = 0;
    const threshold = 40;

    const setImage = (idx) => {
      currentIndex = ((idx % images.length) + images.length) % images.length;
      img.src = images[currentIndex];
    };

    const onPointerDown = (e) => {
      isDragging = true;
      startX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      accumulatedDelta = 0;
      container.style.cursor = 'grabbing';
    };

    const onPointerMove = (e) => {
      if (!isDragging) return;
      const clientX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
      const delta = clientX - startX;
      accumulatedDelta += delta;
      startX = clientX;

      if (Math.abs(accumulatedDelta) >= threshold) {
        const steps = Math.trunc(accumulatedDelta / threshold);
        setImage(currentIndex + steps);
        accumulatedDelta -= steps * threshold;
      }
    };

    const onPointerUp = () => {
      isDragging = false;
      container.style.cursor = 'grab';
    };

    container.style.cursor = 'grab';
    container.addEventListener('mousedown', onPointerDown);
    container.addEventListener('mousemove', onPointerMove);
    container.addEventListener('mouseup', onPointerUp);
    container.addEventListener('mouseleave', onPointerUp);
    container.addEventListener('touchstart', onPointerDown, { passive: true });
    container.addEventListener('touchmove', onPointerMove, { passive: true });
    container.addEventListener('touchend', onPointerUp);
  },

  /* ========================================================================
     animateCounter — Animate a number from 0 to target
     ======================================================================== */
  animateCounter(element, target, duration = 2) {
    if (!element) return;

    const suffix = element.dataset.suffix || '';
    const obj = { val: 0 };

    gsap.to(obj, {
      val: target,
      duration: duration,
      ease: 'power2.out',
      onUpdate() {
        element.textContent = Math.round(obj.val).toLocaleString() + suffix;
      },
    });
  },

  /* ========================================================================
     initStaggerReveal — Scroll-triggered staggered reveals
     ======================================================================== */
  initStaggerReveal() {
    const elements = document.querySelectorAll('[data-reveal]');

    elements.forEach((el) => {
      const direction = el.dataset.reveal || 'up';
      let fromVars = { opacity: 0, duration: 0.8, ease: 'power3.out' };

      switch (direction) {
        case 'left':
          fromVars.x = -60;
          break;
        case 'right':
          fromVars.x = 60;
          break;
        case 'scale':
          fromVars.scale = 0.85;
          break;
        case 'up':
        default:
          fromVars.y = 50;
          break;
      }

      gsap.from(el, {
        scrollTrigger: {
          trigger: el,
          start: 'top 88%',
          once: true,
        },
        ...fromVars,
      });
    });
  },

  /* ========================================================================
     initParallaxLayers — Data-attribute driven parallax
     ======================================================================== */
  initParallaxLayers() {
    gsap.utils.toArray('[data-parallax]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallax) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });

    gsap.utils.toArray('[data-parallax-y]').forEach((el) => {
      const amount = parseFloat(el.dataset.parallaxY) || 50;
      gsap.to(el, {
        y: -amount,
        ease: 'none',
        scrollTrigger: {
          trigger: el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });
    });
  },

  /* ========================================================================
     initMagneticEffect — Cursor-following magnetic pull on elements
     ======================================================================== */
  initMagneticEffect() {
    const elements = document.querySelectorAll('[data-magnetic]');

    elements.forEach((el) => {
      const strength = parseFloat(el.dataset.magnetic) || 0.3;

      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        gsap.to(el, {
          x: x * strength,
          y: y * strength,
          duration: 0.3,
          ease: 'power2.out',
        });
      });

      el.addEventListener('mouseleave', () => {
        gsap.to(el, {
          x: 0,
          y: 0,
          duration: 0.6,
          ease: 'elastic.out(1, 0.3)',
        });
      });
    });
  },

  /* ========================================================================
     initTextReveal — Per-character staggered text animation on scroll
     ======================================================================== */
  initTextReveal() {
    const elements = document.querySelectorAll('[data-text-reveal]');

    elements.forEach((el) => {
      if (typeof SplitType !== 'undefined') {
        const split = new SplitType(el, { types: 'chars', tagName: 'span' });
        if (split.chars) {
          gsap.from(split.chars, {
            scrollTrigger: {
              trigger: el,
              start: 'top 85%',
              once: true,
            },
            opacity: 0,
            y: 20,
            duration: 0.4,
            stagger: 0.025,
            ease: 'power3.out',
          });
        }
      } else {
        const text = el.textContent;
        el.textContent = '';
        const chars = text.split('');
        chars.forEach((char) => {
          const span = document.createElement('span');
          span.textContent = char === ' ' ? '\u00A0' : char;
          span.style.display = 'inline-block';
          el.appendChild(span);
        });

        gsap.from(el.children, {
          scrollTrigger: {
            trigger: el,
            start: 'top 85%',
            once: true,
          },
          opacity: 0,
          y: 20,
          duration: 0.4,
          stagger: 0.025,
          ease: 'power3.out',
        });
      }
    });
  },

  /* ========================================================================
     refresh — Recalculate ScrollTrigger positions (after DOM changes)
     ======================================================================== */
  refresh() {
    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.refresh();
    }
  },

  /* ========================================================================
     destroy — Clean up all animations
     ======================================================================== */
  destroy() {
    if (this.lenis) {
      this.lenis.destroy();
      this.lenis = null;
    }

    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    }

    const cursor = document.querySelector('.custom-cursor');
    const dot = document.querySelector('.custom-cursor-dot');
    if (cursor) cursor.remove();
    if (dot) dot.remove();

    this.isInitialized = false;
  },
};

/* ==========================================================================
   Bootstrap on DOM ready
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  BAnimation.init();

  if (typeof BAnimation.pageTransition === 'function') {
    BAnimation.pageTransition();
  }
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((reg) => {
        console.log('[SW] Registered:', reg.scope);

        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing;
          if (!newWorker) return;

          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'activated' && navigator.serviceWorker.controller) {
              if (typeof Toast !== 'undefined') {
                Toast.info('New version available! Refresh to update.');
              }
            }
          });
        });
      })
      .catch((err) => {
        console.warn('[SW] Registration failed:', err);
      });

    navigator.serviceWorker.addEventListener('message', (event) => {
      if (event.data?.type === 'CACHE_UPDATED') {
        console.log('[SW] Cache updated to version:', event.data.version);
      }
      if (event.data?.type === 'GET_TOKEN') {
        const token = localStorage.getItem('br_token') || '';
        event.ports[0].postMessage(token);
      }
      if (event.data?.type === 'SYNC_COMPLETE') {
        console.log('[SW] Sync complete for:', event.data.resource);
        if (typeof Toast !== 'undefined') {
          Toast.success(`${event.data.resource} synced successfully`);
        }
      }
    });
  });
}
