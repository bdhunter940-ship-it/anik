import crypto from 'crypto';
import { getDb } from '../database/db.js';

const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const TOTP_PERIOD = 30;
const TOTP_DIGITS = 6;
const TOTP_WINDOW = 1;
const SECRET_BYTES = 20;
const ISSUER = 'Bangalirhaat';

function toBase32(buffer) {
  let bits = '';
  for (const byte of buffer) {
    bits += byte.toString(2).padStart(8, '0');
  }
  let result = '';
  for (let i = 0; i < bits.length; i += 5) {
    const chunk = bits.slice(i, i + 5).padEnd(5, '0');
    result += BASE32_CHARS[parseInt(chunk, 2)];
  }
  return result;
}

function fromBase32(str) {
  const normalized = str.replace(/[= ]/g, '').toUpperCase();
  let bits = '';
  for (const char of normalized) {
    const val = BASE32_CHARS.indexOf(char);
    if (val === -1) throw new Error('Invalid base32 character');
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

function generateTOTP(secret, time) {
  const counter = Math.floor(time / TOTP_PERIOD);
  const counterBuffer = Buffer.alloc(8);
  counterBuffer.writeBigInt64BE(BigInt(counter));

  const hmac = crypto.createHmac('sha1', secret).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binary =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);

  const otp = binary % Math.pow(10, TOTP_DIGITS);
  return otp.toString().padStart(TOTP_DIGITS, '0');
}

function generateSecret() {
  return toBase32(crypto.randomBytes(SECRET_BYTES));
}

function generateQRCodeURI(secret, email) {
  const encodedIssuer = encodeURIComponent(ISSUER);
  const encodedEmail = encodeURIComponent(email);
  const encodedSecret = encodeURIComponent(secret);
  return `otpauth://totp/${encodedIssuer}:${encodedEmail}?secret=${encodedSecret}&issuer=${encodedIssuer}&algorithm=SHA1&digits=${TOTP_DIGITS}&period=${TOTP_PERIOD}`;
}

function verifyTOTP(secret, token) {
  const now = Date.now() / 1000;

  for (let i = -TOTP_WINDOW; i <= TOTP_WINDOW; i++) {
    const time = now + i * TOTP_PERIOD;
    const expected = generateTOTP(secret, time);
    if (crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expected))) {
      return true;
    }
  }

  return false;
}

class TwoFactorService {
  generateSecret() {
    return generateSecret();
  }

  generateQRCode(secret, email) {
    return generateQRCodeURI(secret, email);
  }

  generateTOTP(secret) {
    return generateTOTP(secret, Date.now() / 1000);
  }

  verifyTOTP(secret, token) {
    if (!token || token.length !== TOTP_DIGITS || !/^\d+$/.test(token)) {
      return false;
    }
    return verifyTOTP(secret, token);
  }

  async enable2FA(userId) {
    const db = getDb();
    const user = db.prepare('SELECT id, email, two_factor_enabled FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');
    if (user.two_factor_enabled) throw new Error('2FA is already enabled');

    const secret = generateSecret();
    const backupCodes = Array.from({ length: 8 }, () =>
      crypto.randomBytes(4).toString('hex').toUpperCase()
    );

    db.prepare(`
      UPDATE users SET two_factor_secret = ?, updated_at = datetime('now') WHERE id = ?
    `).run(secret, userId);

    db.prepare(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, new_value, ip_address, user_agent)
      VALUES (?, 'enable_2fa_initiated', 'users', ?, ?, NULL, NULL)
    `).run(userId, userId, JSON.stringify({ backup_codes_generated: true }));

    return {
      secret,
      qrCodeURI: generateQRCodeURI(secret, user.email),
      backupCodes,
    };
  }

  async verify2FA(userId, token) {
    const db = getDb();
    const user = db.prepare(
      'SELECT id, two_factor_enabled, two_factor_secret FROM users WHERE id = ?'
    ).get(userId);

    if (!user) throw new Error('User not found');
    if (user.two_factor_enabled) throw new Error('2FA is already enabled');
    if (!user.two_factor_secret) throw new Error('No pending 2FA setup');

    if (!verifyTOTP(user.two_factor_secret, token)) {
      throw new Error('Invalid 2FA token');
    }

    db.prepare(`
      UPDATE users SET two_factor_enabled = 1, updated_at = datetime('now') WHERE id = ?
    `).run(userId);

    db.prepare(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, new_value)
      VALUES (?, '2fa_enabled', 'users', ?, NULL)
    `).run(userId, userId);

    return true;
  }

  async disable2FA(userId, token) {
    const db = getDb();
    const user = db.prepare(
      'SELECT id, two_factor_enabled, two_factor_secret FROM users WHERE id = ?'
    ).get(userId);

    if (!user) throw new Error('User not found');
    if (!user.two_factor_enabled) throw new Error('2FA is not enabled');

    if (!verifyTOTP(user.two_factor_secret, token)) {
      throw new Error('Invalid 2FA token');
    }

    db.prepare(`
      UPDATE users SET two_factor_enabled = 0, two_factor_secret = NULL, updated_at = datetime('now')
      WHERE id = ?
    `).run(userId);

    db.prepare(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id)
      VALUES (?, '2fa_disabled', 'users', ?)
    `).run(userId, userId);

    return true;
  }

  async verifyLogin2FA(userId, token) {
    const db = getDb();
    const user = db.prepare(
      'SELECT id, two_factor_enabled, two_factor_secret FROM users WHERE id = ?'
    ).get(userId);

    if (!user) throw new Error('User not found');
    if (!user.two_factor_enabled) return true;
    if (!user.two_factor_secret) return true;

    return verifyTOTP(user.two_factor_secret, token);
  }
}

export default new TwoFactorService();
