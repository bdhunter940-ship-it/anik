# Hostinger Deployment Guide

## ⚠️ গুরুত্বপূর্ণ — আগে পড়ুন

**Hostinger Shared Hosting এ Node.js চলে না।** আপনার অ্যাপ Node.js/Express — তাই:

| Hostinger Plan | কাজ করবে? | দাম |
|----------------|-----------|-----|
| Shared (Single/Premium/Business) | ❌ PHP only | — |
| **VPS** (KVM 1) | ✅ Node.js | ~$5.99/মাস |
| **Cloud Hosting** | ✅ Node.js | ~$9.99/মাস |
| **Premium VPS** | ✅ | ~$8.99/মাস |

> Shared hosting কিনে থাকলে → **refund** নিয়ে **VPS** নিন, অথবা নিচের ফ্রি option ব্যবহার করুন।

---

## Option A: Hostinger VPS (Node.js সহ)

### Step 1 — VPS order করুন
- hPanel → VPS → KVM 1 ($5.99) → Ubuntu 22.04 → install

### Step 2 — SSH login
```bash
ssh root@YOUR_SERVER_IP
```

### Step 3 — Install Node.js + PM2
```bash
# Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs git

# PM2
npm install -g pm2

# Nginx (reverse proxy)
apt-get install -y nginx
```

### Step 4 — Upload code
```bash
# GitHub থেকে (recommended)
git clone https://github.com/YOUR_USER/bangalirhaat.git
cd bangalirhaat
npm install

# অথবা FTP/SCP দিয়ে upload
# (ZIP file extract করে /var/www/bangalirhaat এ)
```

### Step 5 — Environment setup
```bash
cp .env.example .env
nano .env   # JWT_SECRET, SMTP, ইত্যাদি বসান
```

### Step 6 — Start with PM2
```bash
node consolidate.js   # SPA build
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup          # রিবুটের পর auto-start
```

### Step 7 — Nginx reverse proxy
```bash
cat > /etc/nginx/sites-available/bangalirhaat << 'EOF'
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

ln -s /etc/nginx/sites-available/bangalirhaat /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### Step 8 — SSL (Let's Encrypt — free)
```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

**Done!** Website: `https://yourdomain.com`

---

## Option B: ফ্রি (কোন খরচ নেই) — Render.com

Hostinger VPS না কিনে চাইলে **পুরোপুরি ফ্রি**:

1. GitHub এ code push করুন
2. https://render.com → New Web Service → repo connect
3. `render.yaml` auto-detect হবে → **Apply**
4. Done — ২ মিনিটে

Render বনাম Hostinger VPS — দুটোতেই একই code চলবে।

---

## Admin Login
| Role | Email | Password |
|------|-------|----------|
| Super Admin | `admin@bangalirhaat.com` | `Admin@123` |

> ⚠️ Deploy-এর পর সাথে সাথে password change করুন!

## বাধ্যতামূলক `.env`
```
NODE_ENV=production
JWT_SECRET=<random 32+ char>
SESSION_SECRET=<random 32+ char>
DB_PATH=./data/bangalirhaat.db
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=youremail@gmail.com
SMTP_PASS=<app password>
SMTP_FROM=youremail@gmail.com
```
(SMTP setup — `SMTP_SETUP.md` দেখুন)
