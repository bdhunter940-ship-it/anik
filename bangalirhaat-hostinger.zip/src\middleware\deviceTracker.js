import { getDb } from '../database/db.js';

const MOBILE_REGEX = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|Kindle|Silk|Mobile/i;
const TABLET_REGEX = /iPad|Android(?!.*Mobile)|Tablet|PlayBook|Nexus (?!7)|KFAPWI/i;

const BROWSER_PATTERNS = [
  { name: 'Edge', regex: /Edg(?:e|A|iOS)?\/([\d.]+)/ },
  { name: 'Opera', regex: /(?:OPR|Opera)\/([\d.]+)/ },
  { name: 'Chrome', regex: /Chrome\/([\d.]+)/ },
  { name: 'Firefox', regex: /Firefox\/([\d.]+)/ },
  { name: 'Safari', regex: /Version\/([\d.]+).*Safari/ },
  { name: 'IE', regex: /(?:MSIE |Trident.*rv:)([\d.]+)/ },
  { name: 'Samsung Browser', regex: /SamsungBrowser\/([\d.]+)/ },
  { name: 'UC Browser', regex: /UCBrowser\/([\d.]+)/ },
];

const OS_PATTERNS = [
  { name: 'Windows', regex: /Windows NT ([\d.]+)/ },
  { name: 'macOS', regex: /Mac OS X ([\d._]+)/ },
  { name: 'iOS', regex: /(?:iPhone|iPad|iPod).*?OS ([\d_]+)/ },
  { name: 'Android', regex: /Android ([\d.]+)/ },
  { name: 'Linux', regex: /Linux/ },
  { name: 'Chrome OS', regex: /CrOS/ },
];

function parseBrowser(userAgent) {
  for (const { name, regex } of BROWSER_PATTERNS) {
    const match = userAgent.match(regex);
    if (match) {
      return { name, version: match[1] };
    }
  }
  return { name: 'Unknown', version: null };
}

function parseOS(userAgent) {
  for (const { name, regex } of OS_PATTERNS) {
    const match = userAgent.match(regex);
    if (match) {
      return { name, version: match[1] ? match[1].replace(/_/g, '.') : null };
    }
  }
  return { name: 'Unknown', version: null };
}

function detectDeviceType(userAgent) {
  if (TABLET_REGEX.test(userAgent)) return 'tablet';
  if (MOBILE_REGEX.test(userAgent)) return 'mobile';
  return 'desktop';
}

function parseUserAgent(userAgent) {
  if (!userAgent) {
    return { browser: { name: 'Unknown', version: null }, os: { name: 'Unknown', version: null }, deviceType: 'desktop' };
  }

  return {
    browser: parseBrowser(userAgent),
    os: parseOS(userAgent),
    deviceType: detectDeviceType(userAgent),
  };
}

export function deviceTracker(req, res, next) {
  const userAgent = req.get('user-agent') || '';
  const parsed = parseUserAgent(userAgent);

  req.deviceInfo = {
    userAgent,
    browser: parsed.browser,
    os: parsed.os,
    deviceType: parsed.deviceType,
    ip: req.ip || req.realIp || req.socket?.remoteAddress || 'unknown',
  };

  next();
}

export function logLoginDevice(userId, req, status) {
  const db = getDb();
  const userAgent = req.get('user-agent') || '';
  const deviceInfo = parseUserAgent(userAgent);

  db.prepare(`
    INSERT INTO login_history (user_id, ip_address, user_agent, device_info, status)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    userId,
    req.ip || req.realIp || req.socket?.remoteAddress || 'unknown',
    userAgent,
    JSON.stringify(deviceInfo),
    status,
  );
}
