/* ==========================================================================
   Bangalirhaat Service Worker — Offline-First Strategy
   Cache versioning, runtime caching, background sync, push notifications
   ========================================================================== */

const CACHE_VERSION = 'v2';
const CACHE_NAME = `bangalirhaat-${CACHE_VERSION}`;
const CACHE_NAME_IMAGES = `bangalirhaat-images-${CACHE_VERSION}`;
const CACHE_NAME_API = `bangalirhaat-api-${CACHE_VERSION}`;
const CACHE_NAME_FONTS = `bangalirhaat-fonts-${CACHE_VERSION}`;

const OFFLINE_URL = '/offline.html';

const PRECACHE_URLS = [
  '/',
  '/offline.html',
  '/manifest.json',
  '/css/variables.css',
  '/css/base.css',
  '/css/components.css',
  '/css/layout.css',
  '/css/pages.css',
  '/css/responsive.css',
  '/css/animation.css',
  '/js/app.js',
  '/js/animations.js',
  '/assets/icons/icon.svg',
];

const ALLOWED_NAVIGATION_PATHS = [
  '/',
  '/pages/',
];

/* ==========================================================================
   Install — Pre-cache critical assets
   ========================================================================== */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(PRECACHE_URLS).catch((err) => {
          console.warn('[SW] Pre-cache partial failure:', err);
          return Promise.allSettled(
            PRECACHE_URLS.map((url) => cache.add(url).catch(() => null))
          );
        });
      })
      .then(() => self.skipWaiting())
  );
});

/* ==========================================================================
   Activate — Clean up old caches on version update
   ========================================================================== */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((name) => {
              return (
                name.startsWith('bangalirhaat-') &&
                name !== CACHE_NAME &&
                name !== CACHE_NAME_IMAGES &&
                name !== CACHE_NAME_API &&
                name !== CACHE_NAME_FONTS
              );
            })
            .map((name) => {
              console.log('[SW] Deleting old cache:', name);
              return caches.delete(name);
            })
        );
      })
      .then(() => {
        return self.clients.matchAll().then((clients) => {
          clients.forEach((client) => {
            client.postMessage({
              type: 'CACHE_UPDATED',
              version: CACHE_VERSION,
            });
          });
        });
      })
      .then(() => self.clients.claim())
  );
});

/* ==========================================================================
   Fetch — Strategy router based on request type
   ========================================================================== */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.method !== 'GET') return;

  if (url.origin !== self.location.origin && !isAllowedExternal(url)) return;

  if (request.mode === 'navigate') {
    event.respondWith(navigationStrategy(request));
    return;
  }

  if (isImageRequest(url)) {
    event.respondWith(cacheFirstStrategy(request, CACHE_NAME_IMAGES));
    return;
  }

  if (isFontRequest(url)) {
    event.respondWith(cacheFirstStrategy(request, CACHE_NAME_FONTS));
    return;
  }

  if (isAPIRequest(url)) {
    event.respondWith(networkFirstStrategy(request, CACHE_NAME_API));
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith(cacheFirstStrategy(request, CACHE_NAME));
    return;
  }

  event.respondWith(networkFirstStrategy(request, CACHE_NAME));
});

/* ==========================================================================
   Navigation Strategy — Network first, offline fallback
   ========================================================================== */
async function navigationStrategy(request) {
  try {
    const networkResponse = await fetchWithTimeout(request, 8000);
    if (networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) return cachedResponse;

    const offlineResponse = await caches.match(OFFLINE_URL);
    return offlineResponse || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } });
  }
}

/* ==========================================================================
   Cache-First Strategy — For static assets, images, fonts
   ========================================================================== */
async function cacheFirstStrategy(request, cacheName) {
  const cachedResponse = await caches.match(request);
  if (cachedResponse) return cachedResponse;

  try {
    const networkResponse = await fetchWithTimeout(request, 10000);
    if (networkResponse.ok) {
      const cache = await caches.open(cacheName || CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch {
    return new Response('', { status: 408, headers: { 'Content-Type': 'text/plain' } });
  }
}

/* ==========================================================================
   Network-First Strategy — For API, HTML pages
   ========================================================================== */
async function networkFirstStrategy(request, cacheName) {
  try {
    const networkResponse = await fetchWithTimeout(request, 6000);
    if (networkResponse.ok) {
      const cache = await caches.open(cacheName || CACHE_NAME);
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) return cachedResponse;

    if (request.headers.get('accept')?.includes('text/html')) {
      const offlineResponse = await caches.match(OFFLINE_URL);
      if (offlineResponse) return offlineResponse;
    }

    return new Response(JSON.stringify({ error: 'Offline', message: 'Network unavailable' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

/* ==========================================================================
   Stale-While-Revalidate — Fast initial load, background refresh
   ========================================================================== */
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName || CACHE_NAME);
  const cachedResponse = await cache.match(request);

  const fetchPromise = fetchWithTimeout(request, 8000)
    .then((networkResponse) => {
      if (networkResponse.ok) {
        cache.put(request, networkResponse.clone());
      }
      return networkResponse;
    })
    .catch(() => cachedResponse);

  return cachedResponse || fetchPromise;
}

/* ==========================================================================
   Helper: Fetch with timeout
   ========================================================================== */
function fetchWithTimeout(request, timeout = 8000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  return fetch(request, { signal: controller.signal }).finally(() => {
    clearTimeout(timeoutId);
  });
}

/* ==========================================================================
   URL Classification Helpers
   ========================================================================== */
function isAllowedExternal(url) {
  const allowedDomains = [
    'fonts.googleapis.com',
    'fonts.gstatic.com',
    'cdnjs.cloudflare.com',
    'cdn.jsdelivr.net',
    'images.unsplash.com',
    'placehold.co',
  ];
  return allowedDomains.some((domain) => url.hostname === domain);
}

function isImageRequest(url) {
  return (
    /\.(png|jpg|jpeg|gif|webp|avif|svg|ico|bmp|tiff)(\?.*)?$/i.test(url.pathname) ||
    url.pathname.includes('/images/') ||
    url.pathname.includes('/uploads/') ||
    url.pathname.includes('/assets/')
  );
}

function isFontRequest(url) {
  return (
    /\.(woff|woff2|ttf|eot|otf)(\?.*)?$/i.test(url.pathname) ||
    url.hostname === 'fonts.googleapis.com' ||
    url.hostname === 'fonts.gstatic.com'
  );
}

function isAPIRequest(url) {
  return url.pathname.startsWith('/api/');
}

function isStaticAsset(url) {
  return (
    /\.(css|js|mjs)(\?.*)?$/i.test(url.pathname) ||
    url.pathname.includes('/assets/')
  );
}

/* ==========================================================================
   Background Sync — Queue failed cart operations
   ========================================================================== */
self.addEventListener('sync', (event) => {
  if (event.tag === 'cart-sync') {
    event.waitUntil(syncCart());
  }
  if (event.tag === 'wishlist-sync') {
    event.waitUntil(syncWishlist());
  }
});

async function syncCart() {
  try {
    const cache = await caches.open('bangalirhaat-sync-queue');
    const requests = await cache.keys();

    for (const request of requests) {
      if (request.url.includes('/api/cart')) {
        const body = await cache.match(request).then((r) => r?.text());
        if (body) {
          try {
            await fetch(request.url, {
              method: request.headers.get('X-HTTP-Method-Override') || 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${await getStoredToken()}`,
              },
              body,
            });
            await cache.delete(request);
          } catch {
            /* Will retry on next sync */
          }
        }
      }
    }

    await notifyClients({ type: 'SYNC_COMPLETE', resource: 'cart' });
  } catch {
    /* Silent fail — will retry */
  }
}

async function syncWishlist() {
  try {
    const cache = await caches.open('bangalirhaat-sync-queue');
    const requests = await cache.keys();

    for (const request of requests) {
      if (request.url.includes('/api/wishlist')) {
        const body = await cache.match(request).then((r) => r?.text());
        if (body) {
          try {
            await fetch(request.url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${await getStoredToken()}`,
              },
              body,
            });
            await cache.delete(request);
          } catch {
            /* Will retry on next sync */
          }
        }
      }
    }

    await notifyClients({ type: 'SYNC_COMPLETE', resource: 'wishlist' });
  } catch {
    /* Silent fail */
  }
}

/* ==========================================================================
   Queue failed requests for background sync
   ========================================================================== */
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'QUEUE_FOR_SYNC') {
    event.waitUntil(queueForSync(event.data));
  }

  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

async function queueForSync({ url, method, body }) {
  try {
    const cache = await caches.open('bangalirhaat-sync-queue');
    const request = new Request(url, {
      method: 'GET',
      headers: { 'X-HTTP-Method-Override': method },
    });
    const response = new Response(body);
    await cache.put(request, response);

    if ('sync' in self.registration) {
      const tag = url.includes('/cart') ? 'cart-sync' : 'wishlist-sync';
      await self.registration.sync.register(tag);
    }
  } catch {
    /* Silent fail */
  }
}

/* ==========================================================================
   Push Notifications
   ========================================================================== */
self.addEventListener('push', (event) => {
  let data = {
    title: 'Bangalirhaat',
    body: 'You have a new notification',
    icon: '/assets/icons/icon-192.png',
    badge: '/assets/icons/icon-96.png',
    data: { url: '/' },
  };

  if (event.data) {
    try {
      data = { ...data, ...event.data.json() };
    } catch {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: data.icon,
    badge: data.badge,
    vibrate: [100, 50, 100],
    data: data.data,
    tag: data.tag || 'bangalirhaat-notification',
    renotify: true,
    requireInteraction: false,
    actions: data.actions || [
      { action: 'open', title: 'Open', icon: data.icon },
      { action: 'dismiss', title: 'Dismiss' },
    ],
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') return;

  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      return self.clients.openWindow(targetUrl);
    })
  );
});

/* ==========================================================================
   Push Subscription Lifecycle
   ========================================================================== */
self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil(
    self.registration.pushManager.subscribe(event.oldSubscription.options)
      .then((subscription) => {
        return fetch('/api/notifications/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(subscription),
        });
      })
  );
});

/* ==========================================================================
   Utility: Get stored auth token
   ========================================================================== */
async function getStoredToken() {
  try {
    const clients = await self.clients.matchAll();
    if (clients.length > 0) {
      return new Promise((resolve) => {
        const channel = new MessageChannel();
        channel.port1.onmessage = (event) => resolve(event.data);
        clients[0].postMessage({ type: 'GET_TOKEN' }, [channel.port2]);
        setTimeout(() => resolve(''), 1000);
      });
    }
  } catch {
    return '';
  }
  return '';
}

/* ==========================================================================
   Utility: Notify all clients
   ========================================================================== */
async function notifyClients(message) {
  const clients = await self.clients.matchAll();
  clients.forEach((client) => client.postMessage(message));
}
