import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { authenticate, optionalAuth } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import recentlyViewedService from '../services/recentlyviewed.service.js';

const router = Router();

const trackValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
];

router.post('/track', trackValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const userId = req.user?.id || null;
    const { product_id, session_id } = req.body;

    if (!userId && !session_id) {
      throw new AppError('Either authentication or session_id is required', 400);
    }

    const result = await recentlyViewedService.trackView({
      userId,
      sessionId: session_id || null,
      productId: product_id,
    });

    res.status(201).json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

router.get('/', optionalAuth, async (req, res, next) => {
  try {
    const userId = req.user?.id || null;
    const sessionId = req.query.session_id || null;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);

    if (!userId && !sessionId) {
      throw new AppError('Either authentication or session_id query parameter is required', 400);
    }

    const result = await recentlyViewedService.getRecentlyViewed({
      userId,
      sessionId,
      limit,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

router.delete('/clear', authenticate, async (req, res, next) => {
  try {
    const userId = req.user.id;
    const sessionId = req.body.session_id || null;

    const result = await recentlyViewedService.clearHistory({
      userId,
      sessionId,
    });

    res.json({ success: true, message: 'Recently viewed history cleared', data: result });
  } catch (error) {
    next(error);
  }
});

export default router;
