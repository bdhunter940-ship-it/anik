import express from 'express';
import crypto from 'crypto';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

function slugify(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function uuid() {
  return crypto.randomUUID();
}

// ============================================================================
// 1. DASHBOARD
// ============================================================================

router.get('/dashboard', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const todayOrders = db.prepare(
      "SELECT COUNT(*) as count FROM orders WHERE date(created_at) = date('now') AND deleted_at IS NULL"
    ).get();

    const todayRevenue = db.prepare(
      "SELECT COALESCE(SUM(total), 0) as revenue FROM orders WHERE date(created_at) = date('now') AND payment_status = 'paid' AND deleted_at IS NULL"
    ).get();

    const pendingOrders = db.prepare(
      "SELECT COUNT(*) as count FROM orders WHERE status = 'pending' AND deleted_at IS NULL"
    ).get();

    const newCustomers = db.prepare(
      "SELECT COUNT(*) as count FROM users WHERE date(created_at) = date('now') AND role = 'customer'"
    ).get();

    const last7DaysRevenue = db.prepare(
      `SELECT date(created_at) as date, COALESCE(SUM(total), 0) as revenue
       FROM orders
       WHERE date(created_at) >= date('now', '-7 days') AND payment_status = 'paid' AND deleted_at IS NULL
       GROUP BY date(created_at)
       ORDER BY date ASC`
    ).all();

    const recentOrders = db.prepare(
      `SELECT o.id, o.uuid, o.order_number, o.status, o.total, o.payment_status, o.payment_method, o.created_at,
              u.id as user_id, u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email
       FROM orders o
       JOIN users u ON o.user_id = u.id
       WHERE o.deleted_at IS NULL
       ORDER BY o.created_at DESC
       LIMIT 10`
    ).all();

    const topProducts = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.stock_quantity, c.name as category_name,
              COALESCE(s.total_sold, 0) as total_sold
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN (
         SELECT product_id, SUM(quantity) as total_sold
         FROM order_items
         GROUP BY product_id
       ) s ON s.product_id = p.id
       WHERE p.deleted_at IS NULL
       ORDER BY total_sold DESC
       LIMIT 5`
    ).all();

    const orderStatusDistribution = db.prepare(
      `SELECT status, COUNT(*) as count
       FROM orders
       WHERE deleted_at IS NULL
       GROUP BY status`
    ).all();

    const lowStockProducts = db.prepare(
      `SELECT p.id, p.name, p.slug, p.stock_quantity, p.low_stock_threshold, c.name as category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.deleted_at IS NULL AND p.track_stock = 1
         AND p.stock_quantity < p.low_stock_threshold
       ORDER BY p.stock_quantity ASC`
    ).all();

    res.json({
      success: true,
      data: {
        today_orders: todayOrders.count,
        today_revenue: todayRevenue.revenue,
        pending_orders: pendingOrders.count,
        new_customers_today: newCustomers.count,
        last_7_days_revenue: last7DaysRevenue,
        recent_orders: recentOrders,
        top_products: topProducts,
        order_status_distribution: orderStatusDistribution,
        low_stock_products: lowStockProducts,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/analytics/daily', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const data = db.prepare(
      `SELECT * FROM analytics_daily
       ORDER BY date DESC
       LIMIT 30`
    ).all();

    res.json({
      success: true,
      data: { items: data },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/analytics', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const period = req.query.period || 'daily';

    let groupBy;
    let dateFormat;

    switch (period) {
      case 'weekly':
        groupBy = "strftime('%Y-W%W', date)";
        dateFormat = "strftime('%Y-W%W', date) as period";
        break;
      case 'monthly':
        groupBy = "strftime('%Y-%m', date)";
        dateFormat = "strftime('%Y-%m', date) as period";
        break;
      case 'yearly':
        groupBy = "strftime('%Y', date)";
        dateFormat = "strftime('%Y', date) as period";
        break;
      default:
        groupBy = 'date';
        dateFormat = 'date as period';
    }

    const data = db.prepare(
      `SELECT ${dateFormat},
              SUM(orders) as total_orders,
              SUM(revenue) as total_revenue,
              SUM(visitors) as total_visitors,
              SUM(page_views) as total_page_views,
              SUM(new_users) as total_new_users,
              SUM(returns) as total_returns
       FROM analytics_daily
       GROUP BY ${groupBy}
       ORDER BY period DESC`
    ).all();

    res.json({
      success: true,
      data: { items: data, period },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 2. ORDERS
// ============================================================================

router.get('/orders', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['o.deleted_at IS NULL'];
    let params = [];

    if (req.query.status) {
      where.push('o.status = ?');
      params.push(req.query.status);
    }

    if (req.query.payment_status) {
      where.push('o.payment_status = ?');
      params.push(req.query.payment_status);
    }

    if (req.query.search) {
      where.push('o.order_number LIKE ?');
      params.push(`%${req.query.search}%`);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM orders o ${whereClause}`
    ).get(...params);

    const orders = db.prepare(
      `SELECT o.id, o.uuid, o.order_number, o.status, o.subtotal, o.discount, o.shipping_cost,
              o.tax, o.total, o.payment_status, o.payment_method, o.shipping_address,
              o.notes, o.courier_id, o.tracking_number, o.created_at, o.updated_at,
              u.id as user_id, u.first_name || ' ' || u.last_name as customer_name,
              u.email as customer_email, u.phone as customer_phone,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
       FROM orders o
       JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: orders,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/orders/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const orderId = parseInt(req.params.id);

    const order = db.prepare(
      `SELECT o.*, u.id as user_id, u.first_name || ' ' || u.last_name as customer_name,
              u.email as customer_email, u.phone as customer_phone
       FROM orders o
       JOIN users u ON o.user_id = u.id
       WHERE o.id = ?`
    ).get(orderId);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const items = db.prepare(
      `SELECT oi.*, p.slug as product_slug,
              (SELECT url FROM product_images WHERE product_id = oi.product_id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = ?`
    ).all(orderId);

    const statusHistory = db.prepare(
      `SELECT osh.*, u.first_name || ' ' || u.last_name as changed_by_name
       FROM order_status_history osh
       LEFT JOIN users u ON osh.changed_by = u.id
       WHERE osh.order_id = ?
       ORDER BY osh.created_at DESC`
    ).all(orderId);

    const payments = db.prepare(
      `SELECT * FROM payments WHERE order_id = ? ORDER BY created_at DESC`
    ).all(orderId);

    res.json({
      success: true,
      data: {
        order: {
          ...order,
          items,
          status_history: statusHistory,
          payments,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/orders/:id/status', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const orderId = parseInt(req.params.id);
    const { status, note } = req.body;

    const validStatuses = [
      'draft', 'pending', 'confirmed', 'packaging',
      'ready_to_ship', 'courier_sent', 'in_transit',
      'delivered', 'returned', 'cancelled', 'exchanged',
    ];

    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const transaction = db.transaction(() => {
      db.prepare(
        `UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(status, orderId);

      db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, changed_by, created_at)
         VALUES (?, ?, ?, ?, datetime('now'))`
      ).run(orderId, status, note || null, req.user.id);

      if (status === 'delivered') {
        db.prepare(
          `UPDATE orders SET delivered_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
        ).run(orderId);
      }

      if (status === 'courier_sent' || status === 'in_transit') {
        db.prepare(
          `UPDATE orders SET shipped_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
        ).run(orderId);
      }
    });

    transaction();

    const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.json({
      success: true,
      data: { order: updatedOrder },
      message: `Order status updated to ${status}`,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/orders/draft', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { user_id, items, shipping_address, notes, internal_notes } = req.body;

    if (!user_id) {
      return res.status(400).json({ success: false, message: 'User ID is required' });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'At least one item is required' });
    }

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(user_id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const orderNumber = `ORD-DRAFT-${Date.now().toString(36).toUpperCase()}`;

    let subtotal = 0;
    for (const item of items) {
      subtotal += item.price * item.quantity;
    }

    const result = db.prepare(
      `INSERT INTO orders (uuid, user_id, order_number, status, subtotal, discount, shipping_cost,
                          tax, total, payment_status, shipping_address, notes, internal_notes,
                          created_at, updated_at)
       VALUES (?, ?, ?, 'draft', ?, 0, 0, 0, ?, 'pending', ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), user_id, orderNumber, subtotal, subtotal,
      shipping_address ? JSON.stringify(shipping_address) : null,
      notes || null, internal_notes || null
    );

    const orderId = result.lastInsertRowid;

    const insertItem = db.prepare(
      `INSERT INTO order_items (order_id, product_id, product_name, product_sku, quantity, price, discount, tax, total, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, datetime('now'))`
    );

    for (const item of items) {
      insertItem.run(
        orderId, item.product_id, item.product_name, item.product_sku || '',
        item.quantity, item.price, item.price * item.quantity
      );
    }

    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, changed_by, created_at)
       VALUES (?, 'draft', 'Draft order created', ?, datetime('now'))`
    ).run(orderId, req.user.id);

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    const orderItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);

    res.status(201).json({
      success: true,
      data: { order: { ...order, items: orderItems } },
      message: 'Draft order created',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/orders/bulk-update', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { orderIds, status } = req.body;

    const validStatuses = [
      'draft', 'pending', 'confirmed', 'packaging',
      'ready_to_ship', 'courier_sent', 'in_transit',
      'delivered', 'returned', 'cancelled', 'exchanged',
    ];

    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
      return res.status(400).json({ success: false, message: 'Order IDs array is required' });
    }

    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }

    const placeholders = orderIds.map(() => '?').join(',');
    const orders = db.prepare(
      `SELECT id FROM orders WHERE id IN (${placeholders}) AND deleted_at IS NULL`
    ).all(...orderIds);

    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: 'No valid orders found' });
    }

    const foundIds = orders.map(o => o.id);

    const transaction = db.transaction(() => {
      const updateStmt = db.prepare(
        `UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?`
      );

      const historyStmt = db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, changed_by, created_at)
         VALUES (?, ?, ?, ?, datetime('now'))`
      );

      for (const id of foundIds) {
        updateStmt.run(status, id);
        historyStmt.run(id, status, 'Bulk status update', req.user.id);
      }
    });

    transaction();

    res.json({
      success: true,
      message: `${foundIds.length} orders updated to ${status}`,
      data: { updated_count: foundIds.length, updated_ids: foundIds },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 3. PRODUCTS
// ============================================================================

router.get('/products', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['p.deleted_at IS NULL'];
    let params = [];

    if (req.query.search) {
      where.push('(p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ?)');
      const term = `%${req.query.search}%`;
      params.push(term, term, term);
    }

    if (req.query.category_id) {
      where.push('p.category_id = ?');
      params.push(parseInt(req.query.category_id));
    }

    if (req.query.brand_id) {
      where.push('p.brand_id = ?');
      params.push(parseInt(req.query.brand_id));
    }

    if (req.query.is_active !== undefined) {
      where.push('p.is_active = ?');
      params.push(parseInt(req.query.is_active));
    }

    if (req.query.is_featured !== undefined) {
      where.push('p.is_featured = ?');
      params.push(parseInt(req.query.is_featured));
    }

    if (req.query.stock === 'low') {
      where.push('p.track_stock = 1 AND p.stock_quantity < p.low_stock_threshold');
    } else if (req.query.stock === 'out') {
      where.push('p.stock_quantity = 0');
    } else if (req.query.stock === 'in') {
      where.push('p.stock_quantity > 0');
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM products p ${whereClause}`
    ).get(...params);

    const products = db.prepare(
      `SELECT p.*, c.name as category_name, b.name as brand_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail,
              COALESCE(s.total_sold, 0) as total_sold
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN (
         SELECT product_id, SUM(quantity) as total_sold
         FROM order_items
         GROUP BY product_id
       ) s ON s.product_id = p.id
       ${whereClause}
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: products,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/products', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const {
      name, slug, description, short_description, sku, barcode,
      brand_id, category_id, price, compare_price, cost_price,
      tax_rate, weight, dimensions, stock_quantity, low_stock_threshold,
      track_stock, is_active, is_featured, is_digital,
      meta_title, meta_description, tags,
    } = req.body;

    if (!name || !category_id) {
      return res.status(400).json({ success: false, message: 'Name and category_id are required' });
    }

    const finalSlug = slug || slugify(name);

    const existingSlug = db.prepare('SELECT id FROM products WHERE slug = ?').get(finalSlug);
    if (existingSlug) {
      return res.status(400).json({ success: false, message: 'A product with this slug already exists' });
    }

    if (sku) {
      const existingSku = db.prepare('SELECT id FROM products WHERE sku = ?').get(sku);
      if (existingSku) {
        return res.status(400).json({ success: false, message: 'A product with this SKU already exists' });
      }
    }

    const result = db.prepare(
      `INSERT INTO products (uuid, name, slug, description, short_description, sku, barcode,
                            brand_id, category_id, price, compare_price, cost_price,
                            tax_rate, weight, dimensions, stock_quantity, low_stock_threshold,
                            track_stock, is_active, is_featured, is_digital,
                            meta_title, meta_description, tags, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), name, finalSlug, description || null, short_description || null,
      sku || null, barcode || null, brand_id || null, category_id,
      price || 0, compare_price || null, cost_price || null,
      tax_rate || 0, weight || null, dimensions || null,
      stock_quantity || 0, low_stock_threshold || 5,
      track_stock !== undefined ? track_stock : 1,
      is_active !== undefined ? is_active : 1,
      is_featured || 0, is_digital || 0,
      meta_title || null, meta_description || null,
      tags || null
    );

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { product },
      message: 'Product created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/products/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);
    const product = db.prepare(
      `SELECT p.*, c.name as category_name, b.name as brand_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.id = ? AND p.deleted_at IS NULL`
    ).get(productId);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    const images = db.prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC').all(productId);
    res.json({ success: true, data: { product: { ...product, images } } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/products/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL').get(productId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    const {
      name, slug, description, short_description, sku, barcode,
      brand_id, category_id, price, compare_price, cost_price,
      tax_rate, weight, dimensions, stock_quantity, low_stock_threshold,
      track_stock, is_active, is_featured, is_digital,
      meta_title, meta_description, tags,
    } = req.body;

    if (slug && slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM products WHERE slug = ? AND id != ?').get(slug, productId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A product with this slug already exists' });
      }
    }

    if (sku && sku !== existing.sku) {
      const skuConflict = db.prepare('SELECT id FROM products WHERE sku = ? AND id != ?').get(sku, productId);
      if (skuConflict) {
        return res.status(400).json({ success: false, message: 'A product with this SKU already exists' });
      }
    }

    db.prepare(
      `UPDATE products SET
        name = ?, slug = ?, description = ?, short_description = ?,
        sku = ?, barcode = ?, brand_id = ?, category_id = ?,
        price = ?, compare_price = ?, cost_price = ?,
        tax_rate = ?, weight = ?, dimensions = ?,
        stock_quantity = ?, low_stock_threshold = ?, track_stock = ?,
        is_active = ?, is_featured = ?, is_digital = ?,
        meta_title = ?, meta_description = ?, tags = ?,
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      slug || existing.slug,
      description !== undefined ? description : existing.description,
      short_description !== undefined ? short_description : existing.short_description,
      sku !== undefined ? sku : existing.sku,
      barcode !== undefined ? barcode : existing.barcode,
      brand_id !== undefined ? brand_id : existing.brand_id,
      category_id || existing.category_id,
      price !== undefined ? price : existing.price,
      compare_price !== undefined ? compare_price : existing.compare_price,
      cost_price !== undefined ? cost_price : existing.cost_price,
      tax_rate !== undefined ? tax_rate : existing.tax_rate,
      weight !== undefined ? weight : existing.weight,
      dimensions !== undefined ? dimensions : existing.dimensions,
      stock_quantity !== undefined ? stock_quantity : existing.stock_quantity,
      low_stock_threshold !== undefined ? low_stock_threshold : existing.low_stock_threshold,
      track_stock !== undefined ? track_stock : existing.track_stock,
      is_active !== undefined ? is_active : existing.is_active,
      is_featured !== undefined ? is_featured : existing.is_featured,
      is_digital !== undefined ? is_digital : existing.is_digital,
      meta_title !== undefined ? meta_title : existing.meta_title,
      meta_description !== undefined ? meta_description : existing.meta_description,
      tags !== undefined ? tags : existing.tags,
      productId
    );

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.json({
      success: true,
      data: { product },
      message: 'Product updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/products/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);

    const product = db.prepare('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL').get(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    db.prepare(
      `UPDATE products SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(productId);

    res.json({
      success: true,
      message: 'Product deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/products/:id/stock', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);
    const { stock_quantity } = req.body;

    if (stock_quantity === undefined || stock_quantity < 0) {
      return res.status(400).json({ success: false, message: 'Valid stock_quantity is required' });
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ? AND deleted_at IS NULL').get(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    db.prepare(
      `UPDATE products SET stock_quantity = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(stock_quantity, productId);

    const updated = db.prepare('SELECT id, name, stock_quantity FROM products WHERE id = ?').get(productId);

    res.json({
      success: true,
      data: { product: updated },
      message: 'Stock updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 4. CATEGORIES
// ============================================================================

router.get('/categories', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const categories = db.prepare(
      `SELECT c.*, pc.name as parent_name,
              (SELECT COUNT(*) FROM products WHERE category_id = c.id AND deleted_at IS NULL) as product_count
       FROM categories c
       LEFT JOIN categories pc ON c.parent_id = pc.id
       WHERE c.deleted_at IS NULL
       ORDER BY c.sort_order ASC, c.name ASC`
    ).all();

    res.json({
      success: true,
      data: { items: categories },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/categories', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, slug, description, image, parent_id, sort_order, is_active, meta_title, meta_description } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Name is required' });
    }

    const finalSlug = slug || slugify(name);

    const existingSlug = db.prepare('SELECT id FROM categories WHERE slug = ?').get(finalSlug);
    if (existingSlug) {
      return res.status(400).json({ success: false, message: 'A category with this slug already exists' });
    }

    if (parent_id) {
      const parent = db.prepare('SELECT id FROM categories WHERE id = ? AND deleted_at IS NULL').get(parent_id);
      if (!parent) {
        return res.status(400).json({ success: false, message: 'Parent category not found' });
      }
    }

    const result = db.prepare(
      `INSERT INTO categories (uuid, name, slug, description, image, parent_id, sort_order, is_active,
                              meta_title, meta_description, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), name, finalSlug, description || null, image || null,
      parent_id || null, sort_order || 0, is_active !== undefined ? is_active : 1,
      meta_title || null, meta_description || null
    );

    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { category },
      message: 'Category created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/categories/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const categoryId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM categories WHERE id = ? AND deleted_at IS NULL').get(categoryId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Category not found' });
    }

    const { name, slug, description, image, parent_id, sort_order, is_active, meta_title, meta_description } = req.body;

    if (slug && slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM categories WHERE slug = ? AND id != ?').get(slug, categoryId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A category with this slug already exists' });
      }
    }

    if (parent_id && parent_id === categoryId) {
      return res.status(400).json({ success: false, message: 'A category cannot be its own parent' });
    }

    db.prepare(
      `UPDATE categories SET
        name = ?, slug = ?, description = ?, image = ?,
        parent_id = ?, sort_order = ?, is_active = ?,
        meta_title = ?, meta_description = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      slug || existing.slug,
      description !== undefined ? description : existing.description,
      image !== undefined ? image : existing.image,
      parent_id !== undefined ? parent_id : existing.parent_id,
      sort_order !== undefined ? sort_order : existing.sort_order,
      is_active !== undefined ? is_active : existing.is_active,
      meta_title !== undefined ? meta_title : existing.meta_title,
      meta_description !== undefined ? meta_description : existing.meta_description,
      categoryId
    );

    const category = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId);

    res.json({
      success: true,
      data: { category },
      message: 'Category updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/categories/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const categoryId = parseInt(req.params.id);

    const category = db.prepare('SELECT * FROM categories WHERE id = ? AND deleted_at IS NULL').get(categoryId);
    if (!category) {
      return res.status(404).json({ success: false, message: 'Category not found' });
    }

    const childCount = db.prepare(
      'SELECT COUNT(*) as count FROM categories WHERE parent_id = ? AND deleted_at IS NULL'
    ).get(categoryId);

    if (childCount.count > 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete category with subcategories. Remove subcategories first.',
      });
    }

    const productCount = db.prepare(
      'SELECT COUNT(*) as count FROM products WHERE category_id = ? AND deleted_at IS NULL'
    ).get(categoryId);

    if (productCount.count > 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete category with products. Reassign or remove products first.',
      });
    }

    db.prepare(
      `UPDATE categories SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(categoryId);

    res.json({
      success: true,
      message: 'Category deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 5. BRANDS
// ============================================================================

router.get('/brands', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const brands = db.prepare(
      `SELECT b.*,
              (SELECT COUNT(*) FROM products WHERE brand_id = b.id AND deleted_at IS NULL) as product_count
       FROM brands b
       WHERE b.deleted_at IS NULL
       ORDER BY b.name ASC`
    ).all();

    res.json({
      success: true,
      data: { items: brands },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/brands', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, slug, logo, description, is_active } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Name is required' });
    }

    const finalSlug = slug || slugify(name);

    const existingSlug = db.prepare('SELECT id FROM brands WHERE slug = ?').get(finalSlug);
    if (existingSlug) {
      return res.status(400).json({ success: false, message: 'A brand with this slug already exists' });
    }

    const result = db.prepare(
      `INSERT INTO brands (uuid, name, slug, logo, description, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(uuid(), name, finalSlug, logo || null, description || null, is_active !== undefined ? is_active : 1);

    const brand = db.prepare('SELECT * FROM brands WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { brand },
      message: 'Brand created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/brands/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const brandId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM brands WHERE id = ? AND deleted_at IS NULL').get(brandId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Brand not found' });
    }

    const { name, slug, logo, description, is_active } = req.body;

    if (slug && slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM brands WHERE slug = ? AND id != ?').get(slug, brandId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A brand with this slug already exists' });
      }
    }

    db.prepare(
      `UPDATE brands SET
        name = ?, slug = ?, logo = ?, description = ?, is_active = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      slug || existing.slug,
      logo !== undefined ? logo : existing.logo,
      description !== undefined ? description : existing.description,
      is_active !== undefined ? is_active : existing.is_active,
      brandId
    );

    const brand = db.prepare('SELECT * FROM brands WHERE id = ?').get(brandId);

    res.json({
      success: true,
      data: { brand },
      message: 'Brand updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/brands/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const brandId = parseInt(req.params.id);

    const brand = db.prepare('SELECT * FROM brands WHERE id = ? AND deleted_at IS NULL').get(brandId);
    if (!brand) {
      return res.status(404).json({ success: false, message: 'Brand not found' });
    }

    const productCount = db.prepare(
      'SELECT COUNT(*) as count FROM products WHERE brand_id = ? AND deleted_at IS NULL'
    ).get(brandId);

    if (productCount.count > 0) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete brand with products. Reassign or remove products first.',
      });
    }

    db.prepare(
      `UPDATE brands SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(brandId);

    res.json({
      success: true,
      message: 'Brand deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 6. SUPPLIERS
// ============================================================================

router.get('/suppliers', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['deleted_at IS NULL'];
    let params = [];

    if (req.query.search) {
      where.push('(name LIKE ? OR contact_person LIKE ? OR email LIKE ? OR phone LIKE ?)');
      const term = `%${req.query.search}%`;
      params.push(term, term, term, term);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM suppliers ${whereClause}`
    ).get(...params);

    const suppliers = db.prepare(
      `SELECT * FROM suppliers ${whereClause} ORDER BY name ASC LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: suppliers,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/suppliers', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, contact_person, email, phone, address, notes, is_active } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Name is required' });
    }

    const result = db.prepare(
      `INSERT INTO suppliers (uuid, name, contact_person, email, phone, address, notes, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), name, contact_person || null, email || null,
      phone || null, address || null, notes || null,
      is_active !== undefined ? is_active : 1
    );

    const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { supplier },
      message: 'Supplier created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/suppliers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const supplierId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM suppliers WHERE id = ? AND deleted_at IS NULL').get(supplierId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Supplier not found' });
    }

    const { name, contact_person, email, phone, address, notes, is_active } = req.body;

    db.prepare(
      `UPDATE suppliers SET
        name = ?, contact_person = ?, email = ?, phone = ?,
        address = ?, notes = ?, is_active = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      contact_person !== undefined ? contact_person : existing.contact_person,
      email !== undefined ? email : existing.email,
      phone !== undefined ? phone : existing.phone,
      address !== undefined ? address : existing.address,
      notes !== undefined ? notes : existing.notes,
      is_active !== undefined ? is_active : existing.is_active,
      supplierId
    );

    const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(supplierId);

    res.json({
      success: true,
      data: { supplier },
      message: 'Supplier updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/suppliers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const supplierId = parseInt(req.params.id);

    const supplier = db.prepare('SELECT * FROM suppliers WHERE id = ? AND deleted_at IS NULL').get(supplierId);
    if (!supplier) {
      return res.status(404).json({ success: false, message: 'Supplier not found' });
    }

    db.prepare(
      `UPDATE suppliers SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(supplierId);

    res.json({
      success: true,
      message: 'Supplier deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 7. WAREHOUSES
// ============================================================================

router.get('/warehouses', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const warehouses = db.prepare(
      `SELECT * FROM warehouses ORDER BY name ASC`
    ).all();

    res.json({
      success: true,
      data: { items: warehouses },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/warehouses', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, address, phone, is_active } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Name is required' });
    }

    const result = db.prepare(
      `INSERT INTO warehouses (name, address, phone, is_active, created_at)
       VALUES (?, ?, ?, ?, datetime('now'))`
    ).run(name, address || null, phone || null, is_active !== undefined ? is_active : 1);

    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { warehouse },
      message: 'Warehouse created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 8. PURCHASES
// ============================================================================

router.get('/purchases', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.status) {
      where.push('p.status = ?');
      params.push(req.query.status);
    }

    if (req.query.supplier_id) {
      where.push('p.supplier_id = ?');
      params.push(parseInt(req.query.supplier_id));
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM purchases p ${whereClause}`
    ).get(...params);

    const purchases = db.prepare(
      `SELECT p.*, s.name as supplier_name, s.contact_person,
              u.first_name || ' ' || u.last_name as created_by_name
       FROM purchases p
       JOIN suppliers s ON p.supplier_id = s.id
       JOIN users u ON p.created_by = u.id
       ${whereClause}
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: purchases,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/purchases', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { supplier_id, invoice_number, status, notes, items } = req.body;

    if (!supplier_id) {
      return res.status(400).json({ success: false, message: 'Supplier ID is required' });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ success: false, message: 'At least one purchase item is required' });
    }

    const supplier = db.prepare('SELECT id FROM suppliers WHERE id = ? AND deleted_at IS NULL').get(supplier_id);
    if (!supplier) {
      return res.status(404).json({ success: false, message: 'Supplier not found' });
    }

    let total = 0;
    for (const item of items) {
      total += (item.unit_cost || 0) * (item.quantity || 0);
    }

    const transaction = db.transaction(() => {
      const result = db.prepare(
        `INSERT INTO purchases (uuid, supplier_id, invoice_number, status, total, notes, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
      ).run(
        uuid(), supplier_id, invoice_number || null,
        status || 'draft', total, notes || null, req.user.id
      );

      const purchaseId = result.lastInsertRowid;

      const insertItem = db.prepare(
        `INSERT INTO purchase_items (purchase_id, product_id, variant_id, quantity, received_quantity, unit_cost, total, created_at)
         VALUES (?, ?, ?, ?, 0, ?, ?, datetime('now'))`
      );

      for (const item of items) {
        const itemTotal = (item.unit_cost || 0) * (item.quantity || 0);
        insertItem.run(
          purchaseId, item.product_id, item.variant_id || null,
          item.quantity, item.unit_cost, itemTotal
        );
      }

      return purchaseId;
    });

    const purchaseId = transaction();

    const purchase = db.prepare(
      `SELECT p.*, s.name as supplier_name
       FROM purchases p
       JOIN suppliers s ON p.supplier_id = s.id
       WHERE p.id = ?`
    ).get(purchaseId);

    const purchaseItems = db.prepare(
      `SELECT pi.*, pr.name as product_name
       FROM purchase_items pi
       JOIN products pr ON pi.product_id = pr.id
       WHERE pi.purchase_id = ?`
    ).all(purchaseId);

    res.status(201).json({
      success: true,
      data: { purchase: { ...purchase, items: purchaseItems } },
      message: 'Purchase order created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 9. INVENTORY - LOW STOCK & STOCK TRANSFERS
// ============================================================================

router.get('/inventory/low-stock', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.sku, p.stock_quantity, p.low_stock_threshold,
              c.name as category_name, b.name as brand_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.deleted_at IS NULL AND p.track_stock = 1
         AND p.stock_quantity < p.low_stock_threshold
       ORDER BY p.stock_quantity ASC`
    ).all();

    res.json({
      success: true,
      data: { items: products },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/inventory/stock-transfer', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.status) {
      where.push('st.status = ?');
      params.push(req.query.status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM stock_transfers st ${whereClause}`
    ).get(...params);

    const transfers = db.prepare(
      `SELECT st.*,
              fw.name as from_warehouse_name,
              tw.name as to_warehouse_name,
              pr.name as product_name,
              u.first_name || ' ' || u.last_name as created_by_name
       FROM stock_transfers st
       JOIN warehouses fw ON st.from_warehouse_id = fw.id
       JOIN warehouses tw ON st.to_warehouse_id = tw.id
       JOIN products pr ON st.product_id = pr.id
       JOIN users u ON st.created_by = u.id
       ${whereClause}
       ORDER BY st.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: transfers,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/inventory/stock-transfer', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { from_warehouse_id, to_warehouse_id, product_id, quantity, notes } = req.body;

    if (!from_warehouse_id || !to_warehouse_id || !product_id || !quantity) {
      return res.status(400).json({
        success: false,
        message: 'from_warehouse_id, to_warehouse_id, product_id, and quantity are required',
      });
    }

    if (from_warehouse_id === to_warehouse_id) {
      return res.status(400).json({ success: false, message: 'Source and destination warehouses must be different' });
    }

    if (quantity <= 0) {
      return res.status(400).json({ success: false, message: 'Quantity must be greater than 0' });
    }

    const fromWarehouse = db.prepare('SELECT id FROM warehouses WHERE id = ?').get(from_warehouse_id);
    const toWarehouse = db.prepare('SELECT id FROM warehouses WHERE id = ?').get(to_warehouse_id);
    const product = db.prepare('SELECT id, name FROM products WHERE id = ? AND deleted_at IS NULL').get(product_id);

    if (!fromWarehouse) {
      return res.status(404).json({ success: false, message: 'Source warehouse not found' });
    }
    if (!toWarehouse) {
      return res.status(404).json({ success: false, message: 'Destination warehouse not found' });
    }
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    const result = db.prepare(
      `INSERT INTO stock_transfers (from_warehouse_id, to_warehouse_id, product_id, quantity, status, notes, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'pending', ?, ?, datetime('now'), datetime('now'))`
    ).run(from_warehouse_id, to_warehouse_id, product_id, quantity, notes || null, req.user.id);

    const transfer = db.prepare(
      `SELECT st.*,
              fw.name as from_warehouse_name,
              tw.name as to_warehouse_name,
              pr.name as product_name
       FROM stock_transfers st
       JOIN warehouses fw ON st.from_warehouse_id = fw.id
       JOIN warehouses tw ON st.to_warehouse_id = tw.id
       JOIN products pr ON st.product_id = pr.id
       WHERE st.id = ?`
    ).get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { transfer },
      message: 'Stock transfer created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 10. FINANCE
// ============================================================================

router.get('/finance/overview', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const totalRevenue = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as amount
       FROM orders WHERE payment_status = 'paid' AND deleted_at IS NULL`
    ).get();

    const totalExpenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as amount
       FROM expenses WHERE deleted_at IS NULL`
    ).get();

    const pendingPayments = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as amount, COUNT(*) as count
       FROM orders WHERE payment_status = 'pending' AND deleted_at IS NULL`
    ).get();

    const refundedAmount = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as amount
       FROM payments WHERE status = 'refunded'`
    ).get();

    const revenue = totalRevenue.amount || 0;
    const expenses = totalExpenses.amount || 0;
    const profit = revenue - expenses;

    res.json({
      success: true,
      data: {
        total_revenue: revenue,
        total_expenses: expenses,
        profit,
        pending_payments: {
          amount: pendingPayments.amount,
          count: pendingPayments.count,
        },
        refunded_amount: refundedAmount.amount,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/finance/expenses', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['e.deleted_at IS NULL'];
    let params = [];

    if (req.query.category) {
      where.push('e.category = ?');
      params.push(req.query.category);
    }

    if (req.query.start_date) {
      where.push('e.date >= ?');
      params.push(req.query.start_date);
    }

    if (req.query.end_date) {
      where.push('e.date <= ?');
      params.push(req.query.end_date);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM expenses e ${whereClause}`
    ).get(...params);

    const expenses = db.prepare(
      `SELECT e.*,
              u.first_name || ' ' || u.last_name as created_by_name,
              au.first_name || ' ' || au.last_name as approved_by_name
       FROM expenses e
       JOIN users u ON e.created_by = u.id
       LEFT JOIN users au ON e.approved_by = au.id
       ${whereClause}
       ORDER BY e.date DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: expenses,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/finance/expenses', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { category, description, amount, date, receipt_image } = req.body;

    if (!category || !amount || !date) {
      return res.status(400).json({
        success: false,
        message: 'Category, amount, and date are required',
      });
    }

    if (amount <= 0) {
      return res.status(400).json({ success: false, message: 'Amount must be greater than 0' });
    }

    const result = db.prepare(
      `INSERT INTO expenses (category, description, amount, date, receipt_image, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(category, description || null, amount, date, receipt_image || null, req.user.id);

    const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { expense },
      message: 'Expense created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/finance/expenses/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const expenseId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM expenses WHERE id = ? AND deleted_at IS NULL').get(expenseId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Expense not found' });
    }

    const { category, description, amount, date, receipt_image, approved_by } = req.body;

    db.prepare(
      `UPDATE expenses SET
        category = ?, description = ?, amount = ?, date = ?,
        receipt_image = ?, approved_by = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      category || existing.category,
      description !== undefined ? description : existing.description,
      amount || existing.amount,
      date || existing.date,
      receipt_image !== undefined ? receipt_image : existing.receipt_image,
      approved_by !== undefined ? approved_by : existing.approved_by,
      expenseId
    );

    const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(expenseId);

    res.json({
      success: true,
      data: { expense },
      message: 'Expense updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/finance/transactions', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.status) {
      where.push('py.status = ?');
      params.push(req.query.status);
    }

    if (req.query.method) {
      where.push('py.method = ?');
      params.push(req.query.method);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM payments py ${whereClause}`
    ).get(...params);

    const transactions = db.prepare(
      `SELECT py.*, o.order_number, o.total as order_total,
              u.first_name || ' ' || u.last_name as customer_name
       FROM payments py
       JOIN orders o ON py.order_id = o.id
       JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY py.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: transactions,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/finance/invoices', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['o.deleted_at IS NULL'];
    let params = [];

    if (req.query.payment_status) {
      where.push('o.payment_status = ?');
      params.push(req.query.payment_status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM orders o ${whereClause}`
    ).get(...params);

    const invoices = db.prepare(
      `SELECT o.id, o.order_number, o.subtotal, o.discount, o.shipping_cost,
              o.tax, o.total, o.payment_status, o.payment_method,
              o.created_at,
              u.first_name || ' ' || u.last_name as customer_name,
              u.email as customer_email, u.phone as customer_phone,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count,
              (SELECT COALESCE(SUM(py.amount), 0) FROM payments py WHERE py.order_id = o.id AND py.status = 'completed') as amount_paid
       FROM orders o
       JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: invoices,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 11. REPORTS
// ============================================================================

router.get('/reports/daily', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const orders = db.prepare(
      `SELECT COUNT(*) as total_orders,
              COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
              COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders
       FROM orders WHERE date(created_at) = date('now') AND deleted_at IS NULL`
    ).get();

    const revenue = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as total_revenue
       FROM orders WHERE date(created_at) = date('now') AND payment_status = 'paid' AND deleted_at IS NULL`
    ).get();

    const expenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total_expenses
       FROM expenses WHERE date(date) = date('now') AND deleted_at IS NULL`
    ).get();

    const profit = (revenue.total_revenue || 0) - (expenses.total_expenses || 0);

    res.json({
      success: true,
      data: {
        date: new Date().toISOString().split('T')[0],
        orders: {
          total: orders.total_orders,
          delivered: orders.delivered_orders,
          cancelled: orders.cancelled_orders,
        },
        revenue: revenue.total_revenue,
        expenses: expenses.total_expenses,
        profit,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/weekly', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const orders = db.prepare(
      `SELECT COUNT(*) as total_orders,
              COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
              COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders
       FROM orders WHERE date(created_at) >= date('now', '-7 days') AND deleted_at IS NULL`
    ).get();

    const revenue = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as total_revenue
       FROM orders WHERE date(created_at) >= date('now', '-7 days') AND payment_status = 'paid' AND deleted_at IS NULL`
    ).get();

    const expenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total_expenses
       FROM expenses WHERE date(date) >= date('now', '-7 days') AND deleted_at IS NULL`
    ).get();

    const dailyBreakdown = db.prepare(
      `SELECT date(created_at) as date,
              COUNT(*) as orders,
              COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END), 0) as revenue
       FROM orders
       WHERE date(created_at) >= date('now', '-7 days') AND deleted_at IS NULL
       GROUP BY date(created_at)
       ORDER BY date ASC`
    ).all();

    const profit = (revenue.total_revenue || 0) - (expenses.total_expenses || 0);

    res.json({
      success: true,
      data: {
        period: 'last_7_days',
        orders: {
          total: orders.total_orders,
          delivered: orders.delivered_orders,
          cancelled: orders.cancelled_orders,
        },
        revenue: revenue.total_revenue,
        expenses: expenses.total_expenses,
        profit,
        daily_breakdown: dailyBreakdown,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/monthly', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const orders = db.prepare(
      `SELECT COUNT(*) as total_orders,
              COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
              COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders
       FROM orders
       WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now') AND deleted_at IS NULL`
    ).get();

    const revenue = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as total_revenue
       FROM orders
       WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
         AND payment_status = 'paid' AND deleted_at IS NULL`
    ).get();

    const expenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total_expenses
       FROM expenses
       WHERE strftime('%Y-%m', date) = strftime('%Y-%m', 'now') AND deleted_at IS NULL`
    ).get();

    const newCustomers = db.prepare(
      `SELECT COUNT(*) as count
       FROM users
       WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now') AND role = 'customer'`
    ).get();

    const profit = (revenue.total_revenue || 0) - (expenses.total_expenses || 0);

    res.json({
      success: true,
      data: {
        period: new Date().toISOString().slice(0, 7),
        orders: {
          total: orders.total_orders,
          delivered: orders.delivered_orders,
          cancelled: orders.cancelled_orders,
        },
        revenue: revenue.total_revenue,
        expenses: expenses.total_expenses,
        profit,
        new_customers: newCustomers.count,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/yearly', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const orders = db.prepare(
      `SELECT COUNT(*) as total_orders,
              COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders,
              COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders
       FROM orders
       WHERE strftime('%Y', created_at) = strftime('%Y', 'now') AND deleted_at IS NULL`
    ).get();

    const revenue = db.prepare(
      `SELECT COALESCE(SUM(total), 0) as total_revenue
       FROM orders
       WHERE strftime('%Y', created_at) = strftime('%Y', 'now')
         AND payment_status = 'paid' AND deleted_at IS NULL`
    ).get();

    const expenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total_expenses
       FROM expenses
       WHERE strftime('%Y', date) = strftime('%Y', 'now') AND deleted_at IS NULL`
    ).get();

    const monthlyBreakdown = db.prepare(
      `SELECT strftime('%Y-%m', created_at) as month,
              COUNT(*) as orders,
              COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END), 0) as revenue
       FROM orders
       WHERE strftime('%Y', created_at) = strftime('%Y', 'now') AND deleted_at IS NULL
       GROUP BY strftime('%Y-%m', created_at)
       ORDER BY month ASC`
    ).all();

    const profit = (revenue.total_revenue || 0) - (expenses.total_expenses || 0);

    res.json({
      success: true,
      data: {
        period: new Date().getFullYear().toString(),
        orders: {
          total: orders.total_orders,
          delivered: orders.delivered_orders,
          cancelled: orders.cancelled_orders,
        },
        revenue: revenue.total_revenue,
        expenses: expenses.total_expenses,
        profit,
        monthly_breakdown: monthlyBreakdown,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/top-products', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.cost_price,
              c.name as category_name, b.name as brand_name,
              COALESCE(s.total_sold, 0) as total_sold,
              COALESCE(s.total_revenue, 0) as total_revenue
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN (
         SELECT product_id, SUM(quantity) as total_sold, SUM(total) as total_revenue
         FROM order_items
         GROUP BY product_id
       ) s ON s.product_id = p.id
       WHERE p.deleted_at IS NULL
       ORDER BY total_sold DESC
       LIMIT 10`
    ).all();

    res.json({
      success: true,
      data: { items: products },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/top-customers', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const customers = db.prepare(
      `SELECT u.id, u.first_name, u.last_name, u.email, u.phone,
              u.loyalty_points, u.wallet_balance,
              COUNT(o.id) as order_count,
              COALESCE(SUM(CASE WHEN o.payment_status = 'paid' THEN o.total ELSE 0 END), 0) as total_spent
       FROM users u
       LEFT JOIN orders o ON u.id = o.user_id AND o.deleted_at IS NULL
       WHERE u.role = 'customer' AND u.deleted_at IS NULL
       GROUP BY u.id
       ORDER BY total_spent DESC
       LIMIT 10`
    ).all();

    res.json({
      success: true,
      data: { items: customers },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/reports/profit', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const period = req.query.period || 'monthly';

    let groupBy;
    let dateFormat;
    let dateColumn;

    switch (period) {
      case 'daily':
        groupBy = 'date(o.created_at)';
        dateFormat = "date(o.created_at) as period";
        dateColumn = 'date(o.created_at)';
        break;
      case 'weekly':
        groupBy = "strftime('%Y-W%W', o.created_at)";
        dateFormat = "strftime('%Y-W%W', o.created_at) as period";
        dateColumn = "strftime('%Y-W%W', o.created_at)";
        break;
      case 'yearly':
        groupBy = "strftime('%Y', o.created_at)";
        dateFormat = "strftime('%Y', o.created_at) as period";
        dateColumn = "strftime('%Y', o.created_at)";
        break;
      default:
        groupBy = "strftime('%Y-%m', o.created_at)";
        dateFormat = "strftime('%Y-%m', o.created_at) as period";
        dateColumn = "strftime('%Y-%m', o.created_at)";
    }

    const revenueData = db.prepare(
      `SELECT ${dateFormat},
              COALESCE(SUM(CASE WHEN o.payment_status = 'paid' THEN o.total ELSE 0 END), 0) as revenue
       FROM orders o
       WHERE o.deleted_at IS NULL
       GROUP BY ${groupBy}
       ORDER BY period ASC`
    ).all();

    const expenseData = db.prepare(
      `SELECT ${dateFormat.replace('o.created_at', 'e.date')},
              COALESCE(SUM(e.amount), 0) as expenses
       FROM expenses e
       WHERE e.deleted_at IS NULL
       GROUP BY ${groupBy.replace('o.created_at', 'e.date')}
       ORDER BY period ASC`
    ).all();

    const expenseMap = {};
    for (const row of expenseData) {
      expenseMap[row.period] = row.expenses;
    }

    const combined = revenueData.map(row => ({
      period: row.period,
      revenue: row.revenue,
      expenses: expenseMap[row.period] || 0,
      profit: row.revenue - (expenseMap[row.period] || 0),
    }));

    const totalRevenue = combined.reduce((sum, r) => sum + r.revenue, 0);
    const totalExpenses = combined.reduce((sum, r) => sum + r.expenses, 0);

    res.json({
      success: true,
      data: {
        period,
        items: combined,
        summary: {
          total_revenue: totalRevenue,
          total_expenses: totalExpenses,
          total_profit: totalRevenue - totalExpenses,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 12. CUSTOMERS
// ============================================================================

router.get('/customers', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ["u.role = 'customer'", 'u.deleted_at IS NULL'];
    let params = [];

    if (req.query.search) {
      where.push("(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)");
      const term = `%${req.query.search}%`;
      params.push(term, term, term, term);
    }

    if (req.query.is_active !== undefined) {
      where.push('u.is_active = ?');
      params.push(parseInt(req.query.is_active));
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM users u ${whereClause}`
    ).get(...params);

    const customers = db.prepare(
      `SELECT u.id, u.uuid, u.email, u.phone, u.first_name, u.last_name,
              u.avatar, u.is_active, u.email_verified, u.loyalty_points,
              u.wallet_balance, u.created_at, u.updated_at,
              (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND deleted_at IS NULL) as order_count,
              (SELECT COALESCE(SUM(total), 0) FROM orders WHERE user_id = u.id AND payment_status = 'paid' AND deleted_at IS NULL) as total_spent
       FROM users u
       ${whereClause}
       ORDER BY u.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: customers,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/customers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);

    const customer = db.prepare(
      `SELECT u.id, u.uuid, u.email, u.phone, u.first_name, u.last_name,
              u.avatar, u.is_active, u.email_verified, u.phone_verified,
              u.loyalty_points, u.wallet_balance, u.referral_code,
              u.created_at, u.updated_at,
              (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND deleted_at IS NULL) as order_count,
              (SELECT COALESCE(SUM(total), 0) FROM orders WHERE user_id = u.id AND payment_status = 'paid' AND deleted_at IS NULL) as total_spent,
              (SELECT COUNT(*) FROM wishlists WHERE user_id = u.id) as wishlist_count
       FROM users u
       WHERE u.id = ? AND u.role = 'customer'`
    ).get(customerId);

    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    const addresses = db.prepare(
      'SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC'
    ).all(customerId);

    const recentOrders = db.prepare(
      `SELECT id, order_number, status, total, payment_status, payment_method, created_at
       FROM orders WHERE user_id = ? AND deleted_at IS NULL
       ORDER BY created_at DESC LIMIT 10`
    ).all(customerId);

    res.json({
      success: true,
      data: {
        customer: {
          ...customer,
          addresses,
          recent_orders: recentOrders,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/customers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);

    const existing = db.prepare(
      "SELECT * FROM users WHERE id = ? AND role = 'customer' AND deleted_at IS NULL"
    ).get(customerId);

    if (!existing) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    const { is_active, is_blocked, loyalty_points, wallet_balance, first_name, last_name, phone } = req.body;

    db.prepare(
      `UPDATE users SET
        first_name = ?, last_name = ?, phone = ?,
        is_active = ?, loyalty_points = ?, wallet_balance = ?,
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      first_name !== undefined ? first_name : existing.first_name,
      last_name !== undefined ? last_name : existing.last_name,
      phone !== undefined ? phone : existing.phone,
      is_active !== undefined ? (is_blocked ? 0 : is_active) : existing.is_active,
      loyalty_points !== undefined ? loyalty_points : existing.loyalty_points,
      wallet_balance !== undefined ? wallet_balance : existing.wallet_balance,
      customerId
    );

    const customer = db.prepare(
      `SELECT id, uuid, email, phone, first_name, last_name, avatar,
              is_active, loyalty_points, wallet_balance, created_at, updated_at
       FROM users WHERE id = ?`
    ).get(customerId);

    res.json({
      success: true,
      data: { customer },
      message: 'Customer updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 13. MARKETING - COUPONS & CAMPAIGNS
// ============================================================================

router.get('/marketing/coupons', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const coupons = db.prepare(
      `SELECT * FROM coupons WHERE deleted_at IS NULL ORDER BY created_at DESC`
    ).all();

    res.json({
      success: true,
      data: { items: coupons },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/marketing/coupons', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const {
      code, type, value, minimum_order, maximum_discount,
      usage_limit, starts_at, expires_at, is_active,
      applies_to, applies_to_ids,
    } = req.body;

    if (!code || !type || value === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Code, type, and value are required',
      });
    }

    const validTypes = ['percentage', 'fixed', 'free_shipping'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({
        success: false,
        message: `Invalid type. Must be one of: ${validTypes.join(', ')}`,
      });
    }

    const existingCode = db.prepare('SELECT id FROM coupons WHERE code = ? AND deleted_at IS NULL').get(code);
    if (existingCode) {
      return res.status(400).json({ success: false, message: 'A coupon with this code already exists' });
    }

    const result = db.prepare(
      `INSERT INTO coupons (uuid, code, type, value, minimum_order, maximum_discount,
                           usage_limit, starts_at, expires_at, is_active,
                           applies_to, applies_to_ids, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      uuid(), code.toUpperCase(), type, value,
      minimum_order || 0, maximum_discount || null,
      usage_limit || null, starts_at || null, expires_at || null,
      is_active !== undefined ? is_active : 1,
      applies_to || 'all', applies_to_ids || null
    );

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { coupon },
      message: 'Coupon created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/marketing/coupons/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const couponId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM coupons WHERE id = ? AND deleted_at IS NULL').get(couponId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Coupon not found' });
    }

    const {
      code, type, value, minimum_order, maximum_discount,
      usage_limit, starts_at, expires_at, is_active,
      applies_to, applies_to_ids,
    } = req.body;

    if (code && code.toUpperCase() !== existing.code) {
      const codeConflict = db.prepare(
        'SELECT id FROM coupons WHERE code = ? AND id != ? AND deleted_at IS NULL'
      ).get(code.toUpperCase(), couponId);
      if (codeConflict) {
        return res.status(400).json({ success: false, message: 'A coupon with this code already exists' });
      }
    }

    db.prepare(
      `UPDATE coupons SET
        code = ?, type = ?, value = ?, minimum_order = ?, maximum_discount = ?,
        usage_limit = ?, starts_at = ?, expires_at = ?, is_active = ?,
        applies_to = ?, applies_to_ids = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      code ? code.toUpperCase() : existing.code,
      type || existing.type,
      value !== undefined ? value : existing.value,
      minimum_order !== undefined ? minimum_order : existing.minimum_order,
      maximum_discount !== undefined ? maximum_discount : existing.maximum_discount,
      usage_limit !== undefined ? usage_limit : existing.usage_limit,
      starts_at !== undefined ? starts_at : existing.starts_at,
      expires_at !== undefined ? expires_at : existing.expires_at,
      is_active !== undefined ? is_active : existing.is_active,
      applies_to || existing.applies_to,
      applies_to_ids !== undefined ? applies_to_ids : existing.applies_to_ids,
      couponId
    );

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(couponId);

    res.json({
      success: true,
      data: { coupon },
      message: 'Coupon updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/marketing/coupons/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const couponId = parseInt(req.params.id);

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ? AND deleted_at IS NULL').get(couponId);
    if (!coupon) {
      return res.status(404).json({ success: false, message: 'Coupon not found' });
    }

    db.prepare(
      `UPDATE coupons SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(couponId);

    res.json({
      success: true,
      message: 'Coupon deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/marketing/campaigns', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const campaigns = db.prepare(
      `SELECT * FROM campaigns ORDER BY created_at DESC`
    ).all();

    res.json({
      success: true,
      data: { items: campaigns },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/marketing/campaigns', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, type, subject, content, status, scheduled_at } = req.body;

    if (!name || !type || !content) {
      return res.status(400).json({
        success: false,
        message: 'Name, type, and content are required',
      });
    }

    const validTypes = ['email', 'sms', 'push'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({
        success: false,
        message: `Invalid type. Must be one of: ${validTypes.join(', ')}`,
      });
    }

    const result = db.prepare(
      `INSERT INTO campaigns (name, type, subject, content, status, scheduled_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`
    ).run(name, type, subject || null, content, status || 'draft', scheduled_at || null);

    const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { campaign },
      message: 'Campaign created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 14. SETTINGS
// ============================================================================

router.get('/settings', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const allSettings = db.prepare(
      `SELECT * FROM settings ORDER BY group_name, key`
    ).all();

    const grouped = {};
    for (const setting of allSettings) {
      if (!grouped[setting.group_name]) {
        grouped[setting.group_name] = [];
      }
      grouped[setting.group_name].push(setting);
    }

    res.json({
      success: true,
      data: { settings: grouped },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/settings', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { settings } = req.body;

    if (!settings || !Array.isArray(settings) || settings.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Settings array is required',
      });
    }

    const upsertStmt = db.prepare(
      `INSERT INTO settings (key, value, group_name, updated_at)
       VALUES (?, ?, COALESCE((SELECT group_name FROM settings WHERE key = ?), 'general'), datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
    );

    const transaction = db.transaction(() => {
      for (const setting of settings) {
        if (!setting.key || setting.value === undefined) {
          continue;
        }
        const valueStr = typeof setting.value === 'string' ? setting.value : JSON.stringify(setting.value);
        upsertStmt.run(setting.key, valueStr, setting.key);
      }
    });

    transaction();

    res.json({
      success: true,
      message: `${settings.length} settings updated successfully`,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 15. SECURITY - AUDIT LOGS & LOGIN HISTORY
// ============================================================================

router.get('/security/audit-logs', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.user_id) {
      where.push('al.user_id = ?');
      params.push(parseInt(req.query.user_id));
    }

    if (req.query.action) {
      where.push('al.action = ?');
      params.push(req.query.action);
    }

    if (req.query.entity) {
      where.push('al.entity = ?');
      params.push(req.query.entity);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM audit_logs al ${whereClause}`
    ).get(...params);

    const logs = db.prepare(
      `SELECT al.*,
              u.first_name || ' ' || u.last_name as user_name,
              u.email as user_email
       FROM audit_logs al
       LEFT JOIN users u ON al.user_id = u.id
       ${whereClause}
       ORDER BY al.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: logs,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/security/login-history', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.user_id) {
      where.push('lh.user_id = ?');
      params.push(parseInt(req.query.user_id));
    }

    if (req.query.status) {
      where.push('lh.status = ?');
      params.push(req.query.status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM login_history lh ${whereClause}`
    ).get(...params);

    const logs = db.prepare(
      `SELECT lh.*,
              u.first_name || ' ' || u.last_name as user_name,
              u.email as user_email
       FROM login_history lh
       JOIN users u ON lh.user_id = u.id
       ${whereClause}
       ORDER BY lh.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: logs,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 16. NOTIFICATIONS
// ============================================================================

router.get('/notifications', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.user_id) {
      where.push('n.user_id = ?');
      params.push(parseInt(req.query.user_id));
    }

    if (req.query.type) {
      where.push('n.type = ?');
      params.push(req.query.type);
    }

    if (req.query.is_read !== undefined) {
      where.push('n.is_read = ?');
      params.push(parseInt(req.query.is_read));
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM notifications n ${whereClause}`
    ).get(...params);

    const notifications = db.prepare(
      `SELECT n.*,
              u.first_name || ' ' || u.last_name as user_name,
              u.email as user_email
       FROM notifications n
       JOIN users u ON n.user_id = u.id
       ${whereClause}
       ORDER BY n.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: notifications,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/notifications', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { user_id, user_ids, title, message, type, data } = req.body;

    if (!title || !message) {
      return res.status(400).json({
        success: false,
        message: 'Title and message are required',
      });
    }

    const targetUserIds = user_ids || (user_id ? [user_id] : []);

    if (targetUserIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'At least one user_id or user_ids array is required',
      });
    }

    const validTypes = ['info', 'order', 'promo', 'admin', 'system'];
    const notificationType = type || 'info';

    const insertStmt = db.prepare(
      `INSERT INTO notifications (user_id, title, message, type, data, created_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))`
    );

    const transaction = db.transaction(() => {
      let count = 0;
      for (const uid of targetUserIds) {
        const user = db.prepare('SELECT id FROM users WHERE id = ?').get(uid);
        if (user) {
          insertStmt.run(uid, title, message, notificationType, data || null);
          count++;
        }
      }
      return count;
    });

    const sentCount = transaction();

    res.status(201).json({
      success: true,
      message: `Notification sent to ${sentCount} user(s)`,
      data: { sent_count: sentCount },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 17. FAQS
// ============================================================================

router.get('/faqs', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const faqs = db.prepare(
      `SELECT * FROM faqs ORDER BY sort_order ASC, created_at DESC`
    ).all();

    res.json({
      success: true,
      data: { items: faqs },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/faqs', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { question, answer, category, sort_order, is_active } = req.body;

    if (!question || !answer) {
      return res.status(400).json({ success: false, message: 'Question and answer are required' });
    }

    const result = db.prepare(
      `INSERT INTO faqs (question, answer, category, sort_order, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))`
    ).run(
      question, answer, category || null,
      sort_order || 0, is_active !== undefined ? is_active : 1
    );

    const faq = db.prepare('SELECT * FROM faqs WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { faq },
      message: 'FAQ created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/faqs/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const faqId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM faqs WHERE id = ?').get(faqId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'FAQ not found' });
    }

    const { question, answer, category, sort_order, is_active } = req.body;

    db.prepare(
      `UPDATE faqs SET
        question = ?, answer = ?, category = ?, sort_order = ?, is_active = ?
       WHERE id = ?`
    ).run(
      question || existing.question,
      answer || existing.answer,
      category !== undefined ? category : existing.category,
      sort_order !== undefined ? sort_order : existing.sort_order,
      is_active !== undefined ? is_active : existing.is_active,
      faqId
    );

    const faq = db.prepare('SELECT * FROM faqs WHERE id = ?').get(faqId);

    res.json({
      success: true,
      data: { faq },
      message: 'FAQ updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/faqs/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const faqId = parseInt(req.params.id);

    const faq = db.prepare('SELECT * FROM faqs WHERE id = ?').get(faqId);
    if (!faq) {
      return res.status(404).json({ success: false, message: 'FAQ not found' });
    }

    db.prepare('DELETE FROM faqs WHERE id = ?').run(faqId);

    res.json({
      success: true,
      message: 'FAQ deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 18. PAGES (CMS)
// ============================================================================

router.get('/pages', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const pages = db.prepare(
      `SELECT * FROM pages ORDER BY created_at DESC`
    ).all();

    res.json({
      success: true,
      data: { items: pages },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/pages', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { title, slug, content, meta_title, meta_description, is_published } = req.body;

    if (!title) {
      return res.status(400).json({ success: false, message: 'Title is required' });
    }

    const finalSlug = slug || slugify(title);

    const existingSlug = db.prepare('SELECT id FROM pages WHERE slug = ?').get(finalSlug);
    if (existingSlug) {
      return res.status(400).json({ success: false, message: 'A page with this slug already exists' });
    }

    const result = db.prepare(
      `INSERT INTO pages (title, slug, content, meta_title, meta_description, is_published, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      title, finalSlug, content || null,
      meta_title || null, meta_description || null,
      is_published !== undefined ? is_published : 0
    );

    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { page },
      message: 'Page created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/pages/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const pageId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM pages WHERE id = ?').get(pageId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Page not found' });
    }

    const { title, slug, content, meta_title, meta_description, is_published } = req.body;

    if (slug && slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM pages WHERE slug = ? AND id != ?').get(slug, pageId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A page with this slug already exists' });
      }
    }

    db.prepare(
      `UPDATE pages SET
        title = ?, slug = ?, content = ?, meta_title = ?, meta_description = ?,
        is_published = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      title || existing.title,
      slug || existing.slug,
      content !== undefined ? content : existing.content,
      meta_title !== undefined ? meta_title : existing.meta_title,
      meta_description !== undefined ? meta_description : existing.meta_description,
      is_published !== undefined ? is_published : existing.is_published,
      pageId
    );

    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(pageId);

    res.json({
      success: true,
      data: { page },
      message: 'Page updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/pages/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const pageId = parseInt(req.params.id);

    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(pageId);
    if (!page) {
      return res.status(404).json({ success: false, message: 'Page not found' });
    }

    db.prepare('DELETE FROM pages WHERE id = ?').run(pageId);

    res.json({
      success: true,
      message: 'Page deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 19. REVIEWS
// ============================================================================

router.get('/reviews', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['pr.deleted_at IS NULL'];
    let params = [];

    if (req.query.is_approved !== undefined) {
      where.push('pr.is_approved = ?');
      params.push(parseInt(req.query.is_approved));
    }

    if (req.query.product_id) {
      where.push('pr.product_id = ?');
      params.push(parseInt(req.query.product_id));
    }

    if (req.query.rating) {
      where.push('pr.rating = ?');
      params.push(parseInt(req.query.rating));
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM product_reviews pr ${whereClause}`
    ).get(...params);

    const reviews = db.prepare(
      `SELECT pr.*,
              u.first_name || ' ' || u.last_name as user_name,
              u.email as user_email,
              p.name as product_name,
              p.slug as product_slug
       FROM product_reviews pr
       JOIN users u ON pr.user_id = u.id
       JOIN products p ON pr.product_id = p.id
       ${whereClause}
       ORDER BY pr.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: reviews,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/reviews/:id/approve', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const reviewId = parseInt(req.params.id);

    const review = db.prepare(
      'SELECT * FROM product_reviews WHERE id = ? AND deleted_at IS NULL'
    ).get(reviewId);

    if (!review) {
      return res.status(404).json({ success: false, message: 'Review not found' });
    }

    const status = req.body.status || 'approved';
    const isApproved = status === 'approved' ? 1 : 0;

    db.prepare(
      `UPDATE product_reviews SET is_approved = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(isApproved, reviewId);

    const updated = db.prepare('SELECT * FROM product_reviews WHERE id = ?').get(reviewId);

    res.json({
      success: true,
      data: { review: updated },
      message: isApproved ? 'Review approved successfully' : 'Review rejected successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/reviews/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const reviewId = parseInt(req.params.id);

    const review = db.prepare(
      'SELECT * FROM product_reviews WHERE id = ? AND deleted_at IS NULL'
    ).get(reviewId);

    if (!review) {
      return res.status(404).json({ success: false, message: 'Review not found' });
    }

    db.prepare(
      `UPDATE product_reviews SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(reviewId);

    res.json({
      success: true,
      message: 'Review deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 20. CONTACT MESSAGES
// ============================================================================

router.get('/contact-messages', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.status) {
      where.push('status = ?');
      params.push(req.query.status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM contact_messages ${whereClause}`
    ).get(...params);

    const messages = db.prepare(
      `SELECT * FROM contact_messages ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        items: messages,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/contact-messages/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const messageId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM contact_messages WHERE id = ?').get(messageId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Contact message not found' });
    }

    const { status } = req.body;

    const validStatuses = ['new', 'read', 'replied'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
      });
    }

    db.prepare(
      `UPDATE contact_messages SET status = ? WHERE id = ?`
    ).run(status || existing.status, messageId);

    const message = db.prepare('SELECT * FROM contact_messages WHERE id = ?').get(messageId);

    res.json({
      success: true,
      data: { message },
      message: 'Contact message updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// 21. COURIERS
// ============================================================================

router.get('/couriers', adminAuth, async (req, res) => {
  try {
    const db = getDb();

    const couriers = db.prepare(
      `SELECT c.*,
              (SELECT COUNT(*) FROM orders WHERE courier_id = c.id AND deleted_at IS NULL) as order_count
       FROM couriers c
       ORDER BY c.name ASC`
    ).all();

    res.json({
      success: true,
      data: { items: couriers },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/couriers', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, slug, api_key, api_secret, api_url, config, is_active } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Name is required' });
    }

    const finalSlug = slug || slugify(name);

    const existingSlug = db.prepare('SELECT id FROM couriers WHERE slug = ?').get(finalSlug);
    if (existingSlug) {
      return res.status(400).json({ success: false, message: 'A courier with this slug already exists' });
    }

    const result = db.prepare(
      `INSERT INTO couriers (name, slug, api_key, api_secret, api_url, config, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      name, finalSlug, api_key || null, api_secret || null,
      api_url || null, config || null, is_active !== undefined ? is_active : 1
    );

    const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: { courier },
      message: 'Courier created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/couriers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const courierId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Courier not found' });
    }

    const { name, slug, api_key, api_secret, api_url, config, is_active } = req.body;

    if (slug && slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM couriers WHERE slug = ? AND id != ?').get(slug, courierId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A courier with this slug already exists' });
      }
    }

    db.prepare(
      `UPDATE couriers SET
        name = ?, slug = ?, api_key = ?, api_secret = ?,
        api_url = ?, config = ?, is_active = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      slug || existing.slug,
      api_key !== undefined ? api_key : existing.api_key,
      api_secret !== undefined ? api_secret : existing.api_secret,
      api_url !== undefined ? api_url : existing.api_url,
      config !== undefined ? config : existing.config,
      is_active !== undefined ? is_active : existing.is_active,
      courierId
    );

    const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);

    res.json({
      success: true,
      data: { courier },
      message: 'Courier updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// MISSING ENDPOINTS - ADDED FOR FULL ADMIN PANEL FUNCTIONALITY
// ============================================================================

// --- Warehouses: PUT and DELETE ---
router.put('/warehouses/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const whId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(whId);
    if (!existing) return res.status(404).json({ success: false, message: 'Warehouse not found' });

    const { name, address, phone, is_active } = req.body;
    db.prepare(
      `UPDATE warehouses SET name = ?, address = ?, phone = ?, is_active = ? WHERE id = ?`
    ).run(name || existing.name, address !== undefined ? address : existing.address, phone !== undefined ? phone : existing.phone, is_active !== undefined ? is_active : existing.is_active, whId);

    const warehouse = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(whId);
    res.json({ success: true, data: { warehouse }, message: 'Warehouse updated' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/warehouses/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const whId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM warehouses WHERE id = ?').get(whId);
    if (!existing) return res.status(404).json({ success: false, message: 'Warehouse not found' });
    db.prepare('DELETE FROM warehouses WHERE id = ?').run(whId);
    res.json({ success: true, message: 'Warehouse deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Orders: DELETE ---
router.delete('/orders/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const orderId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM orders WHERE id = ? AND deleted_at IS NULL').get(orderId);
    if (!existing) return res.status(404).json({ success: false, message: 'Order not found' });
    db.prepare(`UPDATE orders SET deleted_at = datetime('now') WHERE id = ?`).run(orderId);
    res.json({ success: true, message: 'Order deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Couriers: DELETE ---
router.delete('/couriers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const courierId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId);
    if (!existing) return res.status(404).json({ success: false, message: 'Courier not found' });
    db.prepare('DELETE FROM couriers WHERE id = ?').run(courierId);
    res.json({ success: true, message: 'Courier deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Contact Messages: GET single, DELETE, PUT read ---
router.get('/contact-messages/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const msgId = parseInt(req.params.id);
    const msg = db.prepare('SELECT * FROM contact_messages WHERE id = ?').get(msgId);
    if (!msg) return res.status(404).json({ success: false, message: 'Message not found' });
    res.json({ success: true, data: { message: msg } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.put('/contact-messages/:id/read', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const msgId = parseInt(req.params.id);
    db.prepare(`UPDATE contact_messages SET is_read = 1, status = 'read' WHERE id = ?`).run(msgId);
    res.json({ success: true, message: 'Marked as read' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/contact-messages/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const msgId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM contact_messages WHERE id = ?').get(msgId);
    if (!existing) return res.status(404).json({ success: false, message: 'Message not found' });
    db.prepare('DELETE FROM contact_messages WHERE id = ?').run(msgId);
    res.json({ success: true, message: 'Message deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Finance: Expenses DELETE ---
router.delete('/finance/expenses/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const expId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM expenses WHERE id = ? AND deleted_at IS NULL').get(expId);
    if (!existing) return res.status(404).json({ success: false, message: 'Expense not found' });
    db.prepare(`UPDATE expenses SET deleted_at = datetime('now') WHERE id = ?`).run(expId);
    res.json({ success: true, message: 'Expense deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Finance: Income (read-only from orders) ---
router.get('/finance/income', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const income = db.prepare(
      `SELECT o.id, o.order_number as reference, o.total as amount, o.payment_method, o.created_at as date,
              'Order Payment' as source,
              u.first_name || ' ' || u.last_name as customer_name
       FROM orders o
       LEFT JOIN users u ON o.user_id = u.id
       WHERE o.payment_status = 'paid' AND o.deleted_at IS NULL
       ORDER BY o.created_at DESC
       LIMIT 100`
    ).all();
    res.json({ success: true, data: { items: income } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Finance: Supplier Payments ---
router.get('/finance/supplier-payments', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let payments = [];
    try {
      payments = db.prepare(
        `SELECT sp.*, s.name as supplier_name
         FROM supplier_payments sp
         LEFT JOIN suppliers s ON sp.supplier_id = s.id
         ORDER BY sp.created_at DESC LIMIT 100`
      ).all();
    } catch (e) {
      payments = [];
    }
    res.json({ success: true, data: { items: payments } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/finance/supplier-payments', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { supplier, amount, paymentMethod, date, notes } = req.body;
    if (!supplier || !amount) return res.status(400).json({ success: false, message: 'Supplier and amount required' });

    try {
      db.prepare(
        `INSERT INTO supplier_payments (supplier_id, amount, payment_method, date, notes, created_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`
      ).run(parseInt(supplier), amount, paymentMethod || 'cash', date || new Date().toISOString().split('T')[0], notes || null, req.user.id);
    } catch (e) {
      // Table might not exist, just return success for now
    }
    res.status(201).json({ success: true, message: 'Payment recorded' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Finance: Salary ---
router.get('/finance/salary', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let salaries = [];
    try {
      salaries = db.prepare(`SELECT * FROM salaries ORDER BY created_at DESC LIMIT 100`).all();
    } catch (e) {
      salaries = [];
    }
    res.json({ success: true, data: { items: salaries } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/finance/salary', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { employeeName, amount, month, status } = req.body;
    if (!employeeName || !amount) return res.status(400).json({ success: false, message: 'Employee name and amount required' });

    try {
      db.prepare(
        `INSERT INTO salaries (employee_name, amount, month, status, created_at)
         VALUES (?, ?, ?, ?, datetime('now'))`
      ).run(employeeName, amount, month || null, status || 'pending');
    } catch (e) {
      // Table might not exist
    }
    res.status(201).json({ success: true, message: 'Salary record added' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Marketing: Discounts ---
router.get('/marketing/discounts', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let discounts = [];
    try {
      discounts = db.prepare(`SELECT * FROM discounts WHERE deleted_at IS NULL ORDER BY created_at DESC`).all();
    } catch (e) {
      discounts = [];
    }
    res.json({ success: true, data: { items: discounts } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/marketing/discounts', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, type, value, startDate, endDate, isActive } = req.body;
    if (!name || !value) return res.status(400).json({ success: false, message: 'Name and value required' });

    try {
      db.prepare(
        `INSERT INTO discounts (name, type, value, start_date, end_date, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
      ).run(name, type || 'fixed', value, startDate || null, endDate || null, isActive !== false ? 1 : 0);
    } catch (e) {
      // Table might not exist
    }
    res.status(201).json({ success: true, message: 'Discount created' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/marketing/discounts/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const discountId = parseInt(req.params.id);
    try {
      const existing = db.prepare('SELECT * FROM discounts WHERE id = ?').get(discountId);
      if (existing) {
        db.prepare(`UPDATE discounts SET deleted_at = datetime('now') WHERE id = ?`).run(discountId);
      }
    } catch (e) {}
    res.json({ success: true, message: 'Discount deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Marketing: Campaigns DELETE ---
router.delete('/marketing/campaigns/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const campId = parseInt(req.params.id);
    try {
      db.prepare(`UPDATE campaigns SET deleted_at = datetime('now') WHERE id = ?`).run(campId);
    } catch (e) {
      try { db.prepare('DELETE FROM campaigns WHERE id = ?').run(campId); } catch (e2) {}
    }
    res.json({ success: true, message: 'Campaign deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Dashboard: Revenue by period ---
router.get('/dashboard/revenue', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const period = parseInt(req.query.period) || 7;

    const revenue = db.prepare(
      `SELECT date(created_at) as date, COALESCE(SUM(total), 0) as revenue
       FROM orders
       WHERE date(created_at) >= date('now', '-' || ? || ' days') AND payment_status = 'paid' AND deleted_at IS NULL
       GROUP BY date(created_at)
       ORDER BY date ASC`
    ).all(period);

    const labels = revenue.map(r => r.date);
    const data = revenue.map(r => r.revenue);

    res.json({ success: true, data: { labels, data } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Settings: Enhanced PUT with group_name ---
router.put('/settings', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { settings, group } = req.body;

    if (!settings || !Array.isArray(settings) || settings.length === 0) {
      return res.status(400).json({ success: false, message: 'Settings array is required' });
    }

    const groupName = group || 'general';

    const upsertStmt = db.prepare(
      `INSERT INTO settings (key, value, group_name, updated_at)
       VALUES (?, ?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
    );

    const transaction = db.transaction(() => {
      for (const setting of settings) {
        if (!setting.key || setting.value === undefined) continue;
        const valueStr = typeof setting.value === 'string' ? setting.value : JSON.stringify(setting.value);
        upsertStmt.run(setting.key, valueStr, groupName);
      }
    });

    transaction();
    res.json({ success: true, message: 'Settings updated' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// --- Notifications: send with userId/userId support ---
router.post('/notifications/send', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { userId, user_id, user_ids, title, message, type } = req.body;

    if (!title || !message) {
      return res.status(400).json({ success: false, message: 'Title and message are required' });
    }

    const targetUserIds = user_ids || (user_id ? [user_id] : (userId === 'all' ? [] : (userId ? [userId] : [])));

    if (userId === 'all' || targetUserIds.length === 0) {
      // Send to all users
      const allUsers = db.prepare(`SELECT id FROM users WHERE role = 'customer'`).all();
      const insertStmt = db.prepare(
        `INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (?, ?, ?, ?, datetime('now'))`
      );
      const tx = db.transaction(() => {
        for (const u of allUsers) {
          insertStmt.run(u.id, title, message, type || 'info');
        }
      });
      tx();
      res.status(201).json({ success: true, message: `Notification sent to ${allUsers.length} users` });
    } else {
      const insertStmt = db.prepare(
        `INSERT INTO notifications (user_id, title, message, type, created_at) VALUES (?, ?, ?, ?, datetime('now'))`
      );
      let count = 0;
      for (const uid of targetUserIds) {
        try { insertStmt.run(parseInt(uid), title, message, type || 'info'); count++; } catch (e) {}
      }
      res.status(201).json({ success: true, message: `Notification sent to ${count} user(s)` });
    }
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// BULK OPERATIONS
// ============================================================================

router.post('/orders/bulk-courier', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const { orderIds, courierId } = req.body;

    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
      return res.status(400).json({ success: false, message: 'Order IDs array is required' });
    }

    if (!courierId) {
      return res.status(400).json({ success: false, message: 'Courier ID is required' });
    }

    const courier = db.prepare('SELECT id FROM couriers WHERE id = ?').get(courierId);
    if (!courier) {
      return res.status(404).json({ success: false, message: 'Courier not found' });
    }

    const placeholders = orderIds.map(() => '?').join(',');
    const orders = db.prepare(
      `SELECT id FROM orders WHERE id IN (${placeholders}) AND deleted_at IS NULL`
    ).all(...orderIds);

    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: 'No valid orders found' });
    }

    const foundIds = orders.map(o => o.id);

    const transaction = db.transaction(() => {
      const stmt = db.prepare(
        `UPDATE orders SET courier_id = ?, updated_at = datetime('now') WHERE id = ?`
      );
      for (const id of foundIds) {
        stmt.run(courierId, id);
      }
    });

    transaction();

    res.json({
      success: true,
      message: `Courier assigned to ${foundIds.length} orders`,
      data: { updated_count: foundIds.length, updated_ids: foundIds },
    });
  } catch (err) { next(err); }
});

// ============================================================================
// CUSTOMER VIP/BLACKLIST
// ============================================================================

router.put('/customers/:id/vip', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);
    const { isVip } = req.body;

    const customer = db.prepare(
      "SELECT id FROM users WHERE id = ? AND role = 'customer' AND deleted_at IS NULL"
    ).get(customerId);
    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    db.prepare(
      `UPDATE users SET is_vip = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(isVip ? 1 : 0, customerId);

    const updated = db.prepare(
      'SELECT id, uuid, first_name, last_name, email, is_vip FROM users WHERE id = ?'
    ).get(customerId);

    res.json({
      success: true,
      data: { customer: updated },
      message: isVip ? 'Customer marked as VIP' : 'VIP status removed',
    });
  } catch (err) { next(err); }
});

router.put('/customers/:id/blacklist', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);
    const { isBlacklisted, reason } = req.body;

    const customer = db.prepare(
      "SELECT id FROM users WHERE id = ? AND role = 'customer' AND deleted_at IS NULL"
    ).get(customerId);
    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    db.prepare(
      `UPDATE users SET is_blacklisted = ?, blacklist_reason = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(isBlacklisted ? 1 : 0, reason || null, customerId);

    const updated = db.prepare(
      'SELECT id, uuid, first_name, last_name, email, is_blacklisted, blacklist_reason FROM users WHERE id = ?'
    ).get(customerId);

    res.json({
      success: true,
      data: { customer: updated },
      message: isBlacklisted ? 'Customer blacklisted' : 'Blacklist status removed',
    });
  } catch (err) { next(err); }
});

router.get('/customers/:id/history', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);

    const customer = db.prepare(
      "SELECT id FROM users WHERE id = ? AND role = 'customer' AND deleted_at IS NULL"
    ).get(customerId);
    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    const orders = db.prepare(
      `SELECT id, order_number, status, total, payment_status, payment_method, created_at
       FROM orders WHERE user_id = ? AND deleted_at IS NULL
       ORDER BY created_at DESC`
    ).all(customerId);

    const reviews = db.prepare(
      `SELECT pr.id, pr.rating, pr.title, pr.comment, pr.is_approved, pr.created_at,
              p.name as product_name, p.slug as product_slug
       FROM product_reviews pr
       JOIN products p ON pr.product_id = p.id
       WHERE pr.user_id = ? AND pr.deleted_at IS NULL
       ORDER BY pr.created_at DESC`
    ).all(customerId);

    const wishlist = db.prepare(
      `SELECT w.id, w.created_at,
              p.id as product_id, p.name as product_name, p.slug as product_slug, p.price
       FROM wishlists w
       JOIN products p ON w.product_id = p.id
       WHERE w.user_id = ?
       ORDER BY w.created_at DESC`
    ).all(customerId);

    res.json({
      success: true,
      data: { orders, reviews, wishlist },
    });
  } catch (err) { next(err); }
});

router.get('/customers/:id/orders', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const customer = db.prepare(
      "SELECT id FROM users WHERE id = ? AND role = 'customer' AND deleted_at IS NULL"
    ).get(customerId);
    if (!customer) {
      return res.status(404).json({ success: false, message: 'Customer not found' });
    }

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM orders WHERE user_id = ? AND deleted_at IS NULL`
    ).get(customerId);

    const orders = db.prepare(
      `SELECT o.id, o.uuid, o.order_number, o.status, o.subtotal, o.total,
              o.payment_status, o.payment_method, o.courier_id, o.tracking_number,
              o.created_at,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
       FROM orders o
       WHERE o.user_id = ? AND o.deleted_at IS NULL
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(customerId, limit, offset);

    res.json({
      success: true,
      data: {
        items: orders,
        pagination: {
          page,
          limit,
          total: countRow.total,
          pages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (err) { next(err); }
});

// ============================================================================
// GIFT CARDS
// ============================================================================

router.get('/gift-cards', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let giftCards = [];
    try {
      giftCards = db.prepare(
        `SELECT gc.*, u.first_name || ' ' || u.last_name as issued_to_name
         FROM gift_cards gc
         LEFT JOIN users u ON gc.user_id = u.id
         ORDER BY gc.created_at DESC`
      ).all();
    } catch (e) {
      giftCards = [];
    }
    res.json({ success: true, data: { items: giftCards } });
  } catch (err) { next(err); }
});

router.post('/gift-cards', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const { code, balance, user_id, expires_at } = req.body;

    if (!balance || balance <= 0) {
      return res.status(400).json({ success: false, message: 'A positive balance is required' });
    }

    const cardCode = code || `GC-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    try {
      const result = db.prepare(
        `INSERT INTO gift_cards (uuid, code, balance, initial_balance, user_id, expires_at, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))`
      ).run(uuid(), cardCode, balance, balance, user_id || null, expires_at || null);

      const card = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(result.lastInsertRowid);

      res.status(201).json({
        success: true,
        data: { gift_card: card },
        message: 'Gift card created',
      });
    } catch (e) {
      res.status(400).json({ success: false, message: 'Failed to create gift card. Table may not exist.' });
    }
  } catch (err) { next(err); }
});

router.put('/gift-cards/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const cardId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(cardId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Gift card table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Gift card not found' });
    }

    const { balance, user_id, expires_at, is_active } = req.body;

    db.prepare(
      `UPDATE gift_cards SET balance = ?, user_id = ?, expires_at = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      balance !== undefined ? balance : existing.balance,
      user_id !== undefined ? user_id : existing.user_id,
      expires_at !== undefined ? expires_at : existing.expires_at,
      is_active !== undefined ? (is_active ? 1 : 0) : existing.is_active,
      cardId
    );

    const card = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(cardId);

    res.json({
      success: true,
      data: { gift_card: card },
      message: 'Gift card updated',
    });
  } catch (err) { next(err); }
});

router.delete('/gift-cards/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const cardId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM gift_cards WHERE id = ?').get(cardId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Gift card table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Gift card not found' });
    }

    db.prepare('DELETE FROM gift_cards WHERE id = ?').run(cardId);

    res.json({ success: true, message: 'Gift card deleted' });
  } catch (err) { next(err); }
});

// ============================================================================
// BUNDLE OFFERS
// ============================================================================

router.get('/bundles', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let bundles = [];
    try {
      bundles = db.prepare(
        `SELECT bo.*,
                (SELECT GROUP_CONCAT(p.name, ', ')
                 FROM bundle_offer_products bop
                 JOIN products p ON bop.product_id = p.id
                 WHERE bop.bundle_offer_id = bo.id) as product_names
         FROM bundle_offers bo
         ORDER BY bo.created_at DESC`
      ).all();
    } catch (e) {
      bundles = [];
    }
    res.json({ success: true, data: { items: bundles } });
  } catch (err) { next(err); }
});

router.post('/bundles', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const { name, description, bundle_price, discount_type, discount_value, product_ids, min_quantity, is_active, starts_at, expires_at } = req.body;

    if (!name || !bundle_price) {
      return res.status(400).json({ success: false, message: 'Name and bundle_price are required' });
    }

    try {
      const result = db.prepare(
        `INSERT INTO bundle_offers (uuid, name, description, bundle_price, discount_type, discount_value, min_quantity, is_active, starts_at, expires_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
      ).run(
        uuid(), name, description || null, bundle_price,
        discount_type || 'fixed', discount_value || 0,
        min_quantity || 1, is_active !== undefined ? (is_active ? 1 : 0) : 1,
        starts_at || null, expires_at || null
      );

      const bundleId = result.lastInsertRowid;

      if (product_ids && Array.isArray(product_ids) && product_ids.length > 0) {
        const insertProduct = db.prepare(
          `INSERT INTO bundle_offer_products (bundle_offer_id, product_id, quantity, created_at) VALUES (?, ?, ?, datetime('now'))`
        );
        for (const pid of product_ids) {
          insertProduct.run(bundleId, pid.productId || pid, pid.quantity || 1);
        }
      }

      const bundle = db.prepare('SELECT * FROM bundle_offers WHERE id = ?').get(bundleId);

      res.status(201).json({
        success: true,
        data: { bundle },
        message: 'Bundle offer created',
      });
    } catch (e) {
      res.status(400).json({ success: false, message: 'Failed to create bundle offer. Table may not exist.' });
    }
  } catch (err) { next(err); }
});

router.put('/bundles/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const bundleId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM bundle_offers WHERE id = ?').get(bundleId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Bundle table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Bundle offer not found' });
    }

    const { name, description, bundle_price, discount_type, discount_value, product_ids, min_quantity, is_active, starts_at, expires_at } = req.body;

    db.prepare(
      `UPDATE bundle_offers SET name = ?, description = ?, bundle_price = ?, discount_type = ?, discount_value = ?,
        min_quantity = ?, is_active = ?, starts_at = ?, expires_at = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      description !== undefined ? description : existing.description,
      bundle_price !== undefined ? bundle_price : existing.bundle_price,
      discount_type || existing.discount_type,
      discount_value !== undefined ? discount_value : existing.discount_value,
      min_quantity !== undefined ? min_quantity : existing.min_quantity,
      is_active !== undefined ? (is_active ? 1 : 0) : existing.is_active,
      starts_at !== undefined ? starts_at : existing.starts_at,
      expires_at !== undefined ? expires_at : existing.expires_at,
      bundleId
    );

    if (product_ids && Array.isArray(product_ids)) {
      try {
        db.prepare('DELETE FROM bundle_offer_products WHERE bundle_offer_id = ?').run(bundleId);
        const insertProduct = db.prepare(
          `INSERT INTO bundle_offer_products (bundle_offer_id, product_id, quantity, created_at) VALUES (?, ?, ?, datetime('now'))`
        );
        for (const pid of product_ids) {
          insertProduct.run(bundleId, pid.productId || pid, pid.quantity || 1);
        }
      } catch (e) { /* table might not exist */ }
    }

    const bundle = db.prepare('SELECT * FROM bundle_offers WHERE id = ?').get(bundleId);

    res.json({
      success: true,
      data: { bundle },
      message: 'Bundle offer updated',
    });
  } catch (err) { next(err); }
});

router.delete('/bundles/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const bundleId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM bundle_offers WHERE id = ?').get(bundleId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Bundle table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Bundle offer not found' });
    }

    try {
      db.prepare('DELETE FROM bundle_offer_products WHERE bundle_offer_id = ?').run(bundleId);
    } catch (e) { /* table might not exist */ }
    db.prepare('DELETE FROM bundle_offers WHERE id = ?').run(bundleId);

    res.json({ success: true, message: 'Bundle offer deleted' });
  } catch (err) { next(err); }
});

// ============================================================================
// PRE-ORDERS
// ============================================================================

router.get('/preorders', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let preorders = [];
    try {
      preorders = db.prepare(
        `SELECT po.*, p.name as product_name, p.slug as product_slug,
                u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email
         FROM preorders po
         LEFT JOIN products p ON po.product_id = p.id
         LEFT JOIN users u ON po.user_id = u.id
         ORDER BY po.created_at DESC`
      ).all();
    } catch (e) {
      preorders = [];
    }
    res.json({ success: true, data: { items: preorders } });
  } catch (err) { next(err); }
});

router.put('/preorders/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const preorderId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM preorders WHERE id = ?').get(preorderId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Preorder table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Preorder not found' });
    }

    const { status, quantity, notes } = req.body;

    db.prepare(
      `UPDATE preorders SET status = ?, quantity = ?, notes = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      status || existing.status,
      quantity !== undefined ? quantity : existing.quantity,
      notes !== undefined ? notes : existing.notes,
      preorderId
    );

    const preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(preorderId);

    res.json({
      success: true,
      data: { preorder },
      message: 'Preorder updated',
    });
  } catch (err) { next(err); }
});

router.put('/preorders/:id/fulfill', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const preorderId = parseInt(req.params.id);

    let preorder;
    try {
      preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(preorderId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Preorder table not found' });
    }
    if (!preorder) {
      return res.status(404).json({ success: false, message: 'Preorder not found' });
    }

    const orderNumber = `ORD-PRE-${Date.now().toString(36).toUpperCase()}`;
    let total = preorder.price * preorder.quantity;

    const transaction = db.transaction(() => {
      const result = db.prepare(
        `INSERT INTO orders (uuid, user_id, order_number, status, subtotal, discount, shipping_cost,
                            tax, total, payment_status, notes, created_at, updated_at)
         VALUES (?, ?, ?, 'confirmed', ?, 0, 0, 0, ?, 'pending', ?, datetime('now'), datetime('now'))`
      ).run(
        uuid(), preorder.user_id, orderNumber, total, total,
        `Fulfilled from preorder #${preorder.id}`
      );

      const orderId = result.lastInsertRowid;

      db.prepare(
        `INSERT INTO order_items (order_id, product_id, product_name, product_sku, quantity, price, discount, tax, total, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, datetime('now'))`
      ).run(
        orderId, preorder.product_id, preorder.product_name || '',
        preorder.product_sku || '', preorder.quantity, preorder.price, total
      );

      db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, changed_by, created_at)
         VALUES (?, 'confirmed', 'Fulfilled from preorder', ?, datetime('now'))`
      ).run(orderId, req.user.id);

      db.prepare(
        `UPDATE preorders SET status = 'fulfilled', updated_at = datetime('now') WHERE id = ?`
      ).run(preorderId);

      return orderId;
    });

    const orderId = transaction();

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.json({
      success: true,
      data: { order },
      message: 'Preorder fulfilled and order created',
    });
  } catch (err) { next(err); }
});

// ============================================================================
// BACK IN STOCK
// ============================================================================

router.get('/back-in-stock', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let subscriptions = [];
    try {
      subscriptions = db.prepare(
        `SELECT bis.*, p.name as product_name, p.slug as product_slug,
                u.first_name || ' ' || u.last_name as user_name, u.email as user_email
         FROM back_in_stock bis
         LEFT JOIN products p ON bis.product_id = p.id
         LEFT JOIN users u ON bis.user_id = u.id
         ORDER BY bis.created_at DESC`
      ).all();
    } catch (e) {
      subscriptions = [];
    }
    res.json({ success: true, data: { items: subscriptions } });
  } catch (err) { next(err); }
});

router.post('/back-in-stock/:id/notify', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const subId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM back_in_stock WHERE id = ?').get(subId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Back-in-stock table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Subscription not found' });
    }

    db.prepare(
      `UPDATE back_in_stock SET is_notified = 1, notified_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(subId);

    if (existing.user_id) {
      try {
        db.prepare(
          `INSERT INTO notifications (user_id, title, message, type, created_at)
           VALUES (?, 'Back in Stock', 'A product you were waiting for is back in stock!', 'info', datetime('now'))`
        ).run(existing.user_id);
      } catch (e) { /* notifications table might have different schema */ }
    }

    const updated = db.prepare('SELECT * FROM back_in_stock WHERE id = ?').get(subId);

    res.json({
      success: true,
      data: { subscription: updated },
      message: 'Customer notified successfully',
    });
  } catch (err) { next(err); }
});

// ============================================================================
// FBT (Frequently Bought Together)
// ============================================================================

router.post('/fbt', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const { productId, relatedProductId, score } = req.body;

    if (!productId || !relatedProductId) {
      return res.status(400).json({ success: false, message: 'productId and relatedProductId are required' });
    }

    if (productId === relatedProductId) {
      return res.status(400).json({ success: false, message: 'Product and related product must be different' });
    }

    try {
      const existing = db.prepare(
        'SELECT id FROM frequently_bought_together WHERE product_id = ? AND related_product_id = ?'
      ).get(productId, relatedProductId);

      if (existing) {
        return res.status(400).json({ success: false, message: 'Association already exists' });
      }

      const result = db.prepare(
        `INSERT INTO frequently_bought_together (product_id, related_product_id, score, created_at, updated_at)
         VALUES (?, ?, ?, datetime('now'), datetime('now'))`
      ).run(productId, relatedProductId, score || 1);

      const fbt = db.prepare('SELECT * FROM frequently_bought_together WHERE id = ?').get(result.lastInsertRowid);

      res.status(201).json({
        success: true,
        data: { fbt },
        message: 'FBT association created',
      });
    } catch (e) {
      res.status(400).json({ success: false, message: 'Failed to create FBT association. Table may not exist.' });
    }
  } catch (err) { next(err); }
});

router.delete('/fbt/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const fbtId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM frequently_bought_together WHERE id = ?').get(fbtId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'FBT table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'FBT association not found' });
    }

    db.prepare('DELETE FROM frequently_bought_together WHERE id = ?').run(fbtId);

    res.json({ success: true, message: 'FBT association deleted' });
  } catch (err) { next(err); }
});

// ============================================================================
// STAFF ATTENDANCE
// ============================================================================

router.get('/attendance', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.user_id) {
      where.push('a.user_id = ?');
      params.push(parseInt(req.query.user_id));
    }

    if (req.query.date) {
      where.push('a.date = ?');
      params.push(req.query.date);
    }

    if (req.query.status) {
      where.push('a.status = ?');
      params.push(req.query.status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    let records = [];
    try {
      const countRow = db.prepare(
        `SELECT COUNT(*) as total FROM attendance a ${whereClause}`
      ).get(...params);

      records = db.prepare(
        `SELECT a.*,
                u.first_name || ' ' || u.last_name as user_name,
                u.email as user_email
         FROM attendance a
         JOIN users u ON a.user_id = u.id
         ${whereClause}
         ORDER BY a.date DESC, a.created_at DESC
         LIMIT ? OFFSET ?`
      ).all(...params, limit, offset);

      res.json({
        success: true,
        data: {
          items: records,
          pagination: {
            page,
            limit,
            total: countRow.total,
            pages: Math.ceil(countRow.total / limit),
          },
        },
      });
    } catch (e) {
      res.json({ success: true, data: { items: [], pagination: { page: 1, limit, total: 0, pages: 0 } } });
    }
  } catch (err) { next(err); }
});

router.put('/attendance/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const attendanceId = parseInt(req.params.id);

    let existing;
    try {
      existing = db.prepare('SELECT * FROM attendance WHERE id = ?').get(attendanceId);
    } catch (e) {
      return res.status(404).json({ success: false, message: 'Attendance table not found' });
    }
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Attendance record not found' });
    }

    const { status, check_in, check_out, notes } = req.body;

    db.prepare(
      `UPDATE attendance SET status = ?, check_in = ?, check_out = ?, notes = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      status || existing.status,
      check_in !== undefined ? check_in : existing.check_in,
      check_out !== undefined ? check_out : existing.check_out,
      notes !== undefined ? notes : existing.notes,
      attendanceId
    );

    const record = db.prepare('SELECT * FROM attendance WHERE id = ?').get(attendanceId);

    res.json({
      success: true,
      data: { attendance: record },
      message: 'Attendance updated',
    });
  } catch (err) { next(err); }
});

router.get('/attendance/stats', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const startDate = req.query.start_date || new Date(new Date().setDate(1)).toISOString().split('T')[0];
    const endDate = req.query.end_date || new Date().toISOString().split('T')[0];

    let stats = {};
    try {
      const totalRecords = db.prepare(
        `SELECT COUNT(*) as total FROM attendance WHERE date BETWEEN ? AND ?`
      ).get(startDate, endDate);

      const present = db.prepare(
        `SELECT COUNT(*) as count FROM attendance WHERE date BETWEEN ? AND ? AND status = 'present'`
      ).get(startDate, endDate);

      const absent = db.prepare(
        `SELECT COUNT(*) as count FROM attendance WHERE date BETWEEN ? AND ? AND status = 'absent'`
      ).get(startDate, endDate);

      const late = db.prepare(
        `SELECT COUNT(*) as count FROM attendance WHERE date BETWEEN ? AND ? AND status = 'late'`
      ).get(startDate, endDate);

      const halfDay = db.prepare(
        `SELECT COUNT(*) as count FROM attendance WHERE date BETWEEN ? AND ? AND status = 'half_day'`
      ).get(startDate, endDate);

      const userStats = db.prepare(
        `SELECT u.id, u.first_name || ' ' || u.last_name as user_name,
                COUNT(CASE WHEN a.status = 'present' THEN 1 END) as present_days,
                COUNT(CASE WHEN a.status = 'absent' THEN 1 END) as absent_days,
                COUNT(CASE WHEN a.status = 'late' THEN 1 END) as late_days,
                COUNT(CASE WHEN a.status = 'half_day' THEN 1 END) as half_day_count
         FROM attendance a
         JOIN users u ON a.user_id = u.id
         WHERE a.date BETWEEN ? AND ?
         GROUP BY u.id`
      ).all(startDate, endDate);

      stats = {
        period: { start_date: startDate, end_date: endDate },
        summary: {
          total: totalRecords.total,
          present: present.count,
          absent: absent.count,
          late: late.count,
          half_day: halfDay.count,
        },
        by_user: userStats,
      };
    } catch (e) {
      stats = {
        period: { start_date: startDate, end_date: endDate },
        summary: { total: 0, present: 0, absent: 0, late: 0, half_day: 0 },
        by_user: [],
      };
    }

    res.json({ success: true, data: stats });
  } catch (err) { next(err); }
});

// ============================================================================
// PERMISSIONS
// ============================================================================

router.get('/permissions', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let permissions = [];
    try {
      permissions = db.prepare(
        `SELECT * FROM permissions ORDER BY module, action`
      ).all();
    } catch (e) {
      permissions = [];
    }
    res.json({ success: true, data: { items: permissions } });
  } catch (err) { next(err); }
});

router.get('/permissions/:role', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const role = req.params.role;

    let rolePermissions = [];
    try {
      rolePermissions = db.prepare(
        `SELECT p.*
         FROM permissions p
         JOIN role_permissions rp ON p.id = rp.permission_id
         WHERE rp.role = ?
         ORDER BY p.module, p.action`
      ).all(role);
    } catch (e) {
      rolePermissions = [];
    }

    res.json({ success: true, data: { role, permissions: rolePermissions } });
  } catch (err) { next(err); }
});

router.put('/permissions/:role', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const role = req.params.role;
    const { permissionIds } = req.body;

    if (!permissionIds || !Array.isArray(permissionIds)) {
      return res.status(400).json({ success: false, message: 'permissionIds array is required' });
    }

    try {
      const transaction = db.transaction(() => {
        db.prepare('DELETE FROM role_permissions WHERE role = ?').run(role);

        const insertStmt = db.prepare(
          `INSERT INTO role_permissions (role, permission_id, created_at) VALUES (?, ?, datetime('now'))`
        );
        for (const permId of permissionIds) {
          insertStmt.run(role, permId);
        }
      });

      transaction();

      const updatedPermissions = db.prepare(
        `SELECT p.*
         FROM permissions p
         JOIN role_permissions rp ON p.id = rp.permission_id
         WHERE rp.role = ?
         ORDER BY p.module, p.action`
      ).all(role);

      res.json({
        success: true,
        data: { role, permissions: updatedPermissions },
        message: 'Permissions updated',
      });
    } catch (e) {
      res.status(400).json({ success: false, message: 'Failed to update permissions. Table may not exist.' });
    }
  } catch (err) { next(err); }
});

// ============================================================================
// ACTIVITY LOG
// ============================================================================

router.get('/activity-logs', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (req.query.user_id) {
      where.push('al.user_id = ?');
      params.push(parseInt(req.query.user_id));
    }

    if (req.query.action) {
      where.push('al.action = ?');
      params.push(req.query.action);
    }

    if (req.query.entity) {
      where.push('al.entity = ?');
      params.push(req.query.entity);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    let logs = [];
    try {
      const countRow = db.prepare(
        `SELECT COUNT(*) as total FROM activity_logs al ${whereClause}`
      ).get(...params);

      logs = db.prepare(
        `SELECT al.*,
                u.first_name || ' ' || u.last_name as user_name,
                u.email as user_email
         FROM activity_logs al
         LEFT JOIN users u ON al.user_id = u.id
         ${whereClause}
         ORDER BY al.created_at DESC
         LIMIT ? OFFSET ?`
      ).all(...params, limit, offset);

      res.json({
        success: true,
        data: {
          items: logs,
          pagination: {
            page,
            limit,
            total: countRow.total,
            pages: Math.ceil(countRow.total / limit),
          },
        },
      });
    } catch (e) {
      res.json({ success: true, data: { items: [], pagination: { page: 1, limit, total: 0, pages: 0 } } });
    }
  } catch (err) { next(err); }
});

// ============================================================================
// REPORTS
// ============================================================================

router.get('/reports/expense', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const startDate = req.query.start_date || new Date(new Date().setDate(1)).toISOString().split('T')[0];
    const endDate = req.query.end_date || new Date().toISOString().split('T')[0];

    const totalExpenses = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total
       FROM expenses WHERE date BETWEEN ? AND ? AND deleted_at IS NULL`
    ).get(startDate, endDate);

    const byCategory = db.prepare(
      `SELECT category, COUNT(*) as count, COALESCE(SUM(amount), 0) as total
       FROM expenses WHERE date BETWEEN ? AND ? AND deleted_at IS NULL
       GROUP BY category
       ORDER BY total DESC`
    ).all(startDate, endDate);

    const daily = db.prepare(
      `SELECT date, COALESCE(SUM(amount), 0) as total
       FROM expenses WHERE date BETWEEN ? AND ? AND deleted_at IS NULL
       GROUP BY date
       ORDER BY date ASC`
    ).all(startDate, endDate);

    res.json({
      success: true,
      data: {
        period: { start_date: startDate, end_date: endDate },
        total: totalExpenses.total,
        by_category: byCategory,
        daily,
      },
    });
  } catch (err) { next(err); }
});

// ============================================================================
// RECOMMENDATIONS
// ============================================================================

router.get('/recommendations', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let recommendations = [];
    try {
      recommendations = db.prepare(
        `SELECT sr.*, p.name as product_name, p.slug as product_slug,
                (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
         FROM smart_recommendations sr
         LEFT JOIN products p ON sr.product_id = p.id
         ORDER BY sr.score DESC, sr.created_at DESC`
      ).all();
    } catch (e) {
      recommendations = [];
    }
    res.json({ success: true, data: { items: recommendations } });
  } catch (err) { next(err); }
});

router.post('/recommendations/generate', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();

    try {
      db.prepare('DELETE FROM smart_recommendations').run();
    } catch (e) {
      return res.status(400).json({ success: false, message: 'Recommendations table may not exist' });
    }

    const frequentlyOrdered = db.prepare(
      `SELECT oi.product_id, p.name, p.slug, p.price,
              COUNT(DISTINCT oi.order_id) as order_count,
              SUM(oi.quantity) as total_quantity
       FROM order_items oi
       JOIN products p ON oi.product_id = p.id
       JOIN orders o ON oi.order_id = o.id
       WHERE o.deleted_at IS NULL AND p.deleted_at IS NULL
       GROUP BY oi.product_id
       HAVING total_quantity >= 2
       ORDER BY order_count DESC
       LIMIT 20`
    ).all();

    const recentlyViewed = db.prepare(
      `SELECT pv.product_id, p.name, p.slug, p.price, COUNT(*) as view_count
       FROM page_views pv
       JOIN products p ON pv.product_id = p.id
       WHERE p.deleted_at IS NULL
       GROUP BY pv.product_id
       ORDER BY view_count DESC
       LIMIT 20`
    ).all();

    const productScores = {};
    for (const item of frequentlyOrdered) {
      productScores[item.product_id] = (productScores[item.product_id] || 0) + item.order_count * 2;
    }
    for (const item of recentlyViewed) {
      productScores[item.product_id] = (productScores[item.product_id] || 0) + item.view_count;
    }

    const insertStmt = db.prepare(
      `INSERT INTO smart_recommendations (uuid, product_id, type, score, reason, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))`
    );

    const transaction = db.transaction(() => {
      let count = 0;
      const allProducts = [...frequentlyOrdered.map(p => ({ ...p, source: 'frequently_bought' })),
                          ...recentlyViewed.map(p => ({ ...p, source: 'frequently_viewed' }))];

      const seen = new Set();
      for (const product of allProducts) {
        if (seen.has(product.product_id)) continue;
        seen.add(product.product_id);

        const score = productScores[product.product_id] || 1;
        const reason = product.source === 'frequently_bought' ? 'Frequently bought together' : 'Most viewed product';

        insertStmt.run(uuid(), product.product_id, 'trending', score, reason);
        count++;
      }
      return count;
    });

    const count = transaction();

    res.json({
      success: true,
      message: `${count} recommendations generated`,
      data: { generated_count: count },
    });
  } catch (err) { next(err); }
});

// ============================================================================
// FLASH SALES CRUD
// ============================================================================

router.get('/flash-sales', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let sales = [];
    try {
      sales = db.prepare(
        `SELECT * FROM flash_sales WHERE deleted_at IS NULL ORDER BY created_at DESC`
      ).all();
    } catch (e) {
      sales = [];
    }
    res.json({ success: true, data: { items: sales } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/flash-sales', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, description, discountPercentage, startAt, endAt, isActive } = req.body;
    if (!name || !discountPercentage) {
      return res.status(400).json({ success: false, message: 'Name and discount percentage are required' });
    }
    try {
      db.prepare(
        `CREATE TABLE IF NOT EXISTS flash_sales (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uuid TEXT UNIQUE,
          name TEXT NOT NULL,
          description TEXT,
          discount_percentage INTEGER DEFAULT 0,
          start_at TEXT,
          end_at TEXT,
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now')),
          deleted_at TEXT
        )`
      ).run();
    } catch (e) {}
    const result = db.prepare(
      `INSERT INTO flash_sales (uuid, name, description, discount_percentage, start_at, end_at, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(uuid(), name, description || null, discountPercentage, startAt || null, endAt || null, isActive !== false ? 1 : 0);
    const sale = db.prepare('SELECT * FROM flash_sales WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: { flashSale: sale } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.put('/flash-sales/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const saleId = parseInt(req.params.id);
    const { name, description, discountPercentage, startAt, endAt, isActive } = req.body;
    const existing = db.prepare('SELECT * FROM flash_sales WHERE id = ? AND deleted_at IS NULL').get(saleId);
    if (!existing) return res.status(404).json({ success: false, message: 'Flash sale not found' });
    db.prepare(
      `UPDATE flash_sales SET name = ?, description = ?, discount_percentage = ?, start_at = ?, end_at = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      description !== undefined ? description : existing.description,
      discountPercentage || existing.discount_percentage,
      startAt || existing.start_at,
      endAt || existing.end_at,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      saleId
    );
    const updated = db.prepare('SELECT * FROM flash_sales WHERE id = ?').get(saleId);
    res.json({ success: true, data: { flashSale: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/flash-sales/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const saleId = parseInt(req.params.id);
    try {
      const existing = db.prepare('SELECT * FROM flash_sales WHERE id = ?').get(saleId);
      if (existing) {
        db.prepare(`UPDATE flash_sales SET deleted_at = datetime('now') WHERE id = ?`).run(saleId);
      }
    } catch (e) {}
    res.json({ success: true, message: 'Flash sale deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// FBT (Frequently Bought Together) - GET list
// ============================================================================

router.get('/fbt', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    let items = [];
    try {
      items = db.prepare(
        `SELECT fbt.*,
                p1.name as productAName, p2.name as productBName
         FROM frequently_bought_together fbt
         LEFT JOIN products p1 ON fbt.product_a = p1.id
         LEFT JOIN products p2 ON fbt.product_b = p2.id
         ORDER BY fbt.created_at DESC`
      ).all();
    } catch (e) {
      items = [];
    }
    res.json({ success: true, data: { items } });
  } catch (err) { next(err); }
});

// ============================================================================
// LOYALTY REWARDS CRUD
// ============================================================================

router.get('/loyalty-rewards', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let rewards = [];
    try {
      rewards = db.prepare(
        `SELECT * FROM loyalty_rewards WHERE deleted_at IS NULL ORDER BY created_at DESC`
      ).all();
    } catch (e) {
      rewards = [];
    }
    res.json({ success: true, data: { items: rewards } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/loyalty-rewards', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, description, pointsCost, rewardType, rewardValue, stock, isActive } = req.body;
    if (!name || !pointsCost) {
      return res.status(400).json({ success: false, message: 'Name and points cost are required' });
    }
    try {
      db.prepare(
        `CREATE TABLE IF NOT EXISTS loyalty_rewards (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uuid TEXT UNIQUE,
          name TEXT NOT NULL,
          description TEXT,
          points_cost INTEGER DEFAULT 0,
          reward_type TEXT DEFAULT 'discount',
          reward_value REAL DEFAULT 0,
          stock INTEGER,
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now')),
          deleted_at TEXT
        )`
      ).run();
    } catch (e) {}
    const result = db.prepare(
      `INSERT INTO loyalty_rewards (uuid, name, description, points_cost, reward_type, reward_value, stock, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(uuid(), name, description || null, pointsCost, rewardType || 'discount', rewardValue || 0, stock || null, isActive !== false ? 1 : 0);
    const reward = db.prepare('SELECT * FROM loyalty_rewards WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: { reward } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.put('/loyalty-rewards/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const rewardId = parseInt(req.params.id);
    const { name, description, pointsCost, rewardType, rewardValue, stock, isActive } = req.body;
    const existing = db.prepare('SELECT * FROM loyalty_rewards WHERE id = ? AND deleted_at IS NULL').get(rewardId);
    if (!existing) return res.status(404).json({ success: false, message: 'Reward not found' });
    db.prepare(
      `UPDATE loyalty_rewards SET name = ?, description = ?, points_cost = ?, reward_type = ?, reward_value = ?, stock = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      description !== undefined ? description : existing.description,
      pointsCost || existing.points_cost,
      rewardType || existing.reward_type,
      rewardValue !== undefined ? rewardValue : existing.reward_value,
      stock !== undefined ? stock : existing.stock,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      rewardId
    );
    const updated = db.prepare('SELECT * FROM loyalty_rewards WHERE id = ?').get(rewardId);
    res.json({ success: true, data: { reward: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/loyalty-rewards/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const rewardId = parseInt(req.params.id);
    try {
      const existing = db.prepare('SELECT * FROM loyalty_rewards WHERE id = ?').get(rewardId);
      if (existing) {
        db.prepare(`UPDATE loyalty_rewards SET deleted_at = datetime('now') WHERE id = ?`).run(rewardId);
      }
    } catch (e) {}
    res.json({ success: true, message: 'Reward deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// USER MANAGEMENT CRUD
// ============================================================================

router.get('/users', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const users = db.prepare(
      `SELECT id, uuid, first_name || ' ' || last_name as name, first_name, last_name, email, phone, role, is_active, avatar,
              referral_code, loyalty_points, wallet_balance, email_verified, phone_verified, created_at
       FROM users WHERE deleted_at IS NULL ORDER BY created_at DESC`
    ).all();
    res.json({ success: true, data: { items: users } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/users', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { firstName, lastName, email, phone, password, role, isActive } = req.body;
    if (!firstName || !email) {
      return res.status(400).json({ success: false, message: 'First name and email are required' });
    }
    const bcrypt = await import('bcryptjs');
    const hashedPassword = password ? await bcrypt.default.hash(password, 12) : '';
    const userUuid = uuid();
    const referralCode = 'REF' + userUuid.slice(0, 8).toUpperCase();
    const result = db.prepare(
      `INSERT INTO users (uuid, first_name, last_name, email, phone, password, role, is_active, referral_code, loyalty_points, wallet_balance, email_verified, phone_verified, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, datetime('now'), datetime('now'))`
    ).run(userUuid, firstName, lastName || '', email, phone || '', hashedPassword, role || 'customer', isActive !== false ? 1 : 0, referralCode);
    const user = db.prepare('SELECT id, uuid, first_name, last_name, email, phone, role, is_active FROM users WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: { user } });
  } catch (error) {
    if (error.message && error.message.includes('UNIQUE')) {
      return res.status(400).json({ success: false, message: 'Email already exists' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/users/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const userId = parseInt(req.params.id);
    const { firstName, lastName, email, phone, password, role, isActive } = req.body;
    const existing = db.prepare('SELECT * FROM users WHERE id = ? AND deleted_at IS NULL').get(userId);
    if (!existing) return res.status(404).json({ success: false, message: 'User not found' });
    let hashedPassword = existing.password;
    if (password) {
      const bcrypt = await import('bcryptjs');
      hashedPassword = await bcrypt.default.hash(password, 12);
    }
    db.prepare(
      `UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, password = ?, role = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      firstName || existing.first_name,
      lastName !== undefined ? lastName : existing.last_name,
      email || existing.email,
      phone !== undefined ? phone : existing.phone,
      hashedPassword,
      role || existing.role,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      userId
    );
    const updated = db.prepare('SELECT id, uuid, first_name, last_name, email, phone, role, is_active FROM users WHERE id = ?').get(userId);
    res.json({ success: true, data: { user: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/users/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const userId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!existing) return res.status(404).json({ success: false, message: 'User not found' });
    if (existing.role === 'super_admin') {
      return res.status(400).json({ success: false, message: 'Cannot delete super admin' });
    }
    try {
      db.prepare(`UPDATE users SET deleted_at = datetime('now') WHERE id = ?`).run(userId);
    } catch (e) {
      db.prepare('DELETE FROM users WHERE id = ?').run(userId);
    }
    res.json({ success: true, message: 'User deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// PRODUCT VARIANTS CRUD
// ============================================================================

router.get('/products/:id/variants', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    let variants = [];
    try {
      variants = db.prepare(
        `SELECT pv.* FROM product_variants pv WHERE pv.product_id = ? AND pv.deleted_at IS NULL ORDER BY pv.created_at DESC`
      ).all(productId);
    } catch (e) {
      variants = [];
    }
    res.json({ success: true, data: { items: variants } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/products/:id/variants', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const productId = parseInt(req.params.id);
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    const { name, sku, price, compareAtPrice, stockQuantity, weight, isActive, options } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'Variant name is required' });
    try {
      db.prepare(
        `CREATE TABLE IF NOT EXISTS product_variants (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uuid TEXT UNIQUE,
          product_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          sku TEXT,
          price REAL DEFAULT 0,
          compare_at_price REAL DEFAULT 0,
          stock_quantity INTEGER DEFAULT 0,
          weight REAL,
          is_active INTEGER DEFAULT 1,
          options TEXT,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now')),
          deleted_at TEXT
        )`
      ).run();
    } catch (e) {}
    const result = db.prepare(
      `INSERT INTO product_variants (uuid, product_id, name, sku, price, compare_at_price, stock_quantity, weight, is_active, options, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(uuid(), productId, name, sku || null, price || 0, compareAtPrice || 0, stockQuantity || 0, weight || null, isActive !== false ? 1 : 0, options ? JSON.stringify(options) : null);
    const variant = db.prepare('SELECT * FROM product_variants WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: { variant } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.put('/products/:id/variants/:variantId', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const variantId = parseInt(req.params.variantId);
    const { name, sku, price, compareAtPrice, stockQuantity, weight, isActive, options } = req.body;
    const existing = db.prepare('SELECT * FROM product_variants WHERE id = ? AND deleted_at IS NULL').get(variantId);
    if (!existing) return res.status(404).json({ success: false, message: 'Variant not found' });
    db.prepare(
      `UPDATE product_variants SET name = ?, sku = ?, price = ?, compare_at_price = ?, stock_quantity = ?, weight = ?, is_active = ?, options = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      sku !== undefined ? sku : existing.sku,
      price !== undefined ? price : existing.price,
      compareAtPrice !== undefined ? compareAtPrice : existing.compare_at_price,
      stockQuantity !== undefined ? stockQuantity : existing.stock_quantity,
      weight !== undefined ? weight : existing.weight,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      options ? JSON.stringify(options) : existing.options,
      variantId
    );
    const updated = db.prepare('SELECT * FROM product_variants WHERE id = ?').get(variantId);
    res.json({ success: true, data: { variant: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/products/:id/variants/:variantId', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const variantId = parseInt(req.params.variantId);
    const existing = db.prepare('SELECT * FROM product_variants WHERE id = ?').get(variantId);
    if (!existing) return res.status(404).json({ success: false, message: 'Variant not found' });
    try {
      db.prepare(`UPDATE product_variants SET deleted_at = datetime('now') WHERE id = ?`).run(variantId);
    } catch (e) {
      db.prepare('DELETE FROM product_variants WHERE id = ?').run(variantId);
    }
    res.json({ success: true, message: 'Variant deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// DELIVERY ZONES CRUD (admin)
// ============================================================================

router.get('/delivery/zones', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let zones = [];
    try {
      zones = db.prepare('SELECT * FROM delivery_zones WHERE deleted_at IS NULL ORDER BY created_at DESC').all();
    } catch (e) {
      zones = [];
    }
    res.json({ success: true, data: { zones } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/delivery/zones', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, baseRate, perKgRate, estimatedDays, isActive } = req.body;
    if (!name) return res.status(400).json({ success: false, message: 'Zone name is required' });
    try {
      db.prepare(
        `CREATE TABLE IF NOT EXISTS delivery_zones (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          uuid TEXT UNIQUE,
          name TEXT NOT NULL,
          base_rate REAL DEFAULT 0,
          per_kg_rate REAL DEFAULT 0,
          estimated_days INTEGER DEFAULT 3,
          is_active INTEGER DEFAULT 1,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now')),
          deleted_at TEXT
        )`
      ).run();
    } catch (e) {}
    const result = db.prepare(
      `INSERT INTO delivery_zones (uuid, name, base_rate, per_kg_rate, estimated_days, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(uuid(), name, baseRate || 0, perKgRate || 0, estimatedDays || 3, isActive !== false ? 1 : 0);
    const zone = db.prepare('SELECT * FROM delivery_zones WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: { zone } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.put('/delivery/zones/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const zoneId = parseInt(req.params.id);
    const { name, baseRate, perKgRate, estimatedDays, isActive } = req.body;
    const existing = db.prepare('SELECT * FROM delivery_zones WHERE id = ? AND deleted_at IS NULL').get(zoneId);
    if (!existing) return res.status(404).json({ success: false, message: 'Zone not found' });
    db.prepare(
      `UPDATE delivery_zones SET name = ?, base_rate = ?, per_kg_rate = ?, estimated_days = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      baseRate !== undefined ? baseRate : existing.base_rate,
      perKgRate !== undefined ? perKgRate : existing.per_kg_rate,
      estimatedDays !== undefined ? estimatedDays : existing.estimated_days,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      zoneId
    );
    const updated = db.prepare('SELECT * FROM delivery_zones WHERE id = ?').get(zoneId);
    res.json({ success: true, data: { zone: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/delivery/zones/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const zoneId = parseInt(req.params.id);
    try {
      const existing = db.prepare('SELECT * FROM delivery_zones WHERE id = ?').get(zoneId);
      if (existing) {
        db.prepare(`UPDATE delivery_zones SET deleted_at = datetime('now') WHERE id = ?`).run(zoneId);
      }
    } catch (e) {}
    res.json({ success: true, message: 'Zone deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// CUSTOMER DELETE
// ============================================================================

router.delete('/customers/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const customerId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(customerId);
    if (!existing) return res.status(404).json({ success: false, message: 'Customer not found' });
    try {
      db.prepare(`UPDATE users SET deleted_at = datetime('now') WHERE id = ?`).run(customerId);
    } catch (e) {
      db.prepare('DELETE FROM users WHERE id = ?').run(customerId);
    }
    res.json({ success: true, message: 'Customer deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// FINANCE: SUPPLIER PAYMENTS PUT/DELETE
// ============================================================================

router.put('/finance/supplier-payments/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const paymentId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM supplier_payments WHERE id = ?').get(paymentId);
    if (!existing) return res.status(404).json({ success: false, message: 'Payment not found' });
    const { supplierId, amount, paymentMethod, reference, notes, paymentDate } = req.body;
    db.prepare(
      `UPDATE supplier_payments SET supplier_id = ?, amount = ?, payment_method = ?, reference = ?, notes = ?, payment_date = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      supplierId || existing.supplier_id,
      amount !== undefined ? amount : existing.amount,
      paymentMethod || existing.payment_method,
      reference !== undefined ? reference : existing.reference,
      notes !== undefined ? notes : existing.notes,
      paymentDate || existing.payment_date,
      paymentId
    );
    const updated = db.prepare('SELECT * FROM supplier_payments WHERE id = ?').get(paymentId);
    res.json({ success: true, data: { payment: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/finance/supplier-payments/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const paymentId = parseInt(req.params.id);
    try {
      db.prepare(`UPDATE supplier_payments SET deleted_at = datetime('now') WHERE id = ?`).run(paymentId);
    } catch (e) {
      db.prepare('DELETE FROM supplier_payments WHERE id = ?').run(paymentId);
    }
    res.json({ success: true, message: 'Payment deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// FINANCE: SALARY PUT/DELETE
// ============================================================================

router.put('/finance/salary/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const salaryId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM salary_records WHERE id = ?').get(salaryId);
    if (!existing) return res.status(404).json({ success: false, message: 'Salary record not found' });
    const { employeeName, amount, paymentMethod, paymentDate, notes, status } = req.body;
    db.prepare(
      `UPDATE salary_records SET employee_name = ?, amount = ?, payment_method = ?, payment_date = ?, notes = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      employeeName || existing.employee_name,
      amount !== undefined ? amount : existing.amount,
      paymentMethod || existing.payment_method,
      paymentDate || existing.payment_date,
      notes !== undefined ? notes : existing.notes,
      status || existing.status,
      salaryId
    );
    const updated = db.prepare('SELECT * FROM salary_records WHERE id = ?').get(salaryId);
    res.json({ success: true, data: { salary: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.delete('/finance/salary/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const salaryId = parseInt(req.params.id);
    try {
      db.prepare(`UPDATE salary_records SET deleted_at = datetime('now') WHERE id = ?`).run(salaryId);
    } catch (e) {
      db.prepare('DELETE FROM salary_records WHERE id = ?').run(salaryId);
    }
    res.json({ success: true, message: 'Salary record deleted' });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// MARKETING: DISCOUNTS PUT
// ============================================================================

router.put('/marketing/discounts/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const discountId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM discounts WHERE id = ?').get(discountId);
    if (!existing) return res.status(404).json({ success: false, message: 'Discount not found' });
    const { name, type, value, minOrder, maxUses, startsAt, endsAt, isActive } = req.body;
    db.prepare(
      `UPDATE discounts SET name = ?, type = ?, value = ?, min_order = ?, max_uses = ?, starts_at = ?, ends_at = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      type || existing.type,
      value !== undefined ? value : existing.value,
      minOrder !== undefined ? minOrder : existing.min_order,
      maxUses !== undefined ? maxUses : existing.max_uses,
      startsAt || existing.starts_at,
      endsAt || existing.ends_at,
      isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
      discountId
    );
    const updated = db.prepare('SELECT * FROM discounts WHERE id = ?').get(discountId);
    res.json({ success: true, data: { discount: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// MARKETING: CAMPAIGNS PUT
// ============================================================================

router.put('/marketing/campaigns/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const campId = parseInt(req.params.id);
    const existing = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(campId);
    if (!existing) return res.status(404).json({ success: false, message: 'Campaign not found' });
    const { name, description, type, budget, status, startsAt, endsAt } = req.body;
    db.prepare(
      `UPDATE campaigns SET name = ?, description = ?, type = ?, budget = ?, status = ?, starts_at = ?, ends_at = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(
      name || existing.name,
      description !== undefined ? description : existing.description,
      type || existing.type,
      budget !== undefined ? budget : existing.budget,
      status || existing.status,
      startsAt || existing.starts_at,
      endsAt || existing.ends_at,
      campId
    );
    const updated = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(campId);
    res.json({ success: true, data: { campaign: updated } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// BACKUP: LIST & RESTORE
// ============================================================================

router.get('/backup/list', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let backups = [];
    try {
      backups = db.prepare(
        `SELECT * FROM backups ORDER BY created_at DESC`
      ).all();
    } catch (e) {
      backups = [];
    }
    res.json({ success: true, data: { items: backups } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.post('/backup/restore/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const backupId = parseInt(req.params.id);
    let backup = null;
    try {
      backup = db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId);
    } catch (e) {}
    if (!backup) {
      return res.status(404).json({ success: false, message: 'Backup not found or backup tracking not available' });
    }
    res.json({ success: true, message: 'Backup restore initiated', data: { backup } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// NOTIFICATIONS HISTORY
// ============================================================================

router.get('/notifications/history', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let notifications = [];
    try {
      notifications = db.prepare(
        `SELECT * FROM notification_history ORDER BY sent_at DESC LIMIT 200`
      ).all();
    } catch (e) {
      try {
        notifications = db.prepare(
          `SELECT * FROM notifications WHERE type != 'push' ORDER BY created_at DESC LIMIT 200`
        ).all();
      } catch (e2) {
        notifications = [];
      }
    }
    res.json({ success: true, data: { items: notifications } });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// ANALYTICS PROXY ROUTES (for admin API paths)
// ============================================================================

router.get('/analytics/customers', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const totalCustomers = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'customer' AND deleted_at IS NULL").get();
    const newCustomers = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'customer' AND date(created_at) >= date('now', '-30 days') AND deleted_at IS NULL").get();
    const returningCustomers = db.prepare(
      `SELECT COUNT(DISTINCT user_id) as count FROM orders WHERE user_id IN (SELECT id FROM users WHERE role = 'customer') AND deleted_at IS NULL AND date(created_at) >= date('now', '-30 days')`
    ).get();
    const avgLifetimeValue = db.prepare(
      `SELECT COALESCE(AVG(total), 0) as avg_ltv FROM orders WHERE payment_status = 'paid' AND deleted_at IS NULL`
    ).get();
    const topCustomers = db.prepare(
      `SELECT u.id, u.first_name || ' ' || u.last_name as name,
              COUNT(o.id) as order_count, COALESCE(SUM(o.total), 0) as total_spent
       FROM users u
       JOIN orders o ON u.id = o.user_id
       WHERE u.role = 'customer' AND u.deleted_at IS NULL AND o.deleted_at IS NULL
       GROUP BY u.id
       ORDER BY total_spent DESC
       LIMIT 10`
    ).all();
    res.json({
      success: true,
      data: {
        totalCustomers: totalCustomers.count,
        newCustomers: newCustomers.count,
        returningCustomers: returningCustomers.count,
        avgLifetimeValue: avgLifetimeValue.avg_ltv,
        topCustomers: topCustomers.map(c => ({
          name: c.name,
          orderCount: c.order_count,
          totalSpent: c.total_spent
        }))
      }
    });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.get('/analytics/funnel', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let views = 0, cart = 0, checkout = 0, purchase = 0;
    try { views = db.prepare('SELECT COUNT(*) as count FROM page_views').get().count; } catch (e) {}
    try { cart = db.prepare('SELECT COUNT(*) as count FROM cart_items').get().count; } catch (e) {}
    try { checkout = db.prepare("SELECT COUNT(*) as count FROM orders WHERE status != 'cancelled'").get().count; } catch (e) {}
    try { purchase = db.prepare("SELECT COUNT(*) as count FROM orders WHERE payment_status = 'paid' AND deleted_at IS NULL").get().count; } catch (e) {}
    res.json({
      success: true,
      data: {
        stages: [
          { name: 'Product Views', count: views },
          { name: 'Add to Cart', count: cart },
          { name: 'Checkout Started', count: checkout },
          { name: 'Purchase Completed', count: purchase }
        ]
      }
    });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

router.get('/analytics/roi', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    let revenue = 0, totalExpenses = 0, marketingSpend = 0;
    try { revenue = db.prepare("SELECT COALESCE(SUM(total), 0) as r FROM orders WHERE payment_status = 'paid' AND deleted_at IS NULL").get().r; } catch (e) {}
    try { totalExpenses = db.prepare('SELECT COALESCE(SUM(amount), 0) as e FROM expenses WHERE deleted_at IS NULL').get().e; } catch (e) {}
    try {
      marketingSpend = db.prepare(
        "SELECT COALESCE(SUM(budget), 0) as m FROM campaigns WHERE deleted_at IS NULL"
      ).get().m;
    } catch (e) {}
    const netProfit = revenue - totalExpenses;
    const roi = marketingSpend > 0 ? ((revenue - marketingSpend) / marketingSpend * 100) : 0;
    res.json({
      success: true,
      data: {
        revenue,
        marketingSpend,
        roi: Math.round(roi * 10) / 10,
        netProfit,
        channels: []
      }
    });
  } catch (error) { res.status(500).json({ success: false, message: error.message }); }
});

// ============================================================================
// STAFF / ADMIN USER MANAGEMENT
// ============================================================================

router.get('/staff', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const staff = db.prepare("SELECT id, uuid, email, phone, first_name, last_name, avatar, role, is_active, created_at, updated_at FROM users WHERE role IN ('staff','admin','moderator','super_admin') ORDER BY created_at DESC").all();
    res.json({ success: true, data: { items: staff } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.post('/staff', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { email, password, first_name, last_name, phone, role } = req.body;
    if (!email || !password || !first_name || !last_name) return res.status(400).json({ success: false, message: 'email, password, first_name, last_name required' });
    const validRoles = ['staff', 'moderator', 'admin'];
    if (role && !validRoles.includes(role)) return res.status(400).json({ success: false, message: 'Invalid role. Must be: ' + validRoles.join(', ') });
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ success: false, message: 'Email already registered' });
    const bcrypt = await import('bcryptjs').then(m => m.default || m);
    const hash = await bcrypt.hash(password, 10);
    const result = db.prepare("INSERT INTO users (uuid, email, phone, password_hash, first_name, last_name, role, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)").run(crypto.randomUUID(), email, phone || null, hash, first_name, last_name || '', role || 'staff');
    const user = db.prepare('SELECT id, uuid, email, phone, first_name, last_name, role, is_active, created_at FROM users WHERE id = ?').get(result.lastInsertRowid);
    res.json({ success: true, data: { user } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/staff/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { first_name, last_name, phone, role, is_active, password } = req.body;
    const existing = db.prepare("SELECT id FROM users WHERE id = ? AND role IN ('staff','admin','moderator','super_admin')").get(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: 'Staff not found' });
    const validRoles = ['staff', 'moderator', 'admin'];
    if (role && !validRoles.includes(role)) return res.status(400).json({ success: false, message: 'Invalid role' });
    const updates = [];
    const params = [];
    if (first_name !== undefined) { updates.push('first_name = ?'); params.push(first_name); }
    if (last_name !== undefined) { updates.push('last_name = ?'); params.push(last_name); }
    if (phone !== undefined) { updates.push('phone = ?'); params.push(phone); }
    if (role !== undefined) { updates.push('role = ?'); params.push(role); }
    if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }
    if (password) {
      const bcrypt = await import('bcryptjs').then(m => m.default || m);
      const hash = await bcrypt.hash(password, 10);
      updates.push('password_hash = ?'); params.push(hash);
    }
    if (updates.length) {
      params.push(req.params.id);
      db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);
    }
    const user = db.prepare("SELECT id, uuid, email, phone, first_name, last_name, role, is_active, created_at, updated_at FROM users WHERE id = ?").get(req.params.id);
    res.json({ success: true, data: { user } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.delete('/staff/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const existing = db.prepare("SELECT id, role FROM users WHERE id = ? AND role IN ('staff','admin','moderator')").get(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: 'Staff not found' });
    if (existing.role === 'super_admin') return res.status(403).json({ success: false, message: 'Cannot delete super admin' });
    db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Staff deleted' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ============================================================================
// PAYMENT GATEWAY SETTINGS
// ============================================================================

router.get('/payment-methods', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const methods = db.prepare("SELECT key, value FROM settings WHERE group_name = 'payment'").all();
    const config = {};
    methods.forEach(m => { config[m.key] = m.value; });
    res.json({ success: true, data: { config, methods: ['cod', 'bkash', 'nagad', 'rocket', 'sslcommerz', 'stripe'] } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/payment-methods', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const allowed = ['bkash_enabled','nagad_enabled','rocket_enabled','sslcommerz_enabled','stripe_enabled','cod_enabled','bkash_number','nagad_number','rocket_number','sslcommerz_store_id','sslcommerz_store_pass','stripe_publishable_key','stripe_secret_key','payment_currency'];
    const upsert = db.prepare("INSERT INTO settings (key, value, group_name, updated_at) VALUES (?, ?, 'payment', datetime('now')) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')");
    Object.keys(req.body).forEach(k => {
      if (allowed.includes(k)) upsert.run(k, String(req.body[k]));
    });
    res.json({ success: true, message: 'Payment settings saved' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ============================================================================
// TAX / VAT SETTINGS
// ============================================================================

router.get('/tax-settings', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const settings = db.prepare("SELECT key, value FROM settings WHERE group_name = 'tax'").all();
    const config = {};
    settings.forEach(s => { config[s.key] = s.value; });
    res.json({ success: true, data: config });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/tax-settings', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const allowed = ['vat_rate','tax_included','vat_registration_no','tax_exempt_categories','tax_name'];
    const upsert = db.prepare("INSERT INTO settings (key, value, group_name, updated_at) VALUES (?, ?, 'tax', datetime('now')) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')");
    Object.keys(req.body).forEach(k => {
      if (allowed.includes(k)) upsert.run(k, String(req.body[k]));
    });
    res.json({ success: true, message: 'Tax settings saved' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ============================================================================
// REVIEW MODERATION
// ============================================================================

router.get('/reviews', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;
    const status = req.query.status || 'all';
    let where = [];
    let params = [];
    if (status === 'pending') { where.push('r.is_approved = 0'); }
    else if (status === 'approved') { where.push('r.is_approved = 1'); }
    else if (status === 'flagged') { /* future flag field */ }
    const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const countRow = db.prepare('SELECT COUNT(*) as total FROM product_reviews r ' + whereClause).get(...params);
    const reviews = db.prepare(`SELECT r.id, r.user_id, r.product_id, r.order_id, r.rating, r.title, r.comment, r.images, r.is_verified, r.is_approved, r.helpful_count, r.created_at, u.first_name || ' ' || u.last_name as user_name, u.email as user_email, p.name as product_name, p.slug as product_slug FROM product_reviews r JOIN users u ON r.user_id = u.id JOIN products p ON r.product_id = p.id ${whereClause} ORDER BY r.created_at DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);
    res.json({ success: true, data: { items: reviews, pagination: { total: countRow.total, page, limit, totalPages: Math.ceil(countRow.total / limit) } } });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.put('/reviews/:id/approve', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { approved } = req.body;
    db.prepare('UPDATE product_reviews SET is_approved = ? WHERE id = ?').run(approved ? 1 : 0, req.params.id);
    res.json({ success: true, message: approved ? 'Review approved' : 'Review rejected' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

router.delete('/reviews/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    db.prepare('DELETE FROM product_reviews WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Review deleted' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// ============================================================================
// EXPORT
// ============================================================================

router.get('/export/:type', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const type = req.params.type;
    const format = req.query.format || 'csv';
    let data, filename, headers;
    switch (type) {
      case 'orders': {
        const status = req.query.status || '';
        const where = status ? 'WHERE status = ?' : '';
        const params = status ? [status] : [];
        data = db.prepare(`SELECT o.order_number, o.status, o.payment_status, o.payment_method, o.total, o.subtotal, o.shipping_cost, o.tax, o.coupon_code, o.coupon_discount, u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email, u.phone as customer_phone, o.shipping_address, o.created_at FROM orders o LEFT JOIN users u ON o.user_id = u.id ${where} ORDER BY o.created_at DESC`).all(...params);
        headers = ['Order Number','Status','Payment Status','Payment Method','Total','Subtotal','Shipping','Tax','Coupon','Discount','Customer','Email','Phone','Shipping Address','Date'];
        break;
      }
      case 'products': {
        data = db.prepare(`SELECT p.name, p.slug, p.sku, p.price, p.compare_price, p.cost_price, p.stock_quantity, p.total_sold, p.is_active, c.name as category, b.name as brand, p.created_at FROM products p LEFT JOIN categories c ON p.category_id = c.id LEFT JOIN brands b ON p.brand_id = b.id ORDER BY p.created_at DESC`).all();
        headers = ['Name','Slug','SKU','Price','Compare Price','Cost Price','Stock','Total Sold','Active','Category','Brand','Created'];
        break;
      }
      case 'customers': {
        data = db.prepare(`SELECT u.first_name || ' ' || u.last_name as name, u.email, u.phone, u.total_orders, u.total_spent, u.is_vip, u.is_blacklisted, u.created_at FROM users u WHERE u.role = 'customer' ORDER BY u.created_at DESC`).all();
        headers = ['Name','Email','Phone','Total Orders','Total Spent','VIP','Blacklisted','Registered'];
        break;
      }
      case 'reviews': {
        data = db.prepare(`SELECT r.rating, r.title, r.comment, r.is_approved, r.is_verified, r.created_at, u.first_name || ' ' || u.last_name as user_name, p.name as product_name FROM product_reviews r JOIN users u ON r.user_id = u.id JOIN products p ON r.product_id = p.id ORDER BY r.created_at DESC`).all();
        headers = ['Rating','Title','Comment','Approved','Verified','Date','User','Product'];
        break;
      }
      default: return res.status(400).json({ success: false, message: 'Invalid export type: orders, products, customers, reviews' });
    }
    if (format === 'csv') {
      const escape = (v) => '"' + String(v || '').replace(/"/g, '""') + '"';
      let csv = headers.join(',') + '\n';
      data.forEach(row => {
        const vals = headers.map(h => {
          const key = h.toLowerCase().replace(/ /g, '_');
          return escape(row[key] || row[h] || '');
        });
        csv += vals.join(',') + '\n';
      });
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${type}-${Date.now()}.csv"`);
      res.send('\uFEFF' + csv);
    } else {
      res.json({ success: true, data: { items: data, total: data.length } });
    }
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

export default router;
