import { randomUUID } from 'node:crypto';

const XSS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
  /javascript\s*:/gi,
  /on\w+\s*=\s*["'][^"']*["']/gi,
  /on\w+\s*=\s*[^\s>]*/gi,
  /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi,
  /<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi,
  /<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*\/?>/gi,
  /<applet\b[^<]*(?:(?!<\/applet>)<[^<]*)*<\/applet>/gi,
  /data\s*:\s*text\/html/gi,
  /vbscript\s*:/gi,
  /expression\s*\(/gi,
];

const DANGEROUS_CHARS = /[<>'"]/;

function sanitizeString(value) {
  if (typeof value !== 'string') return value;

  let cleaned = value;

  for (const pattern of XSS_PATTERNS) {
    cleaned = cleaned.replace(pattern, '');
  }

  cleaned = cleaned
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');

  cleaned = cleaned.replace(/javascript\s*:/gi, '');
  cleaned = cleaned.replace(/on\w+\s*=/gi, '');

  return cleaned;
}

function sanitizeObject(obj, depth = 0) {
  if (depth > 10) return obj;
  if (obj === null || obj === undefined) return obj;

  if (typeof obj === 'string') {
    return sanitizeString(obj);
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => sanitizeObject(item, depth + 1));
  }

  if (typeof obj === 'object') {
    const sanitized = {};
    for (const [key, value] of Object.entries(obj)) {
      const cleanKey = sanitizeString(key);
      sanitized[cleanKey] = sanitizeObject(value, depth + 1);
    }
    return sanitized;
  }

  return obj;
}

export function sanitizeInput(req, _res, next) {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeObject(req.body);
  }
  if (req.query && typeof req.query === 'object') {
    req.query = sanitizeObject(req.query);
  }
  if (req.params && typeof req.params === 'object') {
    req.params = sanitizeObject(req.params);
  }
  next();
}

const ALLOWED_CONTENT_TYPES = {
  json: ['application/json'],
  form: ['application/x-www-form-urlencoded'],
  multipart: ['multipart/form-data'],
  none: ['text/plain'],
};

export function validateContentType(allowed = ['json']) {
  return (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      return next();
    }

    const contentType = req.headers['content-type'] || '';

    if (!contentType && req.method === 'GET') {
      return next();
    }

    if (!contentType) {
      return res.status(415).json({
        success: false,
        message: 'Content-Type header is required',
      });
    }

    const normalizedType = contentType.split(';')[0].trim().toLowerCase();

    const allowedTypes = allowed.flatMap((type) => ALLOWED_CONTENT_TYPES[type] || [type]);

    if (!allowedTypes.some((t) => normalizedType.startsWith(t.split(';')[0].trim()))) {
      return res.status(415).json({
        success: false,
        message: `Unsupported Content-Type. Allowed: ${allowed.join(', ')}`,
      });
    }

    next();
  };
}

const STATUS_COLORS = {
  1: '\x1b[36m',
  2: '\x1b[32m',
  3: '\x1b[33m',
  4: '\x1b[31m',
  5: '\x1b[35m',
  reset: '\x1b[0m',
};

function getStatusColor(status) {
  const prefix = String(status)[0];
  return STATUS_COLORS[prefix] || STATUS_COLORS.reset;
}

function formatDuration(ms) {
  if (ms >= 1000) return `${(ms / 1000).toFixed(2)}s`;
  return `${ms.toFixed(1)}ms`;
}

export function requestLogger(req, res, next) {
  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const end = process.hrtime.bigint();
    const durationNs = Number(end - start);
    const durationMs = durationNs / 1e6;
    const status = res.statusCode;
    const color = getStatusColor(status);

    const logLine = [
      `${color}${status}${STATUS_COLORS.reset}`,
      req.method.padEnd(7),
      req.originalUrl,
      formatDuration(durationMs).padStart(10),
      req.ip || '-',
      req.get('user-agent')?.substring(0, 40) || '-',
    ].join(' ');

    if (status >= 500) {
      console.error(`[REQ] ${logLine}`);
    } else if (status >= 400) {
      console.warn(`[REQ] ${logLine}`);
    } else {
      console.log(`[REQ] ${logLine}`);
    }
  });

  next();
}

export function requestId(req, _res, next) {
  const id = req.headers['x-request-id'] || randomUUID();
  req.id = id;
  if (_res.set) {
    _res.set('X-Request-Id', id);
  }
  next();
}

const TRUSTED_PROXY_HEADERS = [
  'x-forwarded-for',
  'x-real-ip',
  'cf-connecting-ip',
  'x-client-ip',
  'x-cluster-client-ip',
  'fastly-client-ip',
  'true-client-ip',
  'x-forwarded',
  'forwarded-for',
  'forwarded',
];

export function ipTracker(req, _res, next) {
  let ip = null;

  for (const header of TRUSTED_PROXY_HEADERS) {
    const value = req.headers[header];
    if (value) {
      const first = value.split(',')[0].trim();
      if (first && first !== 'unknown') {
        ip = first;
        break;
      }
    }
  }

  if (!ip) {
    ip = req.socket?.remoteAddress || req.ip || 'unknown';
  }

  if (ip.startsWith('::ffff:')) {
    ip = ip.slice(7);
  }

  if (ip === '::1' || ip === '127.0.0.1') {
    ip = '127.0.0.1';
  }

  req.realIp = ip;
  next();
}

const SQL_INJECTION_PATTERNS = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE|UNION|FETCH|DECLARE|TRUNCATE|COMMENT)\b)/i,
  /(\/\*|\*\/|;--|--|;)/,
  /(\b(OR|AND)\b\s+\d+\s*=\s*\d+)/i,
  /('\s*(OR|AND)\s+')/i,
  /(CHAR\s*\(|CONCAT\s*\(|0x[0-9a-f]+)/i,
];

export function sqlInjectionGuard(req, res, next) {
  const inputs = [
    JSON.stringify(req.body || {}),
    JSON.stringify(req.query || {}),
    JSON.stringify(req.params || {}),
    req.originalUrl,
  ].join(' ');

  for (const pattern of SQL_INJECTION_PATTERNS) {
    if (pattern.test(inputs)) {
      console.warn(`[SECURITY] Possible SQL injection attempt from ${req.ip}: ${req.originalUrl}`);
      return res.status(400).json({
        success: false,
        message: 'Invalid input detected',
      });
    }
  }

  next();
}

export function securityHeaders(_req, res, next) {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(self), payment=(self)',
  });
  next();
}
