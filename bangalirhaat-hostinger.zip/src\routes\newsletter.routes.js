import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';

const router = Router();

router.post('/subscribe', [
  body('email').trim().isEmail().withMessage('Valid email is required'),
  body('name').optional().trim(),
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    const db = getDb();
    const { email, name } = req.body;
    const existing = db.prepare('SELECT id FROM newsletter_subscribers WHERE email = ?').get(email);
    if (existing) {
      db.prepare('UPDATE newsletter_subscribers SET is_active = 1, unsubscribed_at = NULL WHERE id = ?').run(existing.id);
      return res.json({ success: true, message: 'You are already subscribed!' });
    }
    db.prepare(
      'INSERT INTO newsletter_subscribers (email, name, subscribed_at) VALUES (?, ?, datetime(\'now\'))'
    ).run(email, name || null);
    res.json({ success: true, message: 'Subscribed successfully! Check your email for a welcome offer.' });
  } catch (error) { next(error); }
});

router.post('/unsubscribe', [
  body('email').trim().isEmail().withMessage('Valid email is required'),
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    const db = getDb();
    const { email } = req.body;
    db.prepare(
      "UPDATE newsletter_subscribers SET is_active = 0, unsubscribed_at = datetime('now') WHERE email = ?"
    ).run(email);
    res.json({ success: true, message: 'Unsubscribed successfully.' });
  } catch (error) { next(error); }
});

export default router;
