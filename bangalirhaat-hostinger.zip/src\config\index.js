import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..', '..');

function env(key, fallback = undefined) {
  const value = process.env[key];
  if (value === undefined || value === '') {
    if (fallback === undefined) {
      throw new Error(`Missing required environment variable: ${key}`);
    }
    return fallback;
  }
  return value;
}

function envInt(key, fallback) {
  const raw = process.env[key];
  if (raw === undefined || raw === '') {
    if (fallback === undefined) {
      throw new Error(`Missing required environment variable: ${key}`);
    }
    return fallback;
  }
  const parsed = parseInt(raw, 10);
  if (Number.isNaN(parsed)) {
    throw new Error(`Environment variable ${key} must be an integer, got: "${raw}"`);
  }
  return parsed;
}

function envBool(key, fallback) {
  const raw = process.env[key];
  if (raw === undefined || raw === '') {
    if (fallback === undefined) {
      throw new Error(`Missing required environment variable: ${key}`);
    }
    return fallback;
  }
  return raw === 'true' || raw === '1';
}

const config = {
  env: env('NODE_ENV', 'development'),
  isProduction: env('NODE_ENV', 'development') === 'production',
  isDevelopment: env('NODE_ENV', 'development') === 'development',
  isTest: env('NODE_ENV', 'development') === 'test',

  root: ROOT,

  server: {
    port: envInt('PORT', 5000),
  },

  jwt: {
    secret: env('JWT_SECRET', 'dev-jwt-secret-fallback'),
    expiresIn: env('JWT_EXPIRES_IN', '7d'),
    refreshSecret: env('JWT_REFRESH_SECRET', 'dev-refresh-secret-fallback'),
    refreshExpiresIn: env('JWT_REFRESH_EXPIRES_IN', '30d'),
  },

  db: {
    path: path.resolve(ROOT, env('DB_PATH', './data/bangalirhaat.db')),
  },

  smtp: {
    host: env('SMTP_HOST', 'smtp.gmail.com'),
    port: envInt('SMTP_PORT', 587),
    user: env('SMTP_USER', ''),
    pass: env('SMTP_PASS', ''),
    from: env('SMTP_FROM', '"Bangalirhaat" <noreply@bangalirhaat.com>'),
  },

  courier: {
    steadfast: {
      apiKey: env('STEADFAST_API_KEY', ''),
      apiSecret: env('STEADFAST_API_SECRET', ''),
      url: env('STEADFAST_URL', 'https://portal.packzy.com/api/v1'),
      webhookToken: env('STEADFAST_WEBHOOK_TOKEN', ''),
    },
    sf2: {
      apiKey: env('STEADFAST_SF2_API_KEY', ''),
      apiSecret: env('STEADFAST_SF2_API_SECRET', ''),
      url: env('STEADFAST_URL', 'https://portal.packzy.com/api/v1'),
      webhookToken: env('STEADFAST_WEBHOOK_TOKEN', ''),
    },
  },

  upload: {
    cloudinaryUrl: env('CLOUDINARY_URL', ''),
    localPath: path.resolve(ROOT, env('IMG_UPLOAD_PATH', './public/uploads')),
  },

  cors: {
    origins: env('CORS_ORIGINS', '*')
      .split(',')
      .map((o) => o.trim())
      .filter(Boolean),
  },

  rateLimit: {
    windowMs: envInt('RATE_LIMIT_WINDOW_MS', 900000),
    max: envInt('RATE_LIMIT_MAX', 100),
  },

  session: {
    secret: env('SESSION_SECRET', 'dev-session-secret-fallback'),
  },

  stripe: {
    secretKey: env('STRIPE_SECRET_KEY', ''),
    webhookSecret: env('STRIPE_WEBHOOK_SECRET', ''),
  },

  sslcommerz: {
    storeId: env('SSLCOMMERZ_STORE_ID', ''),
    storePass: env('SSLCOMMERZ_STORE_PASS', ''),
  },

  maintenance: {
    enabled: envBool('MAINTENANCE_MODE', false),
    message: env('MAINTENANCE_MESSAGE', 'We are currently performing scheduled maintenance. Please check back shortly.'),
  },
};

export default config;
