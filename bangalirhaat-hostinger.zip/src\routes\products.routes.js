import { Router } from 'express';
import { query, param, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { optionalAuth } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

const listValidation = [
  query('page').optional().isInt({ min: 1 }).toInt().withMessage('Page must be positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).toInt().withMessage('Limit must be 1-100'),
  query('sort').optional().isIn(['price_asc', 'price_desc', 'newest', 'oldest', 'popular', 'trending', 'bestselling', 'name_asc', 'name_desc', 'rating'])
    .withMessage('Invalid sort option'),
  query('min_price').optional().isFloat({ min: 0 }).toFloat().withMessage('Min price must be positive'),
  query('max_price').optional().isFloat({ min: 0 }).toFloat().withMessage('Max price must be positive'),
  query('category').optional().isInt({ min: 1 }).toInt(),
  query('brand').optional().isString().trim(),
  query('search').optional().isString().trim().isLength({ min: 1, max: 200 }),
];

const slugValidation = [
  param('slug').isString().trim().isLength({ min: 1, max: 200 }),
];

const idValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid product ID'),
];

router.get('/', listValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const page = req.query.page || 1;
    const limit = req.query.limit || 20;
    const offset = (page - 1) * limit;
    const sort = req.query.sort || 'newest';

    let where = ['p.is_active = 1'];
    let params = [];

    if (req.query.category) {
      where.push('p.category_id = ?');
      params.push(req.query.category);
    }

    if (req.query.brand) {
      where.push('b.name = ?');
      params.push(req.query.brand);
    }

    if (req.query.min_price) {
      where.push('p.price >= ?');
      params.push(req.query.min_price);
    }

    if (req.query.max_price) {
      where.push('p.price <= ?');
      params.push(req.query.max_price);
    }

    if (req.query.search) {
      where.push('(p.name LIKE ? OR p.description LIKE ? OR b.name LIKE ?)');
      const searchTerm = `%${req.query.search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    if (req.query.featured === 'true' || req.query.featured === '1') {
      where.push('p.is_featured = 1');
    }

    if (req.query.flashSale === 'true' || req.query.flashSale === '1') {
      where.push('p.is_featured = 1');
    }

    const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';

    let orderClause;
    switch (sort) {
      case 'price_asc': orderClause = 'ORDER BY p.price ASC'; break;
      case 'price_desc': orderClause = 'ORDER BY p.price DESC'; break;
      case 'newest': orderClause = 'ORDER BY p.created_at DESC'; break;
      case 'oldest': orderClause = 'ORDER BY p.created_at ASC'; break;
      case 'popular': orderClause = 'ORDER BY p.total_sold DESC'; break;
      case 'trending': orderClause = 'ORDER BY p.total_sold DESC, p.average_rating DESC'; break;
      case 'bestselling': orderClause = 'ORDER BY p.total_sold DESC'; break;
      case 'name_asc': orderClause = 'ORDER BY p.name ASC'; break;
      case 'name_desc': orderClause = 'ORDER BY p.name DESC'; break;
      case 'rating': orderClause = 'ORDER BY p.average_rating DESC'; break;
      default: orderClause = 'ORDER BY p.created_at DESC';
    }

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM products p ${whereClause}`
    ).get(...params);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.review_count,
               p.total_sold, p.is_featured, p.created_at, p.stock_quantity,
               b.name as brand_name,
              c.name as category_name, c.slug as category_slug,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN categories c ON p.category_id = c.id
       ${whereClause}
       ${orderClause}
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        products,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/featured', async (req, res, next) => {
  try {
    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 12, 50);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.total_sold, p.stock_quantity,
               b.name as brand_name,
               c.name as category_name,
               (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1 AND p.is_featured = 1
       ORDER BY p.created_at DESC
       LIMIT ?`
    ).all(limit);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.get('/trending', async (req, res, next) => {
  try {
    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 12, 50);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.total_sold, p.stock_quantity,
               b.name as brand_name,
               c.name as category_name,
               (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1
        ORDER BY p.total_sold DESC, p.created_at DESC
        LIMIT ?`
    ).all(limit);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.get('/new-arrivals', async (req, res, next) => {
  try {
    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 12, 50);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.stock_quantity,
               b.name as brand_name,
              c.name as category_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.is_active = 1
       ORDER BY p.created_at DESC
       LIMIT ?`
    ).all(limit);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.get('/best-sellers', async (req, res, next) => {
  try {
    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 12, 50);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.total_sold, p.stock_quantity,
               b.name as brand_name,
               c.name as category_name,
               (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1 AND p.total_sold > 0
       ORDER BY p.total_sold DESC
       LIMIT ?`
    ).all(limit);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.get('/flash-sales', async (req, res, next) => {
  try {
    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 12, 50);

    const products = db.prepare(
`SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.stock_quantity,
               b.name as brand_name,
               c.name as category_name,
               (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1 AND p.is_featured = 1
        ORDER BY p.created_at DESC
        LIMIT ?`
    ).all(limit);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.get('/search', async (req, res, next) => {
  try {
    const searchTerm = req.query.q;
    if (!searchTerm || searchTerm.trim().length === 0) {
      return res.json({ success: true, data: { products: [] } });
    }

    const db = getDb();
    const limit = Math.min(parseInt(req.query.limit) || 20, 50);
    const term = `%${searchTerm.trim()}%`;

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating, p.stock_quantity,
               b.name as brand_name,
               c.name as category_name,
               (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active = 1
          AND (p.name LIKE ? OR p.description LIKE ? OR b.name LIKE ? OR p.tags LIKE ?)
       ORDER BY
         CASE WHEN p.name LIKE ? THEN 0 WHEN b.name LIKE ? THEN 1 ELSE 2 END,
         p.total_sold DESC
       LIMIT ?`
    ).all(term, term, term, term, term, term, limit);

    res.json({ success: true, data: { products, query: searchTerm.trim() } });
  } catch (error) {
    next(error);
  }
});

router.get('/compare', async (req, res, next) => {
  try {
    const ids = req.query.ids;
    if (!ids) {
      return res.json({ success: true, data: { products: [] } });
    }

    const idArray = ids.split(',').map(id => parseInt(id.trim())).filter(id => !isNaN(id) && id > 0);
    if (idArray.length === 0) {
      return res.json({ success: true, data: { products: [] } });
    }

    const limited = idArray.slice(0, 4);
    const placeholders = limited.map(() => '?').join(',');

    const db = getDb();
    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.short_description, p.description,
              p.average_rating, p.review_count, p.stock_quantity, p.sku, p.tags,
              b.name as brand_name,
              c.name as category_name, c.slug as category_slug
       FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.id IN (${placeholders}) AND p.is_active = 1`
    ).all(...limited);

    const productsWithImages = products.map(product => {
      const images = db.prepare(
        'SELECT url, alt_text, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order'
      ).all(product.id);
      return { ...product, images };
    });

    res.json({ success: true, data: { products: productsWithImages } });
  } catch (error) {
    next(error);
  }
});

router.get('/:id/specs', async (req, res, next) => {
  try {
    const { id } = req.params;
    const db = getDb();

    const tableCheck = db.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND (name='product_specs' OR name='product_attributes')"
    ).get();

    if (tableCheck) {
      const tableName = tableCheck.name;
      const specs = db.prepare(
        `SELECT name, value FROM ${tableName} WHERE product_id = ?`
      ).all(Number(id));
      return res.json({ success: true, data: specs });
    }

    res.json({ success: true, data: [] });
  } catch (error) {
    next(error);
  }
});

router.get('/:identifier', async (req, res, next) => {
  try {
    const { identifier } = req.params;
    const isId = /^\d+$/.test(identifier);
    const db = getDb();

    let product;
    if (isId) {
      product = db.prepare(
        `SELECT p.*, b.name as brand_name, c.name as category_name, c.slug as category_slug
         FROM products p
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.id = ? AND p.is_active = 1`
      ).get(Number(identifier));
    } else {
      product = db.prepare(
        `SELECT p.*, b.name as brand_name, c.name as category_name, c.slug as category_slug
         FROM products p
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.slug = ? AND p.is_active = 1`
      ).get(identifier);
    }

    if (!product) {
      throw new AppError('Product not found', 404);
    }

    const images = db.prepare(
      'SELECT id, url, alt_text, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY sort_order'
    ).all(product.id);

    const variants = db.prepare(
      `SELECT id, name, price, compare_price, stock_quantity, sku, is_active, color, size
       FROM product_variants
       WHERE product_id = ? AND is_active = 1`
    ).all(product.id);

    const reviewsSummary = db.prepare(
      `SELECT COUNT(*) as total_reviews, 
              AVG(rating) as avg_rating,
              SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
              SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
              SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
              SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
              SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star
       FROM product_reviews WHERE product_id = ? AND is_approved = 1`
    ).get(product.id);

    const recentReviews = db.prepare(
      `SELECT r.id, r.rating, r.comment, r.created_at,
              u.first_name || ' ' || u.last_name as user_name, u.avatar as user_avatar
       FROM product_reviews r
       JOIN users u ON r.user_id = u.id
       WHERE r.product_id = ? AND r.is_approved = 1
       ORDER BY r.created_at DESC
       LIMIT 5`
    ).all(product.id);

    res.json({
      success: true,
      data: {
        product: {
          ...product,
          images,
          variants,
          reviews: {
            summary: reviewsSummary,
            recent: recentReviews,
          },
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
