import { getDb } from './db.js';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { initializeDatabase } from './db.js';

export function seedDatabase(db) {
    console.log('[Seed] Seeding data...');

    // ── USERS ──────────────────────────────────────────────────────────────

    const users = [
      { email: 'admin@bangalirhaat.com', password: 'Admin@123',    first_name: 'Super', last_name: 'Admin', role: 'super_admin', is_active: 1, email_verified: 1, loyalty_points: 5000, wallet_balance: 0 },
      { email: 'manager@bangalirhaat.com', password: 'Manager@123', first_name: 'Admin', last_name: 'User',  role: 'admin',       is_active: 1, email_verified: 1, loyalty_points: 1000, wallet_balance: 0 },
      { email: 'staff@bangalirhaat.com',   password: 'Staff@123',   first_name: 'Staff', last_name: 'User',  role: 'staff',       is_active: 1, email_verified: 1, loyalty_points: 500,  wallet_balance: 0 },
      { email: 'mod@bangalirhaat.com',     password: 'Mod@123',     first_name: 'Mod',   last_name: 'User',  role: 'moderator',   is_active: 1, email_verified: 1, loyalty_points: 300,  wallet_balance: 0 },
      { email: 'customer@bangalirhaat.com', password: 'Customer@123', first_name: 'Rahim', last_name: 'Miah', role: 'customer',   is_active: 1, email_verified: 1, loyalty_points: 200,  wallet_balance: 500 },
    ];

    const insertUser = db.prepare(`INSERT INTO users (uuid, email, password_hash, first_name, last_name, role, is_active, email_verified, loyalty_points, wallet_balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const userIds = [];
    for (const u of users) {
      const hash = bcrypt.hashSync(u.password, 10);
      const uuid = uuidv4();
      const info = insertUser.run(uuid, u.email, hash, u.first_name, u.last_name, u.role, u.is_active, u.email_verified, u.loyalty_points, u.wallet_balance);
      userIds.push(info.lastInsertRowid);
      console.log(`[Seed] Created user: ${u.email} (${u.role})`);
    }

    // address for customer
    db.prepare(`INSERT INTO user_addresses (user_id, label, full_name, phone, division, district, upazila, address_line1, is_default) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(userIds[4], 'home', 'Rahim Miah', '01712345678', 'Dhaka', 'Dhaka', 'Mirpur', '123 Mirpur Road, Dhaka', 1);

    // ── CATEGORIES ─────────────────────────────────────────────────────────

    const categoriesData = [
      { name: 'Electronics',   slug: 'electronics',   description: 'Gadgets, mobile phones, computers & accessories', image: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=600' },
      { name: 'Fashion',       slug: 'fashion',       description: 'Traditional & modern clothing for men, women & kids', image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600' },
      { name: 'Home & Living', slug: 'home-living',   description: 'Furniture, decor, kitchenware & home appliances', image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600' },
      { name: 'Beauty',        slug: 'beauty',        description: 'Skincare, haircare, cosmetics & personal care', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600' },
      { name: 'Sports',        slug: 'sports',        description: 'Sports equipment, gym gear & activewear', image: 'https://images.unsplash.com/photo-1461896836934-bd45ba79e9d9?w=600' },
      { name: 'Books',         slug: 'books',         description: 'Books, stationery & educational materials', image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600' },
      { name: 'Grocery',       slug: 'grocery',       description: 'Fresh food, pantry staples & beverages', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600' },
      { name: 'Health',        slug: 'health',        description: 'Health supplements, medicines & wellness products', image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600' },
    ];

    const insertCategory = db.prepare(`INSERT INTO categories (uuid, name, slug, description, image, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)`);
    const catIds = {};
    for (const c of categoriesData) {
      const uuid = uuidv4();
      const info = insertCategory.run(uuid, c.name, c.slug, c.description, c.image, Object.keys(catIds).length);
      catIds[c.slug] = info.lastInsertRowid;
      console.log(`[Seed] Created category: ${c.name}`);
    }

    // Subcategories
    const subcategories = [
      { name: 'Mobile Phones',  slug: 'mobile-phones',  parent: 'electronics', description: 'Smartphones & feature phones' },
      { name: 'Laptops',        slug: 'laptops',        parent: 'electronics', description: 'Laptops & notebooks' },
      { name: 'Men\'s Fashion', slug: 'mens-fashion',   parent: 'fashion',     description: 'Clothing for men' },
      { name: 'Women\'s Fashion', slug: 'womens-fashion', parent: 'fashion',  description: 'Clothing for women' },
      { name: 'Saree',           slug: 'saree',         parent: 'fashion',     description: 'Handwoven traditional Bangladeshi sarees' },
      { name: 'Kitchen',        slug: 'kitchen',        parent: 'home-living', description: 'Kitchen appliances & utensils' },
      { name: 'Skincare',       slug: 'skincare',       parent: 'beauty',      description: 'Facial & body skincare' },
      { name: 'Fitness',        slug: 'fitness',        parent: 'sports',      description: 'Gym & fitness equipment' },
      { name: 'Academic Books', slug: 'academic-books', parent: 'books',       description: 'Textbooks & academic materials' },
    ];

    const insertSub = db.prepare(`INSERT INTO categories (uuid, name, slug, description, parent_id, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)`);
    const subCatIds = {};
    for (const sc of subcategories) {
      const uuid = uuidv4();
      const info = insertSub.run(uuid, sc.name, sc.slug, sc.description, catIds[sc.parent], Object.keys(subCatIds).length);
      subCatIds[sc.slug] = info.lastInsertRowid;
      console.log(`[Seed] Created subcategory: ${sc.name}`);
    }

    // ── BRANDS ─────────────────────────────────────────────────────────────

    const brandsData = [
      { name: 'Samsung',      slug: 'samsung',        description: 'South Korean electronics giant' },
      { name: 'Apple',        slug: 'apple',          description: 'American tech company' },
      { name: 'Nike',         slug: 'nike',           description: 'American sportswear brand' },
      { name: 'Adidas',       slug: 'adidas',         description: 'German sportswear brand' },
      { name: 'Pran',         slug: 'pran',           description: 'Leading Bangladeshi food & beverage brand' },
      { name: 'Aarong',       slug: 'aarong',         description: 'Bangladeshi ethnic fashion & handicrafts' },
    ];

    const insertBrand = db.prepare(`INSERT INTO brands (uuid, name, slug, description, is_active) VALUES (?, ?, ?, ?, 1)`);
    const brandIds = {};
    for (const b of brandsData) {
      const uuid = uuidv4();
      const info = insertBrand.run(uuid, b.name, b.slug, b.description);
      brandIds[b.slug] = info.lastInsertRowid;
      console.log(`[Seed] Created brand: ${b.name}`);
    }

    // ── PRODUCTS ───────────────────────────────────────────────────────────

    const productsData = [
      // Electronics
      { name: 'Samsung Galaxy S24 Ultra',       slug: 'samsung-galaxy-s24-ultra',       sku: 'SAM-S24U-BLK',    barcode: '8806094785234', cat: 'mobile-phones', brand: 'samsung', price: 135000, compare_price: 145000, cost_price: 115000, stock: 50, desc: '12GB RAM, 256GB Storage, 200MP Camera', is_featured: 1 },
      { name: 'Apple iPhone 16 Pro Max',        slug: 'apple-iphone-16-pro-max',        sku: 'APL-IP16PM-NAT',  barcode: '8806094785235', cat: 'mobile-phones', brand: 'apple',   price: 165000, compare_price: 175000, cost_price: 140000, stock: 35, desc: '256GB, A18 Pro Chip, Titanium Design', is_featured: 1 },
      { name: 'Samsung Galaxy Book 4 Pro',      slug: 'samsung-galaxy-book-4-pro',      sku: 'SAM-GB4P-SLV',    barcode: '8806094785236', cat: 'laptops',      brand: 'samsung', price: 145000, compare_price: 155000, cost_price: 120000, stock: 20, desc: '16GB RAM, 512GB SSD, Intel Core Ultra 7', is_featured: 0 },
      { name: 'Apple MacBook Air M3',           slug: 'apple-macbook-air-m3',            sku: 'APL-MBA3-SP',     barcode: '8806094785237', cat: 'laptops',      brand: 'apple',   price: 135000, compare_price: 145000, cost_price: 115000, stock: 25, desc: '15-inch, 8GB RAM, 256GB SSD', is_featured: 1 },
      { name: 'Sony WH-1000XM6 Headphones',     slug: 'sony-wh-1000xm6',                 sku: 'SONY-WHXM6-BLK',  barcode: '8806094785238', cat: 'electronics',  brand: null,     price: 32000,  compare_price: 35000,  cost_price: 25000,  stock: 40, desc: 'Wireless Noise Cancelling Headphones', is_featured: 0 },

      // Fashion
      { name: 'Jamdani Cotton Saree',           slug: 'jamdani-cotton-saree',            sku: 'AAR-JAM-SAR-01',  barcode: '8806094785239', cat: 'saree',        brand: 'aarong', price: 8500,   compare_price: 10000,  cost_price: 6000,   stock: 100, desc: 'Handwoven pure cotton Jamdani saree', is_featured: 1 },
      { name: 'Silk Tangail Saree',             slug: 'silk-tangail-saree',              sku: 'AAR-TNG-SLK-01',  barcode: '8806094785240', cat: 'saree',        brand: 'aarong', price: 12000,  compare_price: 15000,  cost_price: 8500,   stock: 60,  desc: 'Pure silk Tangail weave saree', is_featured: 0 },
      { name: 'Men\'s Cotton Lungi',            slug: 'mens-cotton-lungi',               sku: 'FASH-LNG-COT-01', barcode: '8806094785241', cat: 'mens-fashion',  brand: null,     price: 550,    compare_price: 650,     cost_price: 350,    stock: 500, desc: 'Traditional Bangladeshi cotton lungi', is_featured: 0 },
      { name: 'Panjabi Set - White',            slug: 'panjabi-set-white',               sku: 'FASH-PNJ-WHT-01', barcode: '8806094785242', cat: 'mens-fashion',  brand: null,     price: 2500,   compare_price: 3000,   cost_price: 1600,   stock: 200, desc: 'Cotton panjabi with pyjama set', is_featured: 1 },
      { name: 'Nike Air Max 270',               slug: 'nike-air-max-270',                sku: 'NKE-AM270-WHT',   barcode: '8806094785243', cat: 'mens-fashion',  brand: 'nike',   price: 16500,  compare_price: 18500,  cost_price: 12000,  stock: 80,  desc: 'Air Max 270 sneakers - white/black', is_featured: 0 },

      // Home & Living
      { name: 'Nakshi Kantha Bed Sheet',        slug: 'nakshi-kantha-bed-sheet',         sku: 'AAR-NKS-BED-01',  barcode: '8806094785244', cat: 'home-living',   brand: 'aarong', price: 3200,   compare_price: 4000,   cost_price: 2200,   stock: 150, desc: 'Traditional Nakshi Kantha embroidered bedsheet', is_featured: 1 },
      { name: 'Brass Showpiece Set',            slug: 'brass-showpiece-set',             sku: 'HOME-BRS-SP-01',  barcode: '8806094785245', cat: 'home-living',   brand: null,     price: 4500,   compare_price: 5500,   cost_price: 3000,   stock: 40,  desc: 'Handcrafted brass decor set (3 pcs)', is_featured: 0 },
      { name: 'Clay Water Pot (Matir Kolshi)',  slug: 'clay-water-pot-matir-kolshi',     sku: 'HOME-CLY-POT-01', barcode: '8806094785246', cat: 'kitchen',      brand: null,     price: 350,    compare_price: 450,     cost_price: 200,    stock: 300, desc: 'Traditional earthenware water pot', is_featured: 0 },

      // Beauty
      { name: 'Kohl Kajal Eye Liner',           slug: 'kohl-kajal-eye-liner',            sku: 'BEAU-KAJ-001',    barcode: '8806094785247', cat: 'beauty',       brand: null,     price: 250,    compare_price: 300,     cost_price: 120,    stock: 500, desc: 'Traditional Bangladeshi kohl kajal', is_featured: 0 },
      { name: 'Neem Face Wash 100ml',           slug: 'neem-face-wash-100ml',            sku: 'BEAU-NEEM-001',   barcode: '8806094785248', cat: 'skincare',     brand: null,     price: 320,    compare_price: 400,     cost_price: 180,    stock: 400, desc: 'Natural neem face wash for acne-prone skin', is_featured: 0 },
      { name: 'Coconut Hair Oil 500ml',         slug: 'coconut-hair-oil-500ml',          sku: 'BEAU-COCO-001',   barcode: '8806094785249', cat: 'beauty',       brand: null,     price: 450,    compare_price: 550,     cost_price: 280,    stock: 350, desc: 'Pure cold-pressed coconut hair oil', is_featured: 0 },

      // Sports
      { name: 'Adidas Predator Football Boots', slug: 'adidas-predator-football-boots',  sku: 'ADI-PRED-001',    barcode: '8806094785250', cat: 'sports',       brand: 'adidas', price: 12000,  compare_price: 14000,  cost_price: 8500,   stock: 30,  desc: 'Predator Accuracy.3 FG football boots', is_featured: 0 },
      { name: 'Cricket Bat - English Willow',   slug: 'cricket-bat-english-willow',      sku: 'SPRT-CRBAT-001',  barcode: '8806094785251', cat: 'sports',       brand: null,     price: 5500,   compare_price: 6500,   cost_price: 3800,   stock: 45,  desc: 'Grade 1 English Willow cricket bat', is_featured: 1 },
      { name: 'Yoga Mat Premium',               slug: 'yoga-mat-premium',                 sku: 'SPRT-YOGA-001',   barcode: '8806094785252', cat: 'fitness',      brand: null,     price: 1800,   compare_price: 2200,   cost_price: 1100,   stock: 120, desc: '6mm thick TPE yoga mat with carrying strap', is_featured: 0 },

      // Books
      { name: 'Bangladesh: A Legacy of Liberation', slug: 'bangladesh-legacy-liberation', sku: 'BKS-BLL-001',    barcode: '8806094785253', cat: 'books',        brand: null,     price: 850,    compare_price: 1000,   cost_price: 500,    stock: 200, desc: 'History of Bangladesh Liberation War', is_featured: 0 },
      { name: 'Himu Series - Set of 5',         slug: 'himu-series-set-5',               sku: 'BKS-HIMU-001',    barcode: '8806094785254', cat: 'books',        brand: null,     price: 1200,   compare_price: 1500,   cost_price: 750,    stock: 150, desc: 'Humayun Ahmed\'s Himu series box set', is_featured: 1 },
      { name: 'Engineering Mathematics',        slug: 'engineering-mathematics',          sku: 'BKS-ENGMATH-01',  barcode: '8806094785255', cat: 'academic-books', brand: null,  price: 950,    compare_price: 1100,   cost_price: 600,    stock: 100, desc: 'Comprehensive engineering mathematics guide', is_featured: 0 },

      // Grocery
      { name: 'Pran Mango Juice 1L',            slug: 'pran-mango-juice-1l',             sku: 'PRN-MJ-1L-001',   barcode: '8806094785256', cat: 'grocery',      brand: 'pran',   price: 120,    compare_price: 150,     cost_price: 80,     stock: 1000, desc: 'Pran natural mango juice 1 litre', is_featured: 0 },
      { name: 'Pran Fortified Biscuits 400g',   slug: 'pran-fortified-biscuits-400g',    sku: 'PRN-BSC-400-01',  barcode: '8806094785257', cat: 'grocery',      brand: 'pran',   price: 180,    compare_price: 220,     cost_price: 120,    stock: 800, desc: 'Vitamin-enriched biscuits family pack', is_featured: 0 },
      { name: 'Miniket Rice 5kg',               slug: 'miniket-rice-5kg',                 sku: 'GROC-RICE-MK-01', barcode: '8806094785258', cat: 'grocery',      brand: null,     price: 650,    compare_price: 750,     cost_price: 500,    stock: 200, desc: 'Premium Miniket rice 5kg bag', is_featured: 0 },
      { name: 'Mustard Oil 1L',                 slug: 'mustard-oil-1l',                   sku: 'GROC-MOIL-1L',   barcode: '8806094785259', cat: 'grocery',      brand: null,     price: 420,    compare_price: 500,     cost_price: 320,    stock: 300, desc: 'Pure mustard cooking oil', is_featured: 0 },

      // Health
      { name: 'Vitamin D3 Supplement 60 Caps',  slug: 'vitamin-d3-supplement-60-caps',   sku: 'HLTH-D3-001',     barcode: '8806094785260', cat: 'health',       brand: null,     price: 750,    compare_price: 900,     cost_price: 500,    stock: 150, desc: 'Vitamin D3 1000IU supplement', is_featured: 0 },
      { name: 'Organic Green Tea 50 Bags',      slug: 'organic-green-tea-50-bags',       sku: 'HLTH-GTEA-001',  barcode: '8806094785261', cat: 'health',       brand: null,     price: 380,    compare_price: 450,     cost_price: 220,    stock: 250, desc: 'Premium organic green tea bags', is_featured: 0 },
      { name: 'Multivitamin Daily Pack',        slug: 'multivitamin-daily-pack',          sku: 'HLTH-MV-001',     barcode: '8806094785262', cat: 'health',       brand: null,     price: 1200,   compare_price: 1400,   cost_price: 800,    stock: 100, desc: 'Complete daily multivitamin pack 30 strips', is_featured: 0 },

      // More fashion
      { name: 'Nike Dri-FIT T-Shirt',           slug: 'nike-dri-fit-tshirt',              sku: 'NKE-DFT-BLK',     barcode: '8806094785263', cat: 'mens-fashion',  brand: 'nike',   price: 3500,   compare_price: 4200,   cost_price: 2400,   stock: 120, desc: 'Performance Dri-FIT training t-shirt', is_featured: 0 },
      { name: 'Adidas Runfalcon 5 Shoes',       slug: 'adidas-runfalcon-5',               sku: 'ADI-RF5-GRY',     barcode: '8806094785264', cat: 'sports',       brand: 'adidas', price: 7500,   compare_price: 9000,   cost_price: 5200,   stock: 60,  desc: 'Lightweight running shoes', is_featured: 0 },
      { name: 'Three-Piece Women\'s Dress',     slug: 'three-piece-womens-dress',         sku: 'AAR-3PC-001',     barcode: '8806094785265', cat: 'womens-fashion', brand: 'aarong', price: 4500,   compare_price: 5500,   cost_price: 3000,   stock: 90,  desc: 'Cotton three-piece embroidered dress set', is_featured: 1 },
    ];

    const insertProduct = db.prepare(`INSERT INTO products (uuid, name, slug, description, sku, barcode, brand_id, category_id, price, compare_price, cost_price, stock_quantity, is_active, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`);
    const productIds = [];
    for (const p of productsData) {
      const catId = subCatIds[p.cat] || catIds[p.cat];
      const brandId = p.brand ? brandIds[p.brand] : null;
      const uuid = uuidv4();
      const info = insertProduct.run(uuid, p.name, p.slug, p.desc, p.sku, p.barcode, brandId, catId, p.price, p.compare_price || null, p.cost_price || null, p.stock, p.is_featured);
      productIds.push(info.lastInsertRowid);
      console.log(`[Seed] Created product: ${p.name}`);
    }

    // ── PRODUCT IMAGES ─────────────────────────────────────────────────────

    const productImages = [
      'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600',   // Samsung Galaxy
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=600',   // iPhone
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600',   // Samsung laptop
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600',   // MacBook
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',   // Headphones
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600',   // Jamdani saree
      'https://images.unsplash.com/photo-1578632292335-df3abbb0d586?w=600',   // Silk saree
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600',   // Lungi
      'https://images.unsplash.com/photo-1590735213920-68192a487bc2?w=600',   // Panjabi
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600',   // Nike shoes
      'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600',   // Bedsheet
      'https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=600',   // Brass showpiece
      'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=600',   // Clay pot
      'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600',   // Kajal
      'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600',   // Face wash
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600',   // Coconut oil
      'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=600',   // Football boots
      'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=600',   // Cricket bat
      'https://images.unsplash.com/photo-1601422407692-ec4eeec1d9b3?w=600',   // Yoga mat
      'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600',   // Book legacy
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600',   // Book set
      'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600',   // Math book
      'https://images.unsplash.com/photo-1622485831930-56a0c47f0a60?w=600',   // Mango juice
      'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600',   // Biscuits
      'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600',   // Rice bag
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600',   // Mustard oil
      'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600',   // Vitamin
      'https://images.unsplash.com/photo-1563822249366-3efb23b8e0c9?w=600',   // Green tea
      'https://images.unsplash.com/photo-1550572017-edd951b55104?w=600',   // Multivitamin
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600',   // Dri-FIT T-shirt
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=600',   // Adidas shoes
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600',   // Three-piece dress
    ];
    const insertImage = db.prepare(`INSERT INTO product_images (product_id, url, alt_text, sort_order, is_primary) VALUES (?, ?, ?, ?, ?)`);
    for (let i = 0; i < productIds.length; i++) {
      const p = productsData[i];
      const imgUrl = productImages[i] || `https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600`;
      insertImage.run(productIds[i], imgUrl, p.name, 0, 1);
    }
    console.log(`[Seed] Created product images`);

    // ── PRODUCT VARIANTS ───────────────────────────────────────────────────

    const insertVariant = db.prepare(`INSERT INTO product_variants (product_id, sku, name, price, stock_quantity, color, size) VALUES (?, ?, ?, ?, ?, ?, ?)`);

    // Variants for Samsung Galaxy S24 Ultra
    insertVariant.run(productIds[0], 'SAM-S24U-BLK', 'Samsung Galaxy S24 Ultra - Black', 135000, 20, 'Black', null);
    insertVariant.run(productIds[0], 'SAM-S24U-VLT', 'Samsung Galaxy S24 Ultra - Violet', 135000, 15, 'Violet', null);
    insertVariant.run(productIds[0], 'SAM-S24U-GRY', 'Samsung Galaxy S24 Ultra - Gray', 135000, 15, 'Gray', null);

    // Variants for iPhone 16 Pro Max
    insertVariant.run(productIds[1], 'APL-IP16PM-NAT', 'iPhone 16 Pro Max - Natural Titanium', 165000, 15, 'Natural Titanium', null);
    insertVariant.run(productIds[1], 'APL-IP16PM-BLK', 'iPhone 16 Pro Max - Black Titanium', 165000, 10, 'Black Titanium', null);
    insertVariant.run(productIds[1], 'APL-IP16PM-WHT', 'iPhone 16 Pro Max - White Titanium', 165000, 10, 'White Titanium', null);

    // Variants for Panjabi Set
    insertVariant.run(productIds[8], 'FASH-PNJ-WHT-M', 'Panjabi Set White - M', 2500, 50, 'White', 'M');
    insertVariant.run(productIds[8], 'FASH-PNJ-WHT-L', 'Panjabi Set White - L', 2500, 80, 'White', 'L');
    insertVariant.run(productIds[8], 'FASH-PNJ-WHT-XL', 'Panjabi Set White - XL', 2500, 70, 'White', 'XL');

    // Variants for Nike Air Max
    insertVariant.run(productIds[9], 'NKE-AM270-WHT-7', 'Nike Air Max 270 White - UK 7', 16500, 10, 'White', 'UK 7');
    insertVariant.run(productIds[9], 'NKE-AM270-WHT-8', 'Nike Air Max 270 White - UK 8', 16500, 15, 'White', 'UK 8');
    insertVariant.run(productIds[9], 'NKE-AM270-WHT-9', 'Nike Air Max 270 White - UK 9', 16500, 12, 'White', 'UK 9');
    insertVariant.run(productIds[9], 'NKE-AM270-WHT-10', 'Nike Air Max 270 White - UK 10', 16500, 8, 'White', 'UK 10');

    console.log(`[Seed] Created product variants`);

    // ── COURIERS ───────────────────────────────────────────────────────────

    const insertCourier = db.prepare(`INSERT INTO couriers (name, slug, api_key, api_secret, api_url, is_active) VALUES (?, ?, ?, ?, ?, 1)`);
    const courierIds = {};
    const courierData = [
      { name: 'SteadFast Courier', slug: 'steadfast', api_key: process.env.STEADFAST_API_KEY || '', api_secret: process.env.STEADFAST_API_SECRET || '', api_url: process.env.STEADFAST_URL || 'https://portal.packzy.com/api/v1' },
      { name: 'Pathao', slug: 'pathao', api_key: '', api_secret: '', api_url: '' },
      { name: 'Paperfly', slug: 'paperfly', api_key: '', api_secret: '', api_url: '' },
      { name: 'Sundarban Courier', slug: 'sundarban', api_key: '', api_secret: '', api_url: '' },
    ];
    for (const c of courierData) {
      const info = insertCourier.run(c.name, c.slug, c.api_key, c.api_secret, c.api_url);
      courierIds[c.slug] = info.lastInsertRowid;
    }
    console.log(`[Seed] Created couriers`);

    // ── ORDERS ─────────────────────────────────────────────────────────────

    const insertOrder = db.prepare(`INSERT INTO orders (uuid, user_id, order_number, status, subtotal, discount, shipping_cost, tax, total, payment_status, payment_method, shipping_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const insertOrderItem = db.prepare(`INSERT INTO order_items (order_id, product_id, product_name, product_sku, quantity, price, discount, tax, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

    const now = new Date();
    const days = (n) => new Date(now.getTime() - n * 86400000).toISOString().replace('T', ' ').substring(0, 19);

    const ordersData = [
      { user_id: userIds[4], order_number: 'BH-20250001', status: 'delivered', subtotal: 2600, discount: 260, shipping_cost: 0, tax: 52, total: 2392, payment_status: 'paid', payment_method: 'bKash', shipping_address: '{"full_name":"Rahim Miah","phone":"01712345678","address":"123 Mirpur Road","district":"Dhaka","division":"Dhaka"}', created_at: days(10), items: [
        { product_id: productIds[8], name: 'Panjabi Set - White', sku: 'FASH-PNJ-WHT-01', qty: 1, price: 2500, discount: 250, tax: 50, total: 2300 },
        { product_id: productIds[7], name: 'Men\'s Cotton Lungi', sku: 'FASH-LNG-COT-01', qty: 2, price: 550, discount: 10, tax: 2, total: 92 },
      ]},
      { user_id: userIds[4], order_number: 'BH-20250002', status: 'in_transit', subtotal: 135000, discount: 5000, shipping_cost: 100, tax: 2700, total: 132800, payment_status: 'paid', payment_method: 'Nagad', shipping_address: '{"full_name":"Rahim Miah","phone":"01712345678","address":"123 Mirpur Road","district":"Dhaka","division":"Dhaka"}', created_at: days(3), items: [
        { product_id: productIds[0], name: 'Samsung Galaxy S24 Ultra', sku: 'SAM-S24U-BLK', qty: 1, price: 135000, discount: 5000, tax: 2700, total: 132700 },
      ]},
      { user_id: userIds[4], order_number: 'BH-20250003', status: 'pending', subtotal: 850, discount: 0, shipping_cost: 60, tax: 17, total: 927, payment_status: 'pending', payment_method: null, shipping_address: '{"full_name":"Rahim Miah","phone":"01712345678","address":"123 Mirpur Road","district":"Dhaka","division":"Dhaka"}', created_at: days(0), items: [
        { product_id: productIds[22], name: 'Pran Mango Juice 1L', sku: 'PRN-MJ-1L-001', qty: 3, price: 120, discount: 0, tax: 7.2, total: 367.2 },
        { product_id: productIds[24], name: 'Miniket Rice 5kg', sku: 'GROC-RICE-MK-01', qty: 1, price: 650, discount: 0, tax: 9.75, total: 559.75 },
      ]},
      { user_id: userIds[4], order_number: 'BH-20250004', status: 'cancelled', subtotal: 12800, discount: 0, shipping_cost: 0, tax: 256, total: 13056, payment_status: 'refunded', payment_method: 'bKash', shipping_address: '{"full_name":"Rahim Miah","phone":"01712345678","address":"123 Mirpur Road","district":"Dhaka","division":"Dhaka"}', created_at: days(15), items: [
        { product_id: productIds[18], name: 'Adidas Predator Football Boots', sku: 'ADI-PRED-001', qty: 1, price: 12000, discount: 0, tax: 240, total: 12240 },
        { product_id: productIds[17], name: 'Coconut Hair Oil 500ml', sku: 'BEAU-COCO-001', qty: 2, price: 450, discount: 0, tax: 16, total: 816 },
      ]},
      { user_id: userIds[4], order_number: 'BH-20250005', status: 'confirmed', subtotal: 24800, discount: 2480, shipping_cost: 0, tax: 496, total: 22816, payment_status: 'paid', payment_method: 'Rocket', shipping_address: '{"full_name":"Rahim Miah","phone":"01712345678","address":"123 Mirpur Road","district":"Dhaka","division":"Dhaka"}', created_at: days(1), items: [
        { product_id: productIds[5], name: 'Jamdani Cotton Saree', sku: 'AAR-JAM-SAR-01', qty: 2, price: 8500, discount: 1700, tax: 340, total: 15640 },
        { product_id: productIds[12], name: 'Nakshi Kantha Bed Sheet', sku: 'AAR-NKS-BED-01', qty: 1, price: 3200, discount: 320, tax: 64, total: 2944 },
        { product_id: productIds[6], name: 'Silk Tangail Saree', sku: 'AAR-TNG-SLK-01', qty: 1, price: 12000, discount: 460, tax: 92, total: 4232 },
      ]},
    ];

    const orderIds = [];
    for (const o of ordersData) {
      const uuid = uuidv4();
      const info = insertOrder.run(uuid, o.user_id, o.order_number, o.status, o.subtotal, o.discount, o.shipping_cost, o.tax, o.total, o.payment_status, o.payment_method, o.shipping_address, o.created_at);
      orderIds.push(info.lastInsertRowid);
      for (const item of o.items) {
        insertOrderItem.run(info.lastInsertRowid, item.product_id, item.name, item.sku, item.qty, item.price, item.discount, item.tax, item.total);
      }
      console.log(`[Seed] Created order: ${o.order_number} (${o.status})`);
    }

    // ── ORDER STATUS HISTORY ───────────────────────────────────────────────

    const insertStatusHistory = db.prepare(`INSERT INTO order_status_history (order_id, status, note, changed_by, created_at) VALUES (?, ?, ?, ?, ?)`);
    for (let i = 0; i < ordersData.length; i++) {
      insertStatusHistory.run(orderIds[i], ordersData[i].status, `Order ${ordersData[i].status}`, userIds[0], ordersData[i].created_at);
    }

    // ── PAYMENTS ───────────────────────────────────────────────────────────

    const insertPayment = db.prepare(`INSERT INTO payments (order_id, method, amount, transaction_id, status) VALUES (?, ?, ?, ?, ?)`);
    for (let i = 0; i < ordersData.length; i++) {
      const o = ordersData[i];
      if (o.payment_status === 'paid' || o.payment_status === 'refunded') {
        insertPayment.run(orderIds[i], o.payment_method, o.total, `TXN${10000 + i}`, o.payment_status === 'paid' ? 'completed' : 'refunded');
      }
    }

    // ── REVIEWS ────────────────────────────────────────────────────────────

    const insertReview = db.prepare(`INSERT INTO product_reviews (user_id, product_id, order_id, rating, title, comment, is_approved) VALUES (?, ?, ?, ?, ?, ?, 1)`);
    const reviews = [
      { uid: userIds[4], pid: productIds[8], oid: orderIds[0], rating: 5, title: 'Great panjabi', comment: 'Excellent quality and fit. True to size.' },
      { uid: userIds[4], pid: productIds[7], oid: orderIds[0], rating: 4, title: 'Good lungi', comment: 'Comfortable cotton. Color is as shown.' },
      { uid: userIds[4], pid: productIds[5], oid: orderIds[4], rating: 5, title: 'Beautiful saree', comment: 'The Jamdani work is exquisite. Worth every taka!' },
      { uid: userIds[4], pid: productIds[12], oid: orderIds[4], rating: 4, title: 'Nice bedsheet', comment: 'Beautiful Nakshi Kantha design. Soft fabric.' },
    ];
    for (const r of reviews) {
      insertReview.run(r.uid, r.pid, r.oid, r.rating, r.title, r.comment);
    }
    console.log(`[Seed] Created product reviews`);

    // ── COUPONS ────────────────────────────────────────────────────────────

    const insertCoupon = db.prepare(`INSERT INTO coupons (uuid, code, type, value, minimum_order, maximum_discount, usage_limit, is_active, applies_to) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'all')`);
    const coupons = [
      { code: 'WELCOME10', type: 'percentage', value: 10, min: 1000, max: 500, limit: 100 },
      { code: 'SAVE500', type: 'fixed', value: 500, min: 5000, max: null, limit: 50 },
      { code: 'FREESHIP', type: 'free_shipping', value: 0, min: 1500, max: null, limit: 200 },
      { code: 'EID50', type: 'percentage', value: 15, min: 3000, max: 1000, limit: 100 },
      { code: 'NEWUSER20', type: 'percentage', value: 20, min: 500, max: 300, limit: 500 },
      { code: 'FLASH25', type: 'percentage', value: 25, min: 2000, max: 2000, limit: 30 },
      { code: 'BIG1000', type: 'fixed', value: 1000, min: 10000, max: null, limit: 20 },
      { code: 'BOGO50', type: 'percentage', value: 50, min: 5000, max: 3000, limit: 10 },
      { code: 'LOYALTY5', type: 'percentage', value: 5, min: 0, max: 200, limit: null },
      { code: 'BOISHAKH', type: 'percentage', value: 12, min: 2000, max: 800, limit: 75 },
    ];
    for (const c of coupons) {
      const uuid = uuidv4();
      insertCoupon.run(uuid, c.code, c.type, c.value, c.min, c.max, c.limit);
      console.log(`[Seed] Created coupon: ${c.code}`);
    }

    // ── FLASH SALES ────────────────────────────────────────────────────────

    const insertFlashSale = db.prepare(`INSERT INTO flash_sales (product_id, discount_percentage, start_at, end_at, is_active) VALUES (?, ?, ?, ?, 1)`);
    const flashSales = [
      { pid: productIds[0], disc: 10, start: days(1), end: days(30) },
      { pid: productIds[5], disc: 15, start: days(1), end: days(30) },
      { pid: productIds[18], disc: 20, start: days(0), end: days(15) },
      { pid: productIds[10], disc: 12, start: days(0), end: days(20) },
      { pid: productIds[22], disc: 25, start: days(0), end: days(7) },
    ];
    for (const fs of flashSales) {
      insertFlashSale.run(fs.pid, fs.disc, fs.start, fs.end);
    }
    console.log(`[Seed] Created flash sales`);

    // ── WAREHOUSES ─────────────────────────────────────────────────────────

    const insertWarehouse = db.prepare(`INSERT INTO warehouses (name, address, phone, is_active) VALUES (?, ?, ?, 1)`);
    insertWarehouse.run('Dhaka Central Warehouse', '102 Kawran Bazar, Dhaka 1215', '01987654321');
    insertWarehouse.run('Chattogram Port Warehouse', '45 Agrabad C/A, Chattogram', '01987654322');
    insertWarehouse.run('Rajshahi Depot', '78 Bara, Rajshahi 6000', '01987654323');
    console.log(`[Seed] Created warehouses`);

    // ── SUPPLIERS ──────────────────────────────────────────────────────────

    const insertSupplier = db.prepare(`INSERT INTO suppliers (uuid, name, contact_person, email, phone, address, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)`);
    const suppliers = [
      { name: 'Rahim Electronics Ltd', contact: 'Abdur Rahim', email: 'rahim@example.com', phone: '01711111111', address: '52 Motijheel, Dhaka' },
      { name: 'Karim Textiles', contact: 'Abdul Karim', email: 'karim@example.com', phone: '01722222222', address: '45 Islampur, Dhaka' },
      { name: 'Nur Trading', contact: 'Nur Hossain', email: 'nur@example.com', phone: '01733333333', address: '23 Khatungonj, Chattogram' },
      { name: 'Pran Foods Supplier', contact: 'Mizan Khan', email: 'mizan@pran.com', phone: '01744444444', address: '12 Shyampur, Dhaka' },
      { name: 'Aarong Wholesale', contact: 'Shahin Akter', email: 'shahin@aarong.com', phone: '01755555555', address: '8 Baily Road, Dhaka' },
    ];
    for (const s of suppliers) {
      const uuid = uuidv4();
      insertSupplier.run(uuid, s.name, s.contact, s.email, s.phone, s.address);
    }
    console.log(`[Seed] Created suppliers`);

    // ── SETTINGS ───────────────────────────────────────────────────────────

    const insertSetting = db.prepare(`INSERT INTO settings (key, value, group_name) VALUES (?, ?, ?)`);
    const settings = [
      ['site_name', '"Bangalir Haat"', 'general'],
      ['site_description', '"Bangladesh\'s Premium Online Marketplace"', 'general'],
      ['currency', '"BDT"', 'general'],
      ['currency_symbol', '"৳"', 'general'],
      ['tax_rate', '5', 'tax'],
      ['tax_name', '"VAT"', 'tax'],
      ['shipping_free_threshold', '1500', 'shipping'],
      ['shipping_flat_rate', '60', 'shipping'],
      ['order_prefix', '"BH"', 'orders'],
      ['low_stock_threshold', '5', 'inventory'],
      ['default_language', '"bn"', 'general'],
      ['timezone', '"Asia/Dhaka"', 'general'],
      ['max_product_images', '10', 'catalog'],
      ['enable_reviews', 'true', 'catalog'],
      ['enable_wallet', 'true', 'payments'],
      ['enable_coupons', 'true', 'marketing'],
      ['flash_sale_max_products', '50', 'marketing'],
      ['referral_points', '100', 'loyalty'],
      ['point_conversion_rate', '1', 'loyalty'],
    ];
    for (const [key, value, group] of settings) {
      insertSetting.run(key, value, group);
    }
    console.log(`[Seed] Created settings`);

    // ── NOTIFICATIONS ──────────────────────────────────────────────────────

    const insertNotification = db.prepare(`INSERT INTO notifications (user_id, title, message, type, is_read, data) VALUES (?, ?, ?, ?, ?, ?)`);
    const notifications = [
      { uid: userIds[4], title: 'Order Confirmed', msg: 'Your order #BH-20250005 has been confirmed!', type: 'order', read: 0, data: '{"order_id":' + orderIds[3] + '}' },
      { uid: userIds[4], title: 'Welcome to Bangalir Haat!', msg: 'Thank you for joining Bangladesh\'s premium marketplace.', type: 'info', read: 0, data: null },
      { uid: userIds[4], title: 'Flash Sale Alert', msg: '25% off on Pran Mango Juice - Limited time offer!', type: 'promo', read: 0, data: '{"flash_sale_id":5}' },
      { uid: userIds[4], title: 'Order Delivered', msg: 'Your order #BH-20250001 has been delivered. Enjoy!', type: 'order', read: 1, data: '{"order_id":' + orderIds[0] + '}' },
      { uid: userIds[1], title: 'New Order Placed', msg: 'Order #BH-20250003 needs review.', type: 'admin', read: 0, data: '{"order_id":' + orderIds[2] + '}' },
    ];
    for (const n of notifications) {
      insertNotification.run(n.uid, n.title, n.msg, n.type, n.read, n.data);
    }
    console.log(`[Seed] Created notifications`);

    // ── FAQS ───────────────────────────────────────────────────────────────

    const insertFaq = db.prepare(`INSERT INTO faqs (question, answer, category, sort_order, is_active) VALUES (?, ?, ?, ?, 1)`);
    const faqs = [
      { q: 'What payment methods do you accept?', a: 'We accept bKash, Nagad, Rocket, credit/debit cards, and cash on delivery.', cat: 'Payments', order: 0 },
      { q: 'How long does delivery take?', a: 'Dhaka: 1-3 business days. Other divisions: 3-7 business days.', cat: 'Shipping', order: 1 },
      { q: 'What is your return policy?', a: 'Items can be returned within 7 days of delivery if damaged or incorrect.', cat: 'Returns', order: 2 },
      { q: 'Do you ship internationally?', a: 'Currently we only deliver within Bangladesh.', cat: 'Shipping', order: 3 },
      { q: 'How can I track my order?', a: 'You can track your order using the tracking number sent via SMS.', cat: 'Orders', order: 4 },
      { q: 'Can I cancel my order?', a: 'Orders can be cancelled within 24 hours of placing.', cat: 'Orders', order: 5 },
      { q: 'Is COD available?', a: 'Yes, Cash on Delivery is available for orders up to ৳50,000.', cat: 'Payments', order: 6 },
      { q: 'How do I contact support?', a: 'Call us at 09612345678 or email support@bangalirhaat.com.', cat: 'Support', order: 7 },
    ];
    for (const f of faqs) {
      insertFaq.run(f.q, f.a, f.cat, f.order);
    }
    console.log(`[Seed] Created FAQs`);

    // ── PAGES ──────────────────────────────────────────────────────────────

    const insertPage = db.prepare(`INSERT INTO pages (title, slug, content, meta_title, is_published) VALUES (?, ?, ?, ?, 1)`);
    const pages = [
      { title: 'About Us', slug: 'about-us', content: '<h1>Welcome to Bangalir Haat</h1><p>Bangalir Haat is Bangladesh\'s premier e-commerce marketplace, connecting local artisans, manufacturers, and trusted sellers with customers nationwide. We are committed to providing authentic Bangladeshi products at competitive prices with reliable delivery.</p><p>Founded with the vision of digitalizing Bangladesh\'s traditional Haat (marketplace), we bring the rich heritage of Bangladeshi craftsmanship to your doorstep.</p>', meta: 'About Bangalir Haat - Bangladesh\'s Premier Online Marketplace' },
      { title: 'Privacy Policy', slug: 'privacy-policy', content: '<h1>Privacy Policy</h1><p>At Bangalir Haat, we take your privacy seriously. This policy describes how we collect, use, and protect your personal information.</p><h2>Information We Collect</h2><p>We collect information you provide during registration, order placement, and communication with our support team.</p><h2>How We Use Your Information</h2><p>Your information is used to process orders, improve our services, and send relevant updates with your consent.</p><h2>Data Protection</h2><p>We implement industry-standard security measures to protect your personal data.</p>', meta: 'Privacy Policy - Bangalir Haat' },
      { title: 'Terms & Conditions', slug: 'terms-conditions', content: '<h1>Terms & Conditions</h1><p>By using Bangalir Haat, you agree to the following terms and conditions.</p><h2>Account Registration</h2><p>You must provide accurate information when creating an account. You are responsible for maintaining confidentiality.</p><h2>Orders & Payments</h2><p>All prices are in Bangladeshi Taka (BDT). Payment must be completed before order processing unless using COD.</p><h2>Shipping & Delivery</h2><p>Delivery times are estimates and may vary based on location and courier availability.</p><h2>Returns & Refunds</h2><p>Please refer to our Return Policy for detailed information on returns and refunds.</p>', meta: 'Terms & Conditions - Bangalir Haat' },
    ];
    for (const p of pages) {
      insertPage.run(p.title, p.slug, p.content, p.meta);
    }
    console.log(`[Seed] Created pages`);

    console.log('\n[Seed] Database seeding completed successfully!');
    console.log(`  Users: ${users.length}`);
    console.log(`  Categories: ${categoriesData.length + subcategories.length}`);
    console.log(`  Brands: ${brandsData.length}`);
    console.log(`  Products: ${productsData.length}`);
    console.log(`  Orders: ${ordersData.length}`);
    console.log(`  Coupons: ${coupons.length}`);
    console.log(`  Flash Sales: ${flashSales.length}`);
    console.log(`  Reviews: ${reviews.length}`);
    console.log(`  Couriers: ${courierData.length}`);
    console.log(`  Suppliers: ${suppliers.length}`);
    console.log(`  Settings: ${settings.length}`);
    console.log(`  Notifications: ${notifications.length}`);
    console.log(`  FAQs: ${faqs.length}`);
    console.log(`  Pages: ${pages.length}`);
}

export function seedIfNeeded() {
  try {
    const db = initializeDatabase();
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    if (userCount === 0) {
      console.log('[Seed] No users found, seeding database...');
      seedDatabase(db);
    } else {
      console.log(`[Seed] ${userCount} users found, skipping seed.`);
    }
  } catch (error) {
    console.error('[Seed] Auto-seed error:', error.message);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const db = initializeDatabase();
    seedDatabase(db);
    process.exit(0);
  } catch (error) {
    console.error('Failed to seed database:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
}
