import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import { authenticate, authorize } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import bundleService from '../services/bundle.service.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

const bundleValidation = [
  body('name').trim().isLength({ min: 2, max: 200 }).withMessage('Name must be 2-200 characters'),
  body('discountType').isIn(['percentage', 'fixed']).withMessage('Discount type must be percentage or fixed'),
  body('discountValue').isFloat({ min: 0.01 }).withMessage('Discount value must be greater than 0'),
  body('productIds').isArray({ min: 2 }).withMessage('At least 2 product IDs are required'),
  body('productIds.*').isInt({ min: 1 }).toInt(),
  body('minQuantity').optional().isInt({ min: 1 }).toInt(),
  body('startsAt').optional({ nullable: true }).isISO8601(),
  body('endsAt').optional({ nullable: true }).isISO8601(),
  body('description').optional({ nullable: true }).trim().isLength({ max: 1000 }),
];

const idValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid bundle ID'),
];

const productIdValidation = [
  param('productId').isInt({ min: 1 }).toInt().withMessage('Invalid product ID'),
];

const calculateValidation = [
  body('quantity').isInt({ min: 1 }).toInt().withMessage('Quantity must be at least 1'),
];

const fbtValidation = [
  body('productId').isInt({ min: 1 }).toInt().withMessage('Invalid product ID'),
  body('relatedProductId').isInt({ min: 1 }).toInt().withMessage('Invalid related product ID'),
];

router.post('/', adminAuth, bundleValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { bundle } = await bundleService.createBundle(req.body);

    res.status(201).json({ success: true, data: { bundle }, message: 'Bundle created successfully' });
  } catch (error) {
    next(error);
  }
});

router.get('/', adminAuth, async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);

    const result = await bundleService.getAllBundles({ page, limit });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

router.get('/product/:productId', productIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { bundles } = await bundleService.getBundlesForProduct(req.params.productId);

    res.json({ success: true, data: { bundles } });
  } catch (error) {
    next(error);
  }
});

router.get('/fbt/:productId', productIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { products } = await bundleService.getFBTProducts(req.params.productId);

    res.json({ success: true, data: { products } });
  } catch (error) {
    next(error);
  }
});

router.post('/fbt', adminAuth, fbtValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { fbt } = await bundleService.addFBT(req.body.productId, req.body.relatedProductId);

    res.status(201).json({ success: true, data: { fbt }, message: 'FBT association created successfully' });
  } catch (error) {
    next(error);
  }
});

router.delete('/fbt/:id', adminAuth, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const result = await bundleService.removeFBT(parseInt(req.params.id));

    res.json({ success: true, message: result.message });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { bundle } = await bundleService.getBundle(req.params.id);

    res.json({ success: true, data: { bundle } });
  } catch (error) {
    next(error);
  }
});

router.put('/:id', adminAuth, [...idValidation, ...bundleValidation], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { bundle } = await bundleService.updateBundle(req.params.id, req.body);

    res.json({ success: true, data: { bundle }, message: 'Bundle updated successfully' });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', adminAuth, idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const result = await bundleService.deleteBundle(req.params.id);

    res.json({ success: true, message: result.message });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/calculate', [...idValidation, ...calculateValidation], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const result = await bundleService.calculateBundlePrice(req.params.id, req.body.quantity);

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

export default router;
