/**
 * Bangalirhaat Analytics & Tracking Integration
 * GA4, Facebook Pixel, Hotjar, and custom event tracking
 */
const BAnalytics = {
  config: {
    ga4Id: null,
    fbPixelId: null,
    hotjarId: null,
    enabled: true,
  },

  _initialized: false,

  _resolveCategory(cat) {
    if (!cat) return '';
    if (typeof cat === 'string') return cat;
    return cat.name || cat.title || String(cat);
  },

  init() {
    if (this._initialized) return;
    this._initialized = true;
    this.loadConfig().then(() => {
      if (!this.config.enabled) return;
      this.initGA4();
      this.initFacebookPixel();
      this.initHotjar();
      this.trackPageView();
      this.trackScrollDepth();
      this.trackTimeOnPage();
      this.trackOutboundLinks();
      this.trackErrors();
    });
  },

  // ── GA4 ──────────────────────────────────────────────────────────────────
  initGA4() {
    if (!this.config.ga4Id) return;

    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${this.config.ga4Id}`;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', this.config.ga4Id, {
      send_page_view: false,
    });
  },

  // ── Facebook Pixel ───────────────────────────────────────────────────────
  initFacebookPixel() {
    if (!this.config.fbPixelId) return;

    window.fbq = window.fbq || function () {
      (window.fbq.q = window.fbq.q || []).push(arguments);
    };
    window._fbq = window.fbq;

    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://connect.facebook.net/en_US/fbevents.js';
    document.head.appendChild(script);

    window.fbq('init', this.config.fbPixelId);
    window.fbq('track', 'PageView');
  },

  // ── Hotjar ───────────────────────────────────────────────────────────────
  initHotjar() {
    if (!this.config.hotjarId) return;

    (function (h, o, t, j, a, r) {
      h.hj = h.hj || function () { (h.hj.q = h.hj.q || []).push(arguments); };
      h._hjSettings = { hjid: t, hjsv: j };
      a = o.createElement('head');
      r = o.getElementsByTagName('head')[0];
      a.async = 1;
      a.src = 'https://static.hotjar.com/c/hotjar-' + t + '.js?sv=' + j;
      r.appendChild(a);
    })(window, document, this.config.hotjarId, '0');
  },

  // ── E-commerce Tracking ──────────────────────────────────────────────────
  trackProductView(product) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      item_brand: product.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(product.category),
      item_variant: product.variant || '',
      currency: 'BDT',
    };

    this._ga4Event('view_item', { items: [item] });
    this._fbEvent('ViewContent', {
      content_ids: [product.id || product._id],
      content_name: product.name,
      content_type: 'product',
      value: product.price || 0,
      currency: 'BDT',
    });
  },

  trackAddToCart(product, quantity = 1) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      quantity,
      item_brand: product.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(product.category),
      currency: 'BDT',
    };

    this._ga4Event('add_to_cart', {
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      items: [item],
    });
    this._fbEvent('AddToCart', {
      content_ids: [product.id || product._id],
      content_name: product.name,
      content_type: 'product',
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      quantity,
    });
  },

  trackRemoveFromCart(product, quantity = 1) {
    if (!product) return;

    const item = {
      item_id: product.id || product._id || '',
      item_name: product.name || '',
      price: product.price || 0,
      quantity,
      currency: 'BDT',
    };

    this._ga4Event('remove_from_cart', {
      value: (product.price || 0) * quantity,
      currency: 'BDT',
      items: [item],
    });
  },

  trackPurchase(order) {
    if (!order) return;

    const items = (order.items || []).map((item) => ({
      item_id: item.productId || item.id || '',
      item_name: item.name || '',
      price: item.price || 0,
      quantity: item.quantity || 1,
      item_brand: item.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(item.category),
      currency: 'BDT',
    }));

    this._ga4Event('purchase', {
      transaction_id: order.id || order._id || order.orderId || '',
      value: order.total || order.totalAmount || 0,
      tax: order.tax || 0,
      shipping: order.shipping || 0,
      currency: 'BDT',
      items,
    });
    this._fbEvent('Purchase', {
      content_ids: items.map((i) => i.item_id),
      content_type: 'product',
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      num_items: items.length,
    });
  },

  trackSearch(query) {
    if (!query) return;

    this._ga4Event('search', {
      search_term: query,
    });
  },

  trackCategoryView(category, items = []) {
    if (!category) return;
    var catName = this._resolveCategory(category);

    const listItems = items.map((item) => ({
      item_id: item.id || item._id || '',
      item_name: item.name || '',
      price: item.price || 0,
      item_brand: item.brand || 'Bangalirhaat',
      item_category: this._resolveCategory(item.category || catName),
      currency: 'BDT',
    }));

    this._ga4Event('view_item_list', {
      item_list_id: catName,
      item_list_name: catName,
      items: listItems,
    });
  },

  trackBeginCheckout(order) {
    if (!order) return;

    const items = (order.items || []).map((item) => ({
      item_id: item.productId || item.id || '',
      item_name: item.name || '',
      price: item.price || 0,
      quantity: item.quantity || 1,
      currency: 'BDT',
    }));

    this._ga4Event('begin_checkout', {
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      items,
    });
    this._fbEvent('InitiateCheckout', {
      content_ids: items.map(i => i.item_id),
      content_type: 'product',
      value: order.total || order.totalAmount || 0,
      currency: 'BDT',
      num_items: items.length,
    });
  },

  trackAddPaymentInfo(order) {
    if (!order) return;
    this._ga4Event('add_payment_info', { currency: 'BDT', value: order.total || 0 });
    this._fbEvent('AddPaymentInfo', { currency: 'BDT', value: order.total || 0 });
  },

  // ── Engagement Tracking ──────────────────────────────────────────────────
  trackScrollDepth() {
    const depths = { 25: false, 50: false, 75: false, 100: false };
    const maxDepth = { value: 0 };

    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight <= 0) return;

      const percent = Math.round((scrollTop / docHeight) * 100);
      if (percent > maxDepth.value) maxDepth.value = percent;

      Object.keys(depths).forEach((depth) => {
        if (!depths[depth] && percent >= Number(depth)) {
          depths[depth] = true;
          this._ga4Event('scroll', {
            percent_scrolled: Number(depth),
            page_location: window.location.href,
          });
        }
      });
    }, { passive: true });

    window.addEventListener('beforeunload', () => {
      if (maxDepth.value > 0) {
        this._ga4Event('user_engagement', {
          engagement_time_msec: this._getEngagementTime(),
          max_scroll_percent: maxDepth.value,
        });
      }
    });
  },

  trackTimeOnPage() {
    const startTime = Date.now();

    window.addEventListener('beforeunload', () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      if (timeSpent > 5) {
        this._ga4Event('session_duration', {
          engagement_time_msec: timeSpent * 1000,
          page_location: window.location.href,
        });
      }
    });
  },

  trackClick(element, category, label) {
    if (!element || !category) return;

    this._ga4Event('select_content', {
      content_type: category,
      content_id: label || '',
    });
    this._trackGenericEvent('click', { category, label });
  },

  trackOutboundLinks() {
    document.addEventListener('click', (e) => {
      const link = e.target.closest('a[href]');
      if (!link) return;

      const href = link.href;
      if (href && href.startsWith('http') && !href.includes(window.location.hostname)) {
        this._ga4Event('click', {
          link_url: href,
          link_text: link.textContent?.trim().substring(0, 100),
        });
      }
    });
  },

  trackErrors() {
    window.addEventListener('error', (e) => {
      this._ga4Event('exception', {
        description: e.message || 'Unknown error',
        fatal: false,
      });
    });
  },

  // ── Conversion Tracking ──────────────────────────────────────────────────
  trackConversion(conversionType, value) {
    this._ga4Event('generate_lead', {
      value: value || 0,
      currency: 'BDT',
      conversion_type: conversionType,
    });
  },

  trackSignUp(method) {
    this._ga4Event('sign_up', { method: method || 'email' });
    this._fbEvent('CompleteRegistration', { method: method || 'email' });
  },

  trackLogin(method) {
    this._ga4Event('login', { method: method || 'email' });
  },

  trackWishlist(product) {
    if (!product) return;
    this._ga4Event('add_to_wishlist', {
      value: product.price || 0,
      currency: 'BDT',
      items: [{
        item_id: product.id || product._id || '',
        item_name: product.name || '',
        price: product.price || 0,
        currency: 'BDT',
      }],
    });
  },

  // ── Custom Events ────────────────────────────────────────────────────────
  trackEvent(eventName, params = {}) {
    this._ga4Event(eventName, params);
  },

  trackFBEvent(eventName, params = {}) {
    this._fbEvent(eventName, params);
  },

  // ── User Properties ──────────────────────────────────────────────────────
  setUserProperties(user) {
    if (!user || !window.gtag) return;

    const props = {};
    if (user.id) props.user_id = user.id;
    if (user.email) props.user_email = user.email;
    if (user.name) props.user_name = user.name;
    if (user.phone) props.phone = user.phone;
    if (user.city) props.city = user.city;

    window.gtag('set', 'user_properties', props);

    if (window.fbq) {
      window.fbq('trackCustom', 'SetUserProperties', {
        user_id: user.id,
        city: user.city,
      });
    }
  },

  clearUserProperties() {
    if (window.gtag) {
      window.gtag('set', 'user_properties', {
        user_id: null,
        user_email: null,
        user_name: null,
      });
    }
  },

  // ── Config ───────────────────────────────────────────────────────────────
  async loadConfig() {
    try {
      const res = await fetch('/api/settings/analytics');
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          this.config.ga4Id = json.data.ga4Id || json.data.ga4_id || null;
          this.config.fbPixelId = json.data.fbPixelId || json.data.fb_pixel_id || null;
          this.config.hotjarId = json.data.hotjarId || json.data.hotjar_id || null;
        }
      }
    } catch { /* settings API unavailable */ }
  },

  setConfig(key, value) {
    if (key in this.config) {
      this.config[key] = value;
    }
  },

  // ── Internal Helpers ─────────────────────────────────────────────────────
  _ga4Event(eventName, params = {}) {
    if (!window.gtag || !this.config.ga4Id) return;
    window.gtag('event', eventName, params);
  },

  _fbEvent(eventName, params = {}) {
    if (!window.fbq || !this.config.fbPixelId) return;
    window.fbq('track', eventName, params);
  },

  _trackGenericEvent(eventName, params = {}) {
    this._ga4Event(eventName, params);
  },

  _getEngagementTime() {
    return String(Math.round(performance.now()));
  },
};

// Auto-initialize on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => BAnalytics.init());
} else {
  BAnalytics.init();
}

window.BAnalytics = BAnalytics;
