import { Router } from 'express';
import { param, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

const idValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid category ID'),
];

const slugValidation = [
  param('slug').isString().trim().isLength({ min: 1, max: 200 }),
];

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();

    const categories = db.prepare(
      `SELECT c.id, c.name, c.slug, c.description, c.image, c.sort_order,
              p.id as parent_id, p.name as parent_name, p.slug as parent_slug
       FROM categories c
       LEFT JOIN categories p ON c.parent_id = p.id
       WHERE c.is_active = 1
       ORDER BY c.sort_order, c.name`
    ).all();

    const tree = [];
    const map = {};

    categories.forEach(cat => {
      map[cat.id] = {
        id: cat.id,
        name: cat.name,
        slug: cat.slug,
        description: cat.description,
        image: cat.image,
        children: [],
      };
    });

    categories.forEach(cat => {
      if (cat.parent_id && map[cat.parent_id]) {
        map[cat.parent_id].children.push(map[cat.id]);
      } else if (!cat.parent_id) {
        tree.push(map[cat.id]);
      }
    });

    const productCounts = db.prepare(
      `SELECT category_id, COUNT(*) as count FROM products WHERE is_active = 1 GROUP BY category_id`
    ).all();

    productCounts.forEach(pc => {
      if (map[pc.category_id]) {
        map[pc.category_id].product_count = pc.count;
      }
    });

    res.json({ success: true, data: { categories: tree } });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const category = db.prepare(
      `SELECT c.*, p.name as parent_name, p.slug as parent_slug
       FROM categories c
       LEFT JOIN categories p ON c.parent_id = p.id
       WHERE c.id = ? AND c.is_active = 1`
    ).get(req.params.id);

    if (!category) {
      throw new AppError('Category not found', 404);
    }

    const children = db.prepare(
      `SELECT id, name, slug, description, image, sort_order
       FROM categories
       WHERE parent_id = ? AND is_active = 1
       ORDER BY sort_order, name`
    ).all(category.id);

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare(
      'SELECT COUNT(*) as total FROM products WHERE category_id = ? AND is_active = 1'
    ).get(category.id);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating,
              b.name as brand_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.category_id = ? AND p.is_active = 1
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(category.id, limit, offset);

    res.json({
      success: true,
      data: {
        category: {
          ...category,
          children,
        },
        products: {
          items: products,
          pagination: {
            total: countRow.total,
            page,
            limit,
            totalPages: Math.ceil(countRow.total / limit),
          },
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:slug', slugValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const category = db.prepare(
      `SELECT c.*, p.name as parent_name, p.slug as parent_slug
       FROM categories c
       LEFT JOIN categories p ON c.parent_id = p.id
       WHERE c.slug = ? AND c.is_active = 1`
    ).get(req.params.slug);

    if (!category) {
      throw new AppError('Category not found', 404);
    }

    const children = db.prepare(
      `SELECT id, name, slug, description, image, sort_order
       FROM categories
       WHERE parent_id = ? AND is_active = 1
       ORDER BY sort_order, name`
    ).all(category.id);

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare(
      'SELECT COUNT(*) as total FROM products WHERE category_id = ? AND is_active = 1'
    ).get(category.id);

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price, p.average_rating,
              b.name as brand_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM products p
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.category_id = ? AND p.is_active = 1
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(category.id, limit, offset);

    res.json({
      success: true,
      data: {
        category: {
          ...category,
          children,
        },
        products: {
          items: products,
          pagination: {
            total: countRow.total,
            page,
            limit,
            totalPages: Math.ceil(countRow.total / limit),
          },
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
