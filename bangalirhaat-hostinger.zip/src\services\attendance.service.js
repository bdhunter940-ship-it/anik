import crypto from 'crypto';
import { getDb } from '../database/db.js';

const WORK_START_HOUR = 9;
const LATE_THRESHOLD_MINUTES = 15;

function getToday() {
  return new Date().toISOString().split('T')[0];
}

function getNow() {
  return new Date().toISOString();
}

class AttendanceService {
  async checkIn(userId) {
    const db = getDb();
    const today = getToday();

    const existing = db.prepare(
      'SELECT * FROM staff_attendance WHERE user_id = ? AND date = ?'
    ).get(String(userId), today);

    if (existing && existing.check_in) {
      throw new Error('Already checked in today');
    }

    const now = getNow();
    const checkTime = new Date(now);
    const workStart = new Date(now);
    workStart.setHours(WORK_START_HOUR, 0, 0, 0);
    const diffMinutes = (checkTime - workStart) / (1000 * 60);
    const status = diffMinutes > LATE_THRESHOLD_MINUTES ? 'late' : 'present';

    if (existing) {
      db.prepare(
        `UPDATE staff_attendance SET check_in = ?, status = ? WHERE id = ?`
      ).run(now, status, existing.id);

      return { id: existing.id, checkIn: now, status };
    }

    const id = crypto.randomUUID();
    db.prepare(`
      INSERT INTO staff_attendance (id, user_id, date, check_in, status, created_at)
      VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).run(id, String(userId), today, now, status);

    return { id, checkIn: now, status };
  }

  async checkOut(userId) {
    const db = getDb();
    const today = getToday();

    const existing = db.prepare(
      'SELECT * FROM staff_attendance WHERE user_id = ? AND date = ?'
    ).get(String(userId), today);

    if (!existing || !existing.check_in) {
      throw new Error('No check-in found for today');
    }

    if (existing.check_out) {
      throw new Error('Already checked out today');
    }

    const now = getNow();
    db.prepare(
      `UPDATE staff_attendance SET check_out = ? WHERE id = ?`
    ).run(now, existing.id);

    return { id: existing.id, checkIn: existing.check_in, checkOut: now, status: existing.status };
  }

  async getAttendance({ userId, startDate, endDate }) {
    const db = getDb();
    let where = ['user_id = ?'];
    let params = [String(userId)];

    if (startDate) { where.push('date >= ?'); params.push(startDate); }
    if (endDate) { where.push('date <= ?'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const items = db.prepare(
      `SELECT * FROM staff_attendance WHERE ${whereClause} ORDER BY date DESC`
    ).all(...params);

    const summary = db.prepare(`
      SELECT status, COUNT(*) as count
      FROM staff_attendance WHERE ${whereClause}
      GROUP BY status
    `).all(...params);

    return { items, summary };
  }

  async getAllAttendance({ date, page = 1, limit = 20 }) {
    const db = getDb();
    let where = ['1=1'];
    let params = [];

    if (date) { where.push('sa.date = ?'); params.push(date); }

    const whereClause = where.join(' AND ');
    const safeLimit = Math.min(Math.max(parseInt(limit) || 20, 1), 100);
    const offset = (Math.max(parseInt(page) || 1, 1) - 1) * safeLimit;

    const total = db.prepare(
      `SELECT COUNT(*) as count FROM staff_attendance sa WHERE ${whereClause}`
    ).get(...params).count;

    const items = db.prepare(`
      SELECT sa.*, u.first_name, u.last_name, u.email
      FROM staff_attendance sa
      JOIN users u ON sa.user_id = u.id
      WHERE ${whereClause}
      ORDER BY sa.date DESC, sa.check_in DESC
      LIMIT ? OFFSET ?
    `).all(...params, safeLimit, offset);

    return {
      items,
      pagination: {
        page: parseInt(page) || 1,
        limit: safeLimit,
        total,
        totalPages: Math.ceil(total / safeLimit),
      },
    };
  }

  async updateAttendance(id, { status, notes }) {
    const db = getDb();
    const validStatuses = ['present', 'absent', 'late', 'half_day', 'leave'];

    const existing = db.prepare('SELECT * FROM staff_attendance WHERE id = ?').get(id);
    if (!existing) throw new Error('Attendance record not found');

    if (status && !validStatuses.includes(status)) {
      throw new Error(`Invalid status. Must be one of: ${validStatuses.join(', ')}`);
    }

    db.prepare(
      `UPDATE staff_attendance SET status = COALESCE(?, status), notes = COALESCE(?, notes) WHERE id = ?`
    ).run(status || null, notes || null, id);

    const updated = db.prepare('SELECT * FROM staff_attendance WHERE id = ?').get(id);
    return updated;
  }

  async getAttendanceStats({ userId, month, year }) {
    const db = getDb();
    const targetMonth = month || (new Date().getMonth() + 1);
    const targetYear = year || new Date().getFullYear();
    const monthStr = String(targetMonth).padStart(2, '0');

    let where = ["strftime('%m', date) = ?", "strftime('%Y', date) = ?"];
    let params = [monthStr, String(targetYear)];

    if (userId) { where.unshift('user_id = ?'); params.unshift(String(userId)); }

    const whereClause = where.join(' AND ');

    const stats = db.prepare(`
      SELECT status, COUNT(*) as count
      FROM staff_attendance WHERE ${whereClause}
      GROUP BY status
    `).all(...params);

    const total = db.prepare(
      `SELECT COUNT(*) as count FROM staff_attendance WHERE ${whereClause}`
    ).get(...params).count;

    const avgCheckIn = db.prepare(`
      SELECT AVG(strftime('%H', check_in) * 60 + strftime('%M', check_in)) as avg_minutes
      FROM staff_attendance WHERE ${whereClause} AND check_in IS NOT NULL
    `).get(...params);

    const summary = {
      total,
      present: 0, absent: 0, late: 0, half_day: 0, leave: 0,
    };
    for (const row of stats) {
      summary[row.status] = row.count;
    }

    const avgMinutes = avgCheckIn?.avg_minutes;
    summary.avgCheckInTime = avgMinutes != null
      ? `${String(Math.floor(avgMinutes / 60)).padStart(2, '0')}:${String(Math.round(avgMinutes % 60)).padStart(2, '0')}`
      : null;

    return { month: targetMonth, year: targetYear, summary };
  }

  async getMonthlyReport({ userId, month, year }) {
    const db = getDb();
    const targetMonth = month || (new Date().getMonth() + 1);
    const targetYear = year || new Date().getFullYear();
    const monthStr = String(targetMonth).padStart(2, '0');

    let where = ["strftime('%m', sa.date) = ?", "strftime('%Y', sa.date) = ?"];
    let params = [monthStr, String(targetYear)];

    if (userId) { where.unshift('sa.user_id = ?'); params.unshift(String(userId)); }

    const whereClause = where.join(' AND ');

    const records = db.prepare(`
      SELECT sa.*, u.first_name, u.last_name, u.email
      FROM staff_attendance sa
      JOIN users u ON sa.user_id = u.id
      WHERE ${whereClause}
      ORDER BY sa.date ASC
    `).all(...params);

    const stats = await this.getAttendanceStats({ userId, month: targetMonth, year: targetYear });

    return { month: targetMonth, year: targetYear, stats, records };
  }
}

export default new AttendanceService();
