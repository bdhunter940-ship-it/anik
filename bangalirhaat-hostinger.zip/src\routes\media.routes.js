import { Router } from 'express';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { uploadGeneral } from '../middleware/upload.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

router.post('/upload', adminAuth, uploadGeneral, async (req, res, next) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'No files uploaded' });
    }

    const db = getDb();
    const insert = db.prepare(
      `INSERT INTO media_files (filename, original_name, mime_type, size, url, uploaded_by)
       VALUES (?, ?, ?, ?, ?, ?)`
    );

    const records = [];
    for (const file of req.files) {
      const url = '/uploads/' + file.filename;
      const result = insert.run(
        file.filename,
        file.originalname,
        file.mimetype,
        file.size,
        url,
        req.user.id
      );
      const record = db.prepare('SELECT * FROM media_files WHERE id = ?').get(result.lastInsertRowid);
      records.push(record);
    }

    res.status(201).json({ success: true, data: records });
  } catch (error) {
    next(error);
  }
});

router.get('/', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const files = db.prepare('SELECT * FROM media_files ORDER BY created_at DESC').all();
    res.json({ success: true, data: files });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const existing = db.prepare('SELECT id FROM media_files WHERE id = ?').get(req.params.id);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Media file not found' });
    }

    db.prepare('DELETE FROM media_files WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Media file deleted successfully' });
  } catch (error) {
    next(error);
  }
});

router.get('/recent', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const files = db.prepare('SELECT * FROM media_files ORDER BY created_at DESC LIMIT 20').all();
    res.json({ success: true, data: files });
  } catch (error) {
    next(error);
  }
});

export default router;
