import config from '../config/index.js';

const SMS_GATEWAY_URL = process.env.SMS_GATEWAY_URL || '';
const SMS_API_KEY = process.env.SMS_API_KEY || '';
const SMS_SENDER_ID = process.env.SMS_SENDER_ID || 'Bangalirhaat';
const SMS_ENABLED = process.env.SMS_ENABLED === 'true';

function normalizeBdPhone(phone) {
  if (!phone) return '';
  let cleaned = phone.replace(/[\s\-()]/g, '');
  if (cleaned.startsWith('+880')) cleaned = cleaned.slice(1);
  if (cleaned.startsWith('880')) cleaned = cleaned;
  if (cleaned.startsWith('01')) cleaned = '880' + cleaned;
  if (!cleaned.startsWith('880')) cleaned = '880' + cleaned;
  return cleaned;
}

function formatBdPhoneDisplay(phone) {
  const num = normalizeBdPhone(phone);
  if (num.length === 13) {
    return `+${num.slice(0, 2)}-${num.slice(2, 6)}-${num.slice(6)}`;
  }
  return phone;
}

class SMSService {
  constructor() {
    this.provider = process.env.SMS_PROVIDER || 'console';
    if (this.provider === 'boomcast') {
      this.config = {
        apiUrl: process.env.BOOMCAST_API_URL || 'https://api.boomcast.com/v2/sms/text',
        apiKey: process.env.BOOMCAST_API_KEY || '',
        senderId: process.env.BOOMCAST_SENDER_ID || 'Bangalirhaat',
        mask: process.env.BOOMCAST_MASK || '',
      };
    } else if (this.provider === 'sslcommerz_sms') {
      this.config = {
        apiUrl: process.env.SSL_SMS_URL || 'https://smspro.sslwireless.com/push-api/dynamic-code.php',
        apiKey: process.env.SSL_SMS_API_KEY || '',
        senderId: process.env.SSL_SMS_SENDER_ID || '8809601002580',
      };
    } else if (this.provider === 'bulkSMSBD') {
      this.config = {
        apiUrl: process.env.BULK_SMS_URL || 'https://bulksmsbd.net/api/v1/sms/send',
        apiKey: process.env.BULK_SMS_API_KEY || '',
        senderId: process.env.BULK_SMS_SENDER_ID || 'Bangalirhaat',
      };
    } else {
      this.config = {};
    }

    console.log(`[SMSService] Initialized with provider: ${this.provider}${SMS_ENABLED ? ' (enabled)' : ' (disabled)'}`);
  }

  async send(phone, message) {
    if (!phone) {
      console.warn('[SMSService] No phone number provided, skipping SMS');
      return { success: false, reason: 'no_phone' };
    }

    const normalizedPhone = normalizeBdPhone(phone);

    if (!SMS_ENABLED || this.provider === 'console') {
      console.log(`[SMSService] (DEV) To: ${formatBdPhoneDisplay(normalizedPhone)} | Message: ${message}`);
      return { success: true, provider: 'console', messageId: `dev-${Date.now()}` };
    }

    try {
      let result;

      if (this.provider === 'boomcast') {
        result = await this._sendBoomCast(normalizedPhone, message);
      } else if (this.provider === 'sslcommerz_sms') {
        result = await this._sendSSLCommerz(normalizedPhone, message);
      } else if (this.provider === 'bulkSMSBD') {
        result = await this._sendBulkSMSBD(normalizedPhone, message);
      } else {
        console.warn(`[SMSService] Unknown provider: ${this.provider}, logging to console`);
        result = { success: true, provider: 'fallback_console', messageId: `fallback-${Date.now()}` };
      }

      console.log(`[SMSService] Sent to ${formatBdPhoneDisplay(normalizedPhone)} via ${result.provider}`);
      return result;
    } catch (error) {
      console.error(`[SMSService] Failed to send SMS to ${formatBdPhoneDisplay(normalizedPhone)}:`, error.message);
      console.log(`[SMSService] (FALLBACK) To: ${formatBdPhoneDisplay(normalizedPhone)} | Message: ${message}`);
      return { success: false, provider: this.provider, error: error.message, fallback: true };
    }
  }

  async _sendBoomCast(phone, message) {
    const body = JSON.stringify({
      sender: this.config.senderId || 'Bangalirhaat',
      to: phone,
      text: message,
      mask: this.config.mask || 'Bangalirhaat',
    });

    const response = await fetch(this.config.apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'authkey': this.config.apiKey,
      },
      body,
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || `BoomCast API error: ${response.status}`);
    }

    const result = await response.json();

    return {
      success: true,
      provider: 'boomcast',
      messageId: result.data?.smsid || result.message_id || `boomcast-${Date.now()}`,
      status: result.status || 'sent',
      cost: result.data?.cost || 0,
      gateway: result,
    };
  }

  async _sendSSLCommerz(phone, message) {
    const params = new URLSearchParams({
      usr: this.config.apiKey,
      pass: process.env.SSL_SMS_PASSWORD || '',
      sender: this.config.senderId,
      'sms[0][num]': phone,
      'sms[0][msg]': message,
      type: 'text',
    });

    const response = await fetch(this.config.apiUrl, {
      method: 'GET',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    });

    const result = await response.json();

    if (result.status !== 'success' && !result.sms_id) {
      throw new Error(result.message || 'SSLCommerz SMS failed');
    }

    return {
      success: true,
      provider: 'sslcommerz_sms',
      messageId: result.sms_id || `ssl-sms-${Date.now()}`,
      status: 'sent',
      gateway: result,
    };
  }

  async _sendBulkSMSBD(phone, message) {
    const body = new URLSearchParams({
      token: this.config.apiKey,
      to: phone,
      sender: this.config.senderId,
      message,
    });

    const response = await fetch(this.config.apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });

    if (!response.ok) {
      throw new Error(`BulkSMSBD API error: ${response.status}`);
    }

    const result = await response.json();

    if (result.status !== 'success') {
      throw new Error(result.message || 'BulkSMSBD send failed');
    }

    return {
      success: true,
      provider: 'bulkSMSBD',
      messageId: result.data?.message_id || `bulk-${Date.now()}`,
      status: 'sent',
      gateway: result,
    };
  }

  async sendOTP(phone, otp) {
    const message = `[Bangalirhaat] Your verification code is: ${otp}. Valid for 10 minutes. Do NOT share this code with anyone. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendOrderConfirmation(phone, orderNumber) {
    const message = `[Bangalirhaat] Your order #${orderNumber} has been placed successfully! We will notify you once it ships. Track your order at bangalirhaat.com. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendShippingNotification(phone, trackingNumber, courier) {
    const courierName = courier || 'our courier partner';
    const message = `[Bangalirhaat] Your order has been shipped! Tracking: ${trackingNumber} via ${courierName}. Track at bangalirhaat.com/orders. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendDeliveryConfirmation(phone, orderNumber) {
    const message = `[Bangalirhaat] Your order #${orderNumber} has been delivered! Thank you for shopping with Bangalirhaat. We hope you love your purchase! -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendCODReminder(phone, orderNumber, amount) {
    const formattedAmount = amount ? `৳${Number(amount).toLocaleString()}` : 'N/A';
    const message = `[Bangalirhaat] Reminder: Your order #${orderNumber} requires cash on delivery payment of ${formattedAmount}. Please keep the exact amount ready. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendReturnApproved(phone, orderNumber) {
    const message = `[Bangalirhaat] Your return request for order #${orderNumber} has been approved. Our courier will pick up the item within 48 hours. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendRefundProcessed(phone, orderNumber, amount) {
    const formattedAmount = amount ? `৳${Number(amount).toLocaleString()}` : 'N/A';
    const message = `[Bangalirhaat] Your refund of ${formattedAmount} for order #${orderNumber} has been processed. It will be credited within 5-10 business days. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendAccountVerification(phone, otp) {
    const message = `[Bangalirhaat] Welcome! Your account verification code is: ${otp}. Valid for 10 minutes. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendPasswordReset(phone, otp) {
    const message = `[Bangalirhaat] Your password reset code is: ${otp}. Valid for 10 minutes. If you did not request this, ignore this SMS. -Bangalirhaat`;
    return this.send(phone, message);
  }

  async sendPromotional(phone, message) {
    const fullMessage = `[Bangalirhaat] ${message}\n\nTo unsubscribe: SMS STOP to +880-XXXXXXXXX`;
    return this.send(phone, fullMessage);
  }

  async sendBulk(phoneNumbers, message) {
    if (!Array.isArray(phoneNumbers) || phoneNumbers.length === 0) {
      return { success: false, reason: 'No phone numbers provided' };
    }

    const results = [];
    for (const phone of phoneNumbers) {
      try {
        const result = await this.send(phone, message);
        results.push({ phone, ...result });
      } catch (error) {
        results.push({ phone, success: false, error: error.message });
      }
    }

    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;

    return { success: true, total: phoneNumbers.length, successful, failed, results };
  }

  getStats() {
    return {
      provider: this.provider,
      enabled: SMS_ENABLED,
      senderId: this.config?.senderId || SMS_SENDER_ID,
      gatewayUrl: SMS_GATEWAY_URL || this.config?.apiUrl || 'N/A',
    };
  }
}

export default new SMSService();
