import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { createServer } from 'node:http';
import { WebSocketServer } from 'ws';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import { readdir } from 'node:fs/promises';
import config from './src/config/index.js';
import { initializeDatabase } from './src/database/db.js';
import { seedIfNeeded } from './src/database/seed.js';
import cronService from './src/services/cron.service.js';
import cacheService from './src/services/cache.service.js';
import { setCsrfCookie } from './src/middleware/csrf.js';
import { deviceTracker } from './src/middleware/deviceTracker.js';
import { maintenanceMode } from './src/middleware/maintenance.js';
import { schedule } from 'node-cron';

// ── Paths ──────────────────────────────────────────────────────────────────
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ── Express App ────────────────────────────────────────────────────────────
const app = express();

// ── Security Headers ───────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: config.isProduction ? undefined : false,
  crossOriginEmbedderPolicy: false,
}));

// ── CORS ───────────────────────────────────────────────────────────────────
const corsOrigins = config.cors.origins.includes('*')
  ? '*'
  : config.cors.origins;

app.use(cors({
  origin: corsOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  maxAge: 86400,
}));

// ── Compression ────────────────────────────────────────────────────────────
app.use(compression({
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  },
  level: 6,
}));

// ── Request Logging ────────────────────────────────────────────────────────
app.use(morgan(config.isProduction ? 'combined' : 'dev'));

// ── Cookie Parser ──────────────────────────────────────────────────────────
app.use(cookieParser(config.session.secret));

// ── Device Tracker ─────────────────────────────────────────────────────────
app.use(deviceTracker);

// ── Maintenance Mode ──────────────────────────────────────────────────────
app.use(maintenanceMode);

// ── CSRF (enable when ready) ───────────────────────────────────────────────
// app.use(setCsrfCookie);

// ── Global Rate Limiter ────────────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many requests, please try again later.',
  },
  keyGenerator: (req) => req.ip,
});
app.use('/api', limiter);

// ── Body Parsing ───────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Static Files ───────────────────────────────────────────────────────────
const publicDir = path.resolve(__dirname, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
app.use(express.static(publicDir, {
  maxAge: config.isProduction ? '7d' : '0',
  etag: true,
  lastModified: true,
}));

// ── PWA Service Worker ─────────────────────────────────────────────────────
app.get('/sw.js', (req, res) => {
  res.setHeader('Service-Worker-Allowed', '/');
  res.setHeader('Cache-Control', 'no-cache');
  res.sendFile(path.join(publicDir, 'sw.js'));
});

// ── PWA Manifest ───────────────────────────────────────────────────────────
app.get('/manifest.webmanifest', (req, res) => {
  res.setHeader('Content-Type', 'application/manifest+json');
  res.sendFile(path.join(publicDir, 'manifest.json'));
});

// ── Health Check ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({
    success: true,
    message: 'Bangalirhaat API is running',
    environment: config.env,
    timestamp: new Date().toISOString(),
  });
});

// ── API Info ───────────────────────────────────────────────────────────────
app.get('/api', (_req, res) => {
  res.json({
    success: true,
    name: 'Bangalirhaat API',
    version: '1.0.0',
    description: 'Premium Bangladeshi E-Commerce Platform',
    documentation: '/api/docs',
  });
});

// ── Mount Route Files ──────────────────────────────────────────────────────
async function mountRoutes() {
  const routesDir = path.resolve(__dirname, 'src', 'routes');

  if (!fs.existsSync(routesDir)) {
    console.warn('⚠  src/routes/ directory not found — no routes mounted');
    return;
  }

  const entries = await readdir(routesDir, { withFileTypes: true });
  const routeFiles = entries
    .filter((e) => e.isFile() && e.name.endsWith('.js'))
    .sort();

  for (const file of routeFiles) {
    const routePath = path.join(routesDir, file.name);
    const routeModule = await import(pathToFileURL(routePath).href);
    const mount = routeModule.default || routeModule;

    if (typeof mount === 'function') {
      // Convention: filename "auth.routes.js" → mount at "/api/auth"
      const routeName = file.name
        .replace(/\.routes?\.(js|mjs)$/i, '')
        .replace(/\.[^.]+$/, '');

      if (routeName === 'index') {
        app.use('/api', mount);
      } else {
        app.use(`/api/${routeName}`, mount);
      }
      console.log(`  ✓  /api/${routeName} ← ${file.name}`);
    } else {
      console.warn(`  ✗  ${file.name} did not export a function — skipped`);
    }
  }
}

// ── Create HTTP Server ─────────────────────────────────────────────────────
const server = createServer(app);

// ── WebSocket Server ───────────────────────────────────────────────────────
const wss = new WebSocketServer({ server, path: '/ws' });

const wsClients = new Map();

wss.on('connection', (ws, req) => {
  const clientId = `client_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

  wsClients.set(clientId, { ws, ip, connectedAt: new Date().toISOString() });

  console.log(`[WS] Client connected: ${clientId} from ${ip} (total: ${wsClients.size})`);

  ws.isAlive = true;
  ws.clientId = clientId;

  ws.on('pong', () => {
    ws.isAlive = true;
  });

  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());

      switch (message.type) {
        case 'ping':
          ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
          break;

        case 'subscribe':
          ws.subscriptions = ws.subscriptions || new Set();
          ws.subscriptions.add(message.channel);
          ws.send(JSON.stringify({
            type: 'subscribed',
            channel: message.channel,
          }));
          break;

        case 'unsubscribe':
          ws.subscriptions?.delete(message.channel);
          ws.send(JSON.stringify({
            type: 'unsubscribed',
            channel: message.channel,
          }));
          break;

        default:
          ws.send(JSON.stringify({
            type: 'error',
            message: `Unknown message type: ${message.type}`,
          }));
      }
    } catch {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Invalid message format',
      }));
    }
  });

  ws.on('close', () => {
    wsClients.delete(clientId);
    console.log(`[WS] Client disconnected: ${clientId} (total: ${wsClients.size})`);
  });

  ws.on('error', (err) => {
    console.error(`[WS] Error from ${clientId}:`, err.message);
    wsClients.delete(clientId);
  });

  ws.send(JSON.stringify({
    type: 'connected',
    clientId,
    message: 'Welcome to Bangalirhaat real-time notifications',
  }));
});

// Heartbeat: terminate dead connections every 30 seconds
const wsHeartbeat = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) {
      wsClients.delete(ws.clientId);
      return ws.terminate();
    }
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

wss.on('close', () => {
  clearInterval(wsHeartbeat);
});

// Broadcast utility (useful from services/controllers)
function broadcast(channel, payload) {
  const message = JSON.stringify({ type: 'broadcast', channel, payload });
  wss.clients.forEach((client) => {
    if (client.readyState === 1 && client.subscriptions?.has(channel)) {
      client.send(message);
    }
  });
}

// Attach broadcast to app for use in route handlers
app.set('broadcast', broadcast);
app.set('wss', wss);

// ── ASCII Art Logo ─────────────────────────────────────────────────────────
function printLogo() {
  const logo = `
\`\`\`
 ██████╗  █████╗ ███████╗██╗     ██╗     ███████╗ █████╗ ██████╗ ██████╗
 ██╔══██╗██╔══██╗██╔════╝██║     ██║     ██╔════╝██╔══██╗██╔══██╗██╔══██╗
 ██████╔╝███████║███████╗██║     ██║     █████╗  ███████║██████╔╝██████╔╝
 ██╔══██╗██╔══██║╚════██║██║     ██║     ██╔══╝  ██╔══██║██╔═══╝ ██╔══██╗
 ██████╔╝██║  ██║███████║███████╗███████╗███████╗██║  ██║██║     ██║  ██║
 ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝
              Premium Bangladeshi E-Commerce Platform
\`\`\``;
  console.log(logo);
}

// ── Graceful Shutdown ──────────────────────────────────────────────────────
let isShuttingDown = false;

async function gracefulShutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;

  console.log(`\n[SERVER] ${signal} received — shutting down gracefully...`);

  // Stop accepting new connections
  server.close(async () => {
    console.log('[SERVER] HTTP server closed');

    // Close all WebSocket connections
    wss.clients.forEach((client) => {
      client.close(1001, 'Server shutting down');
    });
    wss.close(() => {
      console.log('[SERVER] WebSocket server closed');
    });

    // Close database connection if available
    try {
      const { closeDatabase } = await import('./src/database/db.js');
      if (typeof closeDatabase === 'function') {
        await closeDatabase();
        console.log('[SERVER] Database connection closed');
      }
    } catch {
      // Database module may not exist yet during initial setup
    }

    console.log('[SERVER] Shutdown complete');
    process.exit(0);
  });

  // Force exit after 10 seconds
  setTimeout(() => {
    console.error('[SERVER] Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('[SERVER] Unhandled Rejection at:', promise, 'reason:', reason);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('[SERVER] Uncaught Exception:', err.message);
  if (config.env === 'production') {
    gracefulShutdown('UNCAUGHT_EXCEPTION');
  }
});

// ── Bootstrap ──────────────────────────────────────────────────────────────
async function start() {
  printLogo();
  console.log(`[SERVER] Environment : ${config.env}`);
  console.log(`[SERVER] Port        : ${config.server.port}`);

  // Initialize database
  try {
    console.log('[SERVER] Initializing database...');
    await initializeDatabase();
    console.log('[SERVER] Database ready');

    // Auto-seed if no users exist
    seedIfNeeded();

    // Ensure SteadFast courier exists in DB
    try {
      const { getDb } = await import('./src/database/db.js');
      const db = getDb();
      const sf = db.prepare(`SELECT id FROM couriers WHERE slug = 'steadfast'`).get();
      if (!sf) {
        db.prepare(
          `INSERT INTO couriers (name, slug, api_key, api_secret, api_url, is_active, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))`
        ).run(
          'SteadFast Courier', 'steadfast',
          config.courier.steadfast.apiKey,
          config.courier.steadfast.apiSecret,
          config.courier.steadfast.url
        );
        console.log('[SERVER] Seeded SteadFast courier');
      } else {
        db.prepare(
          `UPDATE couriers SET api_key = ?, api_secret = ?, api_url = ?, updated_at = datetime('now') WHERE slug = 'steadfast'`
        ).run(config.courier.steadfast.apiKey, config.courier.steadfast.apiSecret, config.courier.steadfast.url);
      }
    } catch (e) {
      console.warn('[SERVER] SteadFast courier seed warning:', e.message);
    }
  } catch (err) {
    console.error('[SERVER] Database initialization failed:', err.message);
    process.exit(1);
  }

  // Start background services
  cronService.start();
  console.log('[SERVER] Cron jobs started');

  // Abandoned cart recovery — runs every 6 hours
  const abandonedCartJob = schedule('0 */6 * * *', async () => {
    console.log('[Cron] Processing abandoned carts...');
    try {
      const { default: cartService } = await import('./src/services/cart.service.js');
      const result = await cartService.processAbandonedCarts(24);
      console.log(`[Cron] Abandoned carts processed: ${result.processed}`);
    } catch (err) { console.error('[Cron] Abandoned carts error:', err.message); }
  }, { timezone: 'Asia/Dhaka' });

  cacheService.startCleanup();
  console.log('[SERVER] Cache cleanup started');

  // Mount API routes
  console.log('[SERVER] Mounting routes...');
  await mountRoutes();

  // 404 Handler for API Routes (must be after routes)
  app.all('/api/*', (_req, res) => {
    res.status(404).json({
      success: false,
      message: 'API endpoint not found',
    });
  });

  // Catch-all for non-API routes — serve SPA index.html for client-side routing
  app.use((req, res) => {
    if (req.path.startsWith('/api/') || req.path.startsWith('/health') || req.path === '/api') {
      return res.status(404).json({ success: false, message: 'API endpoint not found' });
    }
    res.sendFile(path.join(publicDir, 'index.html'));
  });

  // Global Error Handler
  app.use((err, _req, res, _next) => {
    const statusCode = err.statusCode || 500;
    const message = config.isProduction
      ? 'Internal server error'
      : err.message || 'Internal server error';

    if (statusCode >= 500) {
      console.error('╔══════════════════════════════════════════╗');
      console.error('║           UNHANDLED ERROR                ║');
      console.error('╚══════════════════════════════════════════╝');
      console.error(err);
    }

    res.status(statusCode).json({
      success: false,
      message,
      ...(config.isDevelopment && { stack: err.stack }),
    });
  });

  // Start listening
  server.listen(config.server.port, () => {
    console.log('');
    console.log('══════════════════════════════════════════════════');
    console.log(`  Bangalirhaat API server is running`);
    console.log(`  Local   : http://localhost:${config.server.port}`);
    console.log(`  API     : http://localhost:${config.server.port}/api`);
    console.log(`  WS      : ws://localhost:${config.server.port}/ws`);
    console.log(`  Health  : http://localhost:${config.server.port}/health`);
    console.log('══════════════════════════════════════════════════');
    console.log('');
  });
}

start().catch((err) => {
  console.error('[SERVER] Fatal startup error:', err);
  process.exit(1);
});

export { app, server, wss, broadcast };
