import nodemailer from 'nodemailer';
import config from '../config/index.js';

const BASE_URL = 'https://bangalirhaat.com';

const COLORS = {
  primary: '#C41E3A',
  primaryDark: '#A01830',
  secondary: '#1A6B3C',
  accent: '#D4A843',
  bg: '#FFF8F0',
  cardBg: '#FFFFFF',
  text: '#2D2D2D',
  textLight: '#6B7280',
  border: '#E5D5C5',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

function emailWrapper(title, content) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
</head>
<body style="margin:0;padding:0;background-color:${COLORS.bg};font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;color:${COLORS.text};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:${COLORS.bg};">
<tr><td align="center" style="padding:30px 15px;">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

  <tr><td style="background:linear-gradient(135deg,${COLORS.primary},${COLORS.primaryDark});padding:30px 40px;border-radius:16px 16px 0 0;text-align:center;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
      <td style="text-align:center;">
        <h1 style="margin:0;color:#FFFFFF;font-size:28px;font-weight:800;letter-spacing:1px;">&#127758; Bangalirhaat</h1>
        <p style="margin:6px 0 0;color:${COLORS.accent};font-size:13px;letter-spacing:2px;text-transform:uppercase;">Premium Bangladeshi E-Commerce</p>
      </td>
    </tr></table>
  </td></tr>

  <tr><td style="background-color:${COLORS.cardBg};padding:40px;border:1px solid ${COLORS.border};border-top:none;">
    ${content}
  </td></tr>

  <tr><td style="background-color:${COLORS.cardBg};padding:25px 40px;border:1px solid ${COLORS.border};border-top:none;border-radius:0 0 16px 16px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <td style="border-top:1px solid ${COLORS.border};padding-top:20px;text-align:center;">
          <p style="margin:0 0 8px;font-size:12px;color:${COLORS.textLight};">&copy; ${new Date().getFullYear()} Bangalirhaat. All rights reserved.</p>
          <p style="margin:0 0 8px;font-size:12px;color:${COLORS.textLight};">Dhaka, Bangladesh</p>
          <p style="margin:0;font-size:11px;color:${COLORS.textLight};">
            <a href="${BASE_URL}/unsubscribe" style="color:${COLORS.primary};text-decoration:underline;">Unsubscribe</a>
            &nbsp;|&nbsp;
            <a href="${BASE_URL}/privacy" style="color:${COLORS.primary};text-decoration:underline;">Privacy Policy</a>
          </p>
        </td>
      </tr>
    </table>
  </td></tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

function buttonStyle(bg = COLORS.primary) {
  return `display:inline-block;padding:14px 36px;background-color:${bg};color:#FFFFFF;text-decoration:none;border-radius:8px;font-weight:700;font-size:15px;letter-spacing:0.5px;`;
}

class EmailService {
  constructor() {
    if (!config.smtp.user || !config.smtp.pass) {
      console.warn('[EmailService] SMTP credentials not configured. Emails will be logged to console.');
      this.transporter = null;
    } else {
      this.transporter = nodemailer.createTransport({
        host: config.smtp.host,
        port: config.smtp.port,
        secure: config.smtp.port === 465,
        auth: { user: config.smtp.user, pass: config.smtp.pass },
        tls: { rejectUnauthorized: false },
      });
    }
  }

  async send(to, subject, html) {
    const mailOptions = {
      from: config.smtp.from,
      to,
      subject,
      html,
    };

    if (!this.transporter) {
      console.log(`[EmailService] (DEV) To: ${to} | Subject: ${subject}`);
      return { messageId: `dev-${Date.now()}`, accepted: [to] };
    }

    try {
      const info = await this.transporter.sendMail(mailOptions);
      console.log(`[EmailService] Sent: ${info.messageId} to ${to}`);
      return info;
    } catch (error) {
      console.error(`[EmailService] Failed to send email to ${to}:`, error.message);
      throw error;
    }
  }

  async sendWelcome(user) {
    const subject = 'Welcome to Bangalirhaat! &#127758;';
    const html = emailWrapper('Welcome to Bangalirhaat', `
      <h2 style="margin:0 0 20px;color:${COLORS.primary};font-size:24px;">Welcome, ${user.first_name}!</h2>
      <p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:${COLORS.text};">
        We are thrilled to have you join the <strong>Bangalirhaat</strong> family! You now have access to the finest selection
        of authentic Bangladeshi products &mdash; from handwoven Jamdani sarees to artisanal Tangail silk, traditional Nakshikantha,
        and much more.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:24px 0;">
        <tr>
          <td style="background:${COLORS.bg};border-radius:12px;padding:24px;border:1px solid ${COLORS.border};">
            <h3 style="margin:0 0 14px;color:${COLORS.secondary};font-size:16px;">&#127381; Your Account Benefits</h3>
            <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;">
              <tr><td style="padding:6px 0;font-size:14px;color:${COLORS.text};">&#10004;&#65039; Exclusive member discounts</td></tr>
              <tr><td style="padding:6px 0;font-size:14px;color:${COLORS.text};">&#10004;&#65039; Earn loyalty points on every purchase</td></tr>
              <tr><td style="padding:6px 0;font-size:14px;color:${COLORS.text};">&#10004;&#65039; Early access to flash sales</td></tr>
              <tr><td style="padding:6px 0;font-size:14px;color:${COLORS.text};">&#10004;&#65039; Refer friends &amp; earn rewards</td></tr>
              <tr><td style="padding:6px 0;font-size:14px;color:${COLORS.text};">&#10004;&#65039; Secure checkout with multiple payment options</td></tr>
            </table>
          </td>
        </tr>
      </table>
      ${user.referral_code ? `
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:${COLORS.secondary};border-radius:12px;padding:24px;text-align:center;">
            <p style="margin:0 0 6px;color:${COLORS.accent};font-size:12px;text-transform:uppercase;letter-spacing:2px;">Your Referral Code</p>
            <p style="margin:0;font-size:28px;font-weight:800;color:#FFFFFF;letter-spacing:3px;">${user.referral_code}</p>
            <p style="margin:8px 0 0;color:rgba(255,255,255,0.8);font-size:13px;">Share with friends, earn ৳200 for each referral!</p>
          </td>
        </tr>
      </table>` : ''}
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px 0;">
        <tr><td><a href="${BASE_URL}/shop" style="${buttonStyle()}">Start Shopping &#10140;</a></td></tr>
      </table>
      <p style="margin:20px 0 0;font-size:14px;color:${COLORS.textLight};line-height:1.6;">
        Need help? Contact us at <a href="mailto:support@bangalirhaat.com" style="color:${COLORS.primary};">support@bangalirhaat.com</a>
        or call <strong>+880-1XXXXXXXXX</strong>. We are here for you!
      </p>
    `);
    return this.send(user.email, subject, html);
  }

  async sendOTP(user, otp) {
    const subject = 'Your Verification Code - Bangalirhaat';
    const html = emailWrapper('Verify Your Account', `
      <h2 style="margin:0 0 20px;color:${COLORS.primary};font-size:22px;">Verification Code</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Hi ${user.first_name}, use the following One-Time Password to verify your account. This code is valid for <strong>10 minutes</strong>.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px auto;">
        <tr>
          <td style="background:${COLORS.bg};border:2px dashed ${COLORS.primary};border-radius:12px;padding:24px 48px;text-align:center;">
            <p style="margin:0;font-size:42px;font-weight:900;color:${COLORS.primary};letter-spacing:12px;font-family:'Courier New',monospace;">${otp}</p>
          </td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:#FEF3C7;border-radius:8px;padding:16px;border-left:4px solid ${COLORS.warning};">
            <p style="margin:0;font-size:13px;color:#92400E;line-height:1.5;">
              <strong>&#9888;&#65039; Security Notice:</strong> Never share this OTP with anyone. Bangalirhaat staff will
              never ask for your OTP via phone or email. If you did not request this code, please ignore this email.
            </p>
          </td>
        </tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendOrderConfirmation(order, user) {
    const items = order.items || [];
    const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};
    let itemsHtml = '';
    for (const item of items) {
      itemsHtml += `
        <tr>
          <td style="padding:12px 0;border-bottom:1px solid ${COLORS.border};font-size:14px;color:${COLORS.text};">${item.product_name}</td>
          <td style="padding:12px 0;border-bottom:1px solid ${COLORS.border};font-size:14px;color:${COLORS.text};text-align:center;">x${item.quantity}</td>
          <td style="padding:12px 0;border-bottom:1px solid ${COLORS.border};font-size:14px;color:${COLORS.text};text-align:right;font-weight:600;">&#2547;${item.total.toLocaleString()}</td>
        </tr>`;
    }

    const subject = `Order Confirmed! #${order.order_number} - Bangalirhaat`;
    const html = emailWrapper('Order Confirmation', `
      <h2 style="margin:0 0 10px;color:${COLORS.secondary};font-size:22px;">&#9989; Order Confirmed!</h2>
      <p style="margin:0 0 20px;font-size:15px;color:${COLORS.text};">
        Thank you, <strong>${user.first_name}</strong>! Your order has been placed successfully.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:0 0 24px;">
        <tr>
          <td style="background:${COLORS.bg};border-radius:10px;padding:20px;border:1px solid ${COLORS.border};">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td style="font-size:13px;color:${COLORS.textLight};padding:4px 0;">Order Number</td>
                <td style="font-size:14px;color:${COLORS.text};font-weight:700;text-align:right;padding:4px 0;">${order.order_number}</td>
              </tr>
              <tr>
                <td style="font-size:13px;color:${COLORS.textLight};padding:4px 0;">Payment Method</td>
                <td style="font-size:14px;color:${COLORS.text};font-weight:600;text-align:right;padding:4px 0;">${(order.payment_method || 'N/A').toUpperCase()}</td>
              </tr>
              <tr>
                <td style="font-size:13px;color:${COLORS.textLight};padding:4px 0;">Payment Status</td>
                <td style="font-size:14px;text-align:right;padding:4px 0;"><span style="background:#FEF3C7;color:#92400E;padding:3px 10px;border-radius:12px;font-weight:600;font-size:12px;">${order.payment_status}</span></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <h3 style="margin:0 0 12px;font-size:16px;color:${COLORS.text};">Order Items</h3>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <th style="text-align:left;padding:8px 0;border-bottom:2px solid ${COLORS.border};font-size:12px;color:${COLORS.textLight};text-transform:uppercase;letter-spacing:1px;">Item</th>
          <th style="text-align:center;padding:8px 0;border-bottom:2px solid ${COLORS.border};font-size:12px;color:${COLORS.textLight};text-transform:uppercase;letter-spacing:1px;">Qty</th>
          <th style="text-align:right;padding:8px 0;border-bottom:2px solid ${COLORS.border};font-size:12px;color:${COLORS.textLight};text-transform:uppercase;letter-spacing:1px;">Total</th>
        </tr>
        ${itemsHtml}
      </table>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:16px 0;">
        <tr>
          <td style="font-size:14px;color:${COLORS.textLight};padding:4px 0;">Subtotal</td>
          <td style="font-size:14px;color:${COLORS.text};text-align:right;padding:4px 0;">&#2547;${order.subtotal.toLocaleString()}</td>
        </tr>
        ${order.discount > 0 ? `<tr>
          <td style="font-size:14px;color:${COLORS.success};padding:4px 0;">Discount</td>
          <td style="font-size:14px;color:${COLORS.success};text-align:right;padding:4px 0;">-&nbsp;&#2547;${order.discount.toLocaleString()}</td>
        </tr>` : ''}
        <tr>
          <td style="font-size:14px;color:${COLORS.textLight};padding:4px 0;">Shipping</td>
          <td style="font-size:14px;color:${COLORS.text};text-align:right;padding:4px 0;">${order.shipping_cost === 0 ? '<span style="color:' + COLORS.success + ';font-weight:600;">FREE</span>' : '&#2547;' + order.shipping_cost.toLocaleString()}</td>
        </tr>
        <tr>
          <td style="font-size:16px;font-weight:700;color:${COLORS.text};padding:12px 0 0;border-top:2px solid ${COLORS.text};">Total</td>
          <td style="font-size:18px;font-weight:800;color:${COLORS.primary};text-align:right;padding:12px 0 0;border-top:2px solid ${COLORS.text};">&#2547;${order.total.toLocaleString()}</td>
        </tr>
      </table>
      ${shippingAddr.name ? `
      <h3 style="margin:20px 0 10px;font-size:16px;color:${COLORS.text};">Shipping Address</h3>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin-bottom:20px;">
        <tr><td style="background:${COLORS.bg};border-radius:10px;padding:16px;border:1px solid ${COLORS.border};font-size:14px;line-height:1.7;color:${COLORS.text};">
          <strong>${shippingAddr.name}</strong><br>
          ${shippingAddr.line1 || ''}${shippingAddr.line2 ? ', ' + shippingAddr.line2 : ''}<br>
          ${shippingAddr.city || ''}${shippingAddr.district ? ', ' + shippingAddr.district : ''}<br>
          ${shippingAddr.phone ? 'Phone: ' + shippingAddr.phone : ''}
        </td></tr>
      </table>` : ''}
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:28px 0;">
        <tr><td><a href="${BASE_URL}/orders/${order.order_number}" style="${buttonStyle(COLORS.secondary)}">Track Order &#128269;</a></td></tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendOrderStatusUpdate(order, user) {
    const statusLabels = {
      confirmed: { label: 'Confirmed', icon: '&#9989;', color: COLORS.success },
      packaging: { label: 'Being Packaged', icon: '&#128230;', color: COLORS.warning },
      ready_to_ship: { label: 'Ready to Ship', icon: '&#128666;', color: COLORS.primary },
      courier_sent: { label: 'Dispatched', icon: '&#128640;', color: COLORS.primary },
      in_transit: { label: 'In Transit', icon: '&#128674;', color: '#3B82F6' },
      delivered: { label: 'Delivered', icon: '&#127873;', color: COLORS.success },
      cancelled: { label: 'Cancelled', icon: '&#10060;', color: COLORS.error },
    };
    const info = statusLabels[order.status] || { label: order.status, icon: '&#128196;', color: COLORS.textLight };

    const subject = `Order ${info.label} - ${order.order_number} - Bangalirhaat`;
    const html = emailWrapper('Order Status Update', `
      <h2 style="margin:0 0 20px;color:${info.color};font-size:22px;">${info.icon} Your Order is ${info.label}</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Hi ${user.first_name}, your order <strong>#${order.order_number}</strong> status has been updated.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:${info.color}10;border-radius:12px;padding:24px;border-left:4px solid ${info.color};text-align:center;">
            <p style="margin:0 0 8px;font-size:32px;">${info.icon}</p>
            <p style="margin:0;font-size:20px;font-weight:700;color:${info.color};">${info.label}</p>
            <p style="margin:8px 0 0;font-size:13px;color:${COLORS.textLight};">Order: ${order.order_number}</p>
          </td>
        </tr>
      </table>
      ${order.status === 'delivered' ? `
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:${COLORS.bg};border-radius:10px;padding:20px;border:1px solid ${COLORS.border};text-align:center;">
            <p style="margin:0 0 10px;font-size:14px;color:${COLORS.text};">We hope you love your purchase! Please take a moment to leave a review.</p>
            <a href="${BASE_URL}/orders/${order.order_number}/review" style="${buttonStyle(COLORS.accent)}">Leave a Review &#11088;</a>
          </td>
        </tr>
      </table>` : ''}
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0;">
        <tr><td><a href="${BASE_URL}/orders/${order.order_number}" style="${buttonStyle()}">View Order Details</a></td></tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendShippingNotification(order, user, tracking) {
    const subject = `Your Order Has Been Shipped! - ${order.order_number} - Bangalirhaat`;
    const html = emailWrapper('Shipping Notification', `
      <h2 style="margin:0 0 20px;color:${COLORS.primary};font-size:22px;">&#128666; Your Order is On Its Way!</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Hi ${user.first_name}, great news! Your order <strong>#${order.order_number}</strong> has been dispatched
        and is on its way to you.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:24px 0;">
        <tr>
          <td style="background:linear-gradient(135deg,${COLORS.primary},${COLORS.primaryDark});border-radius:12px;padding:28px;text-align:center;">
            <p style="margin:0 0 8px;color:rgba(255,255,255,0.8);font-size:12px;text-transform:uppercase;letter-spacing:2px;">Tracking Number</p>
            <p style="margin:0;font-size:24px;font-weight:900;color:#FFFFFF;letter-spacing:2px;font-family:'Courier New',monospace;">${tracking.tracking_number || tracking.consignment_id || 'Pending'}</p>
            <p style="margin:8px 0 0;color:rgba(255,255,255,0.7);font-size:13px;">${tracking.courier_name || 'Courier Service'}</p>
          </td>
        </tr>
      </table>
      ${tracking.estimated_delivery ? `
      <p style="margin:0 0 16px;font-size:14px;color:${COLORS.text};text-align:center;">
        <strong>Estimated Delivery:</strong> ${new Date(tracking.estimated_delivery).toLocaleDateString('en-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
      </p>` : ''}
      ${tracking.tracking_url ? `
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:20px auto;">
        <tr><td><a href="${tracking.tracking_url}" style="${buttonStyle(COLORS.secondary)}">Track Shipment &#128269;</a></td></tr>
      </table>` : ''}
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:#DBEAFE;border-radius:8px;padding:16px;border-left:4px solid #3B82F6;">
            <p style="margin:0;font-size:13px;color:#1E40AF;line-height:1.5;">
              <strong>&#128221; Tip:</strong> Please ensure someone is available at the delivery address to receive your package.
              You may be contacted by the courier for delivery confirmation.
            </p>
          </td>
        </tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendRefundConfirmation(order, user, amount) {
    const subject = `Refund Processed - ${order.order_number} - Bangalirhaat`;
    const html = emailWrapper('Refund Confirmation', `
      <h2 style="margin:0 0 20px;color:${COLORS.success};font-size:22px;">&#128176; Refund Processed</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Hi ${user.first_name}, we have processed your refund for order <strong>#${order.order_number}</strong>.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:24px 0;">
        <tr>
          <td style="background:${COLORS.success}10;border-radius:12px;padding:28px;border:1px solid ${COLORS.success}30;text-align:center;">
            <p style="margin:0 0 8px;color:${COLORS.textLight};font-size:13px;text-transform:uppercase;letter-spacing:1px;">Refund Amount</p>
            <p style="margin:0;font-size:36px;font-weight:900;color:${COLORS.success};">&#2547;${amount.toLocaleString()}</p>
            <p style="margin:10px 0 0;font-size:13px;color:${COLORS.textLight};">Refunded to your original payment method</p>
          </td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:16px 0;">
        <tr>
          <td style="font-size:14px;color:${COLORS.textLight};padding:4px 0;">Order Number</td>
          <td style="font-size:14px;color:${COLORS.text};font-weight:600;text-align:right;padding:4px 0;">${order.order_number}</td>
        </tr>
        <tr>
          <td style="font-size:14px;color:${COLORS.textLight};padding:4px 0;">Refund Method</td>
          <td style="font-size:14px;color:${COLORS.text};font-weight:600;text-align:right;padding:4px 0;">${(order.payment_method || 'Original method').toUpperCase()}</td>
        </tr>
        <tr>
          <td style="font-size:14px;color:${COLORS.textLight};padding:4px 0;">Processing Time</td>
          <td style="font-size:14px;color:${COLORS.text};font-weight:600;text-align:right;padding:4px 0;">5-10 business days</td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:#F0FDF4;border-radius:8px;padding:16px;border-left:4px solid ${COLORS.success};">
            <p style="margin:0;font-size:13px;color:#166534;line-height:1.5;">
              Depending on your bank or payment provider, it may take <strong>5-10 business days</strong> for the refund
              to appear in your account. If you have not received it after this time, please contact your bank.
            </p>
          </td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0;">
        <tr><td><a href="${BASE_URL}/orders/${order.order_number}" style="${buttonStyle()}">View Order</a></td></tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendPasswordReset(user, otp) {
    const subject = 'Password Reset Request - Bangalirhaat';
    const html = emailWrapper('Password Reset', `
      <h2 style="margin:0 0 20px;color:${COLORS.primary};font-size:22px;">&#128274; Password Reset</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Hi ${user.first_name}, we received a request to reset the password for your Bangalirhaat account.
      </p>
      <p style="margin:0 0 24px;font-size:15px;color:${COLORS.text};">
        Use the following OTP to reset your password. This code expires in <strong>10 minutes</strong>.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px auto;">
        <tr>
          <td style="background:${COLORS.error}08;border:2px solid ${COLORS.error};border-radius:12px;padding:24px 48px;text-align:center;">
            <p style="margin:0;font-size:42px;font-weight:900;color:${COLORS.error};letter-spacing:12px;font-family:'Courier New',monospace;">${otp}</p>
          </td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:24px 0;">
        <tr>
          <td style="background:#FEF3C7;border-radius:8px;padding:16px;border-left:4px solid ${COLORS.warning};">
            <p style="margin:0;font-size:13px;color:#92400E;line-height:1.5;">
              <strong>&#9888;&#65039; Did not request this?</strong> If you did not request a password reset, your account
              may be at risk. Please contact our support team immediately at
              <a href="mailto:support@bangalirhaat.com" style="color:#92400E;">support@bangalirhaat.com</a>.
            </p>
          </td>
        </tr>
      </table>
    `);
    return this.send(user.email, subject, html);
  }

  async sendContactReply(message, reply) {
    const subject = `Re: ${message.subject || 'Your Inquiry'} - Bangalirhaat`;
    const html = emailWrapper('Reply to Your Inquiry', `
      <h2 style="margin:0 0 20px;color:${COLORS.primary};font-size:22px;">&#128172; We Have Replied</h2>
      <p style="margin:0 0 16px;font-size:15px;color:${COLORS.text};line-height:1.6;">
        Dear <strong>${message.name}</strong>, thank you for contacting Bangalirhaat. Here is our response to your inquiry.
      </p>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:${COLORS.bg};border-radius:10px;padding:20px;border:1px solid ${COLORS.border};">
            <p style="margin:0 0 8px;font-size:12px;color:${COLORS.textLight};text-transform:uppercase;letter-spacing:1px;">Your Message</p>
            <p style="margin:0;font-size:14px;color:${COLORS.textLight};font-style:italic;line-height:1.5;">${message.message}</p>
          </td>
        </tr>
      </table>
      <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin:20px 0;">
        <tr>
          <td style="background:${COLORS.cardBg};border-radius:10px;padding:20px;border:2px solid ${COLORS.primary}30;">
            <p style="margin:0 0 8px;font-size:12px;color:${COLORS.primary};text-transform:uppercase;letter-spacing:1px;font-weight:700;">Our Reply</p>
            <p style="margin:0;font-size:14px;color:${COLORS.text};line-height:1.7;">${reply}</p>
          </td>
        </tr>
      </table>
      <p style="margin:20px 0 0;font-size:14px;color:${COLORS.textLight};line-height:1.6;">
        If you have further questions, feel free to reply to this email or contact us at
        <a href="mailto:support@bangalirhaat.com" style="color:${COLORS.primary};">support@bangalirhaat.com</a>.
      </p>
    `);
    return this.send(message.email, subject, html);
  }
}

export default new EmailService();
