import crypto from 'crypto';
import { getDb } from '../database/db.js';

class AnalyticsService {
  async trackPageView({ sessionId, userId, page, referrer, productId, categoryId, duration }) {
    const db = getDb();
    const id = crypto.randomUUID();

    db.prepare(`
      INSERT INTO page_views (id, session_id, user_id, page, referrer, product_id, category_id, duration, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(id, sessionId || null, userId || null, page, referrer || null, productId || null, categoryId || null, duration || 0);

    return { id };
  }

  async trackHeatmap({ page, elementSelector, xPercent, yPercent }) {
    const db = getDb();

    const existing = db.prepare(
      'SELECT id, clicks FROM heatmap_data WHERE page = ? AND element_selector = ? AND x_percent = ? AND y_percent = ?'
    ).get(page, elementSelector || '', xPercent || 0, yPercent || 0);

    if (existing) {
      db.prepare('UPDATE heatmap_data SET clicks = clicks + 1 WHERE id = ?').run(existing.id);
      return { id: existing.id, clicks: existing.clicks + 1 };
    }

    const id = crypto.randomUUID();
    db.prepare(`
      INSERT INTO heatmap_data (id, page, element_selector, x_percent, y_percent, clicks, created_at)
      VALUES (?, ?, ?, ?, ?, 1, datetime('now'))
    `).run(id, page, elementSelector || '', xPercent || 0, yPercent || 0);

    return { id, clicks: 1 };
  }

  async trackConversion({ sessionId, userId, eventType, productId, orderId, value }) {
    const db = getDb();
    const validTypes = ['view', 'cart', 'checkout', 'payment', 'purchase'];
    if (!validTypes.includes(eventType)) throw new Error('Invalid event_type');

    const id = crypto.randomUUID();
    db.prepare(`
      INSERT INTO conversion_events (id, session_id, user_id, event_type, product_id, order_id, value, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(id, sessionId || null, userId || null, eventType, productId || null, orderId || null, value || 0);

    return { id };
  }

  async getPageViews({ startDate, endDate, page, limit = 50 }) {
    const db = getDb();
    let where = ['1=1'];
    let params = [];

    if (startDate) { where.push('created_at >= ?'); params.push(startDate); }
    if (endDate) { where.push('created_at <= ?'); params.push(endDate); }
    if (page) { where.push('page = ?'); params.push(page); }

    const whereClause = `WHERE ${where.join(' AND ')}`;
    const safeLimit = Math.min(Math.max(parseInt(limit) || 50, 1), 500);

    const total = db.prepare(`SELECT COUNT(*) as count FROM page_views ${whereClause}`).get(...params).count;
    const items = db.prepare(
      `SELECT * FROM page_views ${whereClause} ORDER BY created_at DESC LIMIT ?`
    ).all(...params, safeLimit);

    return {
      items,
      pagination: { total, limit: safeLimit, totalPages: Math.ceil(total / safeLimit) },
    };
  }

  async getHeatmapData(page) {
    const db = getDb();
    const byElement = db.prepare(
      `SELECT element_selector, SUM(clicks) as total_clicks, COUNT(*) as unique_positions
       FROM heatmap_data WHERE page = ? GROUP BY element_selector ORDER BY total_clicks DESC`
    ).all(page);

    const byPosition = db.prepare(
      `SELECT x_percent, y_percent, SUM(clicks) as total_clicks
       FROM heatmap_data WHERE page = ? GROUP BY x_percent, y_percent ORDER BY total_clicks DESC`
    ).all(page);

    const totalClicks = db.prepare(
      'SELECT SUM(clicks) as total FROM heatmap_data WHERE page = ?'
    ).get(page);

    return {
      page,
      totalClicks: totalClicks?.total || 0,
      byElement,
      byPosition,
    };
  }

  async getConversionFunnel({ startDate, endDate }) {
    const db = getDb();
    let where = ['1=1'];
    let params = [];

    if (startDate) { where.push('created_at >= ?'); params.push(startDate); }
    if (endDate) { where.push('created_at <= ?'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const stages = db.prepare(`
      SELECT event_type, COUNT(DISTINCT session_id) as sessions, COUNT(*) as events
      FROM conversion_events
      ${whereClause}
      GROUP BY event_type
    `).all(...params);

    const funnel = { view: 0, cart: 0, checkout: 0, payment: 0, purchase: 0 };
    for (const row of stages) {
      funnel[row.event_type] = row.sessions;
    }

    return {
      funnel,
      rates: {
        view_to_cart: funnel.view ? (funnel.cart / funnel.view * 100).toFixed(2) : 0,
        cart_to_checkout: funnel.cart ? (funnel.checkout / funnel.cart * 100).toFixed(2) : 0,
        checkout_to_payment: funnel.checkout ? (funnel.payment / funnel.checkout * 100).toFixed(2) : 0,
        payment_to_purchase: funnel.payment ? (funnel.purchase / funnel.payment * 100).toFixed(2) : 0,
        view_to_purchase: funnel.view ? (funnel.purchase / funnel.view * 100).toFixed(2) : 0,
      },
    };
  }

  async getConversionRate({ startDate, endDate }) {
    const db = getDb();
    let where = ['1=1'];
    let params = [];

    if (startDate) { where.push('created_at >= ?'); params.push(startDate); }
    if (endDate) { where.push('created_at <= ?'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const views = db.prepare(
      `SELECT COUNT(DISTINCT session_id) as count FROM conversion_events WHERE event_type = 'view' AND ${whereClause}`
    ).get(...params);

    const purchases = db.prepare(
      `SELECT COUNT(DISTINCT session_id) as count FROM conversion_events WHERE event_type = 'purchase' AND ${whereClause}`
    ).get(...params);

    const rate = views.count ? (purchases.count / views.count * 100) : 0;

    return {
      views: views.count,
      purchases: purchases.count,
      conversionRate: parseFloat(rate.toFixed(2)),
    };
  }

  async getDailySalesReport({ startDate, endDate }) {
    const db = getDb();
    let where = ["o.payment_status = 'paid'", 'o.deleted_at IS NULL'];
    let params = [];

    if (startDate) { where.push('DATE(o.created_at) >= DATE(?)'); params.push(startDate); }
    if (endDate) { where.push('DATE(o.created_at) <= DATE(?)'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const daily = db.prepare(`
      SELECT DATE(o.created_at) as date,
             COUNT(*) as orders,
             COALESCE(SUM(o.total), 0) as revenue,
             COALESCE(SUM(oi.quantity), 0) as items_sold
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      WHERE ${whereClause}
      GROUP BY DATE(o.created_at)
      ORDER BY date DESC
    `).all(...params);

    const summary = db.prepare(`
      SELECT COUNT(*) as total_orders,
             COALESCE(SUM(o.total), 0) as total_revenue,
             COALESCE(SUM(oi.quantity), 0) as total_items
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      WHERE ${whereClause}
    `).get(...params);

    return { daily, summary };
  }

  async getMonthlySalesReport({ year }) {
    const db = getDb();
    const targetYear = year || new Date().getFullYear();

    const monthly = db.prepare(`
      SELECT strftime('%m', o.created_at) as month,
             COUNT(*) as orders,
             COALESCE(SUM(o.total), 0) as revenue,
             COALESCE(SUM(oi.quantity), 0) as items_sold
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      WHERE strftime('%Y', o.created_at) = ? AND o.payment_status = 'paid' AND o.deleted_at IS NULL
      GROUP BY strftime('%m', o.created_at)
      ORDER BY month ASC
    `).all(String(targetYear));

    return { year: targetYear, monthly };
  }

  async getYearlySalesReport({ year }) {
    const db = getDb();
    const targetYear = year || new Date().getFullYear();

    const yearly = db.prepare(`
      SELECT strftime('%Y', o.created_at) as year,
             COUNT(*) as orders,
             COALESCE(SUM(o.total), 0) as revenue,
             COALESCE(SUM(oi.quantity), 0) as items_sold
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      WHERE strftime('%Y', o.created_at) = ? AND o.payment_status = 'paid' AND o.deleted_at IS NULL
      GROUP BY strftime('%Y', o.created_at)
    `).all(String(targetYear));

    const topMonths = db.prepare(`
      SELECT strftime('%m', o.created_at) as month,
             COALESCE(SUM(o.total), 0) as revenue
      FROM orders o
      WHERE strftime('%Y', o.created_at) = ? AND o.payment_status = 'paid' AND o.deleted_at IS NULL
      GROUP BY strftime('%m', o.created_at)
      ORDER BY revenue DESC
      LIMIT 3
    `).all(String(targetYear));

    return { year: targetYear, yearly: yearly[0] || { year: targetYear, orders: 0, revenue: 0, items_sold: 0 }, topMonths };
  }

  async getCustomerAnalytics({ startDate, endDate }) {
    const db = getDb();
    let where = ['role = \'customer\''];
    let params = [];

    if (startDate) { where.push('created_at >= ?'); params.push(startDate); }
    if (endDate) { where.push('created_at <= ?'); params.push(endDate); }

    const whereClause = where.join(' AND ');

    const newCustomers = db.prepare(
      `SELECT COUNT(*) as count FROM users WHERE ${whereClause}`
    ).get(...params).count;

    const totalCustomers = db.prepare(
      "SELECT COUNT(*) as count FROM users WHERE role = 'customer' AND deleted_at IS NULL"
    ).get().count;

    const returningCustomers = db.prepare(`
      SELECT COUNT(DISTINCT o.user_id) as count
      FROM orders o
      WHERE o.payment_status = 'paid' AND o.deleted_at IS NULL
        AND o.user_id IN (SELECT id FROM users WHERE role = 'customer')
        AND o.user_id IN (
          SELECT user_id FROM orders
          WHERE payment_status = 'paid' AND deleted_at IS NULL
          GROUP BY user_id HAVING COUNT(*) > 1
        )
    `).get().count;

    const avgLifetimeValue = db.prepare(`
      SELECT COALESCE(AVG(total_spent), 0) as avg_ltv
      FROM users WHERE role = 'customer' AND deleted_at IS NULL AND total_spent > 0
    `).get().avg_ltv;

    return {
      newCustomers,
      totalCustomers,
      returningCustomers,
      avgLifetimeValue: parseFloat(avgLifetimeValue.toFixed(2)),
    };
  }

  async getROIReport({ startDate, endDate }) {
    const db = getDb();
    let orderWhere = ["o.payment_status = 'paid'", 'o.deleted_at IS NULL'];
    let expenseWhere = ['e.deleted_at IS NULL'];
    let params = [];

    if (startDate) {
      orderWhere.push('DATE(o.created_at) >= DATE(?)');
      expenseWhere.push('e.date >= DATE(?)');
      params.push(startDate);
    }
    if (endDate) {
      orderWhere.push('DATE(o.created_at) <= DATE(?)');
      expenseWhere.push('e.date <= DATE(?)');
      params.push(endDate);
    }

    const revenue = db.prepare(`
      SELECT COALESCE(SUM(o.total), 0) as total_revenue
      FROM orders o WHERE ${orderWhere.join(' AND ')}
    `).get(...params).total_revenue;

    const expenses = db.prepare(`
      SELECT COALESCE(SUM(e.amount), 0) as total_expenses
      FROM expenses e WHERE ${expenseWhere.join(' AND ')}
    `).get(...params).total_expenses;

    const cogs = db.prepare(`
      SELECT COALESCE(SUM(oi.quantity * COALESCE(p.cost_price, 0)), 0) as total_cogs
      FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      JOIN products p ON oi.product_id = p.id
      WHERE ${orderWhere.join(' AND ')}
    `).get(...params).total_cogs;

    const profit = revenue - cogs - expenses;
    const roi = revenue > 0 ? (profit / revenue * 100) : 0;

    return {
      revenue,
      cogs,
      expenses,
      profit: parseFloat(profit.toFixed(2)),
      roi: parseFloat(roi.toFixed(2)),
    };
  }

  async getProfitMargin({ startDate, endDate }) {
    const report = await this.getROIReport({ startDate, endDate });
    return {
      revenue: report.revenue,
      costOfGoodsSold: report.cogs,
      operatingExpenses: report.expenses,
      grossProfit: parseFloat((report.revenue - report.cogs).toFixed(2)),
      netProfit: report.profit,
      grossMargin: report.revenue ? parseFloat(((report.revenue - report.cogs) / report.revenue * 100).toFixed(2)) : 0,
      netMargin: report.roi,
    };
  }

  async getTopProducts({ limit = 10, startDate, endDate }) {
    const db = getDb();
    let where = ['o.payment_status = \'paid\'', 'o.deleted_at IS NULL'];
    let params = [];

    if (startDate) { where.push('DATE(o.created_at) >= DATE(?)'); params.push(startDate); }
    if (endDate) { where.push('DATE(o.created_at) <= DATE(?)'); params.push(endDate); }

    const whereClause = where.join(' AND ');
    const safeLimit = Math.min(Math.max(parseInt(limit) || 10, 1), 100);

    const products = db.prepare(`
      SELECT p.id, p.name, p.slug, p.price, p.stock_quantity,
             SUM(oi.quantity) as total_sold,
             SUM(oi.total) as total_revenue,
             COUNT(DISTINCT o.id) as order_count,
             (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
      FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      JOIN products p ON oi.product_id = p.id
      WHERE ${whereClause}
      GROUP BY p.id
      ORDER BY total_sold DESC
      LIMIT ?
    `).all(...params, safeLimit);

    return { products };
  }

  async getLowStockProducts({ threshold = 5 }) {
    const db = getDb();

    const products = db.prepare(`
      SELECT p.id, p.name, p.slug, p.sku, p.stock_quantity, p.low_stock_threshold,
             c.name as category_name, b.name as brand_name,
             (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN brands b ON p.brand_id = b.id
      WHERE p.deleted_at IS NULL AND p.track_stock = 1
        AND p.stock_quantity <= ?
      ORDER BY p.stock_quantity ASC
    `).all(threshold);

    return {
      threshold,
      count: products.length,
      products,
    };
  }
}

export default new AnalyticsService();
