/* ==========================================================================
   Bangalirhaat — Main Application JavaScript
   Premium E-Commerce Platform
   ========================================================================== */

// ============================================
// API Client
// ============================================
const API = {
  BASE_URL: '/api',

  _headers() {
    const h = { 'Content-Type': 'application/json' };
    const t = localStorage.getItem('br_token');
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
  },

  async get(endpoint) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        headers: this._headers(),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async post(endpoint, data) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async put(endpoint, data) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'PUT',
        headers: this._headers(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async delete(endpoint) {
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, {
        method: 'DELETE',
        headers: this._headers(),
      });
      if (!res.ok) throw await this._handleError(res);
      return res.json();
    } catch (err) {
      if (err.status) throw err;
      throw { message: 'Network error. Please check your connection.', status: 0 };
    }
  },

  async _handleError(res) {
    try {
      const body = await res.json();
      if (res.status === 401) {
        Auth.logout();
      }
      return { message: body.message || body.error || 'Something went wrong', status: res.status };
    } catch {
      return { message: 'Something went wrong', status: res.status };
    }
  },
};

// ============================================
// Auth Module
// ============================================
const Auth = {
  user: null,
  token: null,

  async login(email, password) {
    const data = await API.post('/auth/login', { email, password });
    this.token = data.token;
    this.user = data.user;
    localStorage.setItem('br_token', data.token);
    Toast.success(`Welcome back, ${this.user.name}!`);
    return data;
  },

  async register(userData) {
    const data = await API.post('/auth/register', userData);
    this.token = data.token;
    this.user = data.user;
    localStorage.setItem('br_token', data.token);
    Toast.success('Account created successfully!');
    return data;
  },

  async logout() {
    try {
      await API.post('/auth/logout', {});
    } catch { /* ignore */ }
    this.user = null;
    this.token = null;
    localStorage.removeItem('br_token');
    window.location.href = '/';
  },

  async refreshToken() {
    try {
      const data = await API.post('/auth/refresh', {});
      this.token = data.token;
      localStorage.setItem('br_token', data.token);
      return data;
    } catch {
      this.logout();
    }
  },

  async getProfile() {
    const data = await API.get('/auth/profile');
    this.user = data.user || data;
    return this.user;
  },

  isAuthenticated() {
    return !!this.token && !!this.user;
  },

  hasRole(role) {
    return this.user && this.user.role === role;
  },

  _init() {
    this.token = localStorage.getItem('br_token');
    if (this.token) {
      this.getProfile().catch(() => {});
    }
  },
};

// ============================================
// Cart Module
// ============================================
const Cart = {
  items: [],
  count: 0,
  total: 0,

  async load() {
    try {
      if (!Auth.isAuthenticated()) {
        const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
        this.items = local;
        this.count = local.reduce((s, i) => s + i.quantity, 0);
        this.total = local.reduce((s, i) => s + i.price * i.quantity, 0);
        this._updateUI();
        return;
      }
      const data = await API.get('/cart');
      this.items = data.items || [];
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.items.reduce((s, i) => s + (i.price || i.product?.price || 0) * i.quantity, 0);
      this._updateUI();
    } catch { /* silent */ }
  },

  async addItem(productId, quantity = 1, variantId = null) {
    if (!Auth.isAuthenticated()) {
      const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      const existing = local.find(i => i.productId === productId && i.variantId === variantId);
      if (existing) {
        existing.quantity += quantity;
      } else {
        let productInfo = { price: 0, name: 'Product', image: '' };
        try {
          const pData = await API.get(`/products/${productId}`);
          const p = pData.data || pData.product || pData;
          productInfo = { price: p.price || p.sellingPrice || 0, name: p.name || 'Product', image: (p.images && p.images[0]) || p.thumbnail || p.image || '' };
        } catch { /* use defaults */ }
        local.push({ productId, variantId, quantity, ...productInfo });
      }
      localStorage.setItem('br_guest_cart', JSON.stringify(local));
      this.items = local;
      this.count = local.reduce((s, i) => s + i.quantity, 0);
      this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.success('Added to cart!');
      return;
    }
    try {
      const data = await API.post('/cart/items', { productId, quantity, variantId });
      this.items = data.items || this.items;
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.total;
      this._updateUI();
      Toast.success('Added to cart!');
    } catch (err) {
      Toast.error(err.message || 'Failed to add to cart');
    }
  },

  async updateItem(itemId, quantity) {
    if (!Auth.isAuthenticated()) {
      const local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      if (quantity <= 0) {
        this.removeItem(itemId);
        return;
      }
      const item = local.find(i => i.productId === itemId || String(i.productId) === String(itemId));
      if (item) {
        item.quantity = quantity;
        localStorage.setItem('br_guest_cart', JSON.stringify(local));
        this.items = local;
        this.count = local.reduce((s, i) => s + i.quantity, 0);
        this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
        this._updateUI();
      }
      return;
    }
    try {
      const data = await API.put(`/cart/items/${itemId}`, { quantity });
      this.items = data.items || this.items;
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.total;
      this._updateUI();
    } catch (err) {
      Toast.error(err.message || 'Failed to update cart');
    }
  },

  async removeItem(itemId) {
    if (!Auth.isAuthenticated()) {
      let local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
      local = local.filter(i => i.productId !== itemId && String(i.productId) !== String(itemId));
      localStorage.setItem('br_guest_cart', JSON.stringify(local));
      this.items = local;
      this.count = local.reduce((s, i) => s + i.quantity, 0);
      this.total = local.reduce((s, i) => s + (i.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.info('Item removed from cart');
      return;
    }
    try {
      const data = await API.delete(`/cart/items/${itemId}`);
      this.items = data.items || this.items.filter(i => i.id !== itemId);
      this.count = data.count || this.items.reduce((s, i) => s + i.quantity, 0);
      this.total = data.total || this.items.reduce((s, i) => (i.price || i.product?.price || 0) * i.quantity, 0);
      this._updateUI();
      Toast.info('Item removed from cart');
    } catch (err) {
      Toast.error(err.message || 'Failed to remove item');
    }
  },

  async clear() {
    if (!Auth.isAuthenticated()) {
      localStorage.removeItem('br_guest_cart');
      this.items = [];
      this.count = 0;
      this.total = 0;
      this._updateUI();
      return;
    }
    try {
      await API.delete('/cart');
      this.items = [];
      this.count = 0;
      this.total = 0;
      this._updateUI();
    } catch { /* silent */ }
  },

  async applyCoupon(code) {
    try {
      const data = await API.post('/cart/coupon', { code });
      this.total = data.total || this.total;
      this._updateUI();
      Toast.success('Coupon applied successfully!');
      return data;
    } catch (err) {
      Toast.error(err.message || 'Invalid coupon code');
      throw err;
    }
  },

  async removeCoupon() {
    try {
      const data = await API.delete('/cart/coupon');
      this.total = data.total || this.total;
      this._updateUI();
      Toast.info('Coupon removed');
    } catch { /* silent */ }
  },

  _updateUI() {
    this.updateBadge();
    this.renderSidebar();
  },

  updateBadge() {
    const badges = document.querySelectorAll('#cartBadge');
    badges.forEach(b => {
      if (this.count > 0) {
        b.textContent = this.count > 99 ? '99+' : this.count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
    const bottomBadges = document.querySelectorAll('.mobile-bottom-nav .bottom-nav-item[href*="cart"]');
    // handled by count
  },

  renderSidebar() {
    const body = document.getElementById('cartItemsList');
    const empty = document.getElementById('cartEmpty');
    const footer = document.getElementById('cartSidebarFooter');
    const countEl = document.getElementById('cartSidebarCount');
    const totalEl = document.getElementById('cartSidebarTotal');

    if (!body) return;

    if (this.items.length === 0) {
      if (empty) empty.style.display = 'flex';
      body.style.display = 'none';
      if (footer) footer.style.display = 'none';
      if (countEl) countEl.textContent = '0';
      return;
    }

    if (empty) empty.style.display = 'none';
    body.style.display = 'flex';
    if (footer) footer.style.display = 'block';
    if (countEl) countEl.textContent = this.count;
    if (totalEl) totalEl.textContent = Utils.formatCurrency(this.total);

    body.innerHTML = this.items.map(item => `
      <div class="cart-item" data-id="${item.id}">
        <div class="cart-item-image">
          <img src="${item.image || item.product?.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'}" alt="${item.name || item.product?.name || 'Product'}" loading="lazy">
        </div>
        <div class="cart-item-info">
          <div class="cart-item-title">${item.name || item.product?.name || 'Product'}</div>
          <div class="cart-item-variant">${item.variant || ''}</div>
          <div class="cart-item-bottom">
            <div class="quantity-selector">
              <button class="quantity-btn" onclick="Cart.updateItem('${item.id}', ${item.quantity - 1})" ${item.quantity <= 1 ? 'disabled' : ''}>&minus;</button>
              <span class="quantity-value">${item.quantity}</span>
              <button class="quantity-btn" onclick="Cart.updateItem('${item.id}', ${item.quantity + 1})">+</button>
            </div>
            <span style="font-weight:var(--weight-bold);font-size:var(--text-sm);">${Utils.formatCurrency(item.price * item.quantity)}</span>
          </div>
          <button class="cart-item-remove" onclick="Cart.removeItem('${item.id}')">Remove</button>
        </div>
      </div>
    `).join('');
  },
};

// ============================================
// Wishlist Module
// ============================================
const Wishlist = {
  items: [],

  async load() {
    try {
      if (!Auth.isAuthenticated()) {
        this.items = JSON.parse(localStorage.getItem('br_guest_wishlist') || '[]');
        this._updateUI();
        return;
      }
      const data = await API.get('/wishlist');
      this.items = data.items || data || [];
      this._updateUI();
    } catch { /* silent */ }
  },

  async add(productId) {
    if (!Auth.isAuthenticated()) {
      if (!this.items.includes(productId)) {
        this.items.push(productId);
        localStorage.setItem('br_guest_wishlist', JSON.stringify(this.items));
        this._updateUI();
        Toast.success('Added to wishlist!');
      }
      return;
    }
    try {
      await API.post('/wishlist', { productId });
      if (!this.items.find(i => (i.id || i) === productId)) {
        this.items.push(productId);
      }
      this._updateUI();
      Toast.success('Added to wishlist!');
    } catch (err) {
      Toast.error(err.message || 'Failed to add to wishlist');
    }
  },

  async remove(productId) {
    if (!Auth.isAuthenticated()) {
      this.items = this.items.filter(i => i !== productId);
      localStorage.setItem('br_guest_wishlist', JSON.stringify(this.items));
      this._updateUI();
      return;
    }
    try {
      await API.delete(`/wishlist/${productId}`);
      this.items = this.items.filter(i => (i.id || i) !== productId);
      this._updateUI();
      Toast.info('Removed from wishlist');
    } catch (err) {
      Toast.error(err.message || 'Failed to remove from wishlist');
    }
  },

  async check(productId) {
    if (!Auth.isAuthenticated()) {
      return this.items.includes(productId);
    }
    try {
      const data = await API.get(`/wishlist/check/${productId}`);
      return data.inWishlist || data.exists || false;
    } catch {
      return false;
    }
  },

  toggle(productId) {
    const isIn = this.items.some(i => (i.id || i) === productId);
    if (isIn) {
      this.remove(productId);
    } else {
      this.add(productId);
    }
    return !isIn;
  },

  _updateUI() {
    this.updateBadge();
    document.querySelectorAll('.wishlist-btn').forEach(btn => {
      const pid = btn.dataset.productId;
      const isWished = this.items.some(i => (i.id || i) == pid);
      btn.classList.toggle('active', isWished);
    });
  },

  updateBadge() {
    const badges = document.querySelectorAll('#wishlistBadge');
    const count = this.items.length;
    badges.forEach(b => {
      if (count > 0) {
        b.textContent = count > 99 ? '99+' : count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
  },
};

// ============================================
// Theme Module
// ============================================
const Theme = {
  current: 'light',

  init() {
    const saved = localStorage.getItem('br_theme');
    if (saved) {
      this.set(saved);
    } else {
      this.set('light');
    }
  },

  toggle() {
    this.set(this.current === 'dark' ? 'light' : 'dark');
  },

  set(theme) {
    this.current = theme;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('br_theme', theme);
    const icon = document.getElementById('themeIcon');
    if (icon) {
      if (theme === 'dark') {
        icon.innerHTML = '<path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>';
      } else {
        icon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
      }
    }
  },
};

// ============================================
// Toast / Notification Module
// ============================================
const Toast = {
  show(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const icons = {
      success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
      error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
      warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
      info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || icons.info}</span>
      <div class="toast-content">
        <div class="toast-message">${message}</div>
      </div>
      <button class="toast-dismiss" aria-label="Dismiss" onclick="this.parentElement.classList.add('toast-exit'); setTimeout(() => this.parentElement.remove(), 200);">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.add('toast-exit');
        setTimeout(() => toast.remove(), 200);
      }
    }, duration);
  },

  success(message) { this.show(message, 'success'); },
  error(message) { this.show(message, 'error', 5000); },
  warning(message) { this.show(message, 'warning', 4000); },
  info(message) { this.show(message, 'info'); },
};

// ============================================
// Search Module
// ============================================
const Search = {
  debounceTimer: null,
  recentSearches: [],

  init() {
    this.recentSearches = JSON.parse(localStorage.getItem('br_recent_searches') || '[]');
    this._renderRecent();
    const input = document.getElementById('searchInput');
    if (input) {
      input.addEventListener('input', (e) => {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = setTimeout(() => this.search(e.target.value), 300);
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.value.trim()) {
          this.saveRecentSearch(e.target.value.trim());
          window.location.href = `/pages/products.html?q=${encodeURIComponent(e.target.value.trim())}`;
        }
        if (e.key === 'Escape') this.close();
      });
    }
  },

  open() {
    const overlay = document.getElementById('searchOverlay');
    const input = document.getElementById('searchInput');
    if (overlay) {
      overlay.classList.add('active');
      overlay.setAttribute('aria-hidden', 'false');
    }
    if (input) {
      setTimeout(() => input.focus(), 100);
    }
    document.body.style.overflow = 'hidden';
  },

  close() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.setAttribute('aria-hidden', 'true');
    }
    document.body.style.overflow = '';
  },

  async search(query) {
    const container = document.getElementById('searchResults');
    const sugBox = document.getElementById('searchSuggestions');
    if (!container || !sugBox) return;

    if (query.length < 2) {
      container.innerHTML = '';
      sugBox.style.display = query.length > 0 ? 'block' : 'none';
      return;
    }

    sugBox.style.display = 'block';
    container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">Searching...</div>';

    try {
      const data = await API.get(`/products/search?q=${encodeURIComponent(query)}&limit=6`);
      const products = data.products || data || [];
      if (products.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">No results found</div>';
        return;
      }
      container.innerHTML = products.map(p => `
        <a href="/pages/product.html?id=${p._id || p.id}" style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2);border-radius:var(--radius-sm);text-decoration:none;color:var(--text);transition:background 0.15s;" onmouseover="this.style.background='var(--glass-bg)'" onmouseout="this.style.background='transparent'">
          <img src="${p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'}" alt="" style="width:40px;height:40px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy">
          <div style="min-width:0;">
            <div style="font-size:var(--text-sm);font-weight:var(--weight-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</div>
            <div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">${Utils.formatCurrency(p.price)}</div>
          </div>
        </a>
      `).join('');
    } catch {
      container.innerHTML = '<div style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">Search unavailable</div>';
    }
  },

  saveRecentSearch(query) {
    this.recentSearches = this.recentSearches.filter(s => s !== query);
    this.recentSearches.unshift(query);
    if (this.recentSearches.length > 8) this.recentSearches.pop();
    localStorage.setItem('br_recent_searches', JSON.stringify(this.recentSearches));
    this._renderRecent();
  },

  _renderRecent() {
    const container = document.getElementById('recentSearches');
    const list = document.getElementById('recentSearchList');
    if (!container || !list) return;

    if (this.recentSearches.length === 0) {
      container.style.display = 'none';
      return;
    }

    container.style.display = 'block';
    list.innerHTML = this.recentSearches.map(s => `
      <a href="/pages/products.html?q=${encodeURIComponent(s)}" class="tag">${s}</a>
    `).join('');
  },
};

// ============================================
// Animation Module (GSAP)
// ============================================
const Animations = {
  init() {
    if (typeof gsap === 'undefined') return;
    gsap.registerPlugin(ScrollTrigger);
    this.heroAnimation();
    this.scrollAnimations();
  },

  heroAnimation() {
    if (typeof gsap === 'undefined') return;
    const tl = gsap.timeline({ delay: 0.2 });
    const content = document.querySelector('.hero-section-content');
    if (!content) return;

    const title = content.querySelector('.hero-3d-title');
    const subtitle = content.querySelector('.hero-subtitle');
    const actions = content.querySelector('.hero-actions');
    const stats = content.querySelector('.hero-stats');

    if (title) tl.from(title, { y: 40, opacity: 0, duration: 0.8, ease: 'power3.out' });
    if (subtitle) tl.from(subtitle, { y: 30, opacity: 0, duration: 0.7, ease: 'power3.out' }, '-=0.4');
    if (actions) tl.from(actions, { y: 20, opacity: 0, duration: 0.6, ease: 'power3.out' }, '-=0.3');
    if (stats) tl.from(stats, { y: 20, opacity: 0, duration: 0.6, ease: 'power3.out' }, '-=0.2');

    const counters = document.querySelectorAll('[data-counter]');
    counters.forEach(el => {
      const target = parseInt(el.dataset.counter, 10);
      this.counter(el, target);
    });

    const floats = document.querySelectorAll('.hero-floating');
    floats.forEach((el, i) => {
      tl.from(el, { scale: 0, opacity: 0, duration: 0.5, ease: 'back.out(1.7)' }, `-=${0.3 - i * 0.05}`);
    });
  },

  scrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;

    gsap.utils.toArray('.section-header').forEach(el => {
      gsap.from(el.children, {
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.6, stagger: 0.15, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.product-grid').forEach(grid => {
      gsap.from(grid.children, {
        scrollTrigger: { trigger: grid, start: 'top 85%', toggleActions: 'play none none none' },
        y: 40, opacity: 0, duration: 0.5, stagger: 0.08, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.category-grid').forEach(grid => {
      gsap.from(grid.children, {
        scrollTrigger: { trigger: grid, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.5, stagger: 0.06, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.video-banner').forEach(el => {
      gsap.from(el, {
        scrollTrigger: { trigger: el, start: 'top 80%', toggleActions: 'play none none none' },
        scale: 0.95, opacity: 0, duration: 0.8, ease: 'power3.out',
      });
    });

    gsap.utils.toArray('.newsletter-card').forEach(el => {
      gsap.from(el, {
        scrollTrigger: { trigger: el, start: 'top 85%', toggleActions: 'play none none none' },
        y: 30, opacity: 0, duration: 0.7, ease: 'power3.out',
      });
    });
  },

  counter(element, target) {
    if (typeof gsap === 'undefined') {
      element.textContent = target >= 1000 ? `${(target / 1000).toFixed(target >= 10000 ? 0 : 1)}K+` : `${target}+`;
      return;
    }
    const obj = { val: 0 };
    gsap.to(obj, {
      val: target,
      duration: 2,
      delay: 0.5,
      ease: 'power2.out',
      onUpdate() {
        const v = Math.round(obj.val);
        element.textContent = v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 0 : 1)}K+` : `${v}+`;
      },
    });
  },

  staggerReveal(selector) {
    if (typeof gsap === 'undefined') return;
    gsap.from(selector, {
      scrollTrigger: { trigger: selector, start: 'top 85%' },
      y: 30, opacity: 0, duration: 0.5, stagger: 0.1, ease: 'power3.out',
    });
  },
};

// ============================================
// Three.js 3D Module
// ============================================
const Product3D = {
  scene: null,
  camera: null,
  renderer: null,
  mesh: null,
  animId: null,

  init(containerId) {
    if (typeof THREE === 'undefined') return;
    const container = document.getElementById(containerId);
    if (!container || container.clientWidth === 0) return;

    try {
      this.scene = new THREE.Scene();
      this.camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
      this.camera.position.z = 5;

      this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      this.renderer.setSize(container.clientWidth, container.clientHeight);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      container.appendChild(this.renderer.domElement);

      const geo = new THREE.IcosahedronGeometry(1.5, 1);
      const mat = new THREE.MeshPhongMaterial({
        color: 0xdc143c,
        wireframe: true,
        transparent: true,
        opacity: 0.6,
      });
      this.mesh = new THREE.Mesh(geo, mat);
      this.scene.add(this.mesh);

      const geo2 = new THREE.IcosahedronGeometry(1.8, 1);
      const mat2 = new THREE.MeshPhongMaterial({
        color: 0xd4af37,
        wireframe: true,
        transparent: true,
        opacity: 0.3,
      });
      const mesh2 = new THREE.Mesh(geo2, mat2);
      this.scene.add(mesh2);

      const light = new THREE.DirectionalLight(0xffffff, 1);
      light.position.set(5, 5, 5);
      this.scene.add(light);

      const ambient = new THREE.AmbientLight(0x404040, 0.5);
      this.scene.add(ambient);

      this._animate(mesh2);

      window.addEventListener('resize', () => {
        if (!container.clientWidth) return;
        this.camera.aspect = container.clientWidth / container.clientHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(container.clientWidth, container.clientHeight);
      });
    } catch { /* Three.js not available or WebGL not supported */ }
  },

  _animate(mesh2) {
    this.animId = requestAnimationFrame(() => this._animate(mesh2));
    if (this.mesh) {
      this.mesh.rotation.x += 0.003;
      this.mesh.rotation.y += 0.005;
    }
    if (mesh2) {
      mesh2.rotation.x -= 0.002;
      mesh2.rotation.y -= 0.003;
    }
    this.renderer.render(this.scene, this.camera);
  },

  destroy() {
    if (this.animId) cancelAnimationFrame(this.animId);
    if (this.renderer) this.renderer.dispose();
  },
};

// ============================================
// Utility Functions
// ============================================
const Utils = {
  formatCurrency(amount) {
    if (amount == null || isNaN(amount)) return '৳0';
    return '৳' + Number(amount).toLocaleString('en-BD', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  },

  formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  },

  timeAgo(date) {
    const seconds = Math.floor((Date.now() - new Date(date)) / 1000);
    const intervals = [
      { label: 'year', seconds: 31536000 },
      { label: 'month', seconds: 2592000 },
      { label: 'week', seconds: 604800 },
      { label: 'day', seconds: 86400 },
      { label: 'hour', seconds: 3600 },
      { label: 'minute', seconds: 60 },
    ];
    for (const i of intervals) {
      const count = Math.floor(seconds / i.seconds);
      if (count >= 1) return `${count} ${i.label}${count > 1 ? 's' : ''} ago`;
    }
    return 'Just now';
  },

  debounce(fn, delay) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  },

  throttle(fn, limit) {
    let inThrottle;
    return (...args) => {
      if (!inThrottle) {
        fn(...args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  },

  slugify(text) {
    return text.toString().toLowerCase().trim()
      .replace(/[\s_]+/g, '-')
      .replace(/[^\w\-]+/g, '')
      .replace(/\-\-+/g, '-')
      .replace(/^-+/, '')
      .replace(/-+$/, '');
  },

  truncate(text, length = 80) {
    if (!text || text.length <= length) return text;
    return text.substring(0, length).trim() + '...';
  },

  getQueryParams() {
    return Object.fromEntries(new URLSearchParams(window.location.search));
  },

  setQueryParam(key, value) {
    const url = new URL(window.location);
    if (value == null || value === '') {
      url.searchParams.delete(key);
    } else {
      url.searchParams.set(key, value);
    }
    window.history.replaceState({}, '', url);
  },

  scrollTo(element) {
    if (typeof element === 'string') element = document.querySelector(element);
    if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  },

  lazyLoad(images) {
    if ('IntersectionObserver' in window && images.length) {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
            img.removeAttribute('data-src');
            observer.unobserve(img);
          }
        });
      }, { rootMargin: '200px' });
      images.forEach(img => observer.observe(img));
    } else {
      images.forEach(img => {
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
      });
    }
  },

  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      Toast.success('Copied to clipboard!');
    } catch {
      Toast.error('Failed to copy');
    }
  },

  generateStars(rating) {
    const full = Math.floor(rating);
    const half = rating % 1 >= 0.5 ? 1 : 0;
    const empty = 5 - full - half;
    let html = '';
    for (let i = 0; i < full; i++) html += '<span class="star filled">&#9733;</span>';
    if (half) html += '<span class="star half">&#9733;</span>';
    for (let i = 0; i < empty; i++) html += '<span class="star">&#9733;</span>';
    return html;
  },

  getOS() {
    const u = navigator.userAgent;
    if (/Windows/i.test(u)) return 'Windows';
    if (/Mac/i.test(u)) return 'macOS';
    if (/Linux/i.test(u)) return 'Linux';
    if (/Android/i.test(u)) return 'Android';
    if (/iPhone|iPad|iPod/i.test(u)) return 'iOS';
    return 'Unknown';
  },

  getBrowser() {
    const u = navigator.userAgent;
    if (u.includes('Firefox')) return 'Firefox';
    if (u.includes('Edg')) return 'Edge';
    if (u.includes('Chrome')) return 'Chrome';
    if (u.includes('Safari')) return 'Safari';
    return 'Unknown';
  },
};

// ============================================
// Product Card Generator
// ============================================
function createProductCard(product) {
  const p = product;
  const id = p._id || p.id;
  const image = p.images?.[0]?.url || p.images?.[0] || p.image || p.thumbnail || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
  const name = p.name || 'Untitled Product';
  const brand = p.brand || '';
  const category = p.category?.name || p.category || '';
  const price = p.price || 0;
  const originalPrice = p.originalPrice || p.compareAtPrice || p.mrp || 0;
  const rating = p.rating || p.averageRating || 4.5;
  const reviewCount = p.reviewCount || p.numReviews || 0;
  const discount = originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;
  const isWished = Wishlist.items.some(i => (i.id || i) == id);
  const stockQty = p.stock_quantity !== undefined ? p.stock_quantity : p.stockQuantity;
  const outOfStock = stockQty !== undefined && stockQty <= 0;

  return `
    <div class="product-card card-hover" data-product-id="${id}">
      <div class="product-card-image">
        <a href="/pages/product.html?id=${id}" aria-label="View ${name}">
          <img src="${image}" alt="${name}" loading="lazy"${outOfStock ? ' style="opacity:0.6;"' : ''}>
        </a>
        ${outOfStock ? '<div class="product-card-stockout-badge"><span>Stock Out</span></div>' : ''}
        ${!outOfStock && discount > 0 ? `<div class="product-card-badges"><span class="badge badge-danger">-${discount}%</span></div>` : ''}
        <button class="wishlist-btn product-card-wishlist ${isWished ? 'active' : ''}" data-product-id="${id}" onclick="event.preventDefault(); Wishlist.toggle('${id}');" aria-label="Toggle wishlist">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="${isWished ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        </button>
        <div class="product-card-quick-actions">
          <button class="btn btn-sm btn-glass" onclick="event.preventDefault(); window.location.href='/pages/product.html?id=${id}';" style="flex:1;">Quick View</button>
          ${outOfStock ? `<button class="btn btn-sm" disabled style="flex:1;background:var(--muted,#e2e8f0);color:var(--text-muted,#94a3b8);cursor:not-allowed;border:none;">Out of Stock</button>` : `<button class="btn btn-sm btn-primary" onclick="event.preventDefault(); Cart.addItem('${id}');" style="flex:1;">Add to Cart</button>`}
        </div>
      </div>
      <div class="product-card-body">
        ${category ? `<div class="product-card-category">${category}</div>` : ''}
        <a href="/pages/product.html?id=${id}" class="product-card-title" style="text-decoration:none;color:inherit;">${name}</a>
        ${brand ? `<div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">${brand}</div>` : ''}
        <div class="product-card-rating">
          <div class="star-rating star-rating-sm">${Utils.generateStars(rating)}</div>
          <span class="product-card-rating-count">(${reviewCount})</span>
        </div>
      </div>
      <div class="product-card-footer">
        <div class="product-card-price">
          <span class="product-card-price-current">${Utils.formatCurrency(price)}</span>
          ${discount > 0 ? `<span class="product-card-price-original">${Utils.formatCurrency(originalPrice)}</span>` : ''}
        </div>
        ${outOfStock ? `<button class="product-card-add-btn" disabled style="opacity:0.4;cursor:not-allowed;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg></button>` : `<button class="product-card-add-btn" onclick="event.preventDefault(); Cart.addItem('${id}');" aria-label="Add to cart"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></button>`}
      </div>
    </div>
  `;
}

// ============================================
// Loading Screen
// ============================================
function initLoadingScreen() {
  const bar = document.getElementById('loadingBar');
  const percent = document.getElementById('loadingPercent');
  const screen = document.getElementById('loading-screen');
  if (!bar || !percent || !screen) return;

  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 15 + 5;
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      setTimeout(() => {
        screen.classList.add('hidden');
        document.body.style.overflow = '';
      }, 300);
    }
    bar.style.width = progress + '%';
    percent.textContent = Math.round(progress) + '%';
  }, 100);

  setTimeout(() => {
    progress = 100;
    bar.style.width = '100%';
    percent.textContent = '100%';
    clearInterval(interval);
    setTimeout(() => {
      screen.classList.add('hidden');
      document.body.style.overflow = '';
    }, 200);
  }, 2500);
}

// ============================================
// Navbar
// ============================================
function initNavbar() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  const onScroll = Utils.throttle(() => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }, 100);

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Mobile menu
  const mobileToggle = document.getElementById('mobileMenuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileOverlay = document.getElementById('mobileMenuOverlay');
  const mobileClose = document.getElementById('mobileMenuClose');

  function openMobileMenu() {
    mobileMenu?.classList.add('active');
    mobileOverlay?.classList.add('active');
    mobileToggle?.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileMenu() {
    mobileMenu?.classList.remove('active');
    mobileOverlay?.classList.remove('active');
    mobileToggle?.classList.remove('active');
    document.body.style.overflow = '';
  }

  mobileToggle?.addEventListener('click', () => {
    if (mobileMenu?.classList.contains('active')) {
      closeMobileMenu();
    } else {
      openMobileMenu();
    }
  });

  mobileClose?.addEventListener('click', closeMobileMenu);
  mobileOverlay?.addEventListener('click', closeMobileMenu);
}

// ============================================
// Search Overlay
// ============================================
function initSearch() {
  document.getElementById('searchToggle')?.addEventListener('click', () => Search.open());
  document.getElementById('searchClose')?.addEventListener('click', () => Search.close());
  document.getElementById('mobileSearchBtn')?.addEventListener('click', () => {
    const mobileMenu = document.getElementById('mobileMenu');
    const mobileOverlay = document.getElementById('mobileMenuOverlay');
    const mobileToggle = document.getElementById('mobileMenuToggle');
    mobileMenu?.classList.remove('active');
    mobileOverlay?.classList.remove('active');
    mobileToggle?.classList.remove('active');
    document.body.style.overflow = '';
    Search.open();
  });

  document.getElementById('searchOverlay')?.addEventListener('click', (e) => {
    if (e.target.id === 'searchOverlay') Search.close();
  });
}

// ============================================
// Cart Sidebar
// ============================================
function initCartSidebar() {
  const toggle = document.getElementById('cartToggle');
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartSidebarOverlay');
  const close = document.getElementById('cartSidebarClose');

  function openCart() {
    sidebar?.classList.add('active');
    overlay?.classList.add('active');
    document.body.style.overflow = 'hidden';
    Cart.renderSidebar();
  }

  function closeCart() {
    sidebar?.classList.remove('active');
    overlay?.classList.remove('active');
    document.body.style.overflow = '';
  }

  toggle?.addEventListener('click', openCart);
  close?.addEventListener('click', closeCart);
  overlay?.addEventListener('click', closeCart);
}

// ============================================
// Theme Toggle
// ============================================
function initThemeToggle() {
  document.getElementById('themeToggle')?.addEventListener('click', () => Theme.toggle());
}

// ============================================
// Swiper Initialization
// ============================================
function initSwipers() {
  if (typeof Swiper === 'undefined') return;

  new Swiper('.featured-swiper', {
    slidesPerView: 1.2,
    spaceBetween: 16,
    centeredSlides: false,
    grabCursor: true,
    navigation: { nextEl: '.featured-swiper .swiper-button-next', prevEl: '.featured-swiper .swiper-button-prev' },
    breakpoints: {
      640: { slidesPerView: 2.2, spaceBetween: 20 },
      1024: { slidesPerView: 3.2, spaceBetween: 24 },
      1280: { slidesPerView: 4, spaceBetween: 24 },
    },
  });

  new Swiper('.flash-sale-swiper', {
    slidesPerView: 1.5,
    spaceBetween: 16,
    grabCursor: true,
    navigation: { nextEl: '.flash-sale-swiper .swiper-button-next', prevEl: '.flash-sale-swiper .swiper-button-prev' },
    breakpoints: {
      640: { slidesPerView: 2.5, spaceBetween: 20 },
      1024: { slidesPerView: 3.5, spaceBetween: 24 },
      1280: { slidesPerView: 4.5, spaceBetween: 24 },
    },
  });

  new Swiper('.reviews-swiper', {
    slidesPerView: 1,
    spaceBetween: 24,
    grabCursor: true,
    pagination: { el: '.reviews-swiper .swiper-pagination', clickable: true },
    autoplay: { delay: 5000, disableOnInteraction: false },
    breakpoints: {
      640: { slidesPerView: 2 },
      1024: { slidesPerView: 3 },
    },
  });
}

// ============================================
// Countdown Timer
// ============================================
function initCountdown(targetDate) {
  const daysEl = document.getElementById('cdDays');
  const hoursEl = document.getElementById('cdHours');
  const minsEl = document.getElementById('cdMins');
  const secsEl = document.getElementById('cdSecs');
  if (!daysEl) return;

  function update() {
    const now = Date.now();
    let diff = targetDate - now;
    if (diff <= 0) {
      diff = 0;
      // Reset for next 24h
      targetDate = Date.now() + 24 * 60 * 60 * 1000;
    }
    const d = Math.floor(diff / (1000 * 60 * 60 * 24));
    const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const s = Math.floor((diff % (1000 * 60)) / 1000);

    daysEl.textContent = String(d).padStart(2, '0');
    hoursEl.textContent = String(h).padStart(2, '0');
    minsEl.textContent = String(m).padStart(2, '0');
    secsEl.textContent = String(s).padStart(2, '0');
  }

  update();
  setInterval(update, 1000);
}

// ============================================
// Data Loaders
// ============================================
async function loadFeaturedProducts() {
  const container = document.getElementById('featuredProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?featured=true&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => `<div class="swiper-slide">${createProductCard(p)}</div>`).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadNewArrivals() {
  const container = document.getElementById('newArrivals');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=newest&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadTrending() {
  const container = document.getElementById('trendingProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=trending&limit=4');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(4);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(4);
  }
}

async function loadBestSellers() {
  const container = document.getElementById('bestSellerProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?sort=bestselling&limit=4');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(4);
      return;
    }
    container.innerHTML = products.map(p => createProductCard(p)).join('');
  } catch {
    container.innerHTML = _placeholderProducts(4);
  }
}

async function loadFlashSales() {
  const container = document.getElementById('flashSaleProducts');
  if (!container) return;
  try {
    const res = await API.get('/products?flashSale=true&limit=8');
    const products = res.data?.products || res.products || res.data || [];
    if (products.length === 0) {
      container.innerHTML = _placeholderProducts(8);
      return;
    }
    container.innerHTML = products.map(p => `<div class="swiper-slide">${createProductCard(p)}</div>`).join('');
  } catch {
    container.innerHTML = _placeholderProducts(8);
  }
}

async function loadCategories() {
  const container = document.getElementById('categoryGrid');
  if (!container) return;
  try {
    const res = await API.get('/categories');
    const cats = res.data?.categories || res.categories || res.data || [];
    if (cats.length === 0) {
      container.innerHTML = _placeholderCategories();
      return;
    }
    container.innerHTML = cats.slice(0, 8).map(c => `
      <a href="/pages/categories.html?cat=${c.slug || Utils.slugify(c.name)}" class="category-banner card-hover" style="text-decoration:none;">
        <div class="category-banner-bg"><img src="${c.image || 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=600'}" alt="${c.name}" loading="lazy"></div>
        <div class="category-banner-overlay"></div>
        <div class="category-banner-content">
          <div class="category-banner-title">${c.name}</div>
          <div class="category-banner-count">${c.product_count || c.productCount || c.count || 0} Products</div>
        </div>
      </a>
    `).join('');
  } catch {
    container.innerHTML = _placeholderCategories();
  }
}

async function loadReviews() {
  const container = document.getElementById('reviewsSlider');
  if (!container) return;
  try {
    const res = await API.get('/reviews?limit=6&sort=recent');
    const reviews = res.data?.reviews || res.reviews || res.data || [];
    if (reviews.length === 0) {
      container.innerHTML = _placeholderReviews();
      return;
    }
    container.innerHTML = reviews.map(r => `
      <div class="swiper-slide">
        <div class="review-card">
          <div class="review-card-header">
            <div class="avatar avatar-sm">${(r.user?.name || r.author || 'U')[0].toUpperCase()}</div>
            <div>
              <div class="review-card-name">${r.user?.name || r.author || 'Customer'}</div>
              <div class="review-card-date">${Utils.timeAgo(r.createdAt || r.date)}</div>
            </div>
          </div>
          <div class="star-rating star-rating-sm" style="margin-bottom:var(--space-3);">${Utils.generateStars(r.rating || 5)}</div>
          <p class="review-card-text">${r.comment || r.text || r.review || ''}</p>
          ${r.verified ? '<span class="review-card-verified">&#10003; Verified Purchase</span>' : ''}
        </div>
      </div>
    `).join('');
  } catch {
    container.innerHTML = _placeholderReviews();
  }
}

// ============================================
// Placeholder Data (when API is unavailable)
// ============================================
function _placeholderProducts(count) {
  const names = ['Jamdani Saree', 'Terracotta Vase', 'Silk Scarf', 'Brass Necklace', 'Nakshi Kantha', 'Bamboo Basket', 'Muslin Fabric', 'Ceramic Bowl'];
  const cats = ['Fashion', 'Handicraft', 'Textiles', 'Jewelry', 'Home', 'Art', 'Fashion', 'Kitchen'];
  const prices = [4500, 2200, 1800, 3500, 5200, 1200, 8500, 950];
  let html = '';
  for (let i = 0; i < count; i++) {
    const idx = i % names.length;
    const p = { _id: `demo-${i}`, name: names[idx], category: { name: cats[idx] }, price: prices[idx], originalPrice: prices[idx] * 1.3, rating: 4 + Math.random(), reviewCount: Math.floor(Math.random() * 200) + 10, images: [`https://placehold.co/400x400/1a1a1a/dc143c?text=${encodeURIComponent(names[idx])}`] };
    html += `<div class="swiper-slide">${createProductCard(p)}</div>`;
  }
  return html;
}

function _placeholderCategories() {
  const cats = [
    { name: 'Fashion', slug: 'fashion', icon: '&#128085;', count: 120, color: '#dc143c' },
    { name: 'Home & Living', slug: 'home', icon: '&#127968;', count: 85, color: '#d4af37' },
    { name: 'Handicrafts', slug: 'handicraft', icon: '&#127912;', count: 200, color: '#10b981' },
    { name: 'Textiles', slug: 'textiles', icon: '&#129525;', count: 95, color: '#3b82f6' },
    { name: 'Jewelry', slug: 'jewelry', icon: '&#128141;', count: 60, color: '#f59e0b' },
    { name: 'Food & Spices', slug: 'food', icon: '&#127843;', count: 45, color: '#8b5cf6' },
    { name: 'Art & Paintings', slug: 'art', icon: '&#127912;', count: 70, color: '#f43f5e' },
    { name: 'Wellness', slug: 'wellness', icon: '&#127807;', count: 35, color: '#14b8a6' },
  ];
  return cats.map(c => `
    <a href="/pages/categories.html?cat=${c.slug}" class="category-banner card-hover" style="text-decoration:none;background:${c.color};">
      <div class="category-banner-overlay" style="background:linear-gradient(135deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.1) 100%);"></div>
      <div class="category-banner-content" style="color:#fff;">
        <div style="font-size:32px;margin-bottom:var(--space-2);">${c.icon}</div>
        <div class="category-banner-title" style="color:#fff;">${c.name}</div>
        <div class="category-banner-count">${c.count} Products</div>
      </div>
    </a>
  `).join('');
}

function _placeholderReviews() {
  const reviews = [
    { name: 'Fatima K.', rating: 5, text: 'Absolutely stunning Jamdani saree! The craftsmanship is incredible and the delivery was faster than expected.', verified: true },
    { name: 'Rahman A.', rating: 5, text: 'Best quality handicrafts I have found online. The terracotta pieces are museum quality. Highly recommend!', verified: true },
    { name: 'Sara M.', rating: 4, text: 'Beautiful silk scarf, exactly as pictured. The packaging was also very premium. Will order again.', verified: true },
    { name: 'Imran H.', rating: 5, text: 'Perfect gift for my mother. She loved the Nakshi Kantha. The attention to detail is remarkable.', verified: true },
    { name: 'Priya D.', rating: 5, text: 'I have been buying from Bangalirhaat for months now. Consistent quality and excellent customer service.', verified: true },
    { name: 'Zahid R.', rating: 4, text: 'Great collection of authentic Bangladeshi products. The bamboo basket is both functional and beautiful.', verified: true },
  ];
  return reviews.map(r => `
    <div class="swiper-slide">
      <div class="review-card">
        <div class="review-card-header">
          <div class="avatar avatar-sm">${r.name[0]}</div>
          <div>
            <div class="review-card-name">${r.name}</div>
            <div class="review-card-date">2 weeks ago</div>
          </div>
        </div>
        <div class="star-rating star-rating-sm" style="margin-bottom:var(--space-3);">${Utils.generateStars(r.rating)}</div>
        <p class="review-card-text">${r.text}</p>
        ${r.verified ? '<span class="review-card-verified">&#10003; Verified Purchase</span>' : ''}
      </div>
    </div>
  `).join('');
}

// ============================================
// Newsletter Form
// ============================================
function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = form.querySelector('input[type="email"]')?.value;
    if (!email) return;
    try {
      await API.post('/newsletter/subscribe', { email });
      Toast.success('Subscribed successfully! Welcome to the community.');
      form.reset();
    } catch {
      Toast.success('Thank you for subscribing!');
      form.reset();
    }
  });
}

// ============================================
// Keyboard Shortcuts
// ============================================
function initKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      Search.open();
    }
    if (e.key === 'Escape') {
      Search.close();
      const cartSidebar = document.getElementById('cartSidebar');
      if (cartSidebar?.classList.contains('active')) {
        cartSidebar.classList.remove('active');
        document.getElementById('cartSidebarOverlay')?.classList.remove('active');
        document.body.style.overflow = '';
      }
    }
  });
}

// ============================================
// Page Router
// ============================================
const Page = {
  init() {
    const path = window.location.pathname;
    if (path === '/' || path === '/index.html') {
      this.homepage();
    }
  },

  homepage() {
    loadFeaturedProducts();
    loadNewArrivals();
    loadTrending();
    loadBestSellers();
    loadFlashSales();
    loadCategories();
    loadReviews();

    setTimeout(() => {
      initSwipers();
      Animations.init();
      Product3D.init('hero3d');
    }, 100);

    // Flash sale countdown - 24h from now
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);
    initCountdown(endOfDay.getTime());
  },
};

// ============================================
// Initialize Everything
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  // Lock scroll during load
  document.body.style.overflow = 'hidden';

  // Auth
  Auth._init();

  // Theme
  Theme.init();

  // Loading screen
  initLoadingScreen();

  // Core UI
  initNavbar();
  initSearch();
  initCartSidebar();
  initThemeToggle();
  initKeyboardShortcuts();
  initNewsletter();

  // Feature styles
  injectFeatureStyles();

  // Data
  Cart.load().catch(() => {});
  Wishlist.load().catch(() => {});

  // Page routing
  Page.init();

  // Recently Viewed
  const rvContainer = document.getElementById('recentlyViewed');
  if (rvContainer) renderRecentlyViewed(rvContainer);

  // Voice Search
  VoiceSearch.init();

  // AI Search
  const searchInput = document.getElementById('searchInput');
  if (searchInput) AISearch.init(searchInput);

  // Floating Buttons
  FloatingButtons.init();

  // Lazy load images
  Utils.lazyLoad(document.querySelectorAll('img[data-src]'));

  // Unlock scroll after a beat (in case loading screen is slow)
  setTimeout(() => {
    if (!document.getElementById('loading-screen')?.classList.contains('hidden')) {
      document.body.style.overflow = '';
    }
  }, 3000);
});

// ============================================
// 360° Product Viewer
// ============================================
const Product360Viewer = {
  images: [],
  currentIndex: 0,
  isDragging: false,
  startX: 0,
  container: null,
  imageEl: null,
  dotsContainer: null,
  autoPlayTimer: null,
  handlers: {},

  init(containerId, imageUrls) {
    if (!imageUrls || imageUrls.length === 0) return;
    this.images = imageUrls;
    this.currentIndex = 0;
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.container.innerHTML = '';
    this.container.style.position = 'relative';
    this.container.style.overflow = 'hidden';
    this.container.style.userSelect = 'none';
    this.container.style.cursor = 'grab';

    const wrapper = document.createElement('div');
    wrapper.style.position = 'relative';
    wrapper.style.width = '100%';
    wrapper.style.height = '100%';

    this.imageEl = document.createElement('img');
    this.imageEl.src = this.images[0];
    this.imageEl.alt = 'Product 360 view';
    this.imageEl.style.width = '100%';
    this.imageEl.style.height = '100%';
    this.imageEl.style.objectFit = 'cover';
    this.imageEl.draggable = false;
    wrapper.appendChild(this.imageEl);

    const hint = document.createElement('div');
    hint.textContent = 'Drag to rotate';
    hint.style.cssText = 'position:absolute;bottom:12px;left:50%;transform:translateX(-50%);font-size:12px;color:rgba(255,255,255,0.7);background:rgba(0,0,0,0.5);padding:4px 12px;border-radius:20px;pointer-events:none;transition:opacity 0.3s;';
    wrapper.appendChild(hint);
    setTimeout(() => { if (hint.parentElement) hint.style.opacity = '0'; }, 3000);

    this.container.appendChild(wrapper);

    this.dotsContainer = document.createElement('div');
    this.dotsContainer.style.cssText = 'position:absolute;bottom:8px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:2;';
    const dotCount = Math.min(this.images.length, 12);
    const step = Math.max(1, Math.floor(this.images.length / dotCount));
    for (let i = 0; i < dotCount; i++) {
      const dot = document.createElement('button');
      dot.style.cssText = 'width:6px;height:6px;border-radius:50%;border:none;background:rgba(255,255,255,0.4);cursor:pointer;transition:all 0.2s;padding:0;';
      dot.setAttribute('aria-label', `View ${i * step + 1}`);
      dot.addEventListener('click', () => this.goToImage(i * step));
      this.dotsContainer.appendChild(dot);
    }
    this.container.appendChild(this.dotsContainer);
    this._updateDots();

    this.handlers.start = (e) => this.onDragStart(e);
    this.handlers.move = (e) => this.onDragMove(e);
    this.handlers.end = () => this.onDragEnd();

    this.container.addEventListener('mousedown', this.handlers.start);
    this.container.addEventListener('touchstart', this.handlers.start, { passive: true });
    document.addEventListener('mousemove', this.handlers.move);
    document.addEventListener('touchmove', this.handlers.move, { passive: true });
    document.addEventListener('mouseup', this.handlers.end);
    document.addEventListener('touchend', this.handlers.end);
    this.container.addEventListener('mouseenter', () => this.autoPlay());
    this.container.addEventListener('mouseleave', () => this.stopAutoPlay());
  },

  onDragStart(e) {
    this.isDragging = true;
    this.startX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
    this.container.style.cursor = 'grabbing';
    this.stopAutoPlay();
  },

  onDragMove(e) {
    if (!this.isDragging) return;
    const clientX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
    const diff = clientX - this.startX;
    if (Math.abs(diff) > 20) {
      const direction = diff > 0 ? -1 : 1;
      const newIndex = (this.currentIndex + direction + this.images.length) % this.images.length;
      this.goToImage(newIndex);
      this.startX = clientX;
    }
  },

  onDragEnd() {
    this.isDragging = false;
    if (this.container) this.container.style.cursor = 'grab';
  },

  goToImage(index) {
    this.currentIndex = index;
    if (this.imageEl) this.imageEl.src = this.images[index];
    this._updateDots();
  },

  _updateDots() {
    if (!this.dotsContainer) return;
    const dots = this.dotsContainer.children;
    const total = this.images.length;
    const dotCount = dots.length;
    for (let i = 0; i < dotCount; i++) {
      const mappedIndex = Math.round((i / dotCount) * total) % total;
      const isActive = Math.abs(this.currentIndex - mappedIndex) < total / dotCount / 2 || (this.currentIndex === total - 1 && i === dotCount - 1);
      dots[i].style.background = isActive ? '#fff' : 'rgba(255,255,255,0.4)';
      dots[i].style.transform = isActive ? 'scale(1.3)' : 'scale(1)';
    }
  },

  autoPlay() {
    this.stopAutoPlay();
    this.autoPlayTimer = setInterval(() => {
      this.goToImage((this.currentIndex + 1) % this.images.length);
    }, 150);
  },

  stopAutoPlay() {
    if (this.autoPlayTimer) {
      clearInterval(this.autoPlayTimer);
      this.autoPlayTimer = null;
    }
  },

  destroy() {
    this.stopAutoPlay();
    if (this.container) {
      this.container.removeEventListener('mousedown', this.handlers.start);
      this.container.removeEventListener('touchstart', this.handlers.start);
    }
    document.removeEventListener('mousemove', this.handlers.move);
    document.removeEventListener('touchmove', this.handlers.move);
    document.removeEventListener('mouseup', this.handlers.end);
    document.removeEventListener('touchend', this.handlers.end);
    if (this.container) this.container.innerHTML = '';
    this.images = [];
    this.currentIndex = 0;
  },
};

// ============================================
// Image Zoom (Magnifier)
// ============================================
const ImageZoom = {
  lens: null,
  container: null,
  image: null,
  zoomLevel: 2,
  lensSize: 150,
  handlers: {},

  init(container, options = {}) {
    if (typeof container === 'string') container = document.querySelector(container);
    if (!container) return;

    this.container = container;
    this.image = container.querySelector('img');
    if (!this.image) return;

    this.zoomLevel = options.zoomLevel || 2;
    this.lensSize = options.lensSize || 150;

    container.style.position = 'relative';
    container.style.overflow = 'hidden';
    container.style.cursor = 'crosshair';

    this.lens = document.createElement('div');
    this.lens.style.cssText = `position:absolute;width:${this.lensSize}px;height:${this.lensSize}px;border-radius:50%;border:2px solid var(--primary, #dc143c);background-repeat:no-repeat;pointer-events:none;z-index:10;display:none;transform:translate(-50%,-50%);box-shadow:0 0 0 1px rgba(0,0,0,0.2);`;
    container.appendChild(this.lens);

    this.handlers.move = (e) => this.moveLens(e);
    this.handlers.enter = () => { this.lens.style.display = 'block'; };
    this.handlers.leave = () => { this.lens.style.display = 'none'; };

    container.addEventListener('mouseenter', this.handlers.enter);
    container.addEventListener('mouseleave', this.handlers.leave);
    container.addEventListener('mousemove', this.handlers.move);

    let touchStartDist = 0;
    this.handlers.touchStart = (e) => {
      if (e.touches.length === 2) {
        touchStartDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      }
    };
    this.handlers.touchMove = (e) => {
      if (e.touches.length === 2) {
        const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
        const scale = dist / touchStartDist;
        this.image.style.transform = `scale(${Math.min(Math.max(scale, 1), 4)})`;
        e.preventDefault();
      }
    };
    container.addEventListener('touchstart', this.handlers.touchStart, { passive: true });
    container.addEventListener('touchmove', this.handlers.touchMove, { passive: false });
  },

  createLens(container) { /* lens is created in init */ },

  moveLens(e) {
    if (!this.lens || !this.image) return;
    const rect = this.container.getBoundingClientRect();
    let x = e.clientX - rect.left;
    let y = e.clientY - rect.top;
    const halfLens = this.lensSize / 2;

    x = Math.max(halfLens, Math.min(x, rect.width - halfLens));
    y = Math.max(halfLens, Math.min(y, rect.height - halfLens));

    this.lens.style.left = x + 'px';
    this.lens.style.top = y + 'px';

    const zoomW = rect.width * this.zoomLevel;
    const zoomH = rect.height * this.zoomLevel;
    const bgX = -(x * this.zoomLevel - halfLens);
    const bgY = -(y * this.zoomLevel - halfLens);

    this.lens.style.backgroundImage = `url(${this.image.src})`;
    this.lens.style.backgroundSize = `${zoomW}px ${zoomH}px`;
    this.lens.style.backgroundPosition = `${bgX}px ${bgY}px`;
  },

  destroy() {
    if (this.container) {
      this.container.removeEventListener('mouseenter', this.handlers.enter);
      this.container.removeEventListener('mouseleave', this.handlers.leave);
      this.container.removeEventListener('mousemove', this.handlers.move);
      this.container.removeEventListener('touchstart', this.handlers.touchStart);
      this.container.removeEventListener('touchmove', this.handlers.touchMove);
      if (this.lens) this.lens.remove();
    }
    this.lens = null;
    this.container = null;
    this.image = null;
  },
};

// ============================================
// Product Gallery
// ============================================
const ProductGallery = {
  mainImage: null,
  thumbnails: [],
  currentIndex: 0,
  isFullscreen: false,

  init() {
    this.mainImage = document.querySelector('.product-gallery-main img');
    this.thumbnails = Array.from(document.querySelectorAll('.product-gallery-thumb'));

    if (!this.mainImage || this.thumbnails.length === 0) return;

    this.thumbnails.forEach((thumb, index) => {
      thumb.addEventListener('click', () => {
        this.goTo(index);
      });
    });

    const mainContainer = this.mainImage.closest('.product-gallery-main');
    if (mainContainer) {
      mainContainer.addEventListener('dblclick', () => this.toggleFullscreen());
    }

    document.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') this.prev();
      if (e.key === 'ArrowRight') this.next();
      if (e.key === 'Escape' && this.isFullscreen) this.exitFullscreen();
    });

    if (typeof ImageZoom !== 'undefined' && mainContainer) {
      ImageZoom.init(mainContainer);
    }
  },

  goTo(index) {
    if (index < 0 || index >= this.thumbnails.length) return;
    this.currentIndex = index;

    const src = this.thumbnails[index].querySelector('img')?.src;
    if (src && this.mainImage) {
      this.mainImage.src = src;
    }

    this.thumbnails.forEach((t, i) => {
      t.classList.toggle('active', i === index);
    });

    const arrowPrev = document.querySelector('.product-gallery-main .gallery-prev');
    const arrowNext = document.querySelector('.product-gallery-main .gallery-next');
    if (arrowPrev) arrowPrev.style.display = index === 0 ? 'none' : 'flex';
    if (arrowNext) arrowNext.style.display = index === this.thumbnails.length - 1 ? 'none' : 'flex';
  },

  prev() {
    this.goTo(this.currentIndex - 1);
  },

  next() {
    this.goTo(this.currentIndex + 1);
  },

  toggleFullscreen() {
    if (this.isFullscreen) {
      this.exitFullscreen();
    } else {
      this.enterFullscreen();
    }
  },

  enterFullscreen() {
    const container = this.mainImage?.closest('.product-gallery-main');
    if (!container || !document.fullscreenEnabled) return;
    this.isFullscreen = true;
    container.requestFullscreen().catch(() => {});
  },

  exitFullscreen() {
    this.isFullscreen = false;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
  },
};

// ============================================
// Product Comparison
// ============================================
const ProductCompare = {
  STORAGE_KEY: 'compareItems',
  maxItems: 4,

  get items() {
    return JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '[]');
  },

  set items(val) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(val));
    this.updateBadge();
  },

  add(productId) {
    const items = this.items;
    if (items.length >= this.maxItems) {
      Toast.warning(`Maximum ${this.maxItems} products can be compared`);
      return false;
    }
    if (items.includes(productId)) {
      Toast.info('Product already in comparison');
      return false;
    }
    items.push(productId);
    this.items = items;
    Toast.success('Added to comparison');
    this._updateButtons();
    return true;
  },

  remove(productId) {
    let items = this.items;
    items = items.filter(id => id !== productId);
    this.items = items;
    Toast.info('Removed from comparison');
    this._updateButtons();
  },

  clear() {
    this.items = [];
    Toast.info('Comparison cleared');
    this._updateButtons();
  },

  toggle(productId) {
    const items = this.items;
    const idx = items.indexOf(productId);
    if (idx > -1) {
      this.remove(productId);
      return false;
    } else {
      return this.add(productId);
    }
  },

  updateBadge() {
    const items = this.items;
    const count = items.length;
    const badges = document.querySelectorAll('#compareBadge');
    badges.forEach(b => {
      if (count > 0) {
        b.textContent = count > 99 ? '99+' : count;
        b.style.display = 'flex';
      } else {
        b.style.display = 'none';
      }
    });
    const floatBadges = document.querySelectorAll('.compare-float-badge');
    floatBadges.forEach(b => {
      const c = b.querySelector('.count');
      if (count > 0) {
        b.style.display = 'flex';
        if (c) c.textContent = count;
      } else {
        b.style.display = 'none';
      }
    });
  },

  _updateButtons() {
    const items = this.items;
    document.querySelectorAll('.compare-btn, .tp-compare-btn, [data-compare-toggle]').forEach(btn => {
      const pid = btn.dataset.productId || btn.dataset.compareId;
      if (pid) {
        btn.classList.toggle('active', items.some(id => String(id) === String(pid)));
        const label = btn.querySelector('.compare-label');
        if (label) label.textContent = items.includes(Number(pid)) ? 'Remove from Compare' : 'Add to Compare';
      }
    });
  },
};

// ============================================
// Recently Viewed Products
// ============================================
const RecentlyViewed = {
  items: JSON.parse(localStorage.getItem('recentlyViewed') || '[]'),
  maxItems: 20,

  add(product) {
    if (!product || !product.id) return;
    this.items = this.items.filter(item => item.id !== product.id);
    this.items.unshift({
      id: product.id,
      name: product.name || 'Product',
      price: product.price || 0,
      image: product.image || product.images?.[0] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
      category: product.category || '',
      viewedAt: Date.now(),
    });
    if (this.items.length > this.maxItems) {
      this.items = this.items.slice(0, this.maxItems);
    }
    localStorage.setItem('recentlyViewed', JSON.stringify(this.items));
  },

  get() {
    return this.items;
  },

  render(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const items = this.items.slice(0, 8);
    if (items.length === 0) {
      container.innerHTML = '';
      container.style.display = 'none';
      return;
    }
    container.style.display = '';
    container.innerHTML = items.map(item => {
      const p = { _id: item.id, name: item.name, price: item.price, images: [item.image], category: item.category };
      return createProductCard(p);
    }).join('');
  },
};

// ============================================
// Search Autocomplete
// ============================================
const SearchAutocomplete = {
  debounceTimer: null,
  results: [],

  init(input) {
    if (typeof input === 'string') input = document.querySelector(input);
    if (!input) return;

    const dropdown = input.closest('.search-input-wrap')?.querySelector('.search-autocomplete') || document.createElement('div');
    dropdown.classList.add('search-autocomplete');
    if (!dropdown.parentElement) input.parentElement.appendChild(dropdown);

    input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      const query = e.target.value.trim();
      if (query.length < 2) {
        dropdown.classList.remove('active');
        return;
      }
      this.debounceTimer = setTimeout(() => this.search(query).then(results => this.renderDropdown(results, dropdown)), 250);
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        dropdown.classList.remove('active');
      }
      if (e.key === 'Escape') dropdown.classList.remove('active');
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-input-wrap')) {
        dropdown.classList.remove('active');
      }
    });
  },

  async search(query) {
    try {
      const data = await API.get(`/products/search?q=${encodeURIComponent(query)}&limit=6`);
      this.results = data.products || data || [];
    } catch {
      this.results = [];
    }
    return this.results;
  },

  renderDropdown(results, dropdown) {
    if (!dropdown) return;
    if (results.length === 0) {
      dropdown.classList.remove('active');
      return;
    }
    dropdown.innerHTML = results.map(p => {
      const id = p._id || p.id;
      const img = p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
      return `<a href="/pages/product.html?id=${id}" class="search-autocomplete-item">
        <img src="${img}" alt="" loading="lazy">
        <div>
          <div class="search-autocomplete-item-name">${p.name}</div>
          <div class="search-autocomplete-item-price">${Utils.formatCurrency(p.price)}</div>
        </div>
      </a>`;
    }).join('');
    dropdown.classList.add('active');
  },

  select(item) {
    if (item && item.id) {
      window.location.href = `/pages/product.html?id=${item.id}`;
    }
  },
};

// ============================================
// Feature Styles Injection
// ============================================
function injectFeatureStyles() {
  if (document.getElementById('br-feature-styles')) return;
  const s = document.createElement('style');
  s.id = 'br-feature-styles';
  s.textContent = `@keyframes spin{to{transform:rotate(360deg)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes qvSlideIn{from{opacity:0;transform:translateY(20px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes qvOverlayIn{from{opacity:0}to{opacity:1}}
@keyframes qvOverlayOut{from{opacity:1}to{opacity:0}}
.qv-overlay{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6);backdrop-filter:blur(8px);animation:qvOverlayIn .25s}
.qv-exit{animation:qvOverlayOut .25s forwards}
.qv-modal{background:var(--glass-bg,rgba(20,20,30,.95));border:1px solid var(--glass-border,rgba(255,255,255,.1));border-radius:var(--radius-lg,16px);max-width:700px;width:92%;max-height:85vh;overflow-y:auto;backdrop-filter:blur(20px);animation:qvSlideIn .3s;position:relative}
.qv-close{position:absolute;top:12px;right:16px;background:none;border:none;color:var(--text-muted);font-size:28px;cursor:pointer;z-index:2;padding:4px 8px;line-height:1;transition:color .2s}
.qv-close:hover{color:var(--text)}
.qv-body{display:flex;gap:var(--space-4);padding:var(--space-5)}
.qv-image{flex:1;min-width:0;position:relative}
.qv-image img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--radius-md)}
.qv-badge{position:absolute;top:12px;left:12px}
.qv-stockout-badge{position:absolute;top:12px;left:0;background:linear-gradient(135deg,#dc143c,#8b0000);padding:5px 14px 5px 10px;border-radius:0 16px 16px 0;box-shadow:0 4px 12px rgba(220,20,60,.4);z-index:2;animation:stockoutPulse 2s ease-in-out infinite}
.qv-stockout-badge span{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;display:flex;align-items:center;gap:4px}
.qv-stockout-badge span::before{content:"\\2716";font-size:9px}
@keyframes stockoutPulse{0%,100%{box-shadow:0 4px 12px rgba(220,20,60,.4)}50%{box-shadow:0 4px 20px rgba(220,20,60,.7)}}
.qv-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-3)}
.qv-title{margin:0;font-size:var(--text-lg);font-weight:var(--weight-bold);line-height:1.3}
.qv-price-row{display:flex;align-items:center;gap:var(--space-2)}
.qv-price{font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--primary)}
.qv-original-price{font-size:var(--text-sm);text-decoration:line-through;color:var(--text-muted)}
.qv-stock{font-size:var(--text-sm);font-weight:var(--weight-medium)}
.qv-section{display:flex;flex-direction:column;gap:var(--space-1)}
.qv-label{font-size:var(--text-sm);font-weight:var(--weight-medium)}
.qv-colors{display:flex;gap:8px;flex-wrap:wrap}
.qv-color-swatch{width:28px;height:28px;border-radius:50%;border:2px solid var(--glass-border,rgba(255,255,255,.15));cursor:pointer;transition:border-color .2s}
.qv-color-swatch.active{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary)}
.qv-sizes{display:flex;gap:8px;flex-wrap:wrap}
.qv-size-btn{padding:6px 14px;border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:var(--text-sm);transition:all .2s}
.qv-size-btn.active{border-color:var(--primary);background:var(--primary);color:#fff}
.qv-qty{display:flex;align-items:center;gap:var(--space-2)}
.qv-qty-btn{width:32px;height:32px;border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;transition:all .2s}
.qv-qty-btn:hover{border-color:var(--primary)}
.qv-qty-value{font-weight:var(--weight-bold);min-width:24px;text-align:center}
.qv-actions{display:flex;gap:var(--space-2)}
.qv-wishlist-btn{flex:0!important}
.qv-wishlist-btn.active{color:var(--primary)}
@media(max-width:640px){.qv-body{flex-direction:column}.qv-modal{max-height:90vh}}
.ai-search-item:hover{background:var(--glass-bg,rgba(255,255,255,.1))!important}
.voice-search-btn.listening{animation:voicePulse 1s infinite}
.voice-overlay{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.7);backdrop-filter:blur(16px);display:flex;align-items:center;justify-content:center;animation:voiceFadeIn .25s}
.voice-overlay-exit{animation:voiceFadeOut .25s forwards}
.voice-overlay-inner{text-align:center;max-width:480px;width:90%;padding:48px 32px}
.voice-wave{display:flex;align-items:center;justify-content:center;gap:6px;height:60px;margin-bottom:32px}
.voice-wave span{width:6px;height:20px;background:linear-gradient(to top,#dc143c,#ff6b8a);border-radius:20px;animation:voiceWave 1.2s ease-in-out infinite}
.voice-wave span:nth-child(2){animation-delay:.1s;height:30px}
.voice-wave span:nth-child(3){animation-delay:.2s;height:50px}
.voice-wave span:nth-child(4){animation-delay:.3s;height:35px}
.voice-wave span:nth-child(5){animation-delay:.4s;height:25px}
@keyframes voiceWave{0%,100%{transform:scaleY(.5);opacity:.5}50%{transform:scaleY(1);opacity:1}}
@keyframes voiceFadeIn{from{opacity:0}to{opacity:1}}
@keyframes voiceFadeOut{from{opacity:1}to{opacity:0}}
@keyframes voicePulse{0%,100%{box-shadow:0 0 0 0 rgba(220,20,60,.4)}50%{box-shadow:0 0 0 10px rgba(220,20,60,0)}}
.voice-status{font-size:var(--text-sm);color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px}
.voice-text{font-size:var(--text-xl);color:#fff;font-weight:var(--weight-semibold);min-height:60px;display:flex;align-items:center;justify-content:center;margin-bottom:32px;transition:all .2s}
.voice-text.has-text{color:var(--primary);font-size:var(--text-2xl)}
.voice-cancel-btn{padding:12px 40px;border-radius:var(--radius-full);background:rgba(255,255,255,.1);color:rgba(255,255,255,.7);border:1px solid rgba(255,255,255,.15);font-size:var(--text-sm);cursor:pointer;transition:all .2s}
.voice-cancel-btn:hover{background:rgba(255,255,255,.2);color:#fff}
.floating-btn:hover{transform:scale(1.1)!important}
.social-share-btn:hover{transform:scale(1.1)!important}`;
  document.head.appendChild(s);
}

// ============================================
// Recently Viewed - API Tracking
// ============================================
function getSessionId() {
  let sid = localStorage.getItem('br_session_id');
  if (!sid) {
    sid = 'sess_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('br_session_id', sid);
  }
  return sid;
}

async function trackRecentlyViewed(productId) {
  if (!productId) return;
  RecentlyViewed.add({ id: productId });
  try {
    await API.post('/recentlyviewed/track', { product_id: productId, session_id: getSessionId() });
  } catch { /* silent */ }
}

function renderRecentlyViewed(container) {
  if (typeof container === 'string') container = document.getElementById(container);
  if (!container) return;
  (async () => {
    try {
      const data = await API.get(`/recentlyviewed?limit=8&session_id=${getSessionId()}`);
      const items = data.items || data.products || data || [];
      if (items.length > 0) {
        container.innerHTML = items.map(p => {
          const id = p._id || p.id || p.product_id;
          return createProductCard({ _id: id, name: p.name || 'Product', price: p.price || p.sellingPrice || 0, images: [p.images?.[0] || p.image || p.thumbnail || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'] });
        }).join('');
        container.style.display = '';
        return;
      }
    } catch { /* fall through */ }
    const local = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
    if (local.length > 0) {
      container.innerHTML = local.slice(0, 8).map(item =>
        createProductCard({ _id: item.id, name: item.name, price: item.price, images: [item.image] })
      ).join('');
      container.style.display = '';
    } else {
      container.style.display = 'none';
    }
  })();
}

// ============================================
// Quick View Modal
// ============================================
const QuickView = {
  modal: null,
  currentProduct: null,
  selectedColor: null,
  selectedSize: null,
  quantity: 1,

  async open(productId) {
    if (!productId) return;
    let product;
    try {
      const data = await API.get(`/products/id/${productId}`);
      product = data.data || data.product || data;
    } catch {
      Toast.error('Failed to load product details');
      return;
    }
    this.currentProduct = product;
    this.selectedColor = null;
    this.selectedSize = null;
    this.quantity = 1;
    this._render(product);
  },

  close() {
    if (this.modal) {
      this.modal.classList.add('qv-exit');
      setTimeout(() => {
        if (this.modal) this.modal.remove();
        this.modal = null;
        document.body.style.overflow = '';
      }, 250);
    }
  },

  setQuantity(q) {
    this.quantity = Math.max(1, q);
    const qtyEl = this.modal?.querySelector('.qv-qty-value');
    if (qtyEl) qtyEl.textContent = this.quantity;
  },

  selectColor(color, images) {
    this.selectedColor = color;
    const mainImg = this.modal?.querySelector('.qv-image img');
    if (mainImg && images?.length) mainImg.src = images[0];
    this.modal?.querySelectorAll('.qv-color-swatch').forEach(s => {
      s.classList.toggle('active', s.dataset.color === color);
    });
  },

  selectSize(size) {
    this.selectedSize = size;
    this.modal?.querySelectorAll('.qv-size-btn').forEach(s => {
      s.classList.toggle('active', s.dataset.size === size);
    });
    const product = this.currentProduct;
    if (product?.variants?.length) {
      const variant = product.variants.find(v => v.size === size && (!this.selectedColor || v.color === this.selectedColor));
      if (variant) {
        const priceEl = this.modal?.querySelector('.qv-price');
        if (priceEl) priceEl.textContent = Utils.formatCurrency(variant.price || product.price);
        const stockEl = this.modal?.querySelector('.qv-stock');
        if (stockEl) {
          const inStock = variant.stock == null || variant.stock > 0;
          stockEl.textContent = inStock ? 'In Stock' : 'Out of Stock';
          stockEl.style.color = inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)';
        }
      }
    }
  },

  addToCart() {
    const id = this.currentProduct?._id || this.currentProduct?.id;
    if (!id) return;
    Cart.addItem(id, this.quantity);
    this.close();
  },

  _render(product) {
    const id = product._id || product.id;
    const images = product.images || [product.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'];
    const name = product.name || 'Product';
    const price = product.price || 0;
    const originalPrice = product.originalPrice || product.compareAtPrice || product.mrp || 0;
    const discount = originalPrice > price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;
    const colors = product.colors || product.variants?.filter((v, i, a) => v.color && a.findIndex(x => x.color === v.color) === i).map(v => v.color) || [];
    const sizes = product.sizes || product.variants?.filter((v, i, a) => v.size && a.findIndex(x => x.size === v.size) === i).map(v => v.size) || [];
    const isWished = Wishlist.items.some(i => (i.id || i) == id);
    const stock = product.stock_quantity ?? product.stockQuantity ?? product.stock ?? 0;
    const isPreorder = product.is_preorder;
    const inStock = stock > 0;
    const sn = name.replace(/'/g, "\\'");

    this.modal = document.createElement('div');
    this.modal.className = 'qv-overlay';
    let html = '<div class="qv-modal"><button class="qv-close" aria-label="Close">&times;</button><div class="qv-body">';
    html += '<div class="qv-image"><img src="' + images[0] + '" alt="' + name + '" loading="lazy"' + (!inStock ? ' style="opacity:0.5;"' : '') + '>';
    if (!inStock) html += '<div class="qv-stockout-badge"><span>Stock Out</span></div>';
    else if (discount > 0) html += '<span class="badge badge-danger qv-badge">-' + discount + '%</span>';
    html += '</div><div class="qv-info">';
    html += '<h3 class="qv-title">' + name + '</h3>';
    html += '<div class="qv-price-row"><span class="qv-price">' + Utils.formatCurrency(price) + '</span>';
    if (discount > 0) html += '<span class="qv-original-price">' + Utils.formatCurrency(originalPrice) + '</span>';
    html += '</div>';
    html += '<div class="qv-stock" style="color:' + (inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)') + ';">' + (inStock ? 'In Stock' : 'Out of Stock') + '</div>';
    if (colors.length > 0) {
      html += '<div class="qv-section"><div class="qv-label">Color</div><div class="qv-colors">';
      colors.forEach(c => { html += '<button class="qv-color-swatch" data-color="' + c + '" style="background:' + c + ';" title="' + c + '"></button>'; });
      html += '</div></div>';
    }
    if (sizes.length > 0) {
      html += '<div class="qv-section"><div class="qv-label">Size</div><div class="qv-sizes">';
      sizes.forEach(s => { html += '<button class="qv-size-btn" data-size="' + s + '">' + s + '</button>'; });
      html += '</div></div>';
    }
    html += '<div class="qv-section"><div class="qv-label">Quantity</div><div class="qv-qty">';
    html += '<button class="qv-qty-btn" onclick="QuickView.setQuantity(QuickView.quantity - 1)">&minus;</button>';
    html += '<span class="qv-qty-value">1</span>';
    html += '<button class="qv-qty-btn" onclick="QuickView.setQuantity(QuickView.quantity + 1)">+</button></div></div>';
    html += '<div class="qv-actions">';
    if (inStock) {
      html += '<button class="btn btn-primary btn-lg" onclick="QuickView.addToCart()" style="flex:2;">Add to Cart</button>';
    } else if (isPreorder) {
      html += '<button class="btn btn-primary btn-lg" onclick="QuickView.close(); PreOrder.show(\'' + id + '\',\'' + sn + '\');" style="flex:2;">Pre-Order</button>';
    } else {
      html += '<button class="btn btn-glass btn-lg" disabled style="flex:2;opacity:0.5;">Out of Stock</button>';
    }
    html += '<button class="btn btn-glass btn-lg qv-wishlist-btn ' + (isWished ? 'active' : '') + '" onclick="Wishlist.toggle(\'' + id + '\'); this.classList.toggle(\'active\');" aria-label="Wishlist"><svg width="20" height="20" viewBox="0 0 24 24" fill="' + (isWished ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg></button>';
    html += '</div>';
    if (!inStock && !isPreorder) {
      html += '<button class="btn btn-ghost btn-lg" onclick="QuickView.close(); BackInStock.show(\'' + id + '\');" style="width:100%;">Notify When Available</button>';
    }
    html += '<a href="/pages/product.html?id=' + id + '" class="btn btn-ghost btn-lg" style="width:100%;margin-top:var(--space-1);">View Full Details</a>';
    html += '</div></div></div>';
    this.modal.innerHTML = html;
    document.body.appendChild(this.modal);
    document.body.style.overflow = 'hidden';
    this.modal.addEventListener('click', (e) => { if (e.target === this.modal) this.close(); });
    this.modal.querySelector('.qv-close').addEventListener('click', () => this.close());
    this.modal.querySelectorAll('.qv-color-swatch').forEach(s => {
      s.addEventListener('click', () => {
        const color = s.dataset.color;
        const variantImages = product.variants?.filter(v => v.color === color).flatMap(v => v.images || []).filter(Boolean);
        this.selectColor(color, variantImages.length ? variantImages : images);
      });
    });
    this.modal.querySelectorAll('.qv-size-btn').forEach(s => {
      s.addEventListener('click', () => this.selectSize(s.dataset.size));
    });
  },
};

document.addEventListener('click', (e) => {
  const btn = e.target.closest('.quick-view-btn, [data-quick-view]');
  if (btn) {
    e.preventDefault();
    const id = btn.dataset.productId || btn.dataset.quickView;
    if (id) QuickView.open(id);
  }
});

// ============================================
// Pre-Order
// ============================================
const PreOrder = {
  show(productId, productName) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);animation:fadeIn 0.2s;';
    overlay.innerHTML = '<div style="background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-lg,16px);padding:var(--space-6);max-width:420px;width:90%;backdrop-filter:blur(20px);animation:qvSlideIn 0.3s;"><h3 style="margin:0 0 var(--space-2);font-size:var(--text-lg);font-weight:var(--weight-bold);">Pre-Order: ' + (productName || 'Product') + '</h3><p style="color:var(--text-muted);font-size:var(--text-sm);margin:0 0 var(--space-4);">This item is currently out of stock. Place a pre-order to reserve yours.</p><form id="preorderForm"><div style="margin-bottom:var(--space-3);"><label style="display:block;font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Expected Availability Date</label><input type="date" name="expected_date" required style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="margin-bottom:var(--space-4);"><label style="display:block;font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Deposit Amount (Optional)</label><input type="number" name="deposit" min="0" placeholder="0" style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="display:flex;gap:var(--space-2);"><button type="button" class="btn btn-ghost" onclick="this.closest(\'.modal-overlay\').remove()" style="flex:1;">Cancel</button><button type="submit" class="btn btn-primary" style="flex:2;">Place Pre-Order</button></div></form></div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('#preorderForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const payload = { product_id: productId, expected_date: formData.get('expected_date'), deposit: Number(formData.get('deposit')) || 0 };
      try {
        await API.post('/orders/preorder', payload);
        Toast.success('Pre-order placed successfully!');
      } catch { Toast.info('Pre-order request submitted!'); }
      overlay.remove();
    });
  },
};

// ============================================
// Back In Stock Notification
// ============================================
const BackInStock = {
  show(productId) {
    const existing = document.querySelector('.bis-overlay');
    if (existing) existing.remove();
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay bis-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);animation:fadeIn 0.2s;';
    overlay.innerHTML = '<div style="background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-lg,16px);padding:var(--space-6);max-width:400px;width:90%;backdrop-filter:blur(20px);animation:qvSlideIn 0.3s;"><h3 style="margin:0 0 var(--space-2);font-size:var(--text-lg);font-weight:var(--weight-bold);">Notify When Available</h3><p style="color:var(--text-muted);font-size:var(--text-sm);margin:0 0 var(--space-4);">We\'ll email you when this product is back in stock.</p><form id="bisForm"><div style="margin-bottom:var(--space-4);"><input type="email" name="email" placeholder="your@email.com" required style="width:100%;padding:var(--space-2) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border,rgba(255,255,255,0.15));background:var(--glass-bg,rgba(255,255,255,0.05));color:var(--text);font-size:var(--text-sm);box-sizing:border-box;"></div><div style="display:flex;gap:var(--space-2);"><button type="button" class="btn btn-ghost" onclick="this.closest(\'.modal-overlay\').remove()" style="flex:1;">Cancel</button><button type="submit" class="btn btn-primary" style="flex:2;">Subscribe</button></div></form></div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('#bisForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = new FormData(e.target).get('email');
      try {
        await API.post('/back-in-stock/subscribe', { product_id: productId, email });
        Toast.success('You will be notified when this product is back in stock!');
      } catch {       Toast.success('Subscribed! We\'ll notify you when available.'); }
      overlay.remove();
    });
  },
};

// ============================================
// AI Search Suggestion
// ============================================
const AISearch = {
  activeIndex: -1,
  debounceTimer: null,
  dropdown: null,
  input: null,

  init(input) {
    if (typeof input === 'string') input = document.querySelector(input);
    if (!input) return;
    this.input = input;
    this.dropdown = document.createElement('div');
    this.dropdown.className = 'ai-search-dropdown';
    this.dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;margin-top:4px;background:var(--glass-bg,rgba(20,20,30,0.95));border:1px solid var(--glass-border,rgba(255,255,255,0.1));border-radius:var(--radius-md,12px);backdrop-filter:blur(20px);overflow:hidden;z-index:100;display:none;box-shadow:0 12px 40px rgba(0,0,0,0.4);';
    const wrap = input.closest('.search-input-wrap') || input.parentElement;
    if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(this.dropdown); }

    input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      this.activeIndex = -1;
      const q = e.target.value.trim();
      if (q.length < 2) { this.dropdown.style.display = 'none'; return; }
      this.debounceTimer = setTimeout(() => this.fetchSuggestions(q), 300);
    });

    input.addEventListener('keydown', (e) => {
      const items = this.dropdown.querySelectorAll('.ai-search-item');
      if (!items.length || this.dropdown.style.display === 'none') return;
      if (e.key === 'ArrowDown') { e.preventDefault(); this.activeIndex = Math.min(this.activeIndex + 1, items.length - 1); this._highlight(items); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.activeIndex = Math.max(this.activeIndex - 1, -1); this._highlight(items); }
      else if (e.key === 'Enter' && this.activeIndex >= 0 && items[this.activeIndex]) { e.preventDefault(); items[this.activeIndex].click(); }
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-input-wrap') && !e.target.closest('.ai-search-dropdown')) {
        this.dropdown.style.display = 'none';
      }
    });
  },

  async fetchSuggestions(query) {
    if (!this.dropdown) return;
    this.dropdown.style.display = 'block';
    this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">Searching...</div>';
    try {
      const data = await API.post('/ai/search', { query });
      const results = data.results || data.products || data || [];
      if (results.length === 0) {
        this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">No suggestions found</div>';
        return;
      }
      let html = results.slice(0, 6).map(p => {
        const id = p._id || p.id;
        const img = p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600';
        return '<a href="/pages/product.html?id=' + id + '" class="ai-search-item" style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2) var(--space-3);text-decoration:none;color:var(--text);transition:background 0.15s;"><img src="' + img + '" alt="" style="width:40px;height:40px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy"><div style="min-width:0;flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + p.name + '</div><div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">' + Utils.formatCurrency(p.price) + '</div></div></a>';
      }).join('');
      html += '<div style="padding:var(--space-2) var(--space-3);border-top:1px solid var(--glass-border,rgba(255,255,255,0.1));font-size:var(--text-xs);color:var(--text-muted);display:flex;align-items:center;gap:var(--space-1);"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg> Powered by AI</div>';
      this.dropdown.innerHTML = html;
      this.dropdown.querySelectorAll('.ai-search-item').forEach((item, i) => {
        item.addEventListener('mouseenter', () => { this.activeIndex = i; this._highlight(this.dropdown.querySelectorAll('.ai-search-item')); });
      });
    } catch {
      this.dropdown.innerHTML = '<div style="padding:var(--space-4);text-align:center;color:var(--text-muted);font-size:var(--text-sm);">Suggestions unavailable</div>';
    }
  },

  _highlight(items) {
    items.forEach((item, i) => { item.style.background = i === this.activeIndex ? 'var(--glass-bg,rgba(255,255,255,0.1))' : 'transparent'; });
  },
};

// ============================================
// Voice Search
// ============================================
const VoiceSearch = {
  recognition: null,
  isListening: false,
  btn: null,
  overlay: null,
  finalTranscript: '',

  init() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    this.recognition = new SR();
    this.recognition.continuous = false;
    this.recognition.interimResults = true;
    try { this.recognition.lang = 'bn-BD'; } catch { this.recognition.lang = 'en-US'; }

    this.recognition.onresult = (e) => {
      this.finalTranscript = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) this.finalTranscript += e.results[i][0].transcript;
      }
      const interim = Array.from(e.results).map(r => r[0].transcript).join('');
      const input = document.getElementById('searchInput');
      if (input) {
        input.value = interim;
        input.dispatchEvent(new Event('input'));
      }
      this._updateOverlay(interim);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this._updateUI();
      if (this.finalTranscript.trim()) {
        const input = document.getElementById('searchInput');
        if (input) {
          input.value = this.finalTranscript;
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        }
      }
      this._removeOverlay();
    };

    this.recognition.onerror = (ev) => {
      this.isListening = false;
      this._updateUI();
      this._removeOverlay();
      if (ev.error === 'not-allowed') Toast.warning('Microphone access denied. Please allow microphone permissions.');
    };

    this._createMicButton();
  },

  _createMicButton() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    const wrap = searchInput.closest('.search-input-wrap') || searchInput.parentElement;
    if (!wrap || wrap.querySelector('.voice-search-btn')) return;

    this.btn = document.createElement('button');
    this.btn.className = 'voice-search-btn';
    this.btn.type = 'button';
    this.btn.setAttribute('aria-label', 'Voice search');
    this.btn.innerHTML =
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/>' +
      '<path d="M19 10v2a7 7 0 01-14 0v-2"/>' +
      '<line x1="12" y1="19" x2="12" y2="23"/>' +
      '<line x1="8" y1="23" x2="16" y2="23"/></svg>';
    this.btn.style.cssText = 'position:absolute;right:44px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer;padding:6px;border-radius:var(--radius-full);transition:all 0.3s;display:flex;align-items:center;justify-content:center;z-index:5;';
    this.btn.addEventListener('mouseenter', () => { if (!this.isListening) this.btn.style.background = 'var(--glass-bg)'; });
    this.btn.addEventListener('mouseleave', () => { if (!this.isListening) this.btn.style.background = 'none'; });
    this.btn.addEventListener('click', (e) => { e.preventDefault(); this.toggle(); });
    wrap.appendChild(this.btn);
    wrap.style.position = 'relative';
  },

  toggle() { this.isListening ? this.stop() : this.start(); },

  start() {
    if (!this.recognition) return;
    try {
      this.recognition.start();
      this.isListening = true;
      this._updateUI();
      this._showOverlay();
    } catch { /* already started */ }
  },

  stop() {
    if (!this.recognition) return;
    try { this.recognition.stop(); } catch {}
    this.isListening = false;
    this._updateUI();
    this._removeOverlay();
  },

  _showOverlay() {
    if (this.overlay) return;
    this.overlay = document.createElement('div');
    this.overlay.className = 'voice-overlay';
    this.overlay.innerHTML =
      '<div class="voice-overlay-inner">' +
      '<div class="voice-wave"><span></span><span></span><span></span><span></span><span></span></div>' +
      '<div class="voice-status">Listening...</div>' +
      '<div class="voice-text" id="voiceTranscript">Say a product name like "Jamdani shirt" or "ইলিশ মাছ"</div>' +
      '<button class="voice-cancel-btn" id="voiceCancelBtn">Cancel</button>' +
      '</div>';
    document.body.appendChild(this.overlay);
    document.getElementById('voiceCancelBtn')?.addEventListener('click', () => this.stop());
    this.overlay.addEventListener('click', (e) => { if (e.target === this.overlay) this.stop(); });
  },

  _updateOverlay(text) {
    const el = document.getElementById('voiceTranscript');
    if (el) {
      el.textContent = text || 'Listening...';
      el.classList.add('has-text');
    }
  },

  _removeOverlay() {
    if (this.overlay) {
      this.overlay.classList.add('voice-overlay-exit');
      setTimeout(() => { if (this.overlay) { this.overlay.remove(); this.overlay = null; } }, 300);
    }
  },

  _updateUI() {
    if (!this.btn) return;
    if (this.isListening) {
      this.btn.style.color = '#dc143c';
      this.btn.style.background = 'rgba(220,20,60,0.12)';
      this.btn.style.boxShadow = '0 0 20px rgba(220,20,60,0.3)';
      this.btn.classList.add('listening');
      this.btn.title = 'Tap to stop';
    } else {
      this.btn.style.color = '';
      this.btn.style.background = '';
      this.btn.style.boxShadow = '';
      this.btn.classList.remove('listening');
      this.btn.title = 'Voice search';
    }
  },
};

// ============================================
// Floating Buttons (WhatsApp + Messenger)
// ============================================
const FloatingButtons = {
  init() {
    const c = document.createElement('div');
    c.className = 'floating-social-buttons';
    c.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:999;display:flex;flex-direction:column;gap:12px;';
    c.innerHTML = '<a href="https://wa.me/8801XXXXXXXXX?text=' + encodeURIComponent('Hi, I want to order from Bangalirhaat') + '" target="_blank" rel="noopener noreferrer" class="floating-btn floating-whatsapp" title="Order via WhatsApp" style="width:56px;height:56px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;box-shadow:0 4px 16px rgba(37,211,102,0.4);transition:transform 0.2s,box-shadow 0.2s;"><svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a><a href="https://m.me/bangalirhaat" target="_blank" rel="noopener noreferrer" class="floating-btn floating-messenger" title="Chat with us" style="width:56px;height:56px;border-radius:50%;background:#0084FF;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;box-shadow:0 4px 16px rgba(0,132,255,0.4);transition:transform 0.2s,box-shadow 0.2s;"><svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 0C5.373 0 0 4.974 0 11.111c0 3.498 1.744 6.614 4.469 8.654V24l4.088-2.242c1.092.3 2.246.464 3.443.464 6.627 0 12-4.975 12-11.111C24 4.974 18.627 0 12 0zm1.191 14.963l-3.055-3.26-5.963 3.26L10.732 8.2l3.131 3.259L19.752 8.2l-6.561 6.763z"/></svg></a>';
    document.body.appendChild(c);
  },
};

// ============================================
// Invoice QR Code
// ============================================
const InvoiceQR = {
  generate(orderNumber, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container || !orderNumber) return;
    const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(orderNumber);
    container.innerHTML = '<div style="text-align:center;"><img src="' + qrUrl + '" alt="QR Code for ' + orderNumber + '" style="border-radius:var(--radius-sm);background:#fff;padding:8px;" loading="lazy"><div style="font-size:var(--text-xs);color:var(--text-muted);margin-top:var(--space-2);">Scan to track order</div></div>';
  },
};

// ============================================
// Order Tracking Timeline
// ============================================
const OrderTracking = {
  statuses: ['Order Placed', 'Confirmed', 'Processing', 'Shipped', 'Out for Delivery', 'Delivered'],
  statusKeys: ['placed', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered'],

  render(order, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container || !order) return;
    const currentStatus = (order.status || order.orderStatus || '').toLowerCase().replace(/\s+/g, '_');
    const currentIdx = this.statusKeys.indexOf(currentStatus);
    const timeline = order.timeline || order.statusHistory || [];
    const trackingNumber = order.trackingNumber || order.courier_tracking || null;
    const courierName = order.courierName || order.courier || '';

    let html = '<div style="position:relative;padding:var(--space-4) 0;">';
    this.statuses.forEach((label, i) => {
      let state = 'pending';
      let timestamp = '';
      if (currentIdx >= 0 && i < currentIdx) state = 'completed';
      else if (currentIdx >= 0 && i === currentIdx) state = 'current';
      if (i <= currentIdx) {
        const entry = timeline.find(t => (t.status || '').toLowerCase().replace(/\s+/g, '_') === this.statusKeys[i]);
        if (entry?.date || entry?.createdAt) timestamp = Utils.formatDate(entry.date || entry.createdAt);
      }
      const colors = { completed: 'var(--success, #10b981)', current: 'var(--primary, #dc143c)', pending: 'var(--text-muted, #6b7280)' };
      const color = colors[state];
      const isLast = i === this.statuses.length - 1;
      html += '<div style="display:flex;gap:var(--space-3);position:relative;padding-bottom:' + (isLast ? '0' : 'var(--space-6)') + ';">';
      if (!isLast) html += '<div style="position:absolute;left:15px;top:32px;bottom:0;width:2px;background:' + (i < currentIdx ? color : 'var(--glass-border, rgba(255,255,255,0.1))') + ';"></div>';
      html += '<div style="width:32px;height:32px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:var(--weight-bold);background:' + (state === 'pending' ? 'var(--glass-bg, rgba(255,255,255,0.05))' : color + '20') + ';color:' + color + ';border:2px solid ' + color + ';">';
      html += state === 'completed' ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : (i + 1);
      html += '</div><div style="flex:1;padding-top:4px;">';
      html += '<div style="font-size:var(--text-sm);font-weight:' + (state === 'current' ? 'var(--weight-bold)' : 'var(--weight-medium)') + ';color:' + (state === 'pending' ? 'var(--text-muted)' : 'var(--text)') + ';">' + label + '</div>';
      if (timestamp) html += '<div style="font-size:var(--text-xs);color:var(--text-muted);margin-top:2px;">' + timestamp + '</div>';
      html += '</div></div>';
    });
    html += '</div>';
    if (trackingNumber && currentIdx >= 3) {
      html += '<div style="margin-top:var(--space-4);padding:var(--space-3);background:var(--glass-bg, rgba(255,255,255,0.05));border:1px solid var(--glass-border, rgba(255,255,255,0.1));border-radius:var(--radius-sm);"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);margin-bottom:var(--space-1);">Courier Tracking</div><div style="font-size:var(--text-sm);color:var(--text-muted);">' + (courierName ? courierName + ': ' : '') + trackingNumber + '</div></div>';
    }
    container.innerHTML = html;
  },
};

// ============================================
// Infinite Scroll
// ============================================
const InfiniteScroll = {
  observer: null,
  loading: false,
  page: 1,
  hasMore: true,
  grid: null,
  endpoint: '',
  limit: 20,

  init(options = {}) {
    this.grid = typeof options.grid === 'string' ? document.querySelector(options.grid) : options.grid;
    this.endpoint = options.endpoint || '/products';
    this.limit = options.limit || 20;
    this.page = options.startPage || 1;
    this.hasMore = true;
    this.loading = false;
    if (!this.grid) return;
    let sentinel = document.getElementById('infiniteScrollSentinel');
    if (!sentinel) {
      sentinel = document.createElement('div');
      sentinel.id = 'infiniteScrollSentinel';
      sentinel.style.cssText = 'height:1px;width:100%;';
      this.grid.parentElement?.appendChild(sentinel);
    }
    this.observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !this.loading && this.hasMore) this.loadMore();
    }, { rootMargin: '200px' });
    this.observer.observe(sentinel);
  },

  async loadMore() {
    if (this.loading || !this.hasMore) return;
    this.loading = true;
    this._showSpinner();
    try {
      const sep = this.endpoint.includes('?') ? '&' : '?';
      const data = await API.get(this.endpoint + sep + 'page=' + this.page + '&limit=' + this.limit);
      const products = data.products || data.data || data || [];
      if (products.length < this.limit) this.hasMore = false;
      this.page++;
      const fragment = document.createDocumentFragment();
      products.forEach(p => {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = createProductCard(p);
        fragment.appendChild(wrapper.firstElementChild);
      });
      this.grid.appendChild(fragment);
    } catch { this.hasMore = false; }
    finally { this.loading = false; this._hideSpinner(); }
  },

  _showSpinner() {
    let sp = document.getElementById('infiniteScrollSpinner');
    if (!sp) {
      sp = document.createElement('div');
      sp.id = 'infiniteScrollSpinner';
      sp.style.cssText = 'text-align:center;padding:var(--space-6);';
      sp.innerHTML = '<div style="width:32px;height:32px;border:3px solid var(--glass-border);border-top-color:var(--primary);border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto;"></div>';
      this.grid.parentElement?.appendChild(sp);
    }
    sp.style.display = '';
  },

  _hideSpinner() {
    const sp = document.getElementById('infiniteScrollSpinner');
    if (sp) sp.style.display = 'none';
  },

  destroy() {
    if (this.observer) this.observer.disconnect();
    this.loading = false;
    this.hasMore = true;
    document.getElementById('infiniteScrollSentinel')?.remove();
    document.getElementById('infiniteScrollSpinner')?.remove();
  },
};

// ============================================
// Product Variants
// ============================================
const ProductVariants = {
  product: null,
  selectedColor: null,
  selectedSize: null,

  init(product) {
    this.product = product;
    if (!product) return;
    const variants = product.variants || [];
    if (variants.length === 0) return;
    const colors = [...new Set(variants.filter(v => v.color).map(v => v.color))];
    const sizes = [...new Set(variants.filter(v => v.size).map(v => v.size))];
    if (colors.length) this._renderColors(colors);
    if (sizes.length) this._renderSizes(sizes);
  },

  _renderColors(colors) {
    const container = document.querySelector('.variant-colors, [data-variant-colors]');
    if (!container) return;
    container.innerHTML = colors.map(c => {
      const variant = this.product.variants.find(v => v.color === c);
      const img = variant?.image || variant?.images?.[0];
      return '<button class="color-swatch" data-color="' + c + '" style="width:32px;height:32px;border-radius:50%;border:2px solid var(--glass-border, rgba(255,255,255,0.15));background:' + c + ';cursor:pointer;transition:border-color 0.2s;" title="' + c + '"' + (img ? ' data-img="' + img + '"' : '') + '></button>';
    }).join('');
    container.querySelectorAll('.color-swatch').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectedColor = btn.dataset.color;
        container.querySelectorAll('.color-swatch').forEach(b => b.style.borderColor = 'var(--glass-border, rgba(255,255,255,0.15))');
        btn.style.borderColor = 'var(--primary, #dc143c)';
        if (btn.dataset.img) {
          const mainImg = document.querySelector('.product-gallery-main img, .product-main-image');
          if (mainImg) mainImg.src = btn.dataset.img;
        }
        this._updateStockStatus();
      });
    });
  },

  _renderSizes(sizes) {
    const container = document.querySelector('.variant-sizes, [data-variant-sizes]');
    if (!container) return;
    container.innerHTML = sizes.map(s => '<button class="size-btn" data-size="' + s + '" style="padding:var(--space-1) var(--space-3);border-radius:var(--radius-sm);border:1px solid var(--glass-border, rgba(255,255,255,0.15));background:var(--glass-bg);color:var(--text);cursor:pointer;font-size:var(--text-sm);transition:all 0.2s;">' + s + '</button>').join('');
    container.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectedSize = btn.dataset.size;
        container.querySelectorAll('.size-btn').forEach(b => { b.style.borderColor = 'var(--glass-border, rgba(255,255,255,0.15))'; b.style.background = 'var(--glass-bg)'; b.style.color = 'var(--text)'; });
        btn.style.borderColor = 'var(--primary, #dc143c)';
        btn.style.background = 'var(--primary, #dc143c)';
        btn.style.color = '#fff';
        const variant = this.product.variants.find(v => v.size === this.selectedSize && (!this.selectedColor || v.color === this.selectedColor));
        if (variant) {
          const priceEl = document.querySelector('.product-price-current, [data-product-price]');
          if (priceEl) priceEl.textContent = Utils.formatCurrency(variant.price || this.product.price);
        }
        this._updateStockStatus();
      });
    });
  },

  _updateStockStatus() {
    if (!this.product?.variants) return;
    const variant = this.product.variants.find(v => (!this.selectedColor || v.color === this.selectedColor) && (!this.selectedSize || v.size === this.selectedSize));
    const stockEl = document.querySelector('.product-stock-status, [data-stock-status]');
    if (!stockEl || !variant) return;
    const inStock = variant.stock == null || variant.stock > 0;
    stockEl.textContent = inStock ? 'In Stock' : 'Out of Stock';
    stockEl.style.color = inStock ? 'var(--success, #10b981)' : 'var(--danger, #ef4444)';
    const addBtn = document.querySelector('.add-to-cart-btn, [data-add-to-cart]');
    if (addBtn) addBtn.disabled = !inStock;
  },

  getSelected() {
    return { color: this.selectedColor, size: this.selectedSize };
  },
};

// ============================================
// Gift Card
// ============================================
const GiftCard = {
  async renderBalance(container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/giftcard/balance');
      const balance = data.balance || data.amount || 0;
      container.innerHTML = '<div style="padding:var(--space-4);background:linear-gradient(135deg, var(--primary, #dc143c), #ff6b6b);border-radius:var(--radius-md);color:#fff;margin-bottom:var(--space-4);"><div style="font-size:var(--text-xs);text-transform:uppercase;letter-spacing:1px;opacity:0.8;">Gift Card Balance</div><div style="font-size:var(--text-2xl);font-weight:var(--weight-bold);margin-top:var(--space-1);">' + Utils.formatCurrency(balance) + '</div></div>';
    } catch { container.innerHTML = ''; }
  },

  initRedeemForm(form) {
    if (typeof form === 'string') form = document.querySelector(form);
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = form.querySelector('input[name="giftcard_code"]')?.value?.trim();
      if (!code) return;
      try {
        await API.post('/giftcard/redeem', { code });
        Toast.success('Gift card redeemed successfully!');
        form.reset();
        const balanceEl = document.getElementById('giftCardBalance');
        if (balanceEl) this.renderBalance(balanceEl);
      } catch (err) { Toast.error(err.message || 'Invalid gift card code'); }
    });
  },
};

// ============================================
// Bundle Offer
// ============================================
const BundleOffer = {
  async render(productId, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/products/' + productId + '/bundles');
      const bundles = data.bundles || data || [];
      if (bundles.length === 0) { container.style.display = 'none'; return; }
      container.innerHTML = bundles.map(bundle => {
        const originalTotal = (bundle.products || []).reduce((sum, p) => sum + (p.price || 0), 0);
        const bundlePrice = bundle.bundlePrice || bundle.price || 0;
        const savings = originalTotal - bundlePrice;
        let html = '<div style="padding:var(--space-4);border:1px solid var(--primary, #dc143c);border-radius:var(--radius-md);background:var(--glass-bg);margin-bottom:var(--space-3);">';
        html += '<div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-3);"><span class="badge badge-danger">Bundle Deal</span><span style="font-size:var(--text-sm);color:var(--success, #10b981);font-weight:var(--weight-semibold);">Save ' + Utils.formatCurrency(savings) + '</span></div>';
        html += '<div style="display:flex;gap:var(--space-2);overflow-x:auto;padding-bottom:var(--space-2);">';
        (bundle.products || []).forEach(p => {
          html += '<div style="min-width:80px;text-align:center;flex-shrink:0;"><img src="' + (p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600') + '" alt="' + (p.name || '') + '" style="width:64px;height:64px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy"><div style="font-size:var(--text-xs);margin-top:var(--space-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:80px;">' + (p.name || '') + '</div></div>';
        });
        html += '</div>';
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:var(--space-3);"><div><span style="font-size:var(--text-lg);font-weight:var(--weight-bold);color:var(--primary);">' + Utils.formatCurrency(bundlePrice) + '</span><span style="font-size:var(--text-sm);text-decoration:line-through;color:var(--text-muted);margin-left:var(--space-2);">' + Utils.formatCurrency(originalTotal) + '</span></div>';
        html += '<button class="btn btn-primary btn-sm" onclick="BundleOffer.addBundle(\'' + (bundle._id || bundle.id) + '\')">Add Bundle to Cart</button></div></div>';
        return html;
      }).join('');
    } catch { container.style.display = 'none'; }
  },

  async addBundle(bundleId) {
    try {
      await API.post('/cart/bundle', { bundleId });
      Toast.success('Bundle added to cart!');
      Cart.load();
    } catch (err) { Toast.error(err.message || 'Failed to add bundle'); }
  },
};

// ============================================
// Frequently Bought Together (FBT)
// ============================================
const FBT = {
  items: [],
  selected: new Set(),

  async render(productId, container) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    try {
      const data = await API.get('/bundle/fbt/' + productId);
      this.items = data.products || data.items || data || [];
      if (this.items.length === 0) { container.style.display = 'none'; return; }
      this.items.forEach(p => this.selected.add(p._id || p.id));
      container.setAttribute('data-fbt-container', '');
      this._render(productId, container);
    } catch { container.style.display = 'none'; }
  },

  _render(productId, container) {
    const selectedItems = this.items.filter(p => this.selected.has(p._id || p.id));
    const totalPrice = selectedItems.reduce((sum, p) => sum + (p.price || 0), 0);
    const originalTotal = selectedItems.reduce((sum, p) => sum + (p.originalPrice || p.price || 0), 0);
    const savings = originalTotal - totalPrice;
    let html = '<div style="padding:var(--space-4);border:1px solid var(--glass-border, rgba(255,255,255,0.1));border-radius:var(--radius-md);background:var(--glass-bg);">';
    html += '<h4 style="margin:0 0 var(--space-3);font-size:var(--text-md);font-weight:var(--weight-bold);">Frequently Bought Together</h4>';
    html += '<div style="display:flex;gap:var(--space-3);overflow-x:auto;padding-bottom:var(--space-3);align-items:center;">';
    this.items.forEach(p => {
      const id = p._id || p.id;
      const isChecked = this.selected.has(id);
      html += '<label style="min-width:120px;flex-shrink:0;text-align:center;cursor:pointer;display:block;"><input type="checkbox" value="' + id + '"' + (isChecked ? ' checked' : '') + ' onchange="FBT.toggleItem(\'' + id + '\',\'' + productId + '\')" style="display:none;">';
      html += '<div style="border:2px solid ' + (isChecked ? 'var(--primary, #dc143c)' : 'var(--glass-border, rgba(255,255,255,0.1))') + ';border-radius:var(--radius-sm);padding:var(--space-2);transition:border-color 0.2s;">';
      html += '<img src="' + (p.images?.[0] || p.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600') + '" alt="' + (p.name || '') + '" style="width:80px;height:80px;border-radius:var(--radius-sm);object-fit:cover;" loading="lazy">';
      html += '<div style="font-size:var(--text-xs);margin-top:var(--space-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + (p.name || '') + '</div>';
      html += '<div style="font-size:var(--text-xs);color:var(--primary);font-weight:var(--weight-semibold);">' + Utils.formatCurrency(p.price) + '</div></div></label>';
    });
    html += '</div>';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;padding-top:var(--space-3);border-top:1px solid var(--glass-border, rgba(255,255,255,0.1));"><div><span style="font-size:var(--text-sm);color:var(--text-muted);">Total: </span><span style="font-size:var(--text-lg);font-weight:var(--weight-bold);">' + Utils.formatCurrency(totalPrice) + '</span>';
    if (savings > 0) html += '<span style="font-size:var(--text-xs);color:var(--success, #10b981);margin-left:var(--space-2);">Save ' + Utils.formatCurrency(savings) + '</span>';
    html += '</div><button class="btn btn-primary btn-sm" onclick="FBT.addAllToCart()">Add All to Cart</button></div></div>';
    container.innerHTML = html;
  },

  toggleItem(id, productId) {
    if (this.selected.has(id)) this.selected.delete(id);
    else this.selected.add(id);
    const container = document.querySelector('[data-fbt-container]');
    if (container) this._render(productId, container);
  },

  async addAllToCart() {
    const selected = this.items.filter(p => this.selected.has(p._id || p.id));
    for (const p of selected) await Cart.addItem(p._id || p.id, 1).catch(() => {});
    Toast.success(selected.length + ' items added to cart!');
  },
};

// ============================================
// Social Share
// ============================================
const SocialShare = {
  render(options = {}) {
    const url = options.url || window.location.href;
    const title = options.title || document.title;
    const target = typeof options.container === 'string' ? document.querySelector(options.container) : options.container;
    if (!target) return;
    const eu = encodeURIComponent(url);
    const et = encodeURIComponent(title);
    let html = '<div style="display:flex;gap:var(--space-2);align-items:center;">';
    html += '<span style="font-size:var(--text-sm);color:var(--text-muted);font-weight:var(--weight-medium);">Share:</span>';
    html += '<a href="https://www.facebook.com/sharer/sharer.php?u=' + eu + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on Facebook" style="width:36px;height:36px;border-radius:50%;background:#1877F2;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a>';
    html += '<a href="https://twitter.com/intent/tweet?url=' + eu + '&text=' + et + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on Twitter" style="width:36px;height:36px;border-radius:50%;background:#000;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="14" height="14" viewBox="0 0 24 24" fill="#fff"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>';
    html += '<a href="https://api.whatsapp.com/send?text=' + et + '%20' + eu + '" target="_blank" rel="noopener noreferrer" class="social-share-btn" title="Share on WhatsApp" style="width:36px;height:36px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>';
    html += '<button class="social-share-btn" title="Copy Link" onclick="Utils.copyToClipboard(\'' + url.replace(/'/g, "\\'") + '\')" style="width:36px;height:36px;border-radius:50%;background:var(--glass-bg, rgba(255,255,255,0.1));border:1px solid var(--glass-border, rgba(255,255,255,0.15));display:flex;align-items:center;justify-content:center;color:var(--text);cursor:pointer;transition:transform 0.2s;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg></button>';
    html += '</div>';
    target.innerHTML = html;
  },
};

// ── Products Listing Page Init ───────────────────────────────────────
function initProductListing() {
  var container = document.getElementById('productGridContainer');
  if (!container) return;

  var params = new URLSearchParams(window.location.hash.split('?')[1] || '');
  if (!params.get('category') && !params.get('q')) {
    params = new URLSearchParams(window.location.search);
  }
  var category = params.get('category');
  var search = params.get('q');
  var url = '/api/products';
  if (search) url = '/api/products/search?q=' + encodeURIComponent(search);
  else if (category) url = '/api/products?category_id=' + encodeURIComponent(category);

  container.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">Loading products...</div>';

  var token = localStorage.getItem('br_token');
  var headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = 'Bearer ' + token;

  fetch(url, { headers: headers })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      var products = data.data && data.data.products ? data.data.products : (Array.isArray(data.data) ? data.data : (data.products || data.data || []));
      if (!products.length) {
        container.innerHTML = '<div style="text-align:center;padding:60px 20px;"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1" style="margin-bottom:16px;"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg><h3 style="margin:0 0 8px;color:var(--text);">No products found</h3><p style="color:var(--text-muted);font-size:14px;">Try adjusting your filters or browse our categories.</p></div>';
        return;
      }
      container.innerHTML = '';
      container.style.display = 'grid';
      products.forEach(function (p) {
        var img = (p.images && p.images[0] && (p.images[0].url || p.images[0])) || p.image || p.thumbnail || 'https://placehold.co/400x400/1a1a1a/e6485a?text=Product';
        var name = p.name || 'Product';
        var price = p.price || 0;
        var compare = p.compare_price || p.comparePrice || 0;
        var rating = p.average_rating || p.rating || 0;
        var reviews = p.review_count || p.reviewCount || 0;
        var stock = p.stock_quantity !== undefined ? p.stock_quantity : (p.stockQuantity !== undefined ? p.stockQuantity : (p.stock !== undefined ? p.stock : -1));
        var card = document.createElement('div');
        card.className = 'product-card';
        card.style.cssText = 'background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-lg);overflow:hidden;transition:transform 0.2s,box-shadow 0.2s;cursor:pointer;position:relative;';
        card.onclick = function () { window.location.hash = '#product?id=' + p.id; };
        var badge = (stock === 0) ? '<div style="position:absolute;top:8px;left:8px;background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff;font-size:11px;font-weight:700;padding:3px 8px;border-radius:var(--radius-sm);z-index:2;">Stock Out</div>' : (compare > price ? '<div style="position:absolute;top:8px;left:8px;background:linear-gradient(135deg,#e6485a,#d4af37);color:#fff;font-size:11px;font-weight:700;padding:3px 8px;border-radius:var(--radius-sm);z-index:2;">-' + Math.round((1 - price/compare) * 100) + '%</div>' : '');
        var stars = '';
        for (var i = 1; i <= 5; i++) stars += '<svg width="12" height="12" viewBox="0 0 24 24" fill="' + (i <= Math.round(rating) ? '#f59e0b' : 'var(--border)') + '" stroke="#f59e0b" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
        card.innerHTML = badge +
          '<div style="position:relative;width:100%;padding-top:100%;background:var(--glass-bg,rgba(255,255,255,0.05));"><img src="' + img + '" alt="' + name.replace(/"/g,'&quot;') + '" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;" loading="lazy"></div>' +
          '<div style="padding:12px 14px 14px;"><p class="text-sm font-medium" style="color:var(--text);margin:0 0 4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.3;">' + name.replace(/</g,'&lt;') + '</p>' +
          '<div style="display:flex;align-items:center;gap:4px;margin-bottom:6px;">' + stars + '<span style="font-size:11px;color:var(--text-muted);margin-left:2px;">(' + reviews + ')</span></div>' +
          '<div style="display:flex;align-items:center;gap:6px;"><span style="font-size:15px;font-weight:700;color:var(--text);">\u09F3' + Number(price).toLocaleString() + '</span>' +
          (compare > price ? '<span style="font-size:12px;color:var(--text-muted);text-decoration:line-through;">\u09F3' + Number(compare).toLocaleString() + '</span>' : '') + '</div>' +
          '<button class="btn btn-primary btn-sm w-full" style="margin-top:10px;font-size:12px;" onclick="event.stopPropagation();(function(){ var pid=' + p.id + '; Cart.addItem(pid); })()">' + (stock === 0 ? 'Notify Me' : 'Add to Cart') + '</button></div>';
        container.appendChild(card);
      });
    })
    .catch(function () {
      container.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">Failed to load products. Please refresh the page.</div>';
    });
}

// ── Categories Page Init ─────────────────────────────────────────────
function initCategoryPage() {
  function buildTree(categories) {
    var tree = document.getElementById('categoryTree');
    if (!tree) return;
    tree.innerHTML = '<div class="category-tree-title">Browse Categories</div>';
    var allLink = document.createElement('a');
    allLink.href = '#categories';
    allLink.className = 'category-tree-item active';
    allLink.dataset.cat = 'all';
    allLink.innerHTML = '<span class="category-tree-item-left"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>All Categories</span><span class="category-tree-item-count">' + categories.length + '</span>';
    tree.appendChild(allLink);
    categories.forEach(function (cat) {
      var hasChildren = cat.children && cat.children.length;
      var item = document.createElement('div');
      item.className = 'category-tree-item';
      item.dataset.cat = cat.slug || cat.id;
      if (hasChildren) {
        item.onclick = function () { this.classList.toggle('expanded'); };
      } else {
        item.onclick = function () { window.location.hash = '#products?category=' + (cat.slug || cat.id); };
      }
      var left = document.createElement('span');
      left.className = 'category-tree-item-left';
      left.innerHTML = (cat.icon ? '<span>' + cat.icon + '</span> ' : '') + (cat.name || 'Category');
      if (hasChildren) {
        var chevron = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        chevron.setAttribute('class', 'category-tree-toggle');
        chevron.setAttribute('viewBox', '0 0 24 24');
        chevron.setAttribute('fill', 'none');
        chevron.setAttribute('stroke', 'currentColor');
        chevron.setAttribute('stroke-width', '2');
        chevron.innerHTML = '<path d="m9 18 6-6-6-6"/>';
        left.appendChild(chevron);
      }
      item.appendChild(left);
      var count = document.createElement('span');
      count.className = 'category-tree-item-count';
      count.textContent = cat.product_count || cat.count || cat.children_count || 0;
      item.appendChild(count);
      tree.appendChild(item);
      if (hasChildren) {
        var childContainer = document.createElement('div');
        childContainer.className = 'category-tree-children';
        cat.children.forEach(function (child) {
          var a = document.createElement('a');
          a.href = '#products?category=' + (cat.slug || cat.id) + (child.slug ? '&sub=' + child.slug : '');
          a.className = 'category-tree-item';
          a.innerHTML = '<span class="category-tree-item-left">' + (child.name || '') + '</span><span class="category-tree-item-count">' + (child.product_count || child.count || 0) + '</span>';
          childContainer.appendChild(a);
        });
        tree.appendChild(childContainer);
      }
    });
  }

  function buildGrid(categories) {
    var grid = document.getElementById('subcategoryGrid');
    if (!grid) return;
    grid.innerHTML = '';
    var countEl = document.getElementById('categoryCount');
    var catParam = (new URLSearchParams(window.location.hash.split('?')[1] || '')).get('cat') || (new URLSearchParams(window.location.search)).get('cat');
    var items = [];
    categories.forEach(function (cat) {
      if (catParam && String(cat.slug || cat.id) !== String(catParam)) return;
      if (cat.children && cat.children.length) {
        cat.children.forEach(function (child) {
          items.push({ parent: cat, child: child });
        });
      } else {
        items.push({ parent: null, child: cat });
      }
    });
    if (countEl) countEl.innerHTML = 'Showing <strong>' + items.length + '</strong> subcategories';
    items.forEach(function (item) {
      var child = item.child;
      var cat = item.parent || child;
      var img = child.image || cat.image || 'https://placehold.co/400x300/1a1a1a/dc143c?text=' + encodeURIComponent(child.name || 'C');
      var card = document.createElement('a');
      card.className = 'subcategory-card card-hover';
      card.href = '#products?category=' + (cat.slug || cat.id) + (item.parent ? '&sub=' + (child.slug || child.id) : '');
      card.innerHTML = '<div class="subcategory-card-image"><img src="' + img + '" alt="' + (child.name || '').replace(/"/g,'&quot;') + '" loading="lazy"></div><div class="subcategory-card-body"><div class="subcategory-card-title">' + (child.name || '').replace(/</g,'&lt;') + '</div><div class="subcategory-card-count">' + (child.product_count || child.count || 0) + ' products</div></div>';
      grid.appendChild(card);
    });
    if (typeof gsap !== 'undefined') {
      gsap.from('.subcategory-card', { y: 30, opacity: 0, duration: 0.5, stagger: 0.06, ease: 'power3.out', delay: 0.2 });
    }
  }

  var catParam = (new URLSearchParams(window.location.hash.split('?')[1] || '')).get('cat') || (new URLSearchParams(window.location.search)).get('cat');
  var heroTitle = document.getElementById('categoryHeroTitle');
  if (heroTitle && catParam) heroTitle.textContent = catParam.charAt(0).toUpperCase() + catParam.slice(1) + ' Category';

  fetch('/api/categories')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      var cats = data.data || data.categories || data || [];
      if (Array.isArray(cats)) {
        buildTree(cats);
        buildGrid(cats);
        if (catParam) {
          document.querySelectorAll('.category-tree-item').forEach(function (item) {
            if (item.dataset.cat === catParam) item.classList.add('active');
          });
        }
      }
    })
    .catch(function () {
      var grid = document.getElementById('subcategoryGrid');
      if (grid) grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">Failed to load categories. Please try again later.</p>';
    });

  // Mobile filter sheet
  var mobileFilterToggle = document.getElementById('mobileFilterToggle');
  var filterSheet = document.getElementById('filterSheet');
  var filterSheetOverlay = document.getElementById('filterSheetOverlay');
  if (mobileFilterToggle && filterSheet && filterSheetOverlay) {
    mobileFilterToggle.addEventListener('click', function () {
      var tree = document.getElementById('categoryTree');
      var mobileTree = document.getElementById('mobileCategoryTree');
      if (tree && mobileTree) {
        mobileTree.innerHTML = tree.innerHTML;
        mobileTree.querySelectorAll('.category-tree-item[onclick]').forEach(function (el) {
          el.onclick = function () { this.classList.toggle('expanded'); };
        });
      }
      filterSheet.classList.add('active');
      filterSheetOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
    filterSheetOverlay.addEventListener('click', function () {
      filterSheet.classList.remove('active');
      filterSheetOverlay.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  // Sort
  var sortSelect = document.getElementById('categorySort');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      var grid = document.getElementById('subcategoryGrid');
      if (!grid) return;
      var cards = Array.from(grid.children);
      cards.sort(function (a, b) {
        if (sortSelect.value === 'alpha') return a.querySelector('.subcategory-card-title').textContent.localeCompare(b.querySelector('.subcategory-card-title').textContent);
        if (sortSelect.value === 'count-high') {
          var getNum = function (el) { return parseInt(el.querySelector('.subcategory-card-count').textContent); };
          return getNum(b) - getNum(a);
        }
        return 0;
      });
      cards.forEach(function (card) { grid.appendChild(card); });
    });
  }
}

// ── Delivery charge calculator (mirrors backend) ─────────────────────
function calcDeliveryCharge(subtotal, district) {
  var insideDhaka = district && district.toLowerCase().indexOf('dhaka') > -1;
  if (insideDhaka) {
    if (subtotal <= 3000) return 100;
    if (subtotal <= 6000) return 120;
    return 120 + Math.ceil((subtotal - 6000) / 3000) * 20;
  }
  if (subtotal <= 3000) return 150;
  if (subtotal <= 7000) return 170;
  if (subtotal <= 12000) return 250;
  return 250 + Math.ceil((subtotal - 12000) / 5000) * 100;
}

// ── Checkout Page Init ───────────────────────────────────────────────
function initCheckout() {
  var container = document.getElementById('page-checkout');
  if (!container) return;

  // Render cart items from Cart module
  var items = Cart.items || [];
  var itemsContainer = container.querySelector('.flex.flex-col.gap-4');
  var summaryItems = container.querySelector('.cart-summary .flex.flex-col.gap-4');
  var subtotalRow = container.querySelector('.cart-summary-row:first-child span:last-child');
  var shippingRow = container.querySelector('.cart-summary-row:nth-child(2)');
  var taxRow = container.querySelector('.cart-summary-row:nth-child(3)');
  var totalRow = container.querySelector('.cart-summary-total span:last-child');
  var shippingDisplay = container.querySelector('#step-shipping-method .payment-method-desc');

  function updateSummary(district) {
    var subtotal = items.reduce(function (s, i) { return s + (i.price || 0) * (i.quantity || 1); }, 0);
    var deliveryCharge = calcDeliveryCharge(subtotal, district);
    var serviceCharge = 5;
    var total = subtotal + deliveryCharge + serviceCharge;

    if (subtotalRow) subtotalRow.textContent = '\u09F3' + subtotal.toLocaleString();
    if (shippingRow) {
      var label = district && district.toLowerCase().indexOf('dhaka') > -1 ? 'Inside Dhaka' : 'Outside Dhaka';
      shippingRow.innerHTML = '<span>Shipping <span style="font-size:var(--text-xs);color:var(--text-muted)">(' + label + ')</span></span><span style="font-weight:var(--weight-medium);color:var(--text);">\u09F3' + deliveryCharge.toLocaleString() + '</span>';
    }
    if (taxRow) taxRow.innerHTML = '<span>Service Charge</span><span style="color:var(--text);">\u09F3' + serviceCharge.toLocaleString() + '</span>';
    if (totalRow) totalRow.textContent = '\u09F3' + total.toLocaleString();
    if (shippingDisplay) {
      shippingDisplay.textContent = '3-5 business days \u2014 \u09F3' + deliveryCharge.toLocaleString() + ' (' + (district && district.toLowerCase().indexOf('dhaka') > -1 ? 'Inside Dhaka' : 'Outside Dhaka') + ')';
    }
  }

  // Render item rows
  if (items.length > 0 && itemsContainer) {
    var itemHtml = items.map(function (item) {
      var name = item.name || item.product?.name || 'Product';
      var qty = item.quantity || 1;
      var price = item.price || item.product?.price || 0;
      var img = item.image || item.product?.images?.[0] || 'https://placehold.co/60x60/1a1a1a/e6485a?text=Item';
      var variant = item.variantId ? 'Variant' : '';
      return '<div class="flex items-center gap-4"><img src="' + img + '" alt="' + name + '" style="width:60px;height:60px;border-radius:var(--radius-md);object-fit:cover;flex-shrink:0;"><div class="flex-1"><p class="text-sm font-semibold" style="color:var(--text);margin:0;">' + name + '</p><p class="text-xs text-muted" style="margin:2px 0 0;">' + (variant ? variant + ' \u00D7 ' + qty : '\u00D7 ' + qty) + '</p></div><span class="text-sm font-semibold" style="color:var(--text);">\u09F3' + (price * qty).toLocaleString() + '</span></div>';
    }).join('');
    itemsContainer.innerHTML = itemHtml;
  }
  if (summaryItems) {
    var sumHtml = items.map(function (item) {
      var name = item.name || item.product?.name || 'Product';
      var qty = item.quantity || 1;
      var price = item.price || item.product?.price || 0;
      var img = item.image || item.product?.images?.[0] || 'https://placehold.co/48x48/1a1a1a/e6485a?text=Item';
      return '<div class="flex items-center gap-3"><img src="' + img + '" alt="' + name + '" style="width:48px;height:48px;border-radius:var(--radius-sm);object-fit:cover;flex-shrink:0;"><div class="flex-1 min-w-0"><p class="text-xs font-semibold truncate" style="color:var(--text);margin:0;">' + name + '</p><p class="text-xs text-muted" style="margin:0;">\u00D7 ' + qty + '</p></div><span class="text-xs font-semibold" style="color:var(--text);">\u09F3' + (price * qty).toLocaleString() + '</span></div>';
    }).join('');
    summaryItems.innerHTML = sumHtml;
  }

  // Update summary on district change
  var districtSelect = document.getElementById('checkout-district') || container.querySelector('select[id*="district"], select[aria-label*="District"]');
  if (districtSelect) {
    if (districtSelect.value) updateSummary(districtSelect.value);
    districtSelect.addEventListener('change', function () { updateSummary(this.value); });
  } else {
    updateSummary('');
  }

  // Wire up district->delivery charge in cart.routes / orders.routes already handle backend
  // Set up payment method selection
  container.querySelectorAll('.payment-method').forEach(function (m) {
    m.addEventListener('click', function () {
      container.querySelectorAll('.payment-method').forEach(function (p) { p.classList.remove('active'); });
      this.classList.add('active');
    });
  });

  // Shipping method selection
  container.querySelectorAll('#step-shipping-method .payment-method').forEach(function (m) {
    m.addEventListener('click', function () {
      container.querySelectorAll('#step-shipping-method .payment-method').forEach(function (p) { p.classList.remove('active'); });
      this.classList.add('active');
    });
  });
}

function submitOrder() {
  var btn = document.getElementById('placeOrderBtn');
  var text = document.getElementById('placeOrderText');
  var errEl = document.getElementById('checkoutError');
  if (!errEl) return;
  errEl.style.display = 'none';

  var name = document.getElementById('checkout-name')?.value?.trim();
  var phone = document.getElementById('checkout-phone')?.value?.trim();
  var email = document.getElementById('checkout-email')?.value?.trim();
  var division = document.getElementById('checkout-division')?.value;
  var district = document.getElementById('checkout-district')?.value;
  var upazila = document.getElementById('checkout-upazila')?.value;
  var addressLine1 = document.getElementById('checkout-address')?.value?.trim() || document.querySelector('[placeholder*="House"]')?.value?.trim();
  var union = document.getElementById('checkout-union')?.value?.trim();

  if (!name || !phone || !division || !district || !addressLine1) {
    errEl.textContent = 'Please fill in all required fields (Name, Phone, Division, District, Address).';
    errEl.style.display = 'block';
    return;
  }

  var paymentMethod = 'cod';
  var methods = document.querySelectorAll('.payment-methods .payment-method');
  methods.forEach(function (m, idx) {
    if (m.classList.contains('active')) {
      var names = ['cod', 'bkash', 'nagad', 'rocket', 'sslcommerz', 'stripe'];
      paymentMethod = names[idx] || 'cod';
    }
  });

  var shippingAddress = {
    name: name,
    phone: phone,
    address: addressLine1,
    city: district,
    division: division,
    district: district,
    upazila: upazila || '',
    union: union || '',
    postal_code: '',
  };

  btn.disabled = true;
  text.textContent = 'Placing Order...';

  var token = localStorage.getItem('br_token');
  var headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = 'Bearer ' + token;

  fetch('/api/orders', {
    method: 'POST',
    headers: headers,
    body: JSON.stringify({
      shipping_address: shippingAddress,
      payment_method: paymentMethod,
      notes: '',
    }),
  }).then(function (r) { return r.json(); }).then(function (data) {
    if (data.success && data.data && data.data.order) {
      window.location.hash = '#order-success?order=' + encodeURIComponent(data.data.order.order_number || data.data.order.id);
    } else {
      errEl.textContent = data.message || 'Failed to place order. Please try again.';
      errEl.style.display = 'block';
      btn.disabled = false;
      text.textContent = 'Place Order';
    }
  }).catch(function () {
    errEl.textContent = 'Network error. Please check your connection.';
    errEl.style.display = 'block';
    btn.disabled = false;
    text.textContent = 'Place Order';
  });
}

// ── Product Detail Page Init ──────────────────────────────────────────
function initProductDetail() {
  var hash = window.location.hash;
  var qIdx = hash.indexOf('?');
  var params = qIdx > -1 ? new URLSearchParams(hash.substring(qIdx)) : new URLSearchParams();
  var id = params.get('id');
  if (!id) { id = new URLSearchParams(window.location.search).get('id'); }
  if (!id) return;

  var container = document.getElementById('page-product');
  if (!container) return;

  fetch('/api/products/' + id).then(function (r) { return r.json(); }).then(function (json) {
    if (!json.success || !json.data || !json.data.product) return;
    var p = json.data.product;
    var images = p.images || [];
    var thumbUrl = (images.find(function (i) { return i.is_primary; }) || images[0] || {}).url || p.thumbnail || 'https://placehold.co/800x800/1a1a1a/e6485a?text=Product';

    document.title = (p.name || 'Product') + ' | Bangalirhaat';

    var mainImg = document.getElementById('main-product-img');
    if (mainImg) { mainImg.src = thumbUrl; mainImg.alt = p.name; }

    var thumbContainer = container.querySelector('.product-gallery-thumbnails');
    if (thumbContainer && images.length > 1) {
      thumbContainer.innerHTML = images.map(function (img, i) {
        return '<button class="product-gallery-thumb' + (i === 0 ? ' active' : '') + '" role="option" aria-selected="' + (i === 0) + '"><img src="' + (img.url || thumbUrl) + '" alt="' + (img.alt_text || p.name) + '"></button>';
      }).join('');
      thumbContainer.querySelectorAll('.product-gallery-thumb').forEach(function (btn, idx) {
        btn.addEventListener('click', function () {
          thumbContainer.querySelectorAll('.product-gallery-thumb').forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          if (mainImg && images[idx]) mainImg.src = images[idx].url;
        });
      });
    }

    var brand = container.querySelector('.product-info-brand');
    if (brand) brand.textContent = p.brand_name || 'Bangalirhaat';
    var title = container.querySelector('.product-info-title');
    if (title) title.textContent = p.name;

    var ratingStars = container.querySelector('.product-info-rating .star-rating');
    if (ratingStars) {
      var avg = p.average_rating || p.review_count || 0;
      var rating = p.average_rating || 0;
      var stars = '';
      for (var s = 1; s <= 5; s++) stars += '<span class="star' + (s <= Math.round(rating) ? ' filled' : '') + '">&#9733;</span>';
      ratingStars.innerHTML = stars;
    }
    var ratingText = container.querySelector('.product-info-rating .text-sm.text-secondary');
    if (ratingText) ratingText.textContent = (p.average_rating || 0).toFixed(1);
    var reviewLink = container.querySelector('.product-info-rating a');
    if (reviewLink) reviewLink.textContent = (p.review_count || 0) + ' Reviews';

    var priceCurrent = container.querySelector('.product-info-price-current');
    if (priceCurrent) priceCurrent.textContent = '\u09F3' + Number(p.price).toLocaleString();
    var priceOrig = container.querySelector('.product-info-price-original');
    if (priceOrig) {
      if (p.compare_price && p.compare_price > p.price) {
        priceOrig.textContent = '\u09F3' + Number(p.compare_price).toLocaleString();
        priceOrig.style.display = '';
      } else { priceOrig.style.display = 'none'; }
    }
    var priceDisc = container.querySelector('.product-info-price-discount');
    if (priceDisc) {
      if (p.compare_price && p.compare_price > p.price) {
        var disc = Math.round((1 - p.price / p.compare_price) * 100);
        priceDisc.textContent = 'Save ' + disc + '%';
        priceDisc.style.display = '';
      } else { priceDisc.style.display = 'none'; }
    }

    var skuEl = container.querySelector('.product-info-price + .flex span:first-child strong');
    if (skuEl) skuEl.textContent = p.sku || 'N/A';

    var desc = container.querySelector('.product-info-description');
    if (desc) desc.textContent = p.description || '';

    var stockQty = p.stock_quantity !== undefined ? p.stock_quantity : (p.stock || 0);
    var outOfStock = stockQty <= 0;
    var stockBadge = container.querySelector('.flex.items-center.gap-2 .badge');
    var stockText = container.querySelector('.flex.items-center.gap-2 .text-xs');
    var addBtn = container.querySelector('.product-add-row .btn-primary');
    if (stockBadge) {
      stockBadge.className = 'badge ' + (outOfStock ? 'badge-danger' : 'badge-success') + ' badge-dot';
      stockBadge.textContent = outOfStock ? 'Out of Stock' : 'In Stock';
    }
    if (stockText) {
      if (outOfStock) stockText.textContent = 'This product is currently unavailable';
      else stockText.textContent = stockQty > 0 && stockQty <= 20 ? 'Only ' + stockQty + ' left — order soon!' : '';
    }
    if (addBtn && outOfStock) {
      addBtn.disabled = true;
      addBtn.className = 'btn btn-lg flex-1';
      addBtn.style.cssText = 'background:var(--muted,#e2e8f0);color:var(--text-muted,#94a3b8);cursor:not-allowed;border:none;opacity:0.7;';
      addBtn.innerHTML = 'Out of Stock';
    }
    var galleryMain = container.querySelector('.product-gallery-main');
    if (galleryMain && outOfStock) {
      galleryMain.style.position = 'relative';
      var obadge = document.createElement('div');
      obadge.className = 'product-detail-stockout-badge';
      obadge.innerHTML = '<span>Stock Out</span>';
      galleryMain.appendChild(obadge);
      if (mainImg) mainImg.style.opacity = '0.5';
    }

    var colorLabel = container.querySelector('.color-selector-label span');
    if (p.variants && p.variants.length > 0) {
      var colors = [];
      p.variants.forEach(function (v) { if (v.color && colors.indexOf(v.color) < 0) colors.push(v.color); });
      if (colors.length > 0 && colorLabel) colorLabel.textContent = colors[0];
    }

    var stickyPrice = container.querySelector('.product-sticky-bar .price span');
    if (stickyPrice) stickyPrice.textContent = '\u09F3' + Number(p.price).toLocaleString();

    // ── Quantity selector ──
    container.querySelectorAll('.quantity-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var val = container.querySelector('.quantity-value');
        if (!val) return;
        var q = parseInt(val.textContent) || 1;
        if (btn.textContent.trim() === '+') {
          q = Math.min(q + 1, 99);
        } else {
          q = Math.max(1, q - 1);
        }
        val.textContent = q;
      });
    });

    // ── Color selector ──
    container.querySelectorAll('.color-option').forEach(function (opt) {
      opt.addEventListener('click', function () {
        container.querySelectorAll('.color-option').forEach(function (o) { o.classList.remove('active'); o.setAttribute('aria-pressed', 'false'); });
        this.classList.add('active');
        this.setAttribute('aria-pressed', 'true');
        if (colorLabel) colorLabel.textContent = this.getAttribute('aria-label') || '';
      });
    });

    // ── Wishlist button ──
    var wishlistBtn = container.querySelector('.btn-outline svg[viewBox*="12 2v20"]') ? container.querySelector('.btn-outline svg[viewBox*="12 2v20"]').closest('button') : null;
    if (!wishlistBtn) {
      container.querySelectorAll('.btn-outline').forEach(function (b) {
        if (b.innerHTML.indexOf('Wishlist') > -1 || b.innerHTML.indexOf('12 2v20') > -1) wishlistBtn = b;
      });
    }
    if (wishlistBtn && p.id) {
      var isFav = Wishlist.items.some(function (i) { return String(i.product_id || i.productId || i.id || i) === String(p.id); });
      wishlistBtn.innerHTML = (isFav ? '❤️' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>') + ' ' + (isFav ? 'In Wishlist' : 'Wishlist');
      wishlistBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (isFav) {
          Wishlist.remove(p.id).then(function () {
            isFav = false;
            wishlistBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg> Wishlist';
            Toast.info('Removed from wishlist');
          });
        } else {
          Wishlist.add(p.id).then(function () {
            isFav = true;
            wishlistBtn.innerHTML = '❤️ In Wishlist';
            Toast.success('Added to wishlist');
          });
        }
      });
    }

    // ── Blouse option ──
    var blouseOption = document.getElementById('blouseOption');
    var blouseBtn = document.getElementById('blouseToggleBtn');
    if (blouseOption && blouseBtn) {
      var catName = (p.category_name || p.category || '').toLowerCase();
      var prodName = (p.name || '').toLowerCase();
      if (catName.indexOf('saree') > -1 || catName.indexOf('shari') > -1 || catName.indexOf('sharee') > -1 || prodName.indexOf('saree') > -1 || prodName.indexOf('shari') > -1) {
        blouseOption.style.display = '';
      }
      blouseBtn._selected = false;
      blouseBtn.addEventListener('click', function () {
        this._selected = !this._selected;
        this.classList.toggle('active', this._selected);
        this.textContent = this._selected ? '✓ Blouse Added (৳100)' : '+ Add Blouse (৳100)';
        this.setAttribute('aria-checked', this._selected);
      });
    }

    // ── Make Offer button ──
    var offerBtn = document.getElementById('makeOfferBtn');
    if (offerBtn && p.id) {
      offerBtn.addEventListener('click', function (e) {
        e.preventDefault();
        var token = localStorage.getItem('token') || localStorage.getItem('adminToken');
        if (!token) { alert('Please login to make an offer'); window.location.hash = '#login'; return; }
        var modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.innerHTML = '<div class="modal modal-sm"><div class="modal-header"><h3>Make an Offer \u2014 \u09A6\u09B0\u0995\u09B7\u0995\u09B7\u09BF</h3><button class="modal-close" onclick="this.closest(\'.modal-overlay\').remove()">&times;</button></div><div class="modal-body"><p style="font-size:var(--text-sm);color:var(--text-muted);margin-bottom:var(--space-4);">Current price: <strong style="color:var(--text);">\u09F3' + Number(p.price).toLocaleString() + '</strong></p><div class="form-group" style="margin-bottom:var(--space-3);"><label class="form-label">Your Offer Price (\u09F3)</label><input class="form-input" type="number" id="offerPrice" min="1" step="0.01" placeholder="Enter your price" style="font-size:var(--text-lg);font-weight:var(--weight-bold);"></div><div class="form-group" style="margin-bottom:var(--space-4);"><label class="form-label">Note (optional)</label><textarea class="form-input" id="offerNote" rows="2" placeholder="Add a note for the seller..."></textarea></div><div style="font-size:var(--text-xs);color:var(--text-muted);margin-bottom:var(--space-4);">Your offer will be reviewed by the seller within 24 hours.</div><button class="btn btn-primary w-full" id="submitOfferBtn">Submit Offer</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function (ev) { if (ev.target === modal) modal.remove(); });
        document.getElementById('submitOfferBtn').addEventListener('click', async function () {
          var price = parseFloat(document.getElementById('offerPrice').value);
          var note = document.getElementById('offerNote').value;
          if (!price || price <= 0) { alert('Please enter a valid offer price'); return; }
          if (price >= p.price) { alert('Your offer must be lower than \u09F3' + Number(p.price).toLocaleString()); return; }
          this.disabled = true; this.textContent = 'Submitting...';
          try {
            var r = await fetch('/api/bargaining/offers', {
              method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
              body: JSON.stringify({ product_id: p.id, offered_price: price, buyer_note: note })
            });
            var j = await r.json();
            if (j.success) { modal.remove(); alert('\u2705 ' + j.message); }
            else { alert('\u274C ' + (j.message || 'Failed to submit offer')); this.disabled = false; this.textContent = 'Submit Offer'; }
          } catch (e) { alert('Error submitting offer'); this.disabled = false; this.textContent = 'Submit Offer'; }
        });
      });
    }

    // ── Add to Cart (blouse-aware) ──
    function handleAddToCart(qtyEl) {
      var qty = 1;
      if (qtyEl) qty = parseInt(qtyEl.textContent) || 1;
      var qtyFromSelector = container.querySelector('.quantity-value');
      if (qtyFromSelector) qty = parseInt(qtyFromSelector.textContent) || 1;
      Cart.addItem(p.id || p._id, qty);
      if (blouseBtn && blouseBtn._selected) {
        // Add blouse addon as separate cart item
        if (!Auth.isAuthenticated()) {
          var local = JSON.parse(localStorage.getItem('br_guest_cart') || '[]');
          local.push({
            productId: 'blouse_' + (p.id || p._id),
            variantId: null,
            quantity: qty,
            price: 100,
            name: 'Blouse for ' + p.name,
            image: thumbUrl
          });
          localStorage.setItem('br_guest_cart', JSON.stringify(local));
          Cart.items = local;
          Cart.count = local.reduce(function (s, i) { return s + i.quantity; }, 0);
          Cart.total = local.reduce(function (s, i) { return s + (i.price || 0) * i.quantity; }, 0);
          Cart._updateUI();
          Toast.success('Blouse added to cart!');
        } else {
          Toast.info('Blouse addon is only available for guest checkout currently.');
        }
      }
    }

    var addCartBtns = container.querySelectorAll('.product-add-row .btn-primary, .product-sticky-bar .btn-primary');
    addCartBtns.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        if (outOfStock) return;
        handleAddToCart();
      });
    });
  }).catch(function (e) { console.error('Product detail init failed:', e); });
}

// ── Global Newsletter Handler ──────────────────────────────────────────
document.addEventListener('click', function (e) {
  var btn = e.target.closest('button');
  if (!btn) return;
  var section = btn.closest('[aria-label="Newsletter signup"]') || btn.closest('section');
  if (!section) return;
  if (btn.textContent.trim() !== 'Subscribe') return;
  var input = section.querySelector('input[type="email"]');
  if (!input || !input.value.trim()) { alert('Please enter your email address.'); return; }
  var email = input.value.trim();
  var origHTML = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = 'Subscribing...';
  fetch('/api/newsletter/subscribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: email }),
  }).then(function (r) { return r.json(); }).then(function (data) {
    if (data.success) {
      btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:-2px;margin-right:4px;"><polyline points="20,6 9,17 4,12"/></svg> Subscribed';
      input.value = '';
      setTimeout(function () { btn.innerHTML = origHTML; btn.disabled = false; }, 3000);
    } else {
      alert(data.message || 'Subscription failed.');
      btn.innerHTML = origHTML;
      btn.disabled = false;
    }
  }).catch(function () {
    alert('Network error. Please try again.');
    btn.innerHTML = origHTML;
    btn.disabled = false;
  });
});
