import express from 'express';
import { body, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// POST /api/whatsapp/send-order — Generate WhatsApp order link
router.post('/send-order', [
  body('product_name').notEmpty().withMessage('Product name required'),
  body('price').optional().isNumeric(),
  body('quantity').optional().isInt({ min: 1 }),
  body('message').optional().isString(),
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { product_name, price, quantity, message, phone } = req.body;
    const userPhone = phone || (req.user ? (req.user.phone || '') : '');

    const db = getDb();
    const settings = db.prepare("SELECT value FROM settings WHERE key = 'company_info'").get();
    const company = settings ? JSON.parse(settings.value) : {};
    const businessPhone = company.whatsapp_number || '8809612345678';

    let text = `Hi! I want to order: ${product_name}`;
    if (quantity) text += ` (Qty: ${quantity})`;
    if (price) text += ` - ৳${price}`;
    if (message) text += `\n\nNote: ${message}`;
    if (userPhone) text += `\n\nMy phone: ${userPhone}`;
    text += `\n\nFrom: Bangalirhaat`;

    const waLink = `https://wa.me/${businessPhone}?text=${encodeURIComponent(text)}`;

    res.json({
      success: true,
      data: {
        whatsapp_link: waLink,
        phone: businessPhone,
        message_preview: text,
      },
    });
  } catch (err) { next(err); }
});

// POST /api/whatsapp/notify — Send order notification to admin WhatsApp
router.post('/notify', authenticate, async (req, res, next) => {
  try {
    const { order_id, order_number, total, customer_name } = req.body;

    const db = getDb();
    const settings = db.prepare("SELECT value FROM settings WHERE key = 'company_info'").get();
    const company = settings ? JSON.parse(settings.value) : {};
    const businessPhone = company.whatsapp_number || '8809612345678';

    const text = `🛒 *New Order!*\n\nOrder: #${order_number}\nCustomer: ${customer_name}\nTotal: ৳${total}\n\nView: ${process.env.FRONTEND_URL || 'http://localhost:5000'}/admin/orders/${order_id}`;

    const waLink = `https://wa.me/${businessPhone}?text=${encodeURIComponent(text)}`;

    res.json({
      success: true,
      data: {
        whatsapp_link: waLink,
        message: 'WhatsApp notification link generated',
      },
    });
  } catch (err) { next(err); }
});

export default router;
