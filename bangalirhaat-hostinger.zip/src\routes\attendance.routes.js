import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import attendanceService from '../services/attendance.service.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

router.post('/checkin', authenticate, async (req, res) => {
  try {
    const result = await attendanceService.checkIn(req.user.id);
    res.status(201).json({ success: true, data: result, message: 'Checked in successfully' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/checkout', authenticate, async (req, res) => {
  try {
    const result = await attendanceService.checkOut(req.user.id);
    res.json({ success: true, data: result, message: 'Checked out successfully' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/', authenticate, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await attendanceService.getAttendance({ userId: req.user.id, startDate, endDate });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/all', adminAuth, async (req, res) => {
  try {
    const { date, page, limit } = req.query;
    const data = await attendanceService.getAllAttendance({
      date,
      page: page ? parseInt(page) : undefined,
      limit: limit ? parseInt(limit) : undefined,
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/:id', adminAuth, async (req, res) => {
  try {
    const { status, notes } = req.body;
    const data = await attendanceService.updateAttendance(req.params.id, { status, notes });
    res.json({ success: true, data, message: 'Attendance updated' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/stats', adminAuth, async (req, res) => {
  try {
    const { userId, month, year } = req.query;
    const data = await attendanceService.getAttendanceStats({
      userId: userId || undefined,
      month: month ? parseInt(month) : undefined,
      year: year ? parseInt(year) : undefined,
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/report', adminAuth, async (req, res) => {
  try {
    const { userId, month, year } = req.query;
    const data = await attendanceService.getMonthlyReport({
      userId: userId || undefined,
      month: month ? parseInt(month) : undefined,
      year: year ? parseInt(year) : undefined,
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
