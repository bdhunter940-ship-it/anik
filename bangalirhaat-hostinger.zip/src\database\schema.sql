-- ============================================================================
-- Bangalirhaat - Production Database Schema
-- Premium Bangladeshi E-Commerce Platform
-- Engine: SQLite 3.35+ (with JSON support)
-- Version: 1.0.0
-- ============================================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;

-- ============================================================================
-- USERS & AUTHENTICATION
-- ============================================================================

-- Stores all platform users: customers, staff, moderators, admins, super admins
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    email           TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    phone           TEXT    UNIQUE,
    password_hash   TEXT    NOT NULL,
    first_name      TEXT    NOT NULL DEFAULT '',
    last_name       TEXT    NOT NULL DEFAULT '',
    avatar          TEXT,
    role            TEXT    NOT NULL DEFAULT 'customer'
                        CHECK (role IN ('customer','staff','moderator','admin','super_admin')),
    is_active       INTEGER NOT NULL DEFAULT 1,
    email_verified  INTEGER NOT NULL DEFAULT 0,
    phone_verified  INTEGER NOT NULL DEFAULT 0,
    two_factor_enabled INTEGER NOT NULL DEFAULT 0,
    two_factor_secret  TEXT,
    referral_code   TEXT    UNIQUE,
    referred_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    loyalty_points  INTEGER NOT NULL DEFAULT 0 CHECK (loyalty_points >= 0),
    wallet_balance  REAL    NOT NULL DEFAULT 0.00 CHECK (wallet_balance >= 0),
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at      TEXT,
    is_vip INTEGER DEFAULT 0,
    is_blacklisted INTEGER DEFAULT 0,
    vip_since TEXT,
    blacklist_reason TEXT,
    total_orders INTEGER DEFAULT 0,
    total_spent REAL DEFAULT 0,
    last_order_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_users_email       ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone       ON users(phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_referral    ON users(referral_code) WHERE referral_code IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by) WHERE referred_by IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_role        ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_active      ON users(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_users_deleted     ON users(deleted_at) WHERE deleted_at IS NULL;

-- User shipping/billing addresses
CREATE TABLE IF NOT EXISTS user_addresses (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label         TEXT    NOT NULL DEFAULT 'home',
    full_name     TEXT    NOT NULL,
    phone         TEXT    NOT NULL,
    division      TEXT    NOT NULL,
    district      TEXT    NOT NULL,
    upazila       TEXT    NOT NULL,
    "union"       TEXT,
    address_line1 TEXT    NOT NULL,
    address_line2 TEXT,
    postal_code   TEXT,
    is_default    INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_user_addresses_user     ON user_addresses(user_id);
CREATE INDEX IF NOT EXISTS idx_user_addresses_default  ON user_addresses(user_id, is_default) WHERE is_default = 1;

-- JWT / session refresh tokens for persistent authentication
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token       TEXT    NOT NULL UNIQUE,
    user_agent  TEXT,
    ip_address  TEXT,
    expires_at  TEXT    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    revoked_at  TEXT
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user    ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_token   ON refresh_tokens(token);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_expiry  ON refresh_tokens(expires_at) WHERE revoked_at IS NULL;

-- One-time passwords for login, registration, reset, and verification flows
CREATE TABLE IF NOT EXISTS otp_codes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id) ON DELETE CASCADE,
    phone      TEXT,
    email      TEXT,
    code       TEXT    NOT NULL,
    type       TEXT    NOT NULL CHECK (type IN ('login','register','reset','verify')),
    expires_at TEXT    NOT NULL,
    used_at    TEXT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_otp_codes_user  ON otp_codes(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_otp_codes_phone ON otp_codes(phone) WHERE phone IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_otp_codes_email ON otp_codes(email) WHERE email IS NOT NULL;

-- ============================================================================
-- PRODUCT CATALOG
-- ============================================================================

-- Hierarchical product categories (unlimited depth via parent_id)
CREATE TABLE IF NOT EXISTS categories (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    name            TEXT    NOT NULL,
    slug            TEXT    NOT NULL UNIQUE,
    description     TEXT,
    image           TEXT,
    parent_id       INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    sort_order      INTEGER NOT NULL DEFAULT 0,
    is_active       INTEGER NOT NULL DEFAULT 1,
    meta_title      TEXT,
    meta_description TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at      TEXT
);

CREATE INDEX IF NOT EXISTS idx_categories_slug    ON categories(slug);
CREATE INDEX IF NOT EXISTS idx_categories_parent  ON categories(parent_id) WHERE parent_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_categories_active  ON categories(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_categories_sort    ON categories(sort_order);
CREATE INDEX IF NOT EXISTS idx_categories_deleted ON categories(deleted_at) WHERE deleted_at IS NULL;

-- Product brands (e.g., Nakshikantha, Jamdani House)
CREATE TABLE IF NOT EXISTS brands (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid        TEXT    NOT NULL UNIQUE,
    name        TEXT    NOT NULL,
    slug        TEXT    NOT NULL UNIQUE,
    logo        TEXT,
    description TEXT,
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at  TEXT
);

CREATE INDEX IF NOT EXISTS idx_brands_slug    ON brands(slug);
CREATE INDEX IF NOT EXISTS idx_brands_active  ON brands(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_brands_deleted ON brands(deleted_at) WHERE deleted_at IS NULL;

-- Core product catalog with pricing, inventory, and SEO metadata
CREATE TABLE IF NOT EXISTS products (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid              TEXT    NOT NULL UNIQUE,
    name              TEXT    NOT NULL,
    slug              TEXT    NOT NULL UNIQUE,
    description       TEXT,
    short_description TEXT,
    sku               TEXT    UNIQUE,
    barcode           TEXT    UNIQUE,
    brand_id          INTEGER REFERENCES brands(id) ON DELETE SET NULL,
    category_id       INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    price             REAL    NOT NULL CHECK (price >= 0),
    compare_price     REAL    CHECK (compare_price IS NULL OR compare_price >= 0),
    cost_price        REAL    CHECK (cost_price IS NULL OR cost_price >= 0),
    tax_rate          REAL    NOT NULL DEFAULT 0.00 CHECK (tax_rate >= 0 AND tax_rate <= 100),
    weight            REAL,
    dimensions        TEXT,
    stock_quantity    INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    low_stock_threshold INTEGER NOT NULL DEFAULT 5,
    track_stock       INTEGER NOT NULL DEFAULT 1,
    is_active         INTEGER NOT NULL DEFAULT 1,
    is_featured       INTEGER NOT NULL DEFAULT 0,
    is_digital        INTEGER NOT NULL DEFAULT 0,
    meta_title        TEXT,
    meta_description  TEXT,
    tags              TEXT, -- JSON array stored as text for SQLite
    total_sold        INTEGER NOT NULL DEFAULT 0 CHECK (total_sold >= 0),
    average_rating    REAL    NOT NULL DEFAULT 0.00 CHECK (average_rating >= 0 AND average_rating <= 5),
    review_count      INTEGER NOT NULL DEFAULT 0 CHECK (review_count >= 0),
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at        TEXT
);

CREATE INDEX IF NOT EXISTS idx_products_slug         ON products(slug);
CREATE INDEX IF NOT EXISTS idx_products_sku          ON products(sku) WHERE sku IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_products_barcode      ON products(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_products_brand        ON products(brand_id) WHERE brand_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_products_category     ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active       ON products(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_products_featured     ON products(is_featured) WHERE is_featured = 1;
CREATE INDEX IF NOT EXISTS idx_products_price        ON products(price);
CREATE INDEX IF NOT EXISTS idx_products_stock        ON products(stock_quantity);
CREATE INDEX IF NOT EXISTS idx_products_deleted      ON products(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_category_active ON products(category_id, is_active);
CREATE INDEX IF NOT EXISTS idx_products_created      ON products(created_at);

-- Product images with ordering and primary designation
CREATE TABLE IF NOT EXISTS product_images (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    url         TEXT    NOT NULL,
    alt_text    TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    is_primary  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_images_primary ON product_images(product_id, is_primary) WHERE is_primary = 1;
CREATE INDEX IF NOT EXISTS idx_product_images_sort    ON product_images(product_id, sort_order);

-- Variant options for products (color, size, material, etc.)
CREATE TABLE IF NOT EXISTS product_variants (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    sku             TEXT    NOT NULL UNIQUE,
    name            TEXT    NOT NULL,
    price           REAL    NOT NULL CHECK (price >= 0),
    compare_price   REAL    CHECK (compare_price IS NULL OR compare_price >= 0),
    stock_quantity  INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    color           TEXT,
    size            TEXT,
    material        TEXT,
    image           TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_product_variants_product ON product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_product_variants_sku     ON product_variants(sku);
CREATE INDEX IF NOT EXISTS idx_product_variants_active  ON product_variants(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_product_variants_color   ON product_variants(color) WHERE color IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_product_variants_size    ON product_variants(size) WHERE size IS NOT NULL;

-- Customer reviews with ratings (1-5), images, and verification status
CREATE TABLE IF NOT EXISTS product_reviews (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    order_id      INTEGER REFERENCES orders(id) ON DELETE SET NULL,
    rating        INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title         TEXT,
    comment       TEXT,
    images        TEXT, -- JSON array of image URLs
    is_verified   INTEGER NOT NULL DEFAULT 0,
    is_approved   INTEGER NOT NULL DEFAULT 0,
    helpful_count INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at    TEXT
);

CREATE INDEX IF NOT EXISTS idx_product_reviews_product  ON product_reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_product_reviews_user     ON product_reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_product_reviews_rating   ON product_reviews(product_id, rating);
CREATE INDEX IF NOT EXISTS idx_product_reviews_approved ON product_reviews(product_id, is_approved) WHERE is_approved = 1;
CREATE INDEX IF NOT EXISTS idx_product_reviews_deleted  ON product_reviews(deleted_at) WHERE deleted_at IS NULL;

-- Customer wishlist items
CREATE TABLE IF NOT EXISTS wishlists (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE(user_id, product_id)
);

CREATE INDEX IF NOT EXISTS idx_wishlists_user ON wishlists(user_id);

-- ============================================================================
-- DISCOUNTS & PROMOTIONS
-- ============================================================================

-- Coupons for percentage discounts, fixed amounts, and free shipping
CREATE TABLE IF NOT EXISTS coupons (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid              TEXT    NOT NULL UNIQUE,
    code              TEXT    NOT NULL UNIQUE,
    type              TEXT    NOT NULL CHECK (type IN ('percentage','fixed','free_shipping')),
    value             REAL    NOT NULL CHECK (value >= 0),
    minimum_order     REAL    NOT NULL DEFAULT 0.00 CHECK (minimum_order >= 0),
    maximum_discount  REAL    CHECK (maximum_discount IS NULL OR maximum_discount >= 0),
    usage_limit       INTEGER CHECK (usage_limit IS NULL OR usage_limit >= 0),
    used_count        INTEGER NOT NULL DEFAULT 0 CHECK (used_count >= 0),
    starts_at         TEXT,
    expires_at        TEXT,
    is_active         INTEGER NOT NULL DEFAULT 1,
    applies_to        TEXT    NOT NULL DEFAULT 'all'
                        CHECK (applies_to IN ('all','specific_categories','specific_products')),
    applies_to_ids    TEXT, -- JSON array of category/product IDs
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at        TEXT
);

CREATE INDEX IF NOT EXISTS idx_coupons_code       ON coupons(code);
CREATE INDEX IF NOT EXISTS idx_coupons_active     ON coupons(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_coupons_expiry     ON coupons(expires_at) WHERE expires_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_coupons_deleted    ON coupons(deleted_at) WHERE deleted_at IS NOT NULL;

-- Flash sales with time-bounded discount percentages
CREATE TABLE IF NOT EXISTS flash_sales (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id          INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    discount_percentage REAL    NOT NULL CHECK (discount_percentage > 0 AND discount_percentage <= 100),
    start_at            TEXT    NOT NULL,
    end_at              TEXT    NOT NULL,
    is_active           INTEGER NOT NULL DEFAULT 1,
    created_at          TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_flash_sales_product ON flash_sales(product_id);
CREATE INDEX IF NOT EXISTS idx_flash_sales_active  ON flash_sales(is_active, start_at, end_at);
CREATE INDEX IF NOT EXISTS idx_flash_sales_active_only ON flash_sales(is_active, product_id)
    WHERE is_active = 1;

-- ============================================================================
-- SHOPPING CART
-- ============================================================================

-- Shopping carts: one per user or session (for guests)
CREATE TABLE IF NOT EXISTS carts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    session_id      TEXT,
    coupon_id       INTEGER REFERENCES coupons(id) ON DELETE SET NULL,
    coupon_code     TEXT,
    coupon_discount REAL    DEFAULT 0,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_carts_user     ON carts(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_carts_session  ON carts(session_id) WHERE session_id IS NOT NULL;

-- Individual items within a shopping cart
CREATE TABLE IF NOT EXISTS cart_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    cart_id     INTEGER NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    variant_id  INTEGER REFERENCES product_variants(id) ON DELETE SET NULL,
    quantity    INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
    price       REAL    NOT NULL CHECK (price >= 0),
    total_price REAL    DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_cart_items_cart     ON cart_items(cart_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_product  ON cart_items(product_id);

-- ============================================================================
-- ORDERS & FULFILLMENT
-- ============================================================================

-- Customer orders with full financial breakdown and status tracking
CREATE TABLE IF NOT EXISTS orders (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid                TEXT    NOT NULL UNIQUE,
    user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    order_number        TEXT    NOT NULL UNIQUE,
    status              TEXT    NOT NULL DEFAULT 'pending'
                            CHECK (status IN (
                                'draft','pending','confirmed','packaging',
                                'ready_to_ship','courier_sent','in_transit',
                                'delivered','returned','cancelled','exchanged'
                            )),
    subtotal            REAL    NOT NULL DEFAULT 0.00 CHECK (subtotal >= 0),
    discount            REAL    NOT NULL DEFAULT 0.00 CHECK (discount >= 0),
    shipping_cost       REAL    NOT NULL DEFAULT 0.00 CHECK (shipping_cost >= 0),
    tax                 REAL    NOT NULL DEFAULT 0.00 CHECK (tax >= 0),
    total               REAL    NOT NULL DEFAULT 0.00 CHECK (total >= 0),
    currency            TEXT    NOT NULL DEFAULT 'BDT',
    payment_status      TEXT    NOT NULL DEFAULT 'pending'
                            CHECK (payment_status IN (
                                'pending','paid','partial','refunded','failed'
                            )),
    payment_method      TEXT,
    payment_reference   TEXT,
    shipping_address    TEXT, -- JSON snapshot of delivery address
    billing_address     TEXT, -- JSON snapshot of billing address
    notes               TEXT,
    internal_notes      TEXT,
    delivery_charge     REAL    DEFAULT 0,
    return_charge       REAL    DEFAULT 0,
    gift_card_id        TEXT    REFERENCES gift_cards(id),
    gift_card_amount    REAL    DEFAULT 0,
    courier_id          INTEGER REFERENCES couriers(id) ON DELETE SET NULL,
    consignment_id      TEXT,
    tracking_number     TEXT,
    shipped_at          TEXT,
    delivered_at        TEXT,
    created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at          TEXT
);

CREATE INDEX IF NOT EXISTS idx_orders_user          ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_order_number  ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_status        ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_payment       ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_created       ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_orders_courier       ON orders(courier_id) WHERE courier_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_orders_tracking      ON orders(tracking_number) WHERE tracking_number IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_orders_deleted       ON orders(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_orders_user_status   ON orders(user_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders(status, created_at);

-- Line items within each order
CREATE TABLE IF NOT EXISTS order_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    variant_id    INTEGER REFERENCES product_variants(id) ON DELETE SET NULL,
    product_name  TEXT    NOT NULL,
    product_sku   TEXT    NOT NULL,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    price         REAL    NOT NULL CHECK (price >= 0),
    discount      REAL    NOT NULL DEFAULT 0.00 CHECK (discount >= 0),
    tax           REAL    NOT NULL DEFAULT 0.00 CHECK (tax >= 0),
    total         REAL    NOT NULL CHECK (total >= 0),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_order_items_order    ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product  ON order_items(product_id);

-- Audit trail for order status changes
CREATE TABLE IF NOT EXISTS order_status_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    status      TEXT    NOT NULL,
    note        TEXT,
    changed_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_order_status_history_order ON order_status_history(order_id);

-- ============================================================================
-- PAYMENTS & REFUNDS
-- ============================================================================

-- Payment transactions linked to orders
CREATE TABLE IF NOT EXISTS payments (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id          INTEGER NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    method            TEXT    NOT NULL,
    amount            REAL    NOT NULL CHECK (amount > 0),
    currency          TEXT    NOT NULL DEFAULT 'BDT',
    transaction_id    TEXT,
    gateway_response  TEXT, -- JSON response from payment gateway
    status            TEXT    NOT NULL DEFAULT 'pending'
                          CHECK (status IN ('pending','completed','failed','refunded')),
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_payments_order     ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_txn       ON payments(transaction_id) WHERE transaction_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_payments_status    ON payments(status);

-- Refund requests and processing records
CREATE TABLE IF NOT EXISTS refunds (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    payment_id    INTEGER NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
    amount        REAL    NOT NULL CHECK (amount > 0),
    reason        TEXT,
    status        TEXT    NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','approved','rejected')),
    processed_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    processed_at  TEXT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_refunds_order   ON refunds(order_id);
CREATE INDEX IF NOT EXISTS idx_refunds_payment ON refunds(payment_id);
CREATE INDEX IF NOT EXISTS idx_refunds_status  ON refunds(status);

-- ============================================================================
-- COURIER & SHIPPING
-- ============================================================================

-- Supported courier services (e.g., Pathao, Paperfly, Sundarban)
CREATE TABLE IF NOT EXISTS couriers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    slug        TEXT    NOT NULL UNIQUE,
    api_key     TEXT,
    api_secret  TEXT,
    api_url     TEXT,
    config      TEXT, -- JSON: extra configuration (pickup address, etc.)
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_couriers_slug   ON couriers(slug);
CREATE INDEX IF NOT EXISTS idx_couriers_active ON couriers(is_active) WHERE is_active = 1;

-- Shipment tracking with status update history
CREATE TABLE IF NOT EXISTS shipments (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id            INTEGER NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
    courier_id          INTEGER NOT NULL REFERENCES couriers(id) ON DELETE RESTRICT,
    consignment_id      TEXT,
    tracking_number     TEXT,
    status              TEXT    NOT NULL DEFAULT 'pending',
    status_update       TEXT, -- JSON: array of {status, timestamp, location}
    estimated_delivery  TEXT,
    actual_delivery     TEXT,
    cost                REAL    NOT NULL DEFAULT 0.00 CHECK (cost >= 0),
    created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_shipments_order     ON shipments(order_id);
CREATE INDEX IF NOT EXISTS idx_shipments_courier   ON shipments(courier_id);
CREATE INDEX IF NOT EXISTS idx_shipments_tracking  ON shipments(tracking_number) WHERE tracking_number IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_shipments_consignment ON shipments(consignment_id) WHERE consignment_id IS NOT NULL;

-- ============================================================================
-- SUPPLIER & PURCHASE MANAGEMENT
-- ============================================================================

-- Supplier/vendor directory
CREATE TABLE IF NOT EXISTS suppliers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    name            TEXT    NOT NULL,
    contact_person  TEXT,
    email           TEXT,
    phone           TEXT,
    address         TEXT,
    notes           TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at      TEXT
);

CREATE INDEX IF NOT EXISTS idx_suppliers_active ON suppliers(is_active) WHERE is_active = 1;
CREATE INDEX IF NOT EXISTS idx_suppliers_deleted ON suppliers(deleted_at) WHERE deleted_at IS NULL;

-- Purchase orders from suppliers
CREATE TABLE IF NOT EXISTS purchases (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    supplier_id     INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
    invoice_number  TEXT,
    status          TEXT    NOT NULL DEFAULT 'draft'
                        CHECK (status IN ('draft','ordered','received','cancelled')),
    total           REAL    NOT NULL DEFAULT 0.00 CHECK (total >= 0),
    notes           TEXT,
    created_by      INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    received_at     TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);
CREATE INDEX IF NOT EXISTS idx_purchases_status   ON purchases(status);
CREATE INDEX IF NOT EXISTS idx_purchases_created  ON purchases(created_by);

-- Individual line items within a purchase order
CREATE TABLE IF NOT EXISTS purchase_items (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    purchase_id       INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
    product_id        INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    variant_id        INTEGER REFERENCES product_variants(id) ON DELETE SET NULL,
    quantity          INTEGER NOT NULL CHECK (quantity > 0),
    received_quantity INTEGER NOT NULL DEFAULT 0 CHECK (received_quantity >= 0),
    unit_cost         REAL    NOT NULL CHECK (unit_cost >= 0),
    total             REAL    NOT NULL CHECK (total >= 0),
    created_at        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase ON purchase_items(purchase_id);
CREATE INDEX IF NOT EXISTS idx_purchase_items_product  ON purchase_items(product_id);

-- ============================================================================
-- WAREHOUSE & INVENTORY MANAGEMENT
-- ============================================================================

-- Warehouse locations for stock tracking
CREATE TABLE IF NOT EXISTS warehouses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    address     TEXT,
    phone       TEXT,
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_warehouses_active ON warehouses(is_active) WHERE is_active = 1;

-- Inter-warehouse stock transfer records
CREATE TABLE IF NOT EXISTS stock_transfers (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    from_warehouse_id   INTEGER NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
    to_warehouse_id     INTEGER NOT NULL REFERENCES warehouses(id) ON DELETE RESTRICT,
    product_id          INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    quantity            INTEGER NOT NULL CHECK (quantity > 0),
    status              TEXT    NOT NULL DEFAULT 'pending'
                            CHECK (status IN ('pending','in_transit','received')),
    notes               TEXT,
    created_by          INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_stock_transfers_from     ON stock_transfers(from_warehouse_id);
CREATE INDEX IF NOT EXISTS idx_stock_transfers_to       ON stock_transfers(to_warehouse_id);
CREATE INDEX IF NOT EXISTS idx_stock_transfers_product  ON stock_transfers(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_transfers_status   ON stock_transfers(status);

-- ============================================================================
-- EXPENSES
-- ============================================================================

-- Business expense tracking
CREATE TABLE IF NOT EXISTS expenses (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    category      TEXT    NOT NULL,
    description   TEXT,
    amount        REAL    NOT NULL CHECK (amount > 0),
    date          TEXT    NOT NULL,
    receipt_image TEXT,
    approved_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_by    INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now')),
    deleted_at    TEXT
);

CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);
CREATE INDEX IF NOT EXISTS idx_expenses_date     ON expenses(date);
CREATE INDEX IF NOT EXISTS idx_expenses_created  ON expenses(created_by);
CREATE INDEX IF NOT EXISTS idx_expenses_deleted  ON expenses(deleted_at) WHERE deleted_at IS NULL;

-- ============================================================================
-- COUPON USAGE TRACKING
-- ============================================================================

-- Records every coupon redemption against a user and order
CREATE TABLE IF NOT EXISTS coupons_used (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    coupon_id   INTEGER NOT NULL REFERENCES coupons(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_coupons_used_coupon ON coupons_used(coupon_id);
CREATE INDEX IF NOT EXISTS idx_coupons_used_user   ON coupons_used(user_id);
CREATE INDEX IF NOT EXISTS idx_coupons_used_order  ON coupons_used(order_id);

-- ============================================================================
-- LOYALTY PROGRAM
-- ============================================================================

-- Points ledger for earning, redeeming, expiring, and adjusting loyalty points
CREATE TABLE IF NOT EXISTS loyalty_rewards (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    description TEXT,
    points_cost INTEGER NOT NULL DEFAULT 100,
    reward_type TEXT    NOT NULL CHECK (reward_type IN ('discount','free_shipping','gift_card','cashback','product')),
    reward_value REAL   NOT NULL DEFAULT 0,
    min_points  INTEGER DEFAULT 0,
    max_redeem  INTEGER DEFAULT 0,
    is_active   INTEGER DEFAULT 1,
    stock       INTEGER DEFAULT -1,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_loyalty_rewards_active ON loyalty_rewards(is_active);

-- ============================================================================
-- LOYALTY TRANSACTIONS
-- ============================================================================

CREATE TABLE IF NOT EXISTS loyalty_transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    points      INTEGER NOT NULL,
    type        TEXT    NOT NULL CHECK (type IN ('earned','redeemed','expired','adjusted')),
    reference   TEXT,
    description TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_loyalty_tx_user    ON loyalty_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_loyalty_tx_type    ON loyalty_transactions(type);
CREATE INDEX IF NOT EXISTS idx_loyalty_tx_created ON loyalty_transactions(created_at);

-- ============================================================================
-- NOTIFICATIONS
-- ============================================================================

-- In-app and system notifications per user
CREATE TABLE IF NOT EXISTS notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       TEXT    NOT NULL,
    message     TEXT    NOT NULL,
    type        TEXT    NOT NULL DEFAULT 'info',
    is_read     INTEGER NOT NULL DEFAULT 0,
    data        TEXT, -- JSON: extra payload (order_id, link, etc.)
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_notifications_user     ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread   ON notifications(user_id, is_read) WHERE is_read = 0;
CREATE INDEX IF NOT EXISTS idx_notifications_created  ON notifications(created_at);

-- ============================================================================
-- CMS & CONTENT
-- ============================================================================

-- Static/info pages (About Us, Shipping Policy, etc.)
CREATE TABLE IF NOT EXISTS pages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    title           TEXT    NOT NULL,
    slug            TEXT    NOT NULL UNIQUE,
    content         TEXT,
    meta_title      TEXT,
    meta_description TEXT,
    is_published    INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_pages_slug       ON pages(slug);
CREATE INDEX IF NOT EXISTS idx_pages_published  ON pages(is_published) WHERE is_published = 1;

-- Frequently asked questions
CREATE TABLE IF NOT EXISTS faqs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    question    TEXT    NOT NULL,
    answer      TEXT    NOT NULL,
    category    TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_faqs_category ON faqs(category);
CREATE INDEX IF NOT EXISTS idx_faqs_sort     ON faqs(sort_order);
CREATE INDEX IF NOT EXISTS idx_faqs_active   ON faqs(is_active) WHERE is_active = 1;

-- Contact form submissions
CREATE TABLE IF NOT EXISTS contact_messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    email       TEXT    NOT NULL,
    phone       TEXT,
    subject     TEXT,
    message     TEXT    NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'new'
                    CHECK (status IN ('new','read','replied')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_contact_status  ON contact_messages(status);
CREATE INDEX IF NOT EXISTS idx_contact_created ON contact_messages(created_at);

-- ============================================================================
-- MARKETING CAMPAIGNS
-- ============================================================================

-- Email, SMS, and push notification campaign definitions
CREATE TABLE IF NOT EXISTS campaigns (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name              TEXT    NOT NULL,
    type              TEXT    NOT NULL CHECK (type IN ('email','sms','push')),
    subject           TEXT,
    content           TEXT    NOT NULL,
    status            TEXT    NOT NULL DEFAULT 'draft'
                          CHECK (status IN ('draft','scheduled','sent','failed')),
    scheduled_at      TEXT,
    sent_at           TEXT,
    recipient_count   INTEGER NOT NULL DEFAULT 0 CHECK (recipient_count >= 0),
    created_at        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_campaigns_status    ON campaigns(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_type      ON campaigns(type);
CREATE INDEX IF NOT EXISTS idx_campaigns_scheduled ON campaigns(scheduled_at) WHERE scheduled_at IS NOT NULL;

-- ============================================================================
-- ANALYTICS
-- ============================================================================

-- Daily aggregated site metrics (visitors, orders, revenue)
CREATE TABLE IF NOT EXISTS analytics_daily (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    date        TEXT    NOT NULL UNIQUE,
    visitors    INTEGER NOT NULL DEFAULT 0 CHECK (visitors >= 0),
    page_views  INTEGER NOT NULL DEFAULT 0 CHECK (page_views >= 0),
    orders      INTEGER NOT NULL DEFAULT 0 CHECK (orders >= 0),
    revenue     REAL    NOT NULL DEFAULT 0.00 CHECK (revenue >= 0),
    new_users   INTEGER NOT NULL DEFAULT 0 CHECK (new_users >= 0),
    returns     INTEGER NOT NULL DEFAULT 0 CHECK (returns >= 0),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_analytics_date ON analytics_daily(date);

-- ============================================================================
-- SYSTEM & CONFIGURATION
-- ============================================================================

-- Key-value application settings (grouped for admin UI)
CREATE TABLE IF NOT EXISTS settings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT    NOT NULL UNIQUE,
    value       TEXT    NOT NULL, -- JSON value
    group_name  TEXT    NOT NULL DEFAULT 'general',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_settings_key   ON settings(key);
CREATE INDEX IF NOT EXISTS idx_settings_group ON settings(group_name);

-- ============================================================================
-- AUDIT & SECURITY
-- ============================================================================

-- Full audit trail for data changes across all entities
CREATE TABLE IF NOT EXISTS audit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action      TEXT    NOT NULL,
    entity      TEXT    NOT NULL,
    entity_id   INTEGER,
    old_value   TEXT, -- JSON: state before change
    new_value   TEXT, -- JSON: state after change
    ip_address  TEXT,
    user_agent  TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user     ON audit_logs(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity   ON audit_logs(entity, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action   ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created  ON audit_logs(created_at);

-- Login attempt history for security monitoring
CREATE TABLE IF NOT EXISTS login_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ip_address  TEXT,
    user_agent  TEXT,
    device_info TEXT, -- JSON: browser, OS, device type
    status      TEXT    NOT NULL CHECK (status IN ('success','failed')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_login_history_user    ON login_history(user_id);
CREATE INDEX IF NOT EXISTS idx_login_history_status  ON login_history(status);
CREATE INDEX IF NOT EXISTS idx_login_history_created ON login_history(created_at);

-- ============================================================================
-- TRIGGERS: Automatic updated_at timestamps
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS trg_users_updated_at
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    UPDATE users SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_user_addresses_updated_at
AFTER UPDATE ON user_addresses
FOR EACH ROW
BEGIN
    UPDATE user_addresses SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_categories_updated_at
AFTER UPDATE ON categories
FOR EACH ROW
BEGIN
    UPDATE categories SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_brands_updated_at
AFTER UPDATE ON brands
FOR EACH ROW
BEGIN
    UPDATE brands SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_products_updated_at
AFTER UPDATE ON products
FOR EACH ROW
BEGIN
    UPDATE products SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_product_variants_updated_at
AFTER UPDATE ON product_variants
FOR EACH ROW
BEGIN
    UPDATE product_variants SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_product_reviews_updated_at
AFTER UPDATE ON product_reviews
FOR EACH ROW
BEGIN
    UPDATE product_reviews SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_coupons_updated_at
AFTER UPDATE ON coupons
FOR EACH ROW
BEGIN
    UPDATE coupons SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_carts_updated_at
AFTER UPDATE ON carts
FOR EACH ROW
BEGIN
    UPDATE carts SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_cart_items_updated_at
AFTER UPDATE ON cart_items
FOR EACH ROW
BEGIN
    UPDATE cart_items SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_orders_updated_at
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    UPDATE orders SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_payments_updated_at
AFTER UPDATE ON payments
FOR EACH ROW
BEGIN
    UPDATE payments SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_couriers_updated_at
AFTER UPDATE ON couriers
FOR EACH ROW
BEGIN
    UPDATE couriers SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_shipments_updated_at
AFTER UPDATE ON shipments
FOR EACH ROW
BEGIN
    UPDATE shipments SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_suppliers_updated_at
AFTER UPDATE ON suppliers
FOR EACH ROW
BEGIN
    UPDATE suppliers SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_purchases_updated_at
AFTER UPDATE ON purchases
FOR EACH ROW
BEGIN
    UPDATE purchases SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_stock_transfers_updated_at
AFTER UPDATE ON stock_transfers
FOR EACH ROW
BEGIN
    UPDATE stock_transfers SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_expenses_updated_at
AFTER UPDATE ON expenses
FOR EACH ROW
BEGIN
    UPDATE expenses SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_pages_updated_at
AFTER UPDATE ON pages
FOR EACH ROW
BEGIN
    UPDATE pages SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_settings_updated_at
AFTER UPDATE ON settings
FOR EACH ROW
BEGIN
    UPDATE settings SET updated_at = datetime('now') WHERE id = OLD.id;
END;

-- ============================================================================
-- GIFT CARDS
-- ============================================================================

CREATE TABLE IF NOT EXISTS gift_cards (
  id TEXT PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  balance REAL NOT NULL DEFAULT 0,
  initial_amount REAL NOT NULL DEFAULT 0,
  purchaser_id TEXT REFERENCES users(id),
  recipient_email TEXT,
  recipient_name TEXT,
  message TEXT,
  status TEXT DEFAULT 'active' CHECK(status IN ('active','used','expired','cancelled')),
  expires_at TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_gift_cards_code ON gift_cards(code);
CREATE INDEX IF NOT EXISTS idx_gift_cards_status ON gift_cards(status);

CREATE TABLE IF NOT EXISTS gift_card_transactions (
  id TEXT PRIMARY KEY,
  gift_card_id TEXT NOT NULL REFERENCES gift_cards(id),
  amount REAL NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('purchase','redeem','refund')),
  order_id TEXT REFERENCES orders(id),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_gift_card_transactions_card ON gift_card_transactions(gift_card_id);

-- ============================================================================
-- BUNDLE OFFERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS bundle_offers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  discount_type TEXT DEFAULT 'percentage' CHECK(discount_type IN ('percentage','fixed')),
  discount_value REAL NOT NULL DEFAULT 0,
  min_quantity INTEGER DEFAULT 1,
  is_active INTEGER DEFAULT 1,
  starts_at TEXT,
  ends_at TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bundle_offer_products (
  id TEXT PRIMARY KEY,
  bundle_id TEXT NOT NULL REFERENCES bundle_offers(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity INTEGER DEFAULT 1,
  sort_order INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_bundle_products_bundle ON bundle_offer_products(bundle_id);
CREATE INDEX IF NOT EXISTS idx_bundle_products_product ON bundle_offer_products(product_id);

-- ============================================================================
-- RECENTLY VIEWED
-- ============================================================================

CREATE TABLE IF NOT EXISTS recently_viewed (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  session_id TEXT,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  viewed_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_recently_viewed_user ON recently_viewed(user_id);
CREATE INDEX IF NOT EXISTS idx_recently_viewed_session ON recently_viewed(session_id);
CREATE INDEX IF NOT EXISTS idx_recently_viewed_product ON recently_viewed(product_id);

-- ============================================================================
-- PRE-ORDERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS preorders (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  quantity INTEGER DEFAULT 1,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending','confirmed','fulfilled','cancelled')),
  expected_date TEXT,
  deposit_amount REAL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_preorders_product ON preorders(product_id);
CREATE INDEX IF NOT EXISTS idx_preorders_user ON preorders(user_id);
CREATE INDEX IF NOT EXISTS idx_preorders_status ON preorders(status);

-- ============================================================================
-- BACK IN STOCK NOTIFICATIONS
-- ============================================================================

CREATE TABLE IF NOT EXISTS back_in_stock_notifications (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id),
  email TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending','notified','cancelled')),
  notified_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_back_in_stock_product ON back_in_stock_notifications(product_id);
CREATE INDEX IF NOT EXISTS idx_back_in_stock_status ON back_in_stock_notifications(status);

-- ============================================================================
-- FREQUENTLY BOUGHT TOGETHER
-- ============================================================================

CREATE TABLE IF NOT EXISTS frequently_bought_together (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  related_product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  frequency INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_fbt_product ON frequently_bought_together(product_id);

-- ============================================================================
-- CUSTOMER SESSIONS & ANALYTICS
-- ============================================================================

CREATE TABLE IF NOT EXISTS customer_sessions (
  id TEXT PRIMARY KEY,
  session_id TEXT UNIQUE NOT NULL,
  user_id TEXT REFERENCES users(id),
  ip_address TEXT,
  user_agent TEXT,
  started_at TEXT DEFAULT (datetime('now')),
  last_active TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_sessions_id ON customer_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON customer_sessions(user_id);

CREATE TABLE IF NOT EXISTS page_views (
  id TEXT PRIMARY KEY,
  session_id TEXT,
  user_id TEXT REFERENCES users(id),
  page TEXT NOT NULL,
  referrer TEXT,
  product_id TEXT REFERENCES products(id),
  category_id TEXT REFERENCES categories(id),
  duration INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_page_views_session ON page_views(session_id);
CREATE INDEX IF NOT EXISTS idx_page_views_page ON page_views(page);
CREATE INDEX IF NOT EXISTS idx_page_views_created ON page_views(created_at);
CREATE INDEX IF NOT EXISTS idx_page_views_product ON page_views(product_id);

CREATE TABLE IF NOT EXISTS heatmap_data (
  id TEXT PRIMARY KEY,
  page TEXT NOT NULL,
  element_selector TEXT,
  x_percent REAL,
  y_percent REAL,
  clicks INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_heatmap_page ON heatmap_data(page);

CREATE TABLE IF NOT EXISTS conversion_events (
  id TEXT PRIMARY KEY,
  session_id TEXT,
  user_id TEXT REFERENCES users(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('view','cart','checkout','payment','purchase')),
  product_id TEXT REFERENCES products(id),
  order_id TEXT REFERENCES orders(id),
  value REAL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_conversion_session ON conversion_events(session_id);
CREATE INDEX IF NOT EXISTS idx_conversion_type ON conversion_events(event_type);
CREATE INDEX IF NOT EXISTS idx_conversion_created ON conversion_events(created_at);

-- ============================================================================
-- STAFF ATTENDANCE
-- ============================================================================

CREATE TABLE IF NOT EXISTS staff_attendance (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  date TEXT NOT NULL,
  check_in TEXT,
  check_out TEXT,
  status TEXT DEFAULT 'present' CHECK(status IN ('present','absent','late','half_day','leave')),
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_attendance_user ON staff_attendance(user_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON staff_attendance(date);

-- ============================================================================
-- PERMISSIONS & ROLE-BASED ACCESS
-- ============================================================================

CREATE TABLE IF NOT EXISTS permissions (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  module TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS role_permissions (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL,
  permission_id TEXT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_role_perms_role ON role_permissions(role);
CREATE INDEX IF NOT EXISTS idx_role_perms_perm ON role_permissions(permission_id);

-- ============================================================================
-- AI & RECOMMENDATIONS
-- ============================================================================

CREATE TABLE IF NOT EXISTS ai_predictions (
  id TEXT PRIMARY KEY,
  prediction_type TEXT NOT NULL CHECK(prediction_type IN ('sales','stock','demand','price')),
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  prediction_data TEXT NOT NULL,
  confidence REAL DEFAULT 0,
  period TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  expires_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_ai_predictions_type ON ai_predictions(prediction_type);
CREATE INDEX IF NOT EXISTS idx_ai_predictions_entity ON ai_predictions(entity_id);

CREATE TABLE IF NOT EXISTS smart_recommendations (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  session_id TEXT,
  product_id TEXT NOT NULL REFERENCES products(id),
  score REAL DEFAULT 0,
  algorithm TEXT DEFAULT 'collaborative',
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_recommendations_user ON smart_recommendations(user_id);
CREATE INDEX IF NOT EXISTS idx_recommendations_product ON smart_recommendations(product_id);

-- ============================================================================
-- ABANDONED CART RECOVERIES
-- ============================================================================

CREATE TABLE IF NOT EXISTS abandoned_cart_recoveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cart_id INTEGER NOT NULL,
  notification_type TEXT NOT NULL DEFAULT 'email',
  coupon_code TEXT,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  recovered_at DATETIME,
  FOREIGN KEY (cart_id) REFERENCES carts(id)
);

CREATE INDEX IF NOT EXISTS idx_abandoned_cart_recoveries_cart ON abandoned_cart_recoveries(cart_id);
CREATE INDEX IF NOT EXISTS idx_abandoned_cart_recoveries_sent ON abandoned_cart_recoveries(sent_at);

-- ============================================================================
-- BARGAINING / OFFER SYSTEM (Dam-Kam)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bargaining_offers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    offered_price   REAL    NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 1,
    status          TEXT    NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','countered','rejected','expired')),
    counter_price   REAL,
    seller_note     TEXT,
    buyer_note      TEXT,
    expires_at      TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_bargaining_product ON bargaining_offers(product_id);
CREATE INDEX IF NOT EXISTS idx_bargaining_user ON bargaining_offers(user_id);
CREATE INDEX IF NOT EXISTS idx_bargaining_status ON bargaining_offers(status);

-- ============================================================================
-- SETTINGS (Key-Value Store for Pixel, Analytics, etc.)
-- ============================================================================

CREATE TABLE IF NOT EXISTS settings (
    key         TEXT    PRIMARY KEY,
    value       TEXT,
    group_name  TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_settings_group ON settings(group_name);

-- ============================================================================
-- NEWSLETTER SUBSCRIBERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    email           TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    name            TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1,
    source          TEXT    DEFAULT 'website',
    subscribed_at   TEXT    NOT NULL DEFAULT (datetime('now')),
    unsubscribed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_newsletter_email ON newsletter_subscribers(email);
CREATE INDEX IF NOT EXISTS idx_newsletter_active ON newsletter_subscribers(is_active) WHERE is_active = 1;

-- ============================================================================
-- BANNERS / SLIDERS
-- ============================================================================

CREATE TABLE IF NOT EXISTS banners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  subtitle TEXT,
  image_url TEXT NOT NULL,
  link_url TEXT,
  link_text TEXT DEFAULT 'Shop Now',
  position TEXT DEFAULT 'hero' CHECK(position IN ('hero','promo','featured','sidebar')),
  sort_order INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1,
  bg_color TEXT DEFAULT '#1a1a2e',
  text_color TEXT DEFAULT '#ffffff',
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_banners_position ON banners(position);
CREATE INDEX IF NOT EXISTS idx_banners_active ON banners(is_active) WHERE is_active = 1;

-- ============================================================================
-- EMAIL / SMS TEMPLATES
-- ============================================================================

CREATE TABLE IF NOT EXISTS email_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  variables TEXT,
  type TEXT DEFAULT 'email' CHECK(type IN ('email','sms')),
  is_active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_email_templates_slug ON email_templates(slug);

-- ============================================================================
-- MEDIA / FILES
-- ============================================================================

CREATE TABLE IF NOT EXISTS media_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size INTEGER NOT NULL,
  url TEXT NOT NULL,
  thumbnail_url TEXT,
  alt_text TEXT,
  uploaded_by INTEGER REFERENCES users(id),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_media_files_mime ON media_files(mime_type);

-- ============================================================================
-- End of Schema
-- ============================================================================
