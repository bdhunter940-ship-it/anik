import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

router.post('/', [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').trim().isEmail().withMessage('Valid email is required'),
  body('subject').trim().notEmpty().withMessage('Subject is required'),
  body('message').trim().isLength({ min: 10 }).withMessage('Message must be at least 10 characters'),
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    const db = getDb();
    const { name, email, phone, subject, message } = req.body;
    db.prepare(
      `INSERT INTO contact_messages (name, email, phone, subject, message, created_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))`
    ).run(name, email, phone || null, subject, message);
    res.json({ success: true, message: 'Thank you! We will get back to you soon.' });
  } catch (error) { next(error); }
});

export default router;
