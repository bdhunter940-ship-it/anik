import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { getDb } from '../database/db.js';
import { authenticate, generateTokens, setTokenCookies, clearTokenCookies } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

const registerValidation = [
  body('first_name').trim().isLength({ min: 1, max: 50 }).withMessage('First name is required'),
  body('last_name').trim().optional().isLength({ max: 50 }),
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('phone').matches(/^(\+88)?01[3-9]\d{8}$/).withMessage('Valid Bangladeshi phone number is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Password must contain uppercase, lowercase, and number'),
];

const loginValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required'),
];

const forgotPasswordValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
];

const verifyOtpValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('otp').isLength({ min: 4, max: 6 }).isNumeric().withMessage('OTP must be 4-6 digits'),
];

const resetPasswordValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('otp').isLength({ min: 4, max: 6 }).isNumeric().withMessage('OTP must be 4-6 digits'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Password must contain uppercase, lowercase, and number'),
];

router.post('/register', registerValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { first_name, last_name = '', email, phone, password } = req.body;
    const db = getDb();

    const existing = db.prepare('SELECT id FROM users WHERE email = ? OR phone = ?').get(email, phone);
    if (existing) {
      throw new AppError('Email or phone already registered', 409);
    }

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(password, salt);

    const uuid = crypto.randomUUID();
    const referralCode = crypto.randomBytes(6).toString('hex').toUpperCase();

    const result = db.prepare(
      `INSERT INTO users (uuid, first_name, last_name, email, phone, password_hash, referral_code, role)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'customer')`
    ).run(uuid, first_name, last_name, email, phone, hashedPassword, referralCode);

    const user = db.prepare(
      'SELECT id, uuid, first_name, last_name, email, phone, role, referral_code FROM users WHERE id = ?'
    ).get(result.lastInsertRowid);

    const tokens = generateTokens(user);
    setTokenCookies(res, tokens);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: { user, accessToken: tokens.accessToken },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/login', loginValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, password } = req.body;
    const db = getDb();

    const user = db.prepare(
      'SELECT id, uuid, first_name, last_name, email, phone, password_hash, role, is_active FROM users WHERE email = ?'
    ).get(email);

    if (!user) {
      throw new AppError('Invalid email or password', 401);
    }

    if (!user.is_active) {
      throw new AppError('Account is deactivated', 403);
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      throw new AppError('Invalid email or password', 401);
    }

    const { password_hash, ...userWithoutPassword } = user;
    const tokens = generateTokens(userWithoutPassword);
    setTokenCookies(res, tokens);

    res.json({
      success: true,
      message: 'Login successful',
      data: { user: userWithoutPassword, accessToken: tokens.accessToken },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const refreshToken = req.cookies?.refreshToken;

    if (refreshToken) {
      db.prepare(
        `UPDATE refresh_tokens SET revoked_at = datetime('now') WHERE user_id = ? AND token = ? AND revoked_at IS NULL`
      ).run(req.user.id, refreshToken);
    }

    clearTokenCookies(res);

    res.json({ success: true, message: 'Logged out successfully' });
  } catch (error) {
    next(error);
  }
});

router.post('/refresh', async (req, res, next) => {
  try {
    const refreshToken = req.cookies?.refreshToken;
    if (!refreshToken) {
      throw new AppError('Refresh token not found', 401);
    }

    const db = getDb();
    const jwt = await import('jsonwebtoken');
    const decoded = jwt.default.verify(refreshToken, process.env.JWT_REFRESH_SECRET);

    const storedToken = db.prepare(
      'SELECT id, user_id FROM refresh_tokens WHERE token = ? AND revoked_at IS NULL AND expires_at > datetime(\'now\')'
    ).get(refreshToken);

    if (!storedToken) {
      throw new AppError('Invalid refresh token', 401);
    }

    const user = db.prepare(
      'SELECT id, uuid, first_name, last_name, email, phone, role, is_active FROM users WHERE id = ?'
    ).get(decoded.id);

    if (!user || !user.is_active) {
      throw new AppError('Account is not accessible', 403);
    }

    db.prepare(`UPDATE refresh_tokens SET revoked_at = datetime('now') WHERE id = ?`).run(storedToken.id);

    const tokens = generateTokens(user);
    setTokenCookies(res, tokens);

    res.json({
      success: true,
      message: 'Token refreshed',
      data: { accessToken: tokens.accessToken },
    });
  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      return next(new AppError('Invalid or expired refresh token', 401));
    }
    next(error);
  }
});

router.post('/forgot-password', forgotPasswordValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email } = req.body;
    const db = getDb();

    const user = db.prepare('SELECT id FROM users WHERE email = ?').get(email);

    if (!user) {
      return res.json({ success: true, message: 'If email exists, OTP has been sent' });
    }

    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    db.prepare(
      `INSERT INTO otp_codes (user_id, email, code, type, expires_at) VALUES (?, ?, ?, 'reset', ?)`
    ).run(user.id, email, otp, expiresAt);

    res.json({ success: true, message: 'OTP sent to your email' });
  } catch (error) {
    next(error);
  }
});

router.post('/verify-otp', verifyOtpValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, otp } = req.body;
    const db = getDb();

    const otpRecord = db.prepare(
      `SELECT id FROM otp_codes WHERE email = ? AND code = ? AND type = 'reset'
       AND used_at IS NULL AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1`
    ).get(email, otp);

    if (!otpRecord) {
      throw new AppError('Invalid or expired OTP', 400);
    }

    db.prepare(`UPDATE otp_codes SET used_at = datetime('now') WHERE id = ?`).run(otpRecord.id);

    res.json({ success: true, message: 'OTP verified successfully' });
  } catch (error) {
    next(error);
  }
});

router.post('/reset-password', resetPasswordValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, otp, password } = req.body;
    const db = getDb();

    const otpRecord = db.prepare(
      `SELECT id, user_id FROM otp_codes WHERE email = ? AND code = ? AND type = 'reset'
       AND used_at IS NULL AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1`
    ).get(email, otp);

    if (!otpRecord) {
      throw new AppError('Invalid or expired OTP', 400);
    }

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(password, salt);

    db.prepare(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(hashedPassword, otpRecord.user_id);

    db.prepare(`UPDATE otp_codes SET used_at = datetime('now') WHERE id = ?`).run(otpRecord.id);

    db.prepare(`DELETE FROM refresh_tokens WHERE user_id = ?`).run(otpRecord.user_id);

    clearTokenCookies(res);

    res.json({ success: true, message: 'Password reset successful' });
  } catch (error) {
    next(error);
  }
});

router.get('/me', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const user = db.prepare(
      `SELECT id, uuid, first_name, last_name, email, phone, role, avatar, referral_code,
              loyalty_points, wallet_balance, email_verified, phone_verified, created_at
       FROM users WHERE id = ?`
    ).get(req.user.id);

    if (!user) {
      throw new AppError('User not found', 404);
    }

    res.json({ success: true, data: { user } });
  } catch (error) {
    next(error);
  }
});

export default router;
