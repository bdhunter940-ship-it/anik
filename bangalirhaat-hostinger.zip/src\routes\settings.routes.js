import { Router } from 'express';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();

function getSettings(group) {
  const db = getDb();
  let rows;
  if (group) {
    rows = db.prepare('SELECT key, value FROM settings WHERE group_name = ?').all(group);
  } else {
    rows = db.prepare('SELECT key, value FROM settings').all();
  }
  const obj = {};
  rows.forEach(r => { obj[r.key] = r.value; });
  return obj;
}

function setSetting(key, value, group) {
  const db = getDb();
  db.prepare(
    `INSERT INTO settings (key, value, group_name, created_at, updated_at)
     VALUES (?, ?, ?, datetime('now'), datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
  ).run(key, value, group || null);
}

router.get('/', async (req, res, next) => {
  try {
    const group = req.query.group;
    const settings = getSettings(group || null);
    res.json({ success: true, data: { settings } });
  } catch (error) { next(error); }
});

router.get('/analytics', async (req, res, next) => {
  try {
    const settings = getSettings('analytics');
    res.json({
      success: true,
      data: {
        fbPixelId: settings.fb_pixel_id || '',
        ga4Id: settings.ga4_id || '',
        hotjarId: settings.hotjar_id || '',
      }
    });
  } catch (error) { next(error); }
});

router.put('/', authenticate, authorize('admin', 'super_admin'), async (req, res, next) => {
  try {
    const { settings } = req.body;
    if (!settings || !Array.isArray(settings)) {
      return res.status(400).json({ success: false, message: 'settings array required' });
    }
    const db = getDb();
    const upsert = db.prepare(
      `INSERT INTO settings (key, value, group_name, created_at, updated_at)
       VALUES (?, ?, ?, datetime('now'), datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
    );
    const txn = db.transaction((items) => {
      for (const s of items) {
        if (s.key) upsert.run(s.key, String(s.value ?? ''), s.group || null);
      }
    });
    txn(settings);
    res.json({ success: true, message: 'Settings saved' });
  } catch (error) { next(error); }
});

export default router;