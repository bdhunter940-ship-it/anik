import Database from 'better-sqlite3';
import { readFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import config from '../config/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let db = null;

export function initializeDatabase() {
  if (db) return db;

  const dbPath = config.db.path;
  const dbDir = dirname(dbPath);
  mkdirSync(dbDir, { recursive: true });

  const schemaPath = resolve(__dirname, 'schema.sql');

  db = new Database(dbPath);

  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  db.pragma('synchronous = NORMAL');
  db.pragma('cache_size = -64000');

  const schema = readFileSync(schemaPath, 'utf-8');

  try {
    db.exec(schema);
  } catch (err) {
    const msg = err.message || '';
    if (
      msg.includes('already exists') ||
      msg.includes('duplicate column')
    ) {
      console.log(`[DB] Schema info: ${msg.substring(0, 100)}`);
    } else {
      throw err;
    }
  }

  console.log(`[DB] Connected to ${dbPath}`);
  return db;
}

export function getDb() {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

export function closeDatabase() {
  if (db) {
    db.close();
    db = null;
    console.log('[DB] Connection closed');
  }
}

export default { initializeDatabase, getDb, closeDatabase };
