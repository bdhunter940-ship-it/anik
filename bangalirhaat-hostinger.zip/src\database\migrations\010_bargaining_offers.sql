CREATE TABLE IF NOT EXISTS bargaining_offers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid            TEXT    NOT NULL UNIQUE,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    offered_price   REAL    NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 1,
    status          TEXT    NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','countered','rejected','expired')),
    counter_price   REAL,
    seller_note     TEXT,
    buyer_note      TEXT,
    expires_at      TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_bargaining_product ON bargaining_offers(product_id);
CREATE INDEX IF NOT EXISTS idx_bargaining_user ON bargaining_offers(user_id);
CREATE INDEX IF NOT EXISTS idx_bargaining_status ON bargaining_offers(status);
