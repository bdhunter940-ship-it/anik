import { Router } from 'express';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

function slugify(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+|-+$/g, '');
}

router.get('/:slug', async (req, res, next) => {
  try {
    const db = getDb();
    const template = db.prepare(
      `SELECT * FROM email_templates WHERE slug = ? AND is_active = 1`
    ).get(req.params.slug);

    if (!template) {
      return res.status(404).json({ success: false, message: 'Template not found' });
    }

    res.json({ success: true, data: template });
  } catch (error) {
    next(error);
  }
});

router.get('/', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const templates = db.prepare(
      `SELECT * FROM email_templates ORDER BY name ASC`
    ).all();

    res.json({ success: true, data: { items: templates } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const { name, subject, body, variables, type } = req.body;

    if (!name || !subject || !body) {
      return res.status(400).json({ success: false, message: 'name, subject, and body are required' });
    }

    const slug = slugify(name);

    const existing = db.prepare('SELECT id FROM email_templates WHERE slug = ?').get(slug);
    if (existing) {
      return res.status(400).json({ success: false, message: 'A template with this slug already exists' });
    }

    const result = db.prepare(
      `INSERT INTO email_templates (name, slug, subject, body, variables, type, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(
      name, slug, subject, body,
      variables ? JSON.stringify(variables) : null,
      type || 'email'
    );

    const template = db.prepare('SELECT * FROM email_templates WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      data: template,
      message: 'Email template created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const templateId = parseInt(req.params.id);

    const existing = db.prepare('SELECT * FROM email_templates WHERE id = ?').get(templateId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Template not found' });
    }

    const { name, subject, body, variables, type, is_active } = req.body;

    const slug = name ? slugify(name) : existing.slug;
    if (slug !== existing.slug) {
      const slugConflict = db.prepare('SELECT id FROM email_templates WHERE slug = ? AND id != ?').get(slug, templateId);
      if (slugConflict) {
        return res.status(400).json({ success: false, message: 'A template with this slug already exists' });
      }
    }

    db.prepare(
      `UPDATE email_templates SET
        name = ?, slug = ?, subject = ?, body = ?,
        variables = ?, type = ?, is_active = ?,
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      name || existing.name,
      slug,
      subject || existing.subject,
      body || existing.body,
      variables !== undefined ? JSON.stringify(variables) : existing.variables,
      type || existing.type,
      is_active !== undefined ? is_active : existing.is_active,
      templateId
    );

    const template = db.prepare('SELECT * FROM email_templates WHERE id = ?').get(templateId);

    res.json({
      success: true,
      data: template,
      message: 'Email template updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/:id', adminAuth, async (req, res) => {
  try {
    const db = getDb();
    const templateId = parseInt(req.params.id);

    const template = db.prepare('SELECT * FROM email_templates WHERE id = ?').get(templateId);
    if (!template) {
      return res.status(404).json({ success: false, message: 'Template not found' });
    }

    db.prepare('DELETE FROM email_templates WHERE id = ?').run(templateId);

    res.json({
      success: true,
      message: 'Email template deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
