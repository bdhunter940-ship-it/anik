import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

const validPositions = ['hero', 'promo', 'featured', 'sidebar'];

const bannerValidation = [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('subtitle').optional({ nullable: true }).trim().isLength({ max: 500 }),
  body('image_url').trim().notEmpty().withMessage('Image URL is required'),
  body('link_url').optional({ nullable: true }).trim(),
  body('link_text').optional({ nullable: true }).trim().isLength({ max: 100 }),
  body('position').optional().isIn(validPositions).withMessage(`Position must be one of: ${validPositions.join(', ')}`),
  body('sort_order').optional().isInt().toInt(),
  body('is_active').optional().isInt({ min: 0, max: 1 }).toInt(),
  body('bg_color').optional().trim().isLength({ max: 20 }),
  body('text_color').optional().trim().isLength({ max: 20 }),
];

const idValidation = [
  param('id').isInt({ min: 1 }).toInt().withMessage('Invalid banner ID'),
];

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();
    const { position } = req.query;

    let sql = 'SELECT * FROM banners WHERE is_active = 1';
    const params = [];

    if (position && validPositions.includes(position)) {
      sql += ' AND position = ?';
      params.push(position);
    }

    sql += ' ORDER BY sort_order';

    const banners = db.prepare(sql).all(...params);

    res.json({ success: true, data: { banners } });
  } catch (error) {
    next(error);
  }
});

router.get('/admin/all', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const banners = db.prepare('SELECT * FROM banners ORDER BY sort_order').all();

    res.json({ success: true, data: { banners } });
  } catch (error) {
    next(error);
  }
});

router.post('/', adminAuth, bannerValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const {
      title, subtitle, image_url, link_url, link_text,
      position, sort_order, is_active, bg_color, text_color,
    } = req.body;

    const result = db.prepare(
      `INSERT INTO banners (title, subtitle, image_url, link_url, link_text, position, sort_order, is_active, bg_color, text_color)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      title,
      subtitle || null,
      image_url,
      link_url || null,
      link_text || 'Shop Now',
      position || 'hero',
      sort_order ?? 0,
      is_active ?? 1,
      bg_color || '#1a1a2e',
      text_color || '#ffffff',
    );

    const banner = db.prepare('SELECT * FROM banners WHERE id = ?').get(result.lastInsertRowid);

    res.status(201).json({ success: true, data: { banner }, message: 'Banner created successfully' });
  } catch (error) {
    next(error);
  }
});

router.put('/:id', adminAuth, [...idValidation, ...bannerValidation], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const existing = db.prepare('SELECT id FROM banners WHERE id = ?').get(req.params.id);
    if (!existing) {
      throw new AppError('Banner not found', 404);
    }

    const {
      title, subtitle, image_url, link_url, link_text,
      position, sort_order, is_active, bg_color, text_color,
    } = req.body;

    db.prepare(
      `UPDATE banners
       SET title = ?, subtitle = ?, image_url = ?, link_url = ?, link_text = ?,
           position = ?, sort_order = ?, is_active = ?, bg_color = ?, text_color = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).run(
      title,
      subtitle || null,
      image_url,
      link_url || null,
      link_text || 'Shop Now',
      position || 'hero',
      sort_order ?? 0,
      is_active ?? 1,
      bg_color || '#1a1a2e',
      text_color || '#ffffff',
      req.params.id,
    );

    const banner = db.prepare('SELECT * FROM banners WHERE id = ?').get(req.params.id);

    res.json({ success: true, data: { banner }, message: 'Banner updated successfully' });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', adminAuth, idValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const existing = db.prepare('SELECT id FROM banners WHERE id = ?').get(req.params.id);
    if (!existing) {
      throw new AppError('Banner not found', 404);
    }

    db.prepare('DELETE FROM banners WHERE id = ?').run(req.params.id);

    res.json({ success: true, message: 'Banner deleted successfully' });
  } catch (error) {
    next(error);
  }
});

export default router;
