import crypto from 'crypto';
import { getDb } from '../database/db.js';
import config from '../config/index.js';

const GATEWAY_STATUS_MAP = {
  SUCCESS: 'completed',
  VALIDATED: 'completed',
  SUCCESSFUL: 'completed',
  failed: 'failed',
  Failed: 'failed',
  cancelled: 'failed',
  BACKLINK_CANCEL: 'failed',
  Pending: 'pending',
  Unbounded: 'pending',
};

class PaymentService {
  constructor() {
    this._bkashToken = null;
    this._bkashTokenExpiry = 0;
  }

  _generateTxnId(prefix = 'TXN') {
    return `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  }

  _recordPayment(db, { orderId, method, amount, currency = 'BDT', transactionId, gatewayResponse, status }) {
    const stmt = db.prepare(
      `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    );
    return stmt.run(orderId, method, amount, currency, transactionId || null, gatewayResponse ? JSON.stringify(gatewayResponse) : null, status);
  }

  _updateOrderPayment(db, orderId, status, method, reference) {
    db.prepare(
      `UPDATE orders SET payment_status = ?, payment_method = COALESCE(?, payment_method),
       payment_reference = COALESCE(?, payment_reference), updated_at = datetime('now') WHERE id = ?`
    ).run(status, method || null, reference || null, orderId);
  }

  _addStatusHistory(db, orderId, status, note) {
    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, ?, ?, datetime('now'))`
    ).run(orderId, status, note);
  }

  async processCOD(order) {
    const db = getDb();
    try {
      this._recordPayment(db, {
        orderId: order.id,
        method: 'cod',
        amount: order.total,
        transactionId: this._generateTxnId('COD'),
        status: 'pending',
      });
      this._updateOrderPayment(db, order.id, 'pending', 'cod', null);
      this._addStatusHistory(db, order.id, 'pending', 'COD payment pending on delivery');
      return { success: true, method: 'cod', status: 'pending', message: 'Payment will be collected on delivery' };
    } catch (error) {
      console.error('[PaymentService] COD error:', error.message);
      throw new Error(`COD processing failed: ${error.message}`);
    }
  }

  async createStripeSession(order, user) {
    const stripeKey = config.stripe?.secretKey;
    if (!stripeKey) {
      throw new Error('Stripe secret key not configured');
    }

    const txnId = this._generateTxnId('STR');
    const lineItems = order.items.map(item => ({
      price_data: {
        currency: 'bdt',
        product_data: { name: item.product_name, metadata: { product_id: String(item.product_id) } },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.quantity,
    }));

    if (order.shipping_cost > 0) {
      lineItems.push({
        price_data: {
          currency: 'bdt',
          product_data: { name: 'Shipping Cost' },
          unit_amount: Math.round(order.shipping_cost * 100),
        },
        quantity: 1,
      });
    }

    const body = new URLSearchParams({
      'payment_method_types[]': 'card',
      'line_items[0][price_data][currency]': 'bdt',
      mode: 'payment',
      customer_email: user.email,
      'metadata[order_id]': String(order.id),
      'metadata[order_number]': order.order_number,
      'metadata[txn_id]': txnId,
      success_url: `${config.isProduction ? 'https://bangalirhaat.com' : 'http://localhost:5000'}/orders/${order.order_number}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${config.isProduction ? 'https://bangalirhaat.com' : 'http://localhost:5000'}/orders/${order.order_number}/cancel`,
    });

    const response = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${stripeKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    });

    if (!response.ok) {
      const err = await response.json();
      console.error('[PaymentService] Stripe session creation failed:', err);
      throw new Error(err.error?.message || 'Stripe session creation failed');
    }

    const session = await response.json();

    const db = getDb();
    this._recordPayment(db, {
      orderId: order.id,
      method: 'stripe',
      amount: order.total,
      transactionId: txnId,
      gatewayResponse: session,
      status: 'pending',
    });
    this._updateOrderPayment(db, order.id, 'pending', 'stripe', txnId);

    return {
      success: true,
      sessionId: session.id,
      url: session.url,
      txnId,
    };
  }

  async verifyStripePayment(sessionId) {
    const stripeKey = config.stripe?.secretKey;
    if (!stripeKey) {
      throw new Error('Stripe secret key not configured');
    }

    const response = await fetch(`https://api.stripe.com/v1/checkout/sessions/${sessionId}`, {
      headers: { 'Authorization': `Bearer ${stripeKey}` },
    });

    if (!response.ok) {
      throw new Error('Failed to verify Stripe session');
    }

    const session = await response.json();
    const db = getDb();
    const orderId = parseInt(session.metadata?.order_id, 10);

    if (!orderId) {
      throw new Error('No order_id in session metadata');
    }

    const paymentStatus = session.payment_status === 'paid' ? 'completed' : 'failed';

    this._recordPayment(db, {
      orderId,
      method: 'stripe',
      amount: session.amount_total / 100,
      transactionId: session.payment_intent,
      gatewayResponse: session,
      status: paymentStatus,
    });

    this._updateOrderPayment(db, orderId, paymentStatus, 'stripe', session.payment_intent);

    if (paymentStatus === 'completed') {
      this._addStatusHistory(db, orderId, 'confirmed', 'Payment confirmed via Stripe');
    }

    return { success: true, status: paymentStatus, orderId, sessionId };
  }

  async handleStripeWebhook(event) {
    if (!event || !event.type) {
      throw new Error('Invalid Stripe webhook event');
    }

    const db = getDb();

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const orderId = parseInt(session.metadata?.order_id, 10);
        if (orderId) {
          this._updateOrderPayment(db, orderId, 'completed', 'stripe', session.payment_intent);
          this._addStatusHistory(db, orderId, 'confirmed', 'Stripe payment confirmed via webhook');
        }
        break;
      }
      case 'payment_intent.payment_failed': {
        const intent = event.data.object;
        const orderId = parseInt(intent.metadata?.order_id, 10);
        if (orderId) {
          this._updateOrderPayment(db, orderId, 'failed', 'stripe', intent.id);
          this._addStatusHistory(db, orderId, 'pending', 'Stripe payment failed');
        }
        break;
      }
      case 'charge.refunded': {
        const charge = event.data.object;
        const orderId = parseInt(charge.metadata?.order_id, 10);
        if (orderId) {
          this._updateOrderPayment(db, orderId, 'refunded', 'stripe', charge.id);
        }
        break;
      }
      default:
        console.log(`[PaymentService] Unhandled Stripe event type: ${event.type}`);
    }

    return { success: true, processed: event.type };
  }

  async initSSLCommerz(order, user) {
    const { storeId, storePass } = config.sslcommerz || {};
    if (!storeId || !storePass) {
      throw new Error('SSLCommerz credentials not configured');
    }

    const isLive = process.env.SSLCOMMERZ_ENV === 'live';
    const baseUrl = isLive ? 'https://securepay.sslcommerz.com' : 'sandbox.securepay.sslcommerz.com';
    const txnId = this._generateTxnId('SSL');

    const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};
    const frontendUrl = isLive ? 'https://bangalirhaat.com' : 'http://localhost:5000';

    const params = new URLSearchParams({
      store_id: storeId,
      store_passwd: storePass,
      total_amount: String(order.total),
      currency: 'BDT',
      tran_id: txnId,
      success_url: `${frontendUrl}/api/payments/sslcommerz/success`,
      fail_url: `${frontendUrl}/api/payments/sslcommerz/fail`,
      cancel_url: `${frontendUrl}/api/payments/sslcommerz/cancel`,
      ipn_url: `${frontendUrl}/api/payments/sslcommerz/ipn`,
      cus_name: user.first_name + (user.last_name ? ' ' + user.last_name : ''),
      cus_email: user.email,
      cus_add1: shippingAddr.line1 || 'N/A',
      cus_add2: shippingAddr.line2 || '',
      cus_city: shippingAddr.city || 'Dhaka',
      cus_state: shippingAddr.district || 'Dhaka',
      cus_postcode: shippingAddr.postal_code || '1000',
      cus_country: 'Bangladesh',
      cus_phone: user.phone || shippingAddr.phone || '',
      ship_name: shippingAddr.name || user.first_name,
      ship_add1: shippingAddr.line1 || 'N/A',
      ship_add2: shippingAddr.line2 || '',
      ship_city: shippingAddr.city || 'Dhaka',
      ship_state: shippingAddr.district || 'Dhaka',
      ship_postcode: shippingAddr.postal_code || '1000',
      ship_country: 'Bangladesh',
      product_name: order.items?.map(i => i.product_name).join(', ') || 'Order Items',
      product_category: 'E-Commerce',
      product_profile: 'general',
    });

    const response = await fetch(`${baseUrl}/gwprocess/v4/api.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    });

    const result = await response.json();

    if (result.status !== 'SUCCESS') {
      throw new Error(result.failedreason || 'SSLCommerz initialization failed');
    }

    const db = getDb();
    this._recordPayment(db, {
      orderId: order.id,
      method: 'sslcommerz',
      amount: order.total,
      transactionId: txnId,
      gatewayResponse: result,
      status: 'pending',
    });
    this._updateOrderPayment(db, order.id, 'pending', 'sslcommerz', txnId);

    return {
      success: true,
      sessionId: result.sessionkey,
      url: result.GatewayPageURL,
      redirectUrl: result.redirectURL,
      txnId,
    };
  }

  async verifySSLCommerz(tranId) {
    const { storeId, storePass } = config.sslcommerz || {};
    if (!storeId || !storePass) {
      throw new Error('SSLCommerz credentials not configured');
    }

    const isLive = process.env.SSLCOMMERZ_ENV === 'live';
    const baseUrl = isLive ? 'https://securepay.sslcommerz.com' : 'sandbox.securepay.sslcommerz.com';

    const response = await fetch(`${baseUrl}/validator/api/validationserver.php?val_id=${tranId}&store_id=${storeId}&store_passwd=${storePass}`);
    const result = await response.json();

    const db = getDb();
    const payment = db.prepare('SELECT order_id FROM payments WHERE transaction_id = ?').get(tranId);

    if (!payment) {
      throw new Error('Payment record not found for this transaction');
    }

    const status = GATEWAY_STATUS_MAP[result.status] || 'pending';
    this._updateOrderPayment(db, payment.order_id, status, 'sslcommerz', tranId);

    if (status === 'completed') {
      this._addStatusHistory(db, payment.order_id, 'confirmed', 'SSLCommerz payment verified');
    }

    return { success: true, status, orderId: payment.order_id, gateway: result };
  }

  async handleSSLCommerzWebhook(data) {
    const db = getDb();
    const tranId = data.tran_id;
    if (!tranId) {
      throw new Error('Missing tran_id in SSLCommerz webhook');
    }

    const payment = db.prepare('SELECT order_id FROM payments WHERE transaction_id = ?').get(tranId);
    if (!payment) {
      console.warn(`[PaymentService] SSLCommerz IPN: No payment found for ${tranId}`);
      return { success: false, message: 'Payment not found' };
    }

    const status = GATEWAY_STATUS_MAP[data.status] || 'pending';
    this._updateOrderPayment(db, payment.order_id, status, 'sslcommerz', tranId);

    if (status === 'completed') {
      this._addStatusHistory(db, payment.order_id, 'confirmed', 'SSLCommerz IPN confirmed');
    } else if (status === 'failed') {
      this._addStatusHistory(db, payment.order_id, 'pending', 'SSLCommerz payment failed via IPN');
    }

    return { success: true, status, orderId: payment.order_id };
  }

  async _getBkashToken() {
    if (this._bkashToken && Date.now() < this._bkashTokenExpiry) {
      return this._bkashToken;
    }

    const { appKey, appSecret, username, password, baseUrl } = this._getBkashConfig();
    if (!appKey) {
      throw new Error('bKash credentials not configured');
    }

    const response = await fetch(`${baseUrl}/tokenized/checkout/token/grant`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'username': username,
        'password': password,
      },
      body: JSON.stringify({ app_key: appKey, app_secret: appSecret }),
    });

    if (!response.ok) {
      throw new Error('bKash token grant failed');
    }

    const data = await response.json();
    this._bkashToken = data.id_token;
    this._bkashTokenExpiry = Date.now() + (data.expires_in || 3600) * 1000 - 60000;
    return this._bkashToken;
  }

  _getBkashConfig() {
    return {
      appKey: process.env.BKASH_APP_KEY || '',
      appSecret: process.env.BKASH_APP_SECRET || '',
      username: process.env.BKASH_USERNAME || '',
      password: process.env.BKASH_PASSWORD || '',
      baseUrl: process.env.BKASH_BASE_URL || 'https://tokenized.sandbox.bka.sh/v1.2.0-beta',
      callbackUrl: process.env.BKASH_CALLBACK_URL || 'http://localhost:5000/api/payments/bkash/callback',
    };
  }

  async createBkashPayment(order, user) {
    const bkashConfig = this._getBkashConfig();
    if (!bkashConfig.appKey) {
      throw new Error('bKash credentials not configured');
    }

    const token = await this._getBkashToken();
    const txnId = this._generateTxnId('BKS');
    const frontendUrl = process.env.NODE_ENV === 'production' ? 'https://bangalirhaat.com' : 'http://localhost:5000';

    const response = await fetch(`${bkashConfig.baseUrl}/tokenized/checkout/payment/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token,
      },
      body: JSON.stringify({
        mode: '0000',
        payerReference: user.phone || user.email,
        callbackURL: `${frontendUrl}/api/payments/bkash/callback`,
        merchantInvoiceNumber: order.order_number,
        amount: String(order.total),
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || 'bKash payment creation failed');
    }

    const result = await response.json();
    const db = getDb();

    this._recordPayment(db, {
      orderId: order.id,
      method: 'bkash',
      amount: order.total,
      transactionId: txnId,
      gatewayResponse: result,
      status: 'pending',
    });
    this._updateOrderPayment(db, order.id, 'pending', 'bkash', txnId);

    return {
      success: true,
      paymentId: result.paymentID,
      url: result.bkashURL,
      txnId,
    };
  }

  async verifyBkashPayment(paymentId) {
    const bkashConfig = this._getBkashConfig();
    if (!bkashConfig.appKey) {
      throw new Error('bKash credentials not configured');
    }

    const token = await this._getBkashToken();

    const response = await fetch(`${bkashConfig.baseUrl}/tokenized/checkout/payment/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token,
      },
      body: JSON.stringify({ paymentID: paymentId }),
    });

    if (!response.ok) {
      throw new Error('bKash payment status check failed');
    }

    const result = await response.json();
    const db = getDb();

    const payment = db.prepare('SELECT order_id FROM payments WHERE gateway_response LIKE ?').get(`%"paymentID":"${paymentId}"%`);

    if (!payment) {
      throw new Error('Payment record not found for this bKash transaction');
    }

    const status = result.transactionStatus === 'Completed' ? 'completed' : 'failed';
    this._updateOrderPayment(db, payment.order_id, status, 'bkash', result.trxID || paymentId);

    if (status === 'completed') {
      this._addStatusHistory(db, payment.order_id, 'confirmed', `bKash payment completed. TRX: ${result.trxID}`);
    }

    return { success: true, status, orderId: payment.order_id, transactionStatus: result.transactionStatus, trxID: result.trxID };
  }

  async handleBkashWebhook(data) {
    const db = getDb();
    const paymentId = data.paymentID || data.id;
    if (!paymentId) {
      throw new Error('Missing payment ID in bKash webhook');
    }

    const payment = db.prepare('SELECT order_id FROM payments WHERE gateway_response LIKE ?').get(`%"paymentID":"${paymentId}"%`);

    if (!payment) {
      return { success: false, message: 'Payment not found' };
    }

    const status = data.transactionStatus === 'Completed' ? 'completed' : 'failed';
    this._updateOrderPayment(db, payment.order_id, status, 'bkash', data.trxID || paymentId);

    if (status === 'completed') {
      this._addStatusHistory(db, payment.order_id, 'confirmed', 'bKash webhook confirmed');
    }

    return { success: true, status, orderId: payment.order_id };
  }

  _getNagadConfig() {
    return {
      merchantId: process.env.NAGAD_MERCHANT_ID || '',
      publicKey: process.env.NAGAD_PUBLIC_KEY || '',
      privateKey: process.env.NAGAD_PRIVATE_KEY || '',
      apiUrl: process.env.NAGAD_API_URL || 'https://sandbox.mynagad.com/api/dfs',
      callbackUrl: process.env.NAGAD_CALLBACK_URL || 'http://localhost:5000/api/payments/nagad/callback',
    };
  }

  async createNagadPayment(order, user) {
    const nagadConfig = this._getNagadConfig();
    if (!nagadConfig.merchantId) {
      throw new Error('Nagad credentials not configured');
    }

    const txnId = this._generateTxnId('NGD');
    const frontendUrl = process.env.NODE_ENV === 'production' ? 'https://bangalirhaat.com' : 'http://localhost:5000';
    const initPayload = {
      merchantId: nagadConfig.merchantId,
      dateTime: new Date().toISOString().replace('T', ' ').substring(0, 19),
      campaignCode: '',
      orderReference: order.order_number,
      invoiceAmount: order.total,
      additionalInfo: { orderId: order.id, orderNumber: order.order_number },
      callbackURL: `${frontendUrl}/api/payments/nagad/callback`,
    };

    const bodyString = JSON.stringify(initPayload);
    const signature = crypto.createHash('sha256').update(bodyString).digest('hex');

    const response = await fetch(`${nagadConfig.apiUrl}/merchant/prepaid/precheckout`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Signature': signature,
      },
      body: bodyString,
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || 'Nagad payment initialization failed');
    }

    const result = await response.json();
    const db = getDb();

    this._recordPayment(db, {
      orderId: order.id,
      method: 'nagad',
      amount: order.total,
      transactionId: result.paymentRefId || txnId,
      gatewayResponse: result,
      status: 'pending',
    });
    this._updateOrderPayment(db, order.id, 'pending', 'nagad', result.paymentRefId || txnId);

    return {
      success: true,
      paymentRefId: result.paymentRefId,
      url: result.redirectUrl,
      txnId: result.paymentRefId || txnId,
    };
  }

  async verifyNagadPayment(tranId) {
    const nagadConfig = this._getNagadConfig();
    if (!nagadConfig.merchantId) {
      throw new Error('Nagad credentials not configured');
    }

    const response = await fetch(`${nagadConfig.apiUrl}/merchant/prepaid/status/${tranId}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Nagad verification failed');
    }

    const result = await response.json();
    const db = getDb();

    const payment = db.prepare('SELECT order_id FROM payments WHERE transaction_id = ?').get(tranId);
    if (!payment) {
      throw new Error('Payment record not found for Nagad transaction');
    }

    const status = result.paymentStatus === 'Success' ? 'completed' : 'failed';
    this._updateOrderPayment(db, payment.order_id, status, 'nagad', tranId);

    if (status === 'completed') {
      this._addStatusHistory(db, payment.order_id, 'confirmed', `Nagad payment completed. Ref: ${result.paymentRefId || tranId}`);
    }

    return { success: true, status, orderId: payment.order_id, result };
  }

  async createRocketPayment(order, user) {
    const merchantId = process.env.ROCKET_MERCHANT_ID || '';
    const apiKey = process.env.ROCKET_API_KEY || '';
    if (!merchantId) {
      throw new Error('Rocket credentials not configured');
    }

    const txnId = this._generateTxnId('RKT');
    const frontendUrl = process.env.NODE_ENV === 'production' ? 'https://bangalirhaat.com' : 'http://localhost:5000';

    const response = await fetch('https://sandbox.shurjopay.com/api/v1/request-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prefix: 'br',
        amount: String(order.total),
        order_id: order.order_number,
        currency: 'BDT',
        bank_tx_id: txnId,
        customer_name: user.first_name + (user.last_name ? ' ' + user.last_name : ''),
        customer_phone: user.phone || '',
        customer_email: user.email,
        redirect_url: `${frontendUrl}/api/payments/rocket/callback`,
        cancel_url: `${frontendUrl}/orders/${order.order_number}/cancel`,
        ip_address: '',
      }),
    });

    if (!response.ok) {
      throw new Error('Rocket payment initialization failed');
    }

    const result = await response.json();
    const db = getDb();

    this._recordPayment(db, {
      orderId: order.id,
      method: 'rocket',
      amount: order.total,
      transactionId: txnId,
      gatewayResponse: result,
      status: 'pending',
    });
    this._updateOrderPayment(db, order.id, 'pending', 'rocket', txnId);

    return {
      success: true,
      url: result.redirectUrl || result.checkout_url,
      txnId,
    };
  }

  async verifyRocketPayment(tranId) {
    const db = getDb();
    const payment = db.prepare('SELECT order_id, amount FROM payments WHERE transaction_id = ?').get(tranId);
    if (!payment) {
      throw new Error('Rocket payment record not found');
    }

    const merchantId = process.env.ROCKET_MERCHANT_ID || '';
    const apiKey = process.env.ROCKET_API_KEY || '';
    if (!merchantId) {
      throw new Error('Rocket credentials not configured');
    }

    try {
      const response = await fetch(`https://sandbox.shurjopay.com/api/v1/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bank_tx_id: tranId }),
      });

      if (!response.ok) {
        throw new Error('Status check failed');
      }

      const result = await response.json();
      const status = result.status === 'success' ? 'completed' : 'failed';

      this._updateOrderPayment(db, payment.order_id, status, 'rocket', tranId);

      if (status === 'completed') {
        this._addStatusHistory(db, payment.order_id, 'confirmed', 'Rocket payment completed');
      }

      return { success: true, status, orderId: payment.order_id, gateway: result };
    } catch (error) {
      console.error('[PaymentService] Rocket verification error:', error.message);
      throw error;
    }
  }

  async processRefund(order, amount, reason) {
    const db = getDb();

    const payment = db.prepare(
      'SELECT id, method, amount, transaction_id FROM payments WHERE order_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1'
    ).get(order.id, 'completed');

    if (!payment) {
      throw new Error('No completed payment found for this order');
    }

    if (amount > payment.amount) {
      throw new Error(`Refund amount (${amount}) exceeds payment amount (${payment.amount})`);
    }

    const refundId = this._generateTxnId('REF');

    const insertRefund = db.prepare(
      `INSERT INTO refunds (order_id, payment_id, amount, reason, status, created_at)
       VALUES (?, ?, ?, ?, 'approved', datetime('now'))`
    );
    const refundResult = insertRefund.run(order.id, payment.id, amount, reason || 'Customer requested refund');

    db.prepare(
      `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
       VALUES (?, ?, ?, 'BDT', ?, ?, 'refunded', datetime('now'), datetime('now'))`
    ).run(order.id, payment.method, amount, refundId, JSON.stringify({
      originalTxnId: payment.transaction_id,
      reason,
      type: 'refund',
    }));

    this._updateOrderPayment(db, order.id, 'refunded', null, refundId);
    this._addStatusHistory(db, order.id, 'refunded', `Refund of ৳${amount} processed. Reason: ${reason || 'N/A'}`);

    return {
      success: true,
      refundId,
      amount,
      method: payment.method,
      originalPaymentId: payment.id,
      dbRefundId: refundResult.lastInsertRowid,
    };
  }

  async getPaymentStatus(orderId) {
    const db = getDb();

    const order = db.prepare(
      'SELECT id, order_number, status, payment_status, payment_method, payment_reference, total, created_at FROM orders WHERE id = ?'
    ).get(orderId);

    if (!order) {
      throw new Error('Order not found');
    }

    const payments = db.prepare(
      `SELECT id, method, amount, currency, transaction_id, status, created_at
       FROM payments WHERE order_id = ? ORDER BY created_at DESC`
    ).all(orderId);

    const refunds = db.prepare(
      `SELECT r.id, r.amount, r.reason, r.status, r.created_at
       FROM refunds r WHERE r.order_id = ? ORDER BY r.created_at DESC`
    ).all(orderId);

    const totalPaid = payments.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0);
    const totalRefunded = refunds.filter(r => r.status === 'approved').reduce((sum, r) => sum + r.amount, 0);

    return {
      orderId: order.id,
      orderNumber: order.order_number,
      total: order.total,
      paymentStatus: order.payment_status,
      paymentMethod: order.payment_method,
      payments,
      refunds,
      summary: {
        totalPaid,
        totalRefunded,
        balance: totalPaid - totalRefunded,
      },
    };
  }
}

export default new PaymentService();
