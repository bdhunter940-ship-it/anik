import express from 'express';
import { getDb } from '../database/db.js';

const router = express.Router();

const SITE_URL = process.env.SITE_URL || 'https://bangalirhaat.com';

// GET /sitemap - Generate sitemap.xml
router.get('/sitemap', async (req, res, next) => {
  try {
    const db = getDb();
    const baseUrl = SITE_URL.replace(/\/+$/, '');

    const urls = [];

    urls.push({
      loc: `${baseUrl}/`,
      changefreq: 'daily',
      priority: '1.0',
      lastmod: new Date().toISOString().split('T')[0],
    });

    urls.push({
      loc: `${baseUrl}/products`,
      changefreq: 'daily',
      priority: '0.9',
      lastmod: new Date().toISOString().split('T')[0],
    });

    urls.push({
      loc: `${baseUrl}/categories`,
      changefreq: 'weekly',
      priority: '0.8',
      lastmod: new Date().toISOString().split('T')[0],
    });

    const categories = db.prepare(
      `SELECT slug, updated_at, meta_title
       FROM categories
       WHERE deleted_at IS NULL AND is_active = 1
       ORDER BY sort_order ASC`
    ).all();

    for (const cat of categories) {
      urls.push({
        loc: `${baseUrl}/category/${cat.slug}`,
        changefreq: 'weekly',
        priority: '0.8',
        lastmod: cat.updated_at ? cat.updated_at.split(' ')[0] : new Date().toISOString().split('T')[0],
      });
    }

    const products = db.prepare(
      `SELECT slug, updated_at, created_at, meta_title
       FROM products
       WHERE deleted_at IS NULL AND is_active = 1
       ORDER BY created_at DESC`
    ).all();

    for (const product of products) {
      urls.push({
        loc: `${baseUrl}/product/${product.slug}`,
        changefreq: 'weekly',
        priority: '0.7',
        lastmod: product.updated_at
          ? product.updated_at.split(' ')[0]
          : product.created_at
            ? product.created_at.split(' ')[0]
            : new Date().toISOString().split('T')[0],
      });
    }

    const pages = db.prepare(
      `SELECT slug, updated_at
       FROM pages
       WHERE is_published = 1
       ORDER BY title ASC`
    ).all();

    for (const page of pages) {
      urls.push({
        loc: `${baseUrl}/page/${page.slug}`,
        changefreq: 'monthly',
        priority: '0.5',
        lastmod: page.updated_at ? page.updated_at.split(' ')[0] : new Date().toISOString().split('T')[0],
      });
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${urls.map(u => `  <url>
    <loc>${escapeXml(u.loc)}</loc>
    <lastmod>${u.lastmod}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

    res.set('Content-Type', 'application/xml');
    res.send(xml);
  } catch (error) {
    next(error);
  }
});

// GET /robots - robots.txt
router.get('/robots', (req, res) => {
  const baseUrl = (process.env.SITE_URL || 'https://bangalirhaat.com').replace(/\/+$/, '');

  const robotsTxt = `User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /cart/
Disallow: /checkout/
Disallow: /account/
Disallow: /wishlist/
Disallow: /orders/
Disallow: /*?*sort=
Disallow: /*?*filter=
Disallow: /*?*search=
Disallow: /*?*page=

User-agent: Googlebot
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /cart/
Disallow: /checkout/
Disallow: /account/
Disallow: /wishlist/
Disallow: /orders/

User-agent: Bingbot
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /cart/
Disallow: /checkout/
Disallow: /account/

Sitemap: ${baseUrl}/api/seo/sitemap`;

  res.set('Content-Type', 'text/plain');
  res.send(robotsTxt);
});

function escapeXml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export default router;
