import { initializeDatabase } from './db.js';

function main() {
  try {
    initializeDatabase();
    console.log('Database initialized successfully.');
    process.exit(0);
  } catch (error) {
    console.error('Failed to initialize database:', error.message);
    process.exit(1);
  }
}

main();
