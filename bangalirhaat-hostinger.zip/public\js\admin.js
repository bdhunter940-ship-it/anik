// ── Admin Panel ── Bangalirhaat ──────────────────────────────────────────────
const AdminAPI = {
  BASE_URL: '/api/admin',
  token: null,
  async request(method, path, body) {
    const opts = { method, headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${this.token}` } };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`${this.BASE_URL}${path}`, opts);
    const data = await res.json();
    if (!data.success && res.status >= 400) throw new Error(data.message || 'Request failed');
    return data;
  },
  get(p) { return this.request('GET', p); },
  post(p, b) { return this.request('POST', p, b); },
  put(p, b) { return this.request('PUT', p, b); },
  del(p) { return this.request('DELETE', p); },
};

// ── Admin Auth ──────────────────────────────────────────────────────────────
const AdminAuth = {
  async login(email, password) {
    const res = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const data = await res.json();
    if (data.success) { AdminAPI.token = data.data.accessToken; localStorage.setItem('adminToken', data.data.accessToken); localStorage.setItem('adminUser', JSON.stringify(data.data.user)); }
    return data;
  },
  async logout() {
    await fetch('/api/auth/logout', { method: 'POST', headers: { 'Authorization': `Bearer ${AdminAPI.token}` } });
    AdminAPI.token = null; localStorage.removeItem('adminToken'); localStorage.removeItem('adminUser');
    if (!document.getElementById('page-login')) showLoginPage();
  },
  checkAuth() {
    const token = localStorage.getItem('adminToken');
    const user = JSON.parse(localStorage.getItem('adminUser') || 'null');
    if (token && user && (user.role === 'admin' || user.role === 'super_admin')) {
      AdminAPI.token = token; return user;
    }
    return null;
  }
};

// ── Helper ──────────────────────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }
function qs(s, p) { return (p || document).querySelector(s); }
function qsa(s, p) { return (p || document).querySelectorAll(s); }
function esc(str) { const d = document.createElement('div'); d.textContent = str; return d.innerHTML; }
function dateStr(d) { return new Date(d).toLocaleDateString('en-BD', { day: '2-digit', month: 'short', year: 'numeric' }); }
function timeAgo(d) { const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000); if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + 'm ago'; if (s < 86400) return Math.floor(s / 3600) + 'h ago'; return Math.floor(s / 86400) + 'd ago'; }
function nf(num) { return new Intl.NumberFormat('en-IN').format(num || 0); }
function currency(num) { return '৳' + nf(num); }
function showToast(msg, type = 'success') { const c = $('toastContainer'); if (!c) return; const t = document.createElement('div'); t.className = `toast toast-${type}`; t.innerHTML = `<div class="toast-content">${esc(msg)}</div><button class="toast-close" onclick="this.parentElement.remove()">&times;</button>`; c.appendChild(t); setTimeout(() => t.remove(), 4000); }
function showConfirm(title, msg) { return new Promise(resolve => { const d = $('confirmDialog'); $('confirmTitle').textContent = title; $('confirmMessage').textContent = msg; d.classList.add('active'); $('confirmAction').onclick = () => { d.classList.remove('active'); resolve(true); }; qs('.modal-close', d).onclick = () => { d.classList.remove('active'); resolve(false); }; }); }
function loading(btn, state) { if (!btn) return; if (state) { btn._orig = btn.innerHTML; btn.innerHTML = '<span class="spinner-sm"></span> Loading...'; btn.disabled = true; } else { btn.innerHTML = btn._orig || btn.innerHTML; btn.disabled = false; } }
function pagination(total, page, limit, fn) {
  const pages = Math.ceil(total / limit);
  if (pages <= 1) return '';
  let html = '<div class="pagination">';
  html += `<button class="page-btn" onclick="${fn}(${page - 1})" ${page <= 1 ? 'disabled' : ''}>‹</button>`;
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) {
    html += `<button class="page-btn ${i === page ? 'active' : ''}" onclick="${fn}(${i})">${i}</button>`;
  }
  html += `<button class="page-btn" onclick="${fn}(${page + 1})" ${page >= pages ? 'disabled' : ''}>›</button>`;
  html += '</div>';
  return html;
}

// ── Page Router ─────────────────────────────────────────────────────────────
let currentPage = 'dashboard-overview';
const pageCache = {};

function navigateTo(page) {
  currentPage = page;
  qsa('.admin-nav-item').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  qsa('.admin-page').forEach(el => el.classList.remove('active'));
  let target = $(`page-${page}`);
  if (!target) {
    target = document.createElement('div');
    target.id = `page-${page}`;
    target.className = 'admin-page';
    $('adminContent').appendChild(target);
  }
  target.classList.add('active');
  if (!pageCache[page]) { pageCache[page] = true; initPage(page); }
}

function initPage(page) {
  const handlers = {
    'dashboard-overview': initDashboard,
    'orders-all': () => initOrdersList('all'),
    'orders-pending': () => initOrdersList('pending'),
    'orders-processing': () => initOrdersList('processing'),
    'orders-shipped': () => initOrdersList('shipped'),
    'orders-delivered': () => initOrdersList('delivered'),
    'orders-returns': () => initOrdersList('returned'),
    'orders-cancelled': () => initOrdersList('cancelled'),
    'products': initProducts,
    'add-product': initAddProduct,
    'categories': initCategories,
    'brands': initBrands,
    'low-stock': initLowStock,
    'shipment': initShipments,
    'bulk-courier-send': initBulkCourierSend,
    'invoice-print': initInvoicePrint,
    'invoice-bulk-print': initBulkInvoicePrint,
    'delivery': initDelivery,
    'delivery-zones': initDeliveryZones,
    'settings-courier': initCourierSettings,
    'customers-all': () => initCustomers('all'),
    'customers-vip': () => initCustomers('vip'),
    'customers-blacklist': () => initCustomers('blacklist'),
    'marketing-coupons': initCoupons,
    'marketing-campaigns': initCampaigns,
    'flash-sales': initFlashSales,
    'settings-company': initCompanySettings,
    'settings-invoice': initInvoiceSettings,
    'settings-theme': initThemeSettings,
    'settings-analytics': initAnalyticsSettings,
    'settings-payment': initPaymentSettings,
    'settings-tax': initTaxSettings,
    'settings-email-templates': initEmailTemplates,
    'abandoned-cart': initAbandonedCart,
    'banners': initBanners,
    'reviews': initAdminReviews,
    'media': initMedia,
    'staff': initStaff,
    'audit-logs': initAuditLogs,
    'login-history': initLoginHistory,
    'expenses': initExpenses,
    'income': initFinanceOverview,
    'invoices': () => initOrdersList('delivered'),
    'finance-overview': initFinanceOverview,
    'report-daily': () => initReports('daily'),
    'report-weekly': () => initReports('weekly'),
    'report-monthly': () => initReports('monthly'),
    'report-yearly': () => initReports('yearly'),
    'report-top-products': initTopProductsReport,
    'report-top-customers': initTopCustomersReport,
  };
  if (handlers[page]) handlers[page]();
}

// ── DASHBOARD ───────────────────────────────────────────────────────────────
async function initDashboard() {
  try {
    const res = await AdminAPI.get('/dashboard');
    const d = res.data;
    $('statRevenue').textContent = currency(d.today_revenue);
    $('statOrders').textContent = nf(d.today_orders);
    if ($('statCustomers')) $('statCustomers').textContent = nf(d.new_customers_today);
    if ($('statPending')) $('statPending').textContent = nf(d.pending_orders);
    // Recent orders
    if ($('recentOrdersBody')) {
      var sb = { pending: 'badge-warning', confirmed: 'badge-info', processing: 'badge-info', shipped: 'badge-primary', delivered: 'badge-success', cancelled: 'badge-danger', returned: 'badge-secondary' };
      var recentOrders = d.recent_orders || [];
      $('recentOrdersBody').innerHTML = recentOrders.length ? recentOrders.map(function(o) {
        return '<tr><td style="font-weight:var(--weight-semibold);">#' + esc(o.order_number) + '</td><td>' + esc(o.customer_name || 'N/A') + '</td><td style="text-align:right;font-weight:var(--weight-semibold);">' + currency(o.total) + '</td><td><span class="badge ' + (sb[o.status] || 'badge-secondary') + ' badge-dot">' + esc(o.status) + '</span></td><td style="color:var(--text-muted);">' + dateStr(o.created_at) + '</td></tr>';
      }).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No recent orders</td></tr>';
    }
    // Top products
    if ($('topProductsList')) {
      var top = d.top_products || [];
      $('topProductsList').innerHTML = top.length ? top.map(function(p, i) {
        var border = i < top.length - 1 ? 'border-bottom:1px solid var(--divider);' : '';
        return '<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) 0;' + border + '"><span style="font-size:var(--text-sm);font-weight:var(--weight-semibold);min-width:24px;">' + (i + 1) + '</span><div style="flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);">' + esc(p.name || p.product_name || 'Product') + '</div><div style="font-size:var(--text-xs);color:var(--text-muted);">' + (p.quantity_sold || p.total_sold || 0) + ' sold</div></div><div style="font-size:var(--text-sm);font-weight:var(--weight-bold);">' + currency(p.revenue || p.total_revenue || 0) + '</div></div>';
      }).join('') : '<p style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">No product data yet</p>';
    }
    // Low stock alerts
    if ($('lowStockList')) {
      var low = d.low_stock_products || [];
      $('lowStockList').innerHTML = low.length ? low.map(function(p, i) {
        var level = p.stock_quantity <= 2 ? 'danger' : p.stock_quantity <= 5 ? 'warning' : 'info';
        var label = p.stock_quantity <= 2 ? 'Critical' : p.stock_quantity <= 5 ? 'Low' : 'Watch';
        var dotColor = level === 'danger' ? 'var(--color-danger)' : level === 'warning' ? 'var(--color-warning)' : 'var(--color-info)';
        var border = i < low.length - 1 ? 'border-bottom:1px solid var(--divider);' : '';
        return '<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) 0;' + border + '"><div style="width:8px;height:8px;border-radius:50%;background:' + dotColor + ';flex-shrink:0;"></div><div style="flex:1;"><div style="font-size:var(--text-sm);font-weight:var(--weight-medium);">' + esc(p.name) + '</div><div style="font-size:var(--text-xs);color:var(--text-muted);">' + p.stock_quantity + ' remaining</div></div><span class="badge badge-' + level + '">' + label + '</span></div>';
      }).join('') : '<p style="text-align:center;padding:var(--space-4);color:var(--text-muted);font-size:var(--text-sm);">All products sufficiently stocked</p>';
    }
  } catch (e) { console.error('Dashboard load error:', e); }
}

// ── ORDERS ──────────────────────────────────────────────────────────────────
function renderOrderRow(o) {
  const statusBadge = { pending: 'badge-warning', confirmed: 'badge-info', processing: 'badge-info', shipped: 'badge-primary', delivered: 'badge-success', cancelled: 'badge-danger', returned: 'badge-secondary' };
  return `<tr>
    <td style="font-weight:var(--weight-semibold);">#${esc(o.order_number)}</td>
    <td>${esc(o.customer_name || 'N/A')}</td>
    <td style="text-align:right;font-weight:var(--weight-semibold);">${currency(o.total)}</td>
    <td><span class="badge ${statusBadge[o.status] || 'badge-secondary'} badge-dot">${esc(o.status)}</span></td>
    <td style="color:var(--text-muted);font-size:var(--text-xs);">${dateStr(o.created_at)}</td>
    <td>
      <div class="admin-actions">
        <button class="btn btn-sm btn-ghost" onclick="viewOrder(${o.id})">View</button>
        <button class="btn btn-sm btn-ghost" onclick="editOrderStatus(${o.id})">Status</button>
      </div>
    </td>
  </tr>`;
}

async function initOrdersList(status) {
  const el = $(`page-orders-${status}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${status.charAt(0).toUpperCase() + status.slice(1)} Orders</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover" id="ordersTable${status}"><thead><tr><th>Order #</th><th>Customer</th><th style="text-align:right;">Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="ordersBody${status}"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div><div id="ordersPagination${status}" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadOrdersPage(status, 1);
}

async function loadOrdersPage(status, page) {
  const params = new URLSearchParams({ limit: '15', page: String(page) });
  if (status !== 'all') params.set('status', status === 'processing' ? 'confirmed' : status);
  try {
    const res = await AdminAPI.get(`/orders?${params}`);
    const tbody = $(`ordersBody${status}`);
    if (!tbody) return;
    tbody.innerHTML = res.data.items.length ? res.data.items.map(renderOrderRow).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No orders found</td></tr>';
    const pag = $(`ordersPagination${status}`);
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, `loadOrdersPage('${status}', `);
  } catch (e) { console.error(e); }
}

async function viewOrder(id) {
  try {
    const res = await AdminAPI.get(`/orders/${id}`);
    const o = res.data.order;
    const items = o.items.map(i => `<tr><td>${esc(i.product_name)}</td><td>${i.quantity}</td><td style="text-align:right;">${currency(i.price)}</td><td style="text-align:right;">${currency(i.total)}</td></tr>`).join('');
    showModal(`Order #${o.order_number}`, `<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);margin-bottom:var(--space-4);">
      <div><strong>Status:</strong> ${o.status}</div><div><strong>Payment:</strong> ${o.payment_status}</div>
      <div><strong>Method:</strong> ${o.payment_method || 'N/A'}</div><div><strong>Total:</strong> ${currency(o.total)}</div>
    </div><table class="table"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${items}</tbody></table>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function editOrderStatus(id) {
  const statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned'];
  const opts = statuses.map(s => `<option value="${s}">${s}</option>`).join('');
  showModal('Update Order Status', `<form id="statusForm" onsubmit="updateOrderStatus(${id}, this);return false">
    <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status" required>${opts}</select></div>
    <div class="form-group"><label class="form-label">Note (optional)</label><textarea class="form-input" name="note" rows="2"></textarea></div>
    <button type="submit" class="btn btn-primary w-full" id="statusBtn">Update Status</button>
  </form>`);
}

async function updateOrderStatus(id, form) {
  const btn = $('statusBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    await AdminAPI.put(`/orders/${id}/status`, { status: fd.get('status'), note: fd.get('note') || null });
    showToast('Order status updated');
    document.querySelector('.modal-overlay.active')?.classList.remove('active');
    loadOrdersPage(currentPage.replace('orders-', ''), 1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── PRODUCTS ────────────────────────────────────────────────────────────────
async function initProducts() {
  const el = $('page-products');
  el.innerHTML = `<div class="admin-page-header"><h1>Products</h1><button class="btn btn-primary" onclick="navigateTo('add-product')">+ Add Product</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>SKU</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody id="productsBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div><div id="productsPagination" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadProductsPage(1);
}

async function loadProductsPage(page) {
  try {
    const res = await AdminAPI.get(`/products?limit=15&page=${page}`);
    const tbody = $('productsBody');
    tbody.innerHTML = res.data.items.map(p => `<tr>
      <td><div style="display:flex;align-items:center;gap:var(--space-3);"><div style="width:40px;height:40px;border-radius:var(--radius);background:var(--surface-secondary);overflow:hidden;"><img src="${p.thumbnail || ''}" alt="" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'"></div><div><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(p.category_name || '')}</div></div></div></td>
      <td style="font-size:var(--text-xs);">${esc(p.sku || '-')}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(p.price)}</td>
      <td><span class="${p.stock_quantity < p.low_stock_threshold ? 'badge badge-danger' : 'badge badge-success'}">${p.stock_quantity}</span></td>
      <td><span class="badge ${p.is_active ? 'badge-success' : 'badge-secondary'}">${p.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="editProduct(${p.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteProduct(${p.id},'${esc(p.name)}')">Delete</button></div></td>
    </tr>`).join('');
    const pag = $('productsPagination');
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, 'loadProductsPage');
  } catch (e) { showToast(e.message, 'error'); }
}

async function initAddProduct() {
  const cats = await AdminAPI.get('/categories');
  const catOpts = cats.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  const brands = await AdminAPI.get('/brands');
  const brandOpts = [{ id: '', name: 'None' }, ...brands.data.items].map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('');

  $('page-add-product').innerHTML = `<div class="admin-page-header"><h1>Add Product</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form id="addProductForm" onsubmit="saveProduct(this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Product Name *</label><input class="form-input" name="name" required></div>
      <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" placeholder="Leave blank for auto-generate"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Category *</label><select class="form-select" name="category_id" required>${catOpts}</select></div>
      <div class="form-group"><label class="form-label">Brand</label><select class="form-select" name="brand_id">${brandOpts}</select></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Price *</label><input class="form-input" name="price" type="number" step="0.01" required></div>
      <div class="form-group"><label class="form-label">Compare Price</label><input class="form-input" name="compare_price" type="number" step="0.01"></div>
      <div class="form-group"><label class="form-label">SKU</label><input class="form-input" name="sku"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Stock Quantity</label><input class="form-input" name="stock_quantity" type="number" value="0"></div>
      <div class="form-group"><label class="form-label">Low Stock Threshold</label><input class="form-input" name="low_stock_threshold" type="number" value="5"></div></div>
      <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="4"></textarea></div>
      <div class="form-group"><label class="form-label">Short Description</label><textarea class="form-input" name="short_description" rows="2"></textarea></div>
      <div class="form-row"><div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_featured" value="1"> Featured Product</label></div>
      <div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_active" value="1" checked> Active</label></div></div>
      <button type="submit" class="btn btn-primary" id="saveProductBtn">Save Product</button>
    </form>
  </div></div>`;
}

async function saveProduct(form) {
  const btn = $('saveProductBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());
    data.price = parseFloat(data.price) || 0;
    data.compare_price = data.compare_price ? parseFloat(data.compare_price) : null;
    data.category_id = parseInt(data.category_id);
    data.brand_id = data.brand_id ? parseInt(data.brand_id) : null;
    data.stock_quantity = parseInt(data.stock_quantity) || 0;
    data.is_featured = data.is_featured ? 1 : 0;
    data.is_active = data.is_active ? 1 : 0;
    await AdminAPI.post('/products', data);
    showToast('Product created successfully');
    navigateTo('products');
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

async function deleteProduct(id, name) {
  if (!await showConfirm('Delete Product', `Are you sure you want to delete "${name}"?`)) return;
  try { await AdminAPI.del(`/products/${id}`); showToast('Product deleted'); loadProductsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function editProduct(id) {
  try {
    const res = await AdminAPI.get(`/products/${id}`);
    const p = res.data.product;
    const cats = await AdminAPI.get('/categories');
    const catOpts = cats.data.items.map(c => `<option value="${c.id}" ${c.id === p.category_id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
    const brands = await AdminAPI.get('/brands');
    const brandOpts = [{ id: '', name: 'None' }, ...brands.data.items].map(b => `<option value="${b.id}" ${b.id === p.brand_id ? 'selected' : ''}>${esc(b.name)}</option>`).join('');

    showModal('Edit Product', `<form id="editProductForm" onsubmit="updateProduct(${id}, this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Product Name *</label><input class="form-input" name="name" value="${esc(p.name)}" required></div>
      <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" value="${esc(p.slug)}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Category *</label><select class="form-select" name="category_id" required>${catOpts}</select></div>
      <div class="form-group"><label class="form-label">Brand</label><select class="form-select" name="brand_id">${brandOpts}</select></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Price *</label><input class="form-input" name="price" type="number" step="0.01" value="${p.price}" required></div>
      <div class="form-group"><label class="form-label">Compare Price</label><input class="form-input" name="compare_price" type="number" step="0.01" value="${p.compare_price || ''}"></div>
      <div class="form-group"><label class="form-label">SKU</label><input class="form-input" name="sku" value="${esc(p.sku || '')}"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Stock Quantity</label><input class="form-input" name="stock_quantity" type="number" value="${p.stock_quantity || 0}"></div>
      <div class="form-group"><label class="form-label">Low Stock Threshold</label><input class="form-input" name="low_stock_threshold" type="number" value="${p.low_stock_threshold || 5}"></div></div>
      <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="4">${esc(p.description || '')}</textarea></div>
      <div class="form-row"><div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_featured" value="1" ${p.is_featured ? 'checked' : ''}> Featured</label></div>
      <div class="form-group"><label class="form-checkbox"><input type="checkbox" name="is_active" value="1" ${p.is_active ? 'checked' : ''}> Active</label></div></div>
      <button type="submit" class="btn btn-primary w-full" id="editProductBtn">Update Product</button>
    </form>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateProduct(id, form) {
  const btn = $('editProductBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());
    data.price = parseFloat(data.price) || 0;
    data.compare_price = data.compare_price ? parseFloat(data.compare_price) : null;
    data.category_id = parseInt(data.category_id);
    data.brand_id = data.brand_id ? parseInt(data.brand_id) : null;
    data.stock_quantity = parseInt(data.stock_quantity) || 0;
    data.is_featured = data.is_featured ? 1 : 0;
    data.is_active = data.is_active ? 1 : 0;
    await AdminAPI.put(`/products/${id}`, data);
    showToast('Product updated successfully');
    qs('.modal-overlay.active')?.classList.remove('active');
    loadProductsPage(1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── CATEGORIES ──────────────────────────────────────────────────────────────
async function initCategories() {
  const el = $('page-categories');
  el.innerHTML = `<div class="admin-page-header"><h1>Categories</h1><button class="btn btn-primary" onclick="showAddCategory()">+ Add Category</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Image</th><th>Name</th><th>Slug</th><th>Order</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody id="categoriesBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/categories');
    $('categoriesBody').innerHTML = res.data.items.map(c => `<tr>
      <td>${c.image ? `<img src="${esc(c.image)}" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:var(--radius-sm);display:block;">` : `<div style="width:48px;height:48px;border-radius:var(--radius-sm);background:var(--glass-bg);display:flex;align-items:center;justify-content:center;font-size:20px;">📁</div>`}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.name)}${c.parent_name ? `<br><span style="font-size:var(--text-xs);color:var(--text-muted);">Parent: ${esc(c.parent_name)}</span>` : ''}</div></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${esc(c.slug)}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);text-align:center;">${c.sort_order}</td>
      <td style="text-align:center;">${c.product_count || 0}</td>
      <td><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditCategory(${c.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteCategory(${c.id},'${esc(c.name)}')">Delete</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

async function showAddCategory() {
  const parents = await fetchParentCategories();
  const parentOpts = '<option value="">None (top level)</option>' + parents.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  showModal('Add Category', `<form id="catForm" onsubmit="saveCategory(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" id="catName" required></div>
    <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" id="catSlug" placeholder="Auto-generated from name"></div>
    <div class="form-group"><label class="form-label">Image URL</label><input class="form-input" name="image" id="catImage" placeholder="https://example.com/image.jpg">
      <div id="catImagePreview" style="margin-top:8px;display:none;"><img src="" alt="" style="max-width:120px;max-height:80px;border-radius:var(--radius-sm);border:1px solid var(--border);"></div>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3"></textarea></div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Parent Category</label><select class="form-input" name="parent_id">${parentOpts}</select></div>
      <div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="0" min="0"></div>
    </div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Meta Title</label><input class="form-input" name="meta_title"></div>
      <div class="form-group"><label class="form-label">Meta Description</label><input class="form-input" name="meta_description"></div>
    </div>
    <div class="form-group" style="display:flex;align-items:center;gap:var(--space-2);"><input type="checkbox" name="is_active" id="catActive" checked value="1" style="width:18px;height:18px;"><label for="catActive" style="margin:0;">Active</label></div>
    <button type="submit" class="btn btn-primary w-full">Save Category</button>
  </form>`);
  const imgInput = $('catImage');
  const preview = $('catImagePreview');
  if (imgInput) imgInput.addEventListener('input', () => { if (imgInput.value) { preview.style.display = 'block'; preview.querySelector('img').src = imgInput.value; } else { preview.style.display = 'none'; } });
  const nameInput = $('catName');
  const slugInput = $('catSlug');
  if (nameInput && slugInput) nameInput.addEventListener('input', () => { if (!slugInput.dataset.touched) slugInput.value = nameInput.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); });
  if (slugInput) slugInput.addEventListener('input', () => slugInput.dataset.touched = '1');
}

async function showEditCategory(id) {
  const [parents, catRes] = await Promise.all([fetchParentCategories(), AdminAPI.get('/categories')]);
  const cat = (catRes.data.items || []).find(c => c.id === id);
  if (!cat) { showToast('Category not found', 'error'); return; }
  const parentOpts = '<option value="">None (top level)</option>' + parents.filter(p => p.id !== id).map(p => `<option value="${p.id}"${p.id === cat.parent_id ? ' selected' : ''}>${esc(p.name)}</option>`).join('');
  showModal('Edit Category', `<form id="catForm" onsubmit="saveCategory(this,${id});return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" id="catName" value="${esc(cat.name)}" required></div>
    <div class="form-group"><label class="form-label">Slug</label><input class="form-input" name="slug" id="catSlug" value="${esc(cat.slug || '')}"></div>
    <div class="form-group"><label class="form-label">Image URL</label><input class="form-input" name="image" id="catImage" value="${esc(cat.image || '')}" placeholder="https://example.com/image.jpg">
      <div id="catImagePreview" style="margin-top:8px;${cat.image ? '' : 'display:none;'}"><img src="${esc(cat.image || '')}" alt="" style="max-width:120px;max-height:80px;border-radius:var(--radius-sm);border:1px solid var(--border);"></div>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3">${esc(cat.description || '')}</textarea></div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Parent Category</label><select class="form-input" name="parent_id">${parentOpts}</select></div>
      <div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="${cat.sort_order}" min="0"></div>
    </div>
    <div class="admin-form-grid">
      <div class="form-group"><label class="form-label">Meta Title</label><input class="form-input" name="meta_title" value="${esc(cat.meta_title || '')}"></div>
      <div class="form-group"><label class="form-label">Meta Description</label><input class="form-input" name="meta_description" value="${esc(cat.meta_description || '')}"></div>
    </div>
    <div class="form-group" style="display:flex;align-items:center;gap:var(--space-2);"><input type="checkbox" name="is_active" id="catActive" value="1"${cat.is_active ? ' checked' : ''} style="width:18px;height:18px;"><label for="catActive" style="margin:0;">Active</label></div>
    <button type="submit" class="btn btn-primary w-full">Update Category</button>
  </form>`);
  const imgInput = $('catImage');
  const preview = $('catImagePreview');
  if (imgInput && preview) imgInput.addEventListener('input', () => { if (imgInput.value) { preview.style.display = 'block'; preview.querySelector('img').src = imgInput.value; } else { preview.style.display = 'none'; } });
}

async function fetchParentCategories() {
  try {
    const res = await AdminAPI.get('/categories');
    return (res.data.items || []).filter(c => !c.parent_id);
  } catch { return []; }
}

async function saveCategory(form, id) {
  const fd = new FormData(form);
  const data = Object.fromEntries(fd);
  if (data.is_active === '1') data.is_active = 1; else data.is_active = 0;
  if (!data.parent_id) data.parent_id = null;
  if (!data.image) data.image = null;
  if (data.sort_order) data.sort_order = parseInt(data.sort_order);
  try {
    if (id) { await AdminAPI.put('/categories/' + id, data); showToast('Category updated'); }
    else { await AdminAPI.post('/categories', data); showToast('Category created'); }
    qs('.modal-overlay.active')?.classList.remove('active');
    initCategories();
  } catch (e) { showToast(e.message, 'error'); }
}

async function deleteCategory(id, name) {
  if (!confirm(`Delete category "${name}"?\nThis cannot be undone. Categories with subcategories or products cannot be deleted.`)) return;
  try {
    await AdminAPI.del('/categories/' + id);
    showToast('Category deleted');
    initCategories();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BRANDS ──────────────────────────────────────────────────────────────────
async function initBrands() {
  const el = $('page-brands');
  el.innerHTML = `<div class="admin-page-header"><h1>Brands</h1><button class="btn btn-primary" onclick="showAddBrand()">+ Add Brand</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead><tbody id="brandsBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/brands');
    $('brandsBody').innerHTML = res.data.items.map(b => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(b.name)}</div></td>
      <td>${b.product_count || 0}</td>
      <td><span class="badge ${b.is_active ? 'badge-success' : 'badge-secondary'}">${b.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditBrand(${b.id})">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteBrand(${b.id})">Delete</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddBrand() {
  showModal('Add Brand', `<form id="brandForm" onsubmit="saveBrand(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveBrand(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/brands', Object.fromEntries(fd)); showToast('Brand created'); qs('.modal-overlay.active')?.classList.remove('active'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── LOW STOCK ───────────────────────────────────────────────────────────────
async function initLowStock() {
  const el = $('page-low-stock');
  el.innerHTML = `<div class="admin-page-header"><h1>Low Stock Products</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>Stock</th><th>Threshold</th><th>Status</th></tr></thead><tbody id="lowStockBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/inventory/low-stock');
    $('lowStockBody').innerHTML = res.data.items.map(p => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(p.sku || '')}</div></td>
      <td><span class="badge ${p.stock_quantity === 0 ? 'badge-danger' : 'badge-warning'}">${p.stock_quantity}</span></td>
      <td>${p.low_stock_threshold}</td>
      <td><span class="badge ${p.stock_quantity === 0 ? 'badge-danger' : 'badge-warning'}">${p.stock_quantity === 0 ? 'Out of Stock' : 'Low Stock'}</span></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── CUSTOMERS ────────────────────────────────────────────────────────────────
async function initCustomers(type) {
  const el = $(`page-customers-${type}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${type === 'all' ? 'All' : type === 'vip' ? 'VIP' : 'Blacklisted'} Customers</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Customer</th><th>Email</th><th>Phone</th><th>Orders</th><th>Spent</th><th>Actions</th></tr></thead><tbody id="customersBody${type}"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get(`/customers?${type === 'vip' ? 'vip=1' : type === 'blacklist' ? 'blacklisted=1' : ''}`);
    $(`customersBody${type}`).innerHTML = (res.data.items || []).map(c => `<tr>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.first_name + ' ' + c.last_name)}</div></td>
      <td style="font-size:var(--text-xs);">${esc(c.email)}</td>
      <td>${c.phone || '-'}</td>
      <td>${c.total_orders || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.total_spent || 0)}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="viewCustomer(${c.id})">View</button></div></td>
    </tr>`).join('') || '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No customers found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── SHIPMENTS ────────────────────────────────────────────────────────────────
async function initShipments() {
  const el = $('page-shipment');
  el.innerHTML = `<div class="admin-page-header"><h1>Shipments</h1>
    <div style="display:flex;gap:var(--space-3);">
      <select class="form-select" id="shipmentFilter" style="width:auto;min-width:140px;" onchange="loadShipmentsPage(1)">
        <option value="">All Status</option><option value="pending">Pending</option><option value="in_transit">In Transit</option><option value="delivered">Delivered</option><option value="returned">Returned</option><option value="cancelled">Cancelled</option>
      </select>
      <button class="btn btn-primary" onclick="showCreateShipment()">+ New Shipment</button>
      <button class="btn btn-outline" onclick="syncShipments()">Sync Tracking</button>
    </div>
  </div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Consignment ID</th><th>Order</th><th>Courier</th><th>Tracking</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="shipmentsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>
  <div id="shipmentsPagination" style="display:flex;justify-content:center;padding:var(--space-4) 0;"></div>`;
  await loadShipmentsPage(1);
}

async function loadShipmentsPage(page) {
  try {
    const status = ($('shipmentFilter')?.value || '');
    const params = new URLSearchParams({ limit: '15', page: String(page) });
    if (status) params.set('status', status);
    const res = await AdminAPI.get(`/shipments?${params}`);
    const tbody = $('shipmentsBody');
    const statusBadge = { pending: 'badge-warning', confirmed: 'badge-info', picked: 'badge-primary', in_transit: 'badge-info', out_for_delivery: 'badge-primary', delivered: 'badge-success', returned: 'badge-secondary', cancelled: 'badge-danger' };
    tbody.innerHTML = res.data.items.map(s => `<tr>
      <td style="font-weight:var(--weight-bold);font-size:var(--text-sm);letter-spacing:0.05em;">${esc(s.consignment_id || '-')}</td>
      <td><a href="#" onclick="viewOrder(${s.order_id});return false" style="font-weight:var(--weight-semibold);">#${esc(s.order_number)}</a></td>
      <td style="font-size:var(--text-xs);">${esc(s.courier_name)}</td>
      <td style="font-size:var(--text-xs);">${esc(s.tracking_number || '-')}</td>
      <td><span class="badge ${statusBadge[s.status] || 'badge-secondary'} badge-dot">${esc(s.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(s.created_at)}</td>
      <td><div class="admin-actions">
        <button class="btn btn-sm btn-ghost" onclick="trackShipment(${s.id})">Track</button>
        <button class="btn btn-sm btn-ghost" onclick="editShipment(${s.id})">Edit</button>
        <button class="btn btn-sm btn-danger-ghost" onclick="deleteShipment(${s.id})">Delete</button>
      </div></td>
    </tr>`).join('') || '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">No shipments found</td></tr>';
    const pag = $('shipmentsPagination');
    if (pag) pag.innerHTML = pagination(res.data.pagination.total, page, 15, 'loadShipmentsPage');
  } catch (e) { showToast(e.message, 'error'); }
}

async function showCreateShipment() {
  try {
    const orders = await AdminAPI.get('/orders?limit=50&status=pending');
    const couriers = await AdminAPI.get('/couriers');
    const orderOpts = orders.data.items.map(o => `<option value="${o.id}">#${o.order_number} - ${currency(o.total)}</option>`).join('');
    const courierOpts = couriers.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    showModal('Create Shipment', `<form id="createShipmentForm" onsubmit="createShipment(this);return false">
      <div class="form-group"><label class="form-label">Order *</label><select class="form-select" name="order_id" required>${orderOpts}</select></div>
      <div class="form-group"><label class="form-label">Courier *</label><select class="form-select" name="courier_id" required>${courierOpts}</select></div>
      <button type="submit" class="btn btn-primary w-full" id="createShipBtn">Create Shipment</button>
    </form>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function createShipment(form) {
  const btn = $('createShipBtn'); loading(btn, true);
  try {
    const fd = new FormData(form);
    await AdminAPI.post('/shipments', { order_id: parseInt(fd.get('order_id')), courier_id: parseInt(fd.get('courier_id')) });
    showToast('Shipment created via courier API');
    qs('.modal-overlay.active')?.classList.remove('active');
    loadShipmentsPage(1);
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

async function trackShipment(id) {
  try {
    const res = await AdminAPI.post(`/shipments/${id}/track`);
    const t = res.data.tracking;
    showModal('Tracking Details', `<div style="display:grid;gap:var(--space-3);">
      <div><strong>Status:</strong> ${esc(t.status)}</div>
      <div><strong>Location:</strong> ${esc(t.currentLocation || 'N/A')}</div>
      <div><strong>Events:</strong></div>
      ${(t.events || []).length ? t.events.map(e => `<div style="display:flex;align-items:center;gap:var(--space-3);padding:var(--space-2) 0;border-bottom:1px solid var(--divider);"><span style="width:8px;height:8px;border-radius:50%;background:var(--primary);"></span><div><div style="font-size:var(--text-sm);">${esc(e.status || e.message || 'Update')}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${e.timestamp || e.time || ''}</div></div></div>`).join('') : '<div style="color:var(--text-muted);font-size:var(--text-sm);">No tracking events available</div>'}
    </div>`);
  } catch (e) { showToast(e.message, 'error'); }
}

async function editShipment(id) {
  showModal('Edit Shipment', `<form id="editShipForm" onsubmit="updateShipment(${id}, this);return false">
    <div class="form-group"><label class="form-label">Status</label>
    <select class="form-select" name="status"><option value="">Keep current</option><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="in_transit">In Transit</option><option value="delivered">Delivered</option><option value="cancelled">Cancelled</option><option value="returned">Returned</option></select></div>
    <div class="form-group"><label class="form-label">Tracking Number</label><input class="form-input" name="tracking_number"></div>
    <div class="form-group"><label class="form-label">Consignment ID</label><input class="form-input" name="consignment_id"></div>
    <button type="submit" class="btn btn-primary w-full">Update</button>
  </form>`);
}

async function updateShipment(id, form) {
  const fd = new FormData(form);
  const data = {};
  if (fd.get('status')) data.status = fd.get('status');
  if (fd.get('tracking_number')) data.tracking_number = fd.get('tracking_number');
  if (fd.get('consignment_id')) data.consignment_id = fd.get('consignment_id');
  try { await AdminAPI.put(`/shipments/${id}`, data); showToast('Shipment updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadShipmentsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteShipment(id) {
  if (!await showConfirm('Delete Shipment', 'Are you sure?')) return;
  try { await AdminAPI.del(`/shipments/${id}`); showToast('Shipment deleted'); loadShipmentsPage(1); }
  catch (e) { showToast(e.message, 'error'); }
}

async function syncShipments() {
  try {
    const res = await AdminAPI.post('/sync');
    showToast(res.message || 'Sync complete');
    loadShipmentsPage(1);
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BULK COURIER SEND ───────────────────────────────────────────────────────
async function initBulkCourierSend() {
  const el = $('page-bulk-courier-send');
  try {
    const orders = await AdminAPI.get('/orders?limit=100&status=pending');
    const couriers = await AdminAPI.get('/couriers');
    const orderRows = orders.data.items.map(o => `<tr>
      <td><label class="form-checkbox"><input type="checkbox" class="bulk-order" value="${o.id}"> #${esc(o.order_number)}</label></td>
      <td>${esc(o.customer_name || 'N/A')}</td>
      <td style="text-align:right;">${currency(o.total)}</td>
      <td>${o.payment_method || '-'}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(o.created_at)}</td>
    </tr>`).join('');
    const courierOpts = couriers.data.items.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');

    el.innerHTML = `<div class="admin-page-header"><h1>Bulk Courier Send</h1></div>
    <div class="admin-card"><div class="admin-card-body">
      <div style="display:flex;align-items:center;gap:var(--space-4);margin-bottom:var(--space-4);flex-wrap:wrap;">
        <div class="form-group" style="margin-bottom:0;"><label class="form-label">Courier</label><select class="form-select" id="bulkCourierId">${courierOpts}</select></div>
        <button class="btn btn-primary" onclick="executeBulkSend()" id="bulkSendBtn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg> Send Selected to Courier</button>
        <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-order').forEach(c=>c.checked=true)">Select All</button>
        <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-order').forEach(c=>c.checked=false)">Deselect All</button>
      </div>
      <div class="table-wrapper"><table class="table table-hover"><thead><tr><th style="width:40px;"></th><th>Order #</th><th>Customer</th><th style="text-align:right;">Total</th><th>Payment</th><th>Date</th></tr></thead><tbody>${orderRows}</tbody></table></div>
    </div></div>
    <div class="admin-card" id="bulkResultsCard" style="display:none;"><div class="admin-card-header"><h3>Bulk Send Results</h3></div><div class="admin-card-body" id="bulkResultsBody"></div></div>`;
  } catch (e) { showToast(e.message, 'error'); }
}

async function executeBulkSend() {
  const checked = [...document.querySelectorAll('.bulk-order:checked')].map(c => parseInt(c.value));
  if (!checked.length) { showToast('Select at least one order', 'error'); return; }
  const courierId = parseInt($('bulkCourierId').value);
  if (!courierId) { showToast('Select a courier', 'error'); return; }
  if (!await showConfirm('Bulk Send', `Send ${checked.length} order(s) to courier?`)) return;

  const btn = $('bulkSendBtn'); loading(btn, true);
  try {
    const res = await AdminAPI.post('/bulk-send', { order_ids: checked, courier_id: courierId });
    const results = res.data;
    const card = $('bulkResultsCard'); card.style.display = 'block';
    $('bulkResultsBody').innerHTML = `<div style="margin-bottom:var(--space-3);">
      <span class="badge badge-success">${results.success.length} Succeeded</span>
      <span class="badge badge-danger">${results.failed.length} Failed</span>
    </div>
    ${results.success.length ? `<h4 style="font-size:var(--text-sm);font-weight:var(--weight-semibold);margin-bottom:var(--space-2);">Success</h4>
    <div style="font-size:var(--text-sm);">${results.success.map(s => `<div style="padding:var(--space-2) 0;"># Order ${s.order_id} → Consignment: <strong>${s.consignment_id}</strong> (Shipment #${s.shipment_id})</div>`).join('')}</div>` : ''}
    ${results.failed.length ? `<h4 style="font-size:var(--text-sm);font-weight:var(--weight-semibold);margin-top:var(--space-3);margin-bottom:var(--space-2);color:var(--color-danger);">Failed</h4>
    <div style="font-size:var(--text-sm);">${results.failed.map(f => `<div style="padding:var(--space-2) 0;color:var(--color-danger);">Order ${f.order_id}: ${esc(f.error)}</div>`).join('')}</div>` : ''}`;
    showToast(res.message || 'Bulk send complete');
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── INVOICE PRINT ────────────────────────────────────────────────────────────
async function initInvoicePrint() {
  const el = $('page-invoice-print');
  el.innerHTML = `<div class="admin-page-header"><h1>Invoice Print</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <div class="form-row">
      <div class="form-group"><label class="form-label">Enter Order Number or ID</label>
        <div style="display:flex;gap:var(--space-3);">
          <input class="form-input" id="invoiceOrderInput" placeholder="e.g. BH-20250001 or Order ID" style="flex:1;min-height:44px;">
          <button class="btn btn-primary" onclick="loadInvoice()" id="loadInvoiceBtn" style="min-height:44px;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg> Load Invoice</button>
        </div>
      </div>
    </div>
    <div id="invoicePreview" style="display:none;"></div>
  </div></div>`;
}

async function loadInvoice() {
  const input = $('invoiceOrderInput').value.trim();
  if (!input) { showToast('Enter order number or ID', 'error'); return; }
  const btn = $('loadInvoiceBtn'); loading(btn, true);
  const el = $('invoicePreview');

  try {
    const orderId = /^\d+$/.test(input) ? parseInt(input) : null;
    let orderData;
    if (orderId) {
      const res = await AdminAPI.get(`/orders/${orderId}`);
      orderData = { order: res.data.order, customer: res.data.order, items: res.data.order.items || [] };
    } else {
      const res = await AdminAPI.get(`/orders?search=${encodeURIComponent(input)}`);
      if (!res.data.items.length) throw new Error('Order not found');
      const o = res.data.items[0];
      const detail = await AdminAPI.get(`/orders/${o.id}`);
      orderData = { order: detail.data.order, customer: detail.data.order, items: detail.data.order.items || [] };
    }

    // Fetch invoice data with consignment info
    let invoiceData = { courier: { consignment_id: '', tracking_number: '', name: '' } };
    try {
      const inv = await AdminAPI.get(`/invoice/${orderData.order.id}`);
      invoiceData = inv.data;
    } catch (e) { /* no invoice data available */ }

    const o = orderData.order;
    const consignmentId = (invoiceData.courier?.consignment_id || '').toString();
    const consignmentFormatted = consignmentId.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3') || consignmentId;
    const courierName = invoiceData.courier?.name || 'Steadfast';

    // Status color map
    const statusColors = {
      pending: '#fef3cd', confirmed: '#d1ecf1', packaging: '#cce5ff',
      ready_to_ship: '#d4edda', courier_sent: '#d4edda', in_transit: '#fff3cd',
      delivered: '#d4edda', cancelled: '#f8d7da', returned: '#f8d7da', exchanged: '#cce5ff'
    };
    const statusTextColors = {
      pending: '#856404', confirmed: '#0c5460', packaging: '#004085',
      ready_to_ship: '#155724', courier_sent: '#155724', in_transit: '#856404',
      delivered: '#155724', cancelled: '#721c24', returned: '#721c24', exchanged: '#004085'
    };
    const statusLabel = o.status === 'ready_to_ship' ? 'Ready to Ship' : o.status === 'courier_sent' ? 'Sent to Courier' : o.status.charAt(0).toUpperCase() + o.status.slice(1).replace(/_/g, ' ');

    // Build status timeline
    const statusTimeline = (o.status_history || []).slice(0, 5).map(s => {
      const label = s.status === 'ready_to_ship' ? 'Ready to Ship' : s.status === 'courier_sent' ? 'Sent to Courier' : s.status.charAt(0).toUpperCase() + s.status.slice(1).replace(/_/g, ' ');
      const sc = statusColors[s.status] || '#f5f5f5';
      return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
        <div style="width:10px;height:10px;border-radius:50%;background:${sc === '#d4edda' ? '#28a745' : sc === '#fef3cd' ? '#ffc107' : sc === '#d1ecf1' ? '#17a2b8' : sc === '#cce5ff' ? '#007bff' : '#6c757d'};flex-shrink:0;"></div>
        <div style="flex:1;"><span style="font-size:12px;font-weight:600;color:#333;">${esc(label)}</span><span style="font-size:11px;color:#999;margin-left:8px;">${s.created_at ? dateStr(s.created_at) : ''}</span></div>
        ${s.note ? `<span style="font-size:11px;color:#888;">${esc(s.note)}</span>` : ''}
      </div>`;
    }).join('') || '<div style="font-size:12px;color:#999;">No status updates recorded.</div>';

    // Build payment info
    const paymentRef = o.payment_reference || (o.payments && o.payments[0]?.reference) || '';
    const pmtMethod = o.payment_method || (o.payments && o.payments[0]?.method) || 'N/A';
    const pmtStatus = o.payment_status || 'pending';

    // Build items table
    const items = orderData.items.map((i, idx) => {
      const variant = i.variant_id ? ` (${i.product_sku || 'N/A'})` : ` (${i.product_sku || 'N/A'})`;
      return `<tr${idx % 2 !== 0 ? ' style="background:#f9f9f9;"' : ''}>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;font-size:13px;color:#222;">
          <span style="font-weight:500;">${++idx}. ${esc(i.product_name)}</span>
          <span style="font-size:11px;color:#999;display:block;">SKU: ${esc(i.product_sku || 'N/A')}</span>
        </td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:center;font-size:13px;color:#333;">${i.quantity}</td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:right;font-size:13px;color:#555;">${currency(i.price)}</td>
        <td style="padding:8px 10px;border:1px solid #e0e0e0;text-align:right;font-size:13px;font-weight:600;color:#222;">${currency(i.total)}</td>
      </tr>`;
    }).join('');

    // Shipping address text
    const sa = invoiceData.shipping_address || {};
    const addrParts = [sa.address, sa.line1, sa.line2, sa.city, sa.state, sa.zip, sa.country].filter(Boolean);
    const shipAddr = addrParts.join(', ') || esc(o.shipping_address?.address || o.shipping_address?.line1 || '');

    el.style.display = 'block';
    el.innerHTML = `<div style="background:#fff;color:#222;font-family:'Inter','Segoe UI',sans-serif;max-width:800px;margin:0 auto;border-radius:16px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.12);" id="printArea">

      <!-- ═══ TOP BRAND BAR ═══ -->
      <div style="background:linear-gradient(135deg,#dc143c,#b01030);padding:22px 32px;display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:36px;height:36px;background:rgba(255,255,255,0.2);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:#fff;font-family:sans-serif;">B</div>
            <div>
              <h1 style="margin:0;font-size:24px;font-weight:800;color:#fff;letter-spacing:1px;">বাঙালিরহাট</h1>
              <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">Premium Bangladeshi E-Commerce</p>
            </div>
          </div>
        </div>
        <div style="text-align:right;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.85);">Gulshan 2, Dhaka, Bangladesh</p>
          <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">support@bangalirhaat.com</p>
          <p style="margin:2px 0 0;font-size:12px;color:rgba(255,255,255,0.75);">+880 1700-000000</p>
        </div>
      </div>

      <!-- ═══ INVOICE INFO + STATUS ═══ -->
      <div style="display:flex;justify-content:space-between;align-items:stretch;padding:20px 32px;background:#fafafa;border-bottom:1px solid #eee;">
        <div style="flex:1;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
            <p style="margin:0;font-size:11px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Invoice</p>
            <span style="display:inline-block;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:600;background:${statusColors[o.status] || '#f5f5f5'};color:${statusTextColors[o.status] || '#666'};">${esc(statusLabel)}</span>
          </div>
          <h2 style="margin:0;font-size:20px;font-weight:700;color:#222;">${esc(o.order_number)}</h2>
          <div style="display:flex;gap:24px;margin-top:8px;flex-wrap:wrap;">
            <div><span style="font-size:12px;color:#999;">Date:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.created_at)}</span></div>
            <div><span style="font-size:12px;color:#999;">Items:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${orderData.items.length}</span></div>
            ${o.shipped_at ? `<div><span style="font-size:12px;color:#999;">Shipped:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.shipped_at)}</span></div>` : ''}
            ${o.delivered_at ? `<div><span style="font-size:12px;color:#999;">Delivered:</span><span style="font-size:13px;color:#333;margin-left:4px;font-weight:500;">${dateStr(o.delivered_at)}</span></div>` : ''}
          </div>
        </div>
        ${consignmentId ? `<div style="background:#111;border-radius:10px;padding:12px 22px;text-align:center;display:flex;flex-direction:column;justify-content:center;min-width:200px;">
          <p style="margin:0 0 4px;font-size:9px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:1.5px;">Steadfast Consignment</p>
          <p style="margin:0;font-size:28px;font-weight:900;letter-spacing:6px;color:#fff;font-family:'Courier New',monospace;">${esc(consignmentFormatted)}</p>
          ${invoiceData.courier?.tracking_number ? `<p style="margin:4px 0 0;font-size:10px;color:rgba(255,255,255,0.4);">Tracking: ${esc(invoiceData.courier.tracking_number)}</p>` : ''}
        </div>` : ''}
      </div>

      <!-- ═══ CUSTOMER & SHIPPING ═══ -->
      <div style="display:flex;padding:18px 32px;border-bottom:1px solid #eee;gap:40px;">
        <div style="flex:1;">
          <p style="margin:0 0 6px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Bill To</p>
          <p style="margin:0;font-size:15px;font-weight:600;color:#222;">${esc(invoiceData.customer?.name || orderData.customer?.customer_name || 'N/A')}</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">${esc(invoiceData.customer?.phone || '')}</p>
          <p style="margin:2px 0 0;font-size:13px;color:#555;">${esc(invoiceData.customer?.email || o.customer_email || '')}</p>
        </div>
        <div style="flex:1;">
          <p style="margin:0 0 6px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Shipping Address</p>
          <p style="margin:0;font-size:13px;color:#555;">${shipAddr || 'N/A'}</p>
          ${o.notes ? `<p style="margin:6px 0 0;font-size:12px;color:#888;font-style:italic;">📝 ${esc(o.notes)}</p>` : ''}
        </div>
      </div>

      <!-- ═══ PAYMENT INFO ═══ -->
      <div style="display:flex;padding:14px 32px;border-bottom:1px solid #eee;gap:40px;background:#fcfcfc;">
        <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
          <div><span style="font-size:12px;color:#999;">Method:</span><span style="font-size:13px;color:#333;font-weight:500;margin-left:4px;">${esc(pmtMethod)}</span></div>
          <div><span style="font-size:12px;color:#999;">Status:</span><span style="display:inline-block;margin-left:4px;padding:1px 8px;border-radius:99px;font-size:11px;font-weight:600;background:${pmtStatus === 'paid' ? '#d4edda' : pmtStatus === 'pending' ? '#fef3cd' : '#f8d7da'};color:${pmtStatus === 'paid' ? '#155724' : pmtStatus === 'pending' ? '#856404' : '#721c24'};">${esc(pmtStatus)}</span></div>
          ${paymentRef ? `<div><span style="font-size:12px;color:#999;">Reference:</span><span style="font-size:13px;color:#333;font-weight:500;margin-left:4px;">${esc(paymentRef)}</span></div>` : ''}
        </div>
      </div>

      <!-- ═══ PRODUCTS TABLE ═══ -->
      <div style="padding:18px 32px;">
        <p style="margin:0 0 10px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Order Items <span style="font-weight:400;color:#bbb;">(${orderData.items.length} item${orderData.items.length > 1 ? 's' : ''})</span></p>
        <table style="width:100%;border-collapse:collapse;">
          <thead><tr style="background:#dc143c;color:#fff;">
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:left;">Product</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:center;width:55px;">Qty</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:right;width:95px;">Price</th>
            <th style="padding:8px 10px;font-size:12px;font-weight:600;text-align:right;width:95px;">Total</th>
          </tr></thead>
          <tbody>${items || '<tr><td colspan="4" style="padding:16px;text-align:center;color:#999;font-size:13px;">No items found.</td></tr>'}</tbody>
        </table>
      </div>

      <!-- ═══ TOTALS ═══ -->
      <div style="padding:8px 32px 18px;display:flex;justify-content:flex-end;">
        <div style="min-width:280px;">
          <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Subtotal</span><span style="font-weight:500;">${currency(o.subtotal)}</span></div>
          ${o.discount ? `<div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#e53e3e;"><span>Discount</span><span style="font-weight:500;">-${currency(o.discount)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Shipping</span><span style="font-weight:500;">${currency(o.shipping_cost)}</span></div>
          ${o.tax ? `<div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px;color:#555;"><span>Tax</span><span style="font-weight:500;">${currency(o.tax)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between;padding:9px 0 0;margin-top:5px;border-top:2px solid #222;font-size:20px;font-weight:700;color:#222;"><span>Total</span><span>${currency(o.total)}</span></div>
          ${o.delivery_charge ? `<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:12px;color:#888;"><span>Delivery Charge</span><span>${currency(o.delivery_charge)}</span></div>` : ''}
        </div>
      </div>

      <!-- ═══ STATUS TIMELINE ═══ -->
      ${(o.status_history && o.status_history.length > 0) ? `
      <div style="padding:16px 32px;border-top:1px solid #eee;background:#fcfcfc;">
        <p style="margin:0 0 10px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Order Timeline</p>
        <div style="padding-left:4px;">${statusTimeline}</div>
      </div>` : ''}

      <!-- ═══ FOOTER ═══ -->
      <div style="background:#fafafa;padding:14px 32px;text-align:center;border-top:1px solid #eee;">
        <p style="margin:0;font-size:12px;color:#999;">Thank you for shopping at Bangalirhaat! ❤️</p>
        <p style="margin:4px 0 0;font-size:11px;color:#bbb;">This is a computer-generated invoice. No signature required.</p>
      </div>

      <!-- ═══ PRINT BUTTON ═══ -->
      <div style="text-align:center;padding:18px 32px;">
        <button class="btn btn-primary" onclick="window.print()" style="padding:10px 36px;font-size:14px;border-radius:8px;">🖨️ Print Invoice</button>
      </div>
    </div>`;
  } catch (e) { showToast(e.message, 'error'); } finally { loading(btn, false); }
}

// ── BULK INVOICE PRINT ──────────────────────────────────────────────────────
async function initBulkInvoicePrint() {
  const el = $('page-invoice-bulk-print');
  el.innerHTML = `<div class="admin-page-header"><h1>Bulk Invoice Print</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <div style="margin-bottom:var(--space-4);">
      <label class="form-label">Select Orders</label>
      <div id="bulkInvoiceOrders"><div style="text-align:center;padding:20px;color:var(--text-muted);">Loading orders...</div></div>
    </div>
    <div style="display:flex;gap:var(--space-3);flex-wrap:wrap;">
      <button class="btn btn-primary" id="printSelectedInvoices" onclick="printSelectedInvoices()" disabled>🖨️ Print Selected (0)</button>
      <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-inv-order').forEach(c=>c.checked=true);updateBulkInvoiceCount()">Select All</button>
      <button class="btn btn-sm btn-ghost" onclick="document.querySelectorAll('.bulk-inv-order').forEach(c=>c.checked=false);updateBulkInvoiceCount()">Deselect All</button>
    </div>
  </div></div>`;

  try {
    const res = await AdminAPI.get('/orders?limit=50');
    const html = res.data.items.map(o => `<tr>
      <td><label class="form-checkbox"><input type="checkbox" class="bulk-inv-order" value="${o.id}" onchange="updateBulkInvoiceCount()"> #${esc(o.order_number)}</label></td>
      <td>${esc(o.customer_name || 'N/A')}</td>
      <td style="text-align:right;">${currency(o.total)}</td>
      <td><span class="badge ${o.status === 'delivered' ? 'badge-success' : 'badge-warning'}">${esc(o.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${dateStr(o.created_at)}</td>
    </tr>`).join('');
    $('bulkInvoiceOrders').innerHTML = `<div class="table-wrapper"><table class="table table-hover"><thead><tr><th style="width:40px;"></th><th>Order #</th><th>Customer</th><th style="text-align:right;">Total</th><th>Status</th><th>Date</th></tr></thead><tbody>${html}</tbody></table></div>`;
  } catch (e) { showToast(e.message, 'error'); }
}

function updateBulkInvoiceCount() {
  const count = document.querySelectorAll('.bulk-inv-order:checked').length;
  const btn = $('printSelectedInvoices');
  btn.textContent = `🖨️ Print Selected (${count})`;
  btn.disabled = count === 0;
}

async function printSelectedInvoices() {
  const checked = [...document.querySelectorAll('.bulk-inv-order:checked')].map(c => parseInt(c.value));
  if (!checked.length) return;
  showToast(`Loading ${checked.length} invoices for printing...`);

  try {
    const orders = [];
    for (const id of checked) {
      try {
        const o = await AdminAPI.get(`/orders/${id}`);
        let inv = { courier: { consignment_id: '', tracking_number: '', name: '' } };
        try { inv = await AdminAPI.get(`/invoice/${id}`); } catch (e) {}
        orders.push({ ...o.data.order, items: o.data.order.items || [], invoice: inv.data || inv });
      } catch (e) { console.error('Failed to load order', id, e); }
    }

    const printWin = window.open('', '_blank', 'width=900,height=700');
    printWin.document.write(`<html><head><title>Invoices - Bangalirhaat</title><style>
      @page { margin: 8mm; }
      body { font-family: 'Inter','Segoe UI',sans-serif; font-size: 12px; color: #222; margin:0; padding:0; }
      .invoice-page { page-break-after: always; max-width: 800px; margin: 16px auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.1); }
      .invoice-page:last-child { page-break-after: avoid; }
      .brand-bar { background:linear-gradient(135deg,#dc143c,#b01030); padding:18px 28px; display:flex; justify-content:space-between; align-items:center; }
      .brand-bar h1 { margin:0; font-size:22px; font-weight:800; color:#fff; letter-spacing:1px; }
      .brand-bar p { margin:2px 0 0; font-size:11px; color:rgba(255,255,255,0.85); }
      .info-row { display:flex; justify-content:space-between; align-items:stretch; padding:16px 28px; background:#fafafa; border-bottom:1px solid #eee; }
      .consignment-box { background:#111; border-radius:8px; padding:10px 18px; text-align:center; display:flex; flex-direction:column; justify-content:center; }
      .consignment-box .label { margin:0 0 3px; font-size:9px; font-weight:600; color:rgba(255,255,255,0.5); text-transform:uppercase; letter-spacing:1.5px; }
      .consignment-box .id { margin:0; font-size:24px; font-weight:900; letter-spacing:5px; color:#fff; font-family:'Courier New',monospace; }
      .section { padding:14px 28px; border-bottom:1px solid #eee; }
      .section-title { margin:0 0 8px; font-size:10px; font-weight:600; color:#999; text-transform:uppercase; letter-spacing:1px; }
      .customer-row { display:flex; padding:14px 28px; border-bottom:1px solid #eee; gap:32px; }
      .customer-col { flex:1; }
      .customer-col .label { font-size:10px; font-weight:600; color:#999; text-transform:uppercase; letter-spacing:1px; margin:0 0 5px; }
      table { width:100%; border-collapse:collapse; }
      th { background:#dc143c; color:#fff; padding:7px 10px; font-size:11px; font-weight:600; text-align:left; }
      td { padding:7px 10px; font-size:12px; border:1px solid #e0e0e0; }
      tr:nth-child(even) { background:#f9f9f9; }
      .sku { font-size:10px; color:#999; display:block; }
      .totals { min-width:250px; margin-left:auto; }
      .totals .row { display:flex; justify-content:space-between; padding:4px 0; font-size:13px; color:#555; }
      .totals .total { padding:8px 0 0; margin-top:4px; border-top:2px solid #222; font-size:17px; font-weight:700; color:#222; }
      .footer-bar { background:#fafafa; padding:12px 28px; text-align:center; border-top:1px solid #eee; }
      .footer-bar p { margin:0; font-size:11px; color:#999; }
    </style></head><body>`);

    for (const o of orders) {
      const cid = (o.invoice?.courier?.consignment_id || '').toString();
      const cidFormatted = cid.replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3') || cid;
      const customer = o.invoice?.customer || {};
      const shipAddr = o.shipping_address ? (typeof o.shipping_address === 'string' ? JSON.parse(o.shipping_address) : o.shipping_address) : {};
      const addrParts = [shipAddr.address, shipAddr.line1, shipAddr.line2, shipAddr.city, shipAddr.state, shipAddr.zip, shipAddr.country].filter(Boolean);
      const addrText = addrParts.join(', ') || `${shipAddr.city || ''} ${shipAddr.zip || ''}`.trim() || 'N/A';

      const items = (o.items || []).map((i, idx) => {
        return `<tr${idx % 2 !== 0 ? ' style="background:#f9f9f9;"' : ''}>
          <td><span style="font-weight:500;">${++idx}. ${esc(i.product_name)}</span><span class="sku">SKU: ${esc(i.product_sku || 'N/A')}</span></td>
          <td style="text-align:center;">${i.quantity}</td>
          <td style="text-align:right;color:#555;">${currency(i.price)}</td>
          <td style="text-align:right;font-weight:600;">${currency(i.total)}</td>
        </tr>`;
      }).join('');
      printWin.document.write(`<div class="invoice-page">
        <div class="brand-bar">
          <div><h1>বাঙালিরহাট</h1><p>Premium Bangladeshi E-Commerce</p></div>
          <div style="text-align:right;"><p>Gulshan 2, Dhaka, Bangladesh</p><p>support@bangalirhaat.com | +880 1700-000000</p></div>
        </div>
        <div class="info-row">
          <div>
            <p style="margin:0 0 2px;font-size:10px;font-weight:600;color:#999;text-transform:uppercase;letter-spacing:1px;">Invoice</p>
            <p style="margin:0;font-size:17px;font-weight:700;">${esc(o.order_number)}</p>
            <p style="margin:4px 0 0;font-size:12px;color:#666;">${dateStr(o.created_at)} | ${o.items ? o.items.length + ' item(s)' : ''}</p>
          </div>
          ${cid ? `<div class="consignment-box"><p class="label">Steadfast Consignment</p><p class="id">${esc(cidFormatted)}</p></div>` : ''}
        </div>
        <div class="customer-row">
          <div class="customer-col">
            <p class="label">Customer</p>
            <p style="margin:0;font-size:14px;font-weight:600;color:#222;">${esc(customer.name || o.customer_name || 'N/A')}</p>
            <p style="margin:2px 0 0;font-size:12px;color:#555;">${esc(customer.phone || o.customer_phone || '')}</p>
            <p style="margin:2px 0 0;font-size:12px;color:#555;">${esc(customer.email || o.customer_email || '')}</p>
          </div>
          <div class="customer-col">
            <p class="label">Shipping Address</p>
            <p style="margin:0;font-size:12px;color:#555;">${esc(addrText)}</p>
          </div>
        </div>
        <div class="section">
          <p class="section-title">Order Items</p>
          <table><thead><tr><th>Product</th><th style="text-align:center;width:50px;">Qty</th><th style="text-align:right;width:85px;">Price</th><th style="text-align:right;width:85px;">Total</th></tr></thead><tbody>${items || '<tr><td colspan="4" style="text-align:center;color:#999;">No items</td></tr>'}</tbody></table>
        </div>
        <div style="padding:10px 28px 16px;display:flex;justify-content:flex-end;">
          <div class="totals">
            <div class="row"><span>Subtotal</span><span style="font-weight:500;">${currency(o.subtotal)}</span></div>
            ${o.discount ? `<div class="row" style="color:#e53e3e;"><span>Discount</span><span style="font-weight:500;">-${currency(o.discount)}</span></div>` : ''}
            <div class="row"><span>Shipping</span><span style="font-weight:500;">${currency(o.shipping_cost)}</span></div>
            ${o.tax ? `<div class="row"><span>Tax</span><span style="font-weight:500;">${currency(o.tax)}</span></div>` : ''}
            <div class="total"><span>Total</span><span>${currency(o.total)}</span></div>
          </div>
        </div>
        <div class="footer-bar"><p>Thank you for shopping at Bangalirhaat! ❤️</p></div>
      </div>`);
    }
    printWin.document.write('</body></html>');
    printWin.document.close();
    setTimeout(() => { printWin.print(); }, 500);
  } catch (e) { showToast(e.message, 'error'); }
}

// ── DELIVERY ─────────────────────────────────────────────────────────────────
async function initDelivery() {
  const el = $('page-delivery');
  el.innerHTML = `<div class="admin-page-header"><h1>Delivery Management</h1></div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(4,1fr);">
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">In Transit</div><div class="admin-stat-value" id="delInTransit">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Out for Delivery</div><div class="admin-stat-value" id="delOutFor">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Delivered Today</div><div class="admin-stat-value" id="delToday">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Returned</div><div class="admin-stat-value" id="delReturned">-</div></div></div>
  </div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Order</th><th>Courier</th><th>Consignment</th><th>Status</th><th>Actions</th></tr></thead><tbody><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/shipments?limit=20');
    const s = res.data.items;
    if ($('delInTransit')) $('delInTransit').textContent = s.filter(x => x.status === 'in_transit').length;
    if ($('delOutFor')) $('delOutFor').textContent = s.filter(x => x.status === 'out_for_delivery').length;
    if ($('delToday')) $('delToday').textContent = s.filter(x => x.status === 'delivered').length;
    if ($('delReturned')) $('delReturned').textContent = s.filter(x => x.status === 'returned').length;
  } catch (e) { /* ignore */ }
}

// ── DELIVERY ZONES ──────────────────────────────────────────────────────────
function initDeliveryZones() {
  $('page-delivery-zones').innerHTML = `<div class="admin-page-header"><h1>Delivery Zones</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <p style="color:var(--text-muted);margin-bottom:var(--space-4);">Manage delivery zones and shipping rates.</p>
    <div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Zone</th><th>Inside Dhaka</th><th>Outside Dhaka</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <tr><td>Dhaka Metro</td><td>৳60</td><td>-</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
      <tr><td>Chattogram</td><td>৳100</td><td>৳130</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
      <tr><td>Other Divisions</td><td>৳120</td><td>৳150</td><td><span class="badge badge-success">Active</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost">Edit</button></div></td></tr>
    </tbody></table></div>
    <button class="btn btn-primary" style="margin-top:var(--space-4);">+ Add Zone</button>
  </div></div>`;
}

// ── COURIER SETTINGS ────────────────────────────────────────────────────────
async function initCourierSettings() {
  const el = $('page-settings-courier');
  try {
    const couriers = await AdminAPI.get('/couriers');
    const cards = couriers.data.items.map(c => `<div class="admin-card">
      <div class="admin-card-header"><h3>${esc(c.name)}</h3><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></div>
      <div class="admin-card-body">
        <form onsubmit="updateCourier(${c.id}, this);return false">
          <div class="form-row">
            <div class="form-group"><label class="form-label">API Key</label><input class="form-input" name="api_key" value="${esc(c.api_key || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
            <div class="form-group"><label class="form-label">API Secret</label><input class="form-input" name="api_secret" type="password" value="${esc(c.api_secret || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
          </div>
          <div class="form-group"><label class="form-label">API URL</label><input class="form-input" name="api_url" value="${esc(c.api_url || '')}" style="font-family:monospace;font-size:var(--text-xs);"></div>
          <div class="form-group"><label class="form-label">Shipments: ${c.total_shipments || 0} total, ${c.active_shipments || 0} active</label></div>
          <div style="display:flex;gap:var(--space-3);">
            <button type="submit" class="btn btn-primary">Save</button>
            ${c.slug?.includes('steadfast') ? `<button type="button" class="btn btn-outline" onclick="checkSteadfastBalance()">Check Balance</button>` : ''}
          </div>
        </form>
      </div>
    </div>`).join('');
    el.innerHTML = `<div class="admin-page-header"><h1>Courier Settings</h1></div>${cards}`;
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateCourier(id, form) {
  const fd = new FormData(form);
  try {
    await AdminAPI.put(`/couriers/${id}`, Object.fromEntries(fd));
    showToast('Courier settings saved');
  } catch (e) { showToast(e.message, 'error'); }
}

async function checkSteadfastBalance() {
  try { const res = await AdminAPI.get('/steadfast/balance'); showModal('SteadFast Balance', `<pre>${JSON.stringify(res.data, null, 2)}</pre>`); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── COUPONS ──────────────────────────────────────────────────────────────────
async function initCoupons() {
  const el = $('page-marketing-coupons');
  el.innerHTML = `<div class="admin-page-header"><h1>Coupons</h1><button class="btn btn-primary" onclick="showAddCoupon()">+ Add Coupon</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Used</th><th>Status</th><th>Actions</th></tr></thead><tbody id="couponsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/marketing/coupons');
    $('couponsBody').innerHTML = res.data.items.map(c => `<tr>
      <td style="font-weight:var(--weight-bold);font-family:monospace;">${esc(c.code)}</td>
      <td>${c.type}</td>
      <td>${c.type === 'percentage' ? c.value + '%' : c.type === 'fixed' ? currency(c.value) : 'Free Shipping'}</td>
      <td>${currency(c.minimum_order)}</td>
      <td>${c.used_count || 0}${c.usage_limit ? '/' + c.usage_limit : ''}</td>
      <td><span class="badge ${c.is_active ? 'badge-success' : 'badge-secondary'}">${c.is_active ? 'Active' : 'Inactive'}</span></td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditCoupon(${c.id})">Edit</button></div></td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddCoupon() {
  showModal('Add Coupon', `<form id="couponForm" onsubmit="saveCoupon(this);return false">
    <div class="form-group"><label class="form-label">Code *</label><input class="form-input" name="code" required style="text-transform:uppercase;"></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Type</label><select class="form-select" name="type"><option value="percentage">Percentage</option><option value="fixed">Fixed</option><option value="free_shipping">Free Shipping</option></select></div>
    <div class="form-group"><label class="form-label">Value</label><input class="form-input" name="value" type="number" step="0.01"></div></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Min Order</label><input class="form-input" name="minimum_order" type="number" value="0"></div>
    <div class="form-group"><label class="form-label">Usage Limit</label><input class="form-input" name="usage_limit" type="number" placeholder="Unlimited"></div></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveCoupon(form) {
  const fd = new FormData(form);
  try {     await AdminAPI.post('/marketing/coupons', Object.fromEntries(fd)); showToast('Coupon created'); qs('.modal-overlay.active')?.classList.remove('active'); initCoupons(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── CAMPAIGNS ────────────────────────────────────────────────────────────────
async function initCampaigns() {
  const el = $('page-marketing-campaigns');
  el.innerHTML = `<div class="admin-page-header"><h1>Campaigns</h1><button class="btn btn-primary" onclick="showAddCampaign()">+ New Campaign</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Type</th><th>Subject</th><th>Status</th><th>Scheduled</th><th>Actions</th></tr></thead><tbody id="campaignsBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/marketing/campaigns');
    $('campaignsBody').innerHTML = (res.data.items || []).map(c => `<tr>
      <td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.name)}</td>
      <td><span class="badge badge-info">${esc(c.type)}</span></td>
      <td style="font-size:var(--text-xs);">${esc(c.subject || '-')}</td>
      <td><span class="badge ${c.status === 'sent' ? 'badge-success' : c.status === 'draft' ? 'badge-secondary' : 'badge-warning'}">${esc(c.status)}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${c.scheduled_at ? dateStr(c.scheduled_at) : '-'}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast('View campaign: implement')">View</button></div></td>
    </tr>`).join('') || '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No campaigns</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddCampaign() {
  showModal('New Campaign', `<form id="campaignForm" onsubmit="saveCampaign(this);return false">
    <div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Type</label><select class="form-select" name="type"><option value="email">Email</option><option value="sms">SMS</option><option value="push">Push</option></select></div>
    <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status"><option value="draft">Draft</option><option value="active">Active</option></select></div></div>
    <div class="form-group"><label class="form-label">Subject</label><input class="form-input" name="subject"></div>
    <div class="form-group"><label class="form-label">Content *</label><textarea class="form-input" name="content" rows="4" required></textarea></div>
    <button type="submit" class="btn btn-primary w-full">Save Campaign</button>
  </form>`);
}

async function saveCampaign(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/marketing/campaigns', Object.fromEntries(fd)); showToast('Campaign created'); qs('.modal-overlay.active')?.classList.remove('active'); initCampaigns(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FLASH SALES ─────────────────────────────────────────────────────────────
async function initFlashSales() {
  const el = $('page-flash-sales');
  el.innerHTML = `<div class="admin-page-header"><h1>Flash Sales</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product ID</th><th>Discount</th><th>Start</th><th>End</th><th>Status</th></tr></thead><tbody id="flashSalesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/products?limit=50&is_featured=1');
    $('flashSalesBody').innerHTML = res.data.items.map(p => `<tr>
      <td>${p.id}</td>
      <td><span class="badge badge-danger">${p.compare_price ? Math.round((1 - p.price / p.compare_price) * 100) + '%' : 'N/A'}</span></td>
      <td style="font-size:var(--text-xs);">-</td>
      <td style="font-size:var(--text-xs);">-</td>
      <td><span class="badge badge-success">Active</span></td>
    </tr>`).join('') || '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No flash sales active</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── FINANCE ──────────────────────────────────────────────────────────────────
async function initFinanceOverview() {
  const el = $('page-finance-overview');
  el.innerHTML = `<div class="admin-page-header"><h1>Finance Overview</h1></div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(4,1fr);">
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Total Revenue</div><div class="admin-stat-value" id="finRevenue">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Paid Orders</div><div class="admin-stat-value" id="finPaid">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Pending Payments</div><div class="admin-stat-value" id="finPending">-</div></div></div>
    <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Avg Order Value</div><div class="admin-stat-value" id="finAvg">-</div></div></div>
  </div>`;
  // Load from analytics endpoint
  try {
    const res = await AdminAPI.get('/analytics?period=monthly');
    const items = res.data.items || [];
    const totalRev = items.reduce((s, i) => s + (i.total_revenue || 0), 0);
    const totalOrders = items.reduce((s, i) => s + (i.total_orders || 0), 0);
    if ($('finRevenue')) $('finRevenue').textContent = currency(totalRev);
    if ($('finAvg')) $('finAvg').textContent = totalOrders ? currency(totalRev / totalOrders) : '৳0';
  } catch (e) { /* ignore */ }
}

// ── REPORTS ──────────────────────────────────────────────────────────────────
async function initReports(period) {
  const el = $(`page-report-${period}`); if (!el) return;
  el.innerHTML = `<div class="admin-page-header"><h1>${period.charAt(0).toUpperCase() + period.slice(1)} Report</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <canvas id="reportChart${period}" style="max-height:400px;"></canvas>
  </div></div>`;
  try {
    const res = await AdminAPI.get(`/analytics?period=${period}`);
    const data = res.data.items || [];
    if (window.Chart) {
      new Chart(document.getElementById(`reportChart${period}`), {
        type: 'line',
        data: {
          labels: data.map(d => d.period).reverse(),
          datasets: [
            { label: 'Revenue', data: data.map(d => d.total_revenue).reverse(), borderColor: '#dc143c', tension: 0.4, fill: false },
            { label: 'Orders', data: data.map(d => d.total_orders).reverse(), borderColor: '#2563eb', tension: 0.4, fill: false, yAxisID: 'y1' },
          ]
        },
        options: { responsive: true, interaction: { mode: 'index', intersect: false }, scales: { y1: { position: 'right', grid: { drawOnChartArea: false } } } }
      });
    }
  } catch (e) { /* ignore */ }
}

// ── TOP PRODUCTS REPORT ──────────────────────────────────────────────────────
async function initTopProductsReport() {
  const el = $('page-report-top-products');
  el.innerHTML = `<div class="admin-page-header"><h1>Top Products</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>#</th><th>Product</th><th>Category</th><th>Sold</th><th>Revenue</th></tr></thead><tbody id="topProdBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/products?limit=20&sort=popular');
    $('topProdBody').innerHTML = res.data.items.map((p, i) => `<tr>
      <td>${i + 1}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(p.name)}</div></td>
      <td style="font-size:var(--text-xs);">${esc(p.category_name || '')}</td>
      <td>${p.total_sold || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency((p.total_sold || 0) * p.price)}</td>
    </tr>`).join('');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── TOP CUSTOMERS REPORT ─────────────────────────────────────────────────────
async function initTopCustomersReport() {
  const el = $('page-report-top-customers');
  el.innerHTML = `<div class="admin-page-header"><h1>Top Customers</h1></div><div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>#</th><th>Customer</th><th>Orders</th><th>Total Spent</th></tr></thead><tbody id="topCustBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/customers');
    const sorted = (res.data.items || []).sort((a, b) => (b.total_spent || 0) - (a.total_spent || 0)).slice(0, 20);
    $('topCustBody').innerHTML = sorted.map((c, i) => `<tr>
      <td>${i + 1}</td>
      <td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.first_name + ' ' + c.last_name)}</div><div style="font-size:var(--text-xs);color:var(--text-muted);">${esc(c.email)}</div></td>
      <td>${c.total_orders || 0}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.total_spent || 0)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No data</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── EXPENSES ─────────────────────────────────────────────────────────────────
function initExpenses() {
  $('page-expenses').innerHTML = `<div class="admin-page-header"><h1>Expenses</h1><button class="btn btn-primary" onclick="showAddExpense()">+ Add Expense</button></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Category</th><th>Description</th><th>Amount</th><th>Date</th><th>Actions</th></tr></thead><tbody id="expensesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  loadExpenses(1);
}

async function loadExpenses(page) {
  try {
    const res = await AdminAPI.get(`/finance/expenses?limit=15&page=${page}`);
    const items = res.data?.items || [];
    const tbody = $('expensesBody');
    tbody.innerHTML = items.length ? items.map(e => `<tr>
      <td><span class="badge badge-secondary">${esc(e.category)}</span></td>
      <td style="font-size:var(--text-sm);">${esc(e.description || '-')}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(e.amount)}</td>
      <td style="font-size:var(--text-xs);">${dateStr(e.date)}</td>
      <td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast('Edit: implement')">Edit</button></div></td>
    </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No expenses found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddExpense() {
  showModal('Add Expense', `<form id="expenseForm" onsubmit="saveExpense(this);return false">
    <div class="form-group"><label class="form-label">Category *</label>
    <select class="form-select" name="category" required><option>Utilities</option><option>Rent</option><option>Salary</option><option>Marketing</option><option>Shipping</option><option>Office</option><option>Other</option></select></div>
    <div class="form-group"><label class="form-label">Description</label><input class="form-input" name="description"></div>
    <div class="form-row"><div class="form-group"><label class="form-label">Amount *</label><input class="form-input" name="amount" type="number" step="0.01" required></div>
    <div class="form-group"><label class="form-label">Date</label><input class="form-input" name="date" type="date"></div></div>
    <button type="submit" class="btn btn-primary w-full">Save</button>
  </form>`);
}

async function saveExpense(form) {
  const fd = new FormData(form);
  try { await AdminAPI.post('/finance/expenses', Object.fromEntries(fd)); showToast('Expense saved'); qs('.modal-overlay.active')?.classList.remove('active'); loadExpenses(1); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── SETTINGS ─────────────────────────────────────────────────────────────────
function initCompanySettings() {
  $('page-settings-company').innerHTML = `<div class="admin-page-header"><h1>Company Settings</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form onsubmit="saveCompanySettings(this);return false">
      <div class="form-row"><div class="form-group"><label class="form-label">Site Name</label><input class="form-input" name="site_name" value="Bangalirhaat"></div>
      <div class="form-group"><label class="form-label">Email</label><input class="form-input" name="email" value="support@bangalirhaat.com"></div></div>
      <div class="form-row"><div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone" value="09612-345678"></div>
      <div class="form-group"><label class="form-label">Currency</label><select class="form-select" name="currency"><option value="BDT" selected>BDT (৳)</option></select></div></div>
      <div class="form-group"><label class="form-label">Address</label><textarea class="form-input" name="address" rows="2">Gulshan 2, Dhaka, Bangladesh</textarea></div>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div></div>`;
}

async function saveCompanySettings(form) {
  const fd = new FormData(form);
  const entries = Object.fromEntries(fd);
  const settings = Object.entries(entries).map(([key, value]) => ({ key, value }));
  try { await AdminAPI.put('/settings', { settings }); showToast('Settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

function initInvoiceSettings() {
  $('page-settings-invoice').innerHTML = `<div class="admin-page-header"><h1>Invoice Settings</h1></div>
  <div class="admin-card"><div class="admin-card-body">
    <form onsubmit="saveInvoiceSettings(this);return false">
      <div class="form-group"><label class="form-label">Invoice Prefix</label><input class="form-input" name="invoice_prefix" value="BH-" style="font-family:monospace;"></div>
      <div class="form-group"><label class="form-label">Footer Text</label><textarea class="form-input" name="invoice_footer" rows="2">Thank you for shopping at Bangalirhaat!</textarea></div>
      <div class="form-group"><label class="form-label">Show Consignment ID</label><div><label class="form-checkbox"><input type="checkbox" checked> Yes, show 9-digit consignment ID on invoice</label></div></div>
      <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
  </div></div>`;
}

async function saveInvoiceSettings(form) {
  const fd = new FormData(form);
  const entries = Object.fromEntries(fd);
  const settings = Object.entries(entries).map(([key, value]) => ({ key, value }));
  try { await AdminAPI.put('/settings', { settings }); showToast('Invoice settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── ANALYTICS / PIXEL SETTINGS ────────────────────────────────────────────────
async function initAnalyticsSettings() {
  const el = $('page-settings-analytics');
  let fbVal = '', gaVal = '', hjVal = '';
  try {
    const res = await AdminAPI.get('/settings/analytics');
    if (res.success && res.data) {
      fbVal = res.data.fb_pixel_id || res.data.fbPixelId || '';
      gaVal = res.data.ga4_id || res.data.ga4Id || '';
      hjVal = res.data.hotjar_id || res.data.hotjarId || '';
    }
  } catch {}
  el.innerHTML = `<div class="admin-page-header"><h1>Tracking &amp; Pixel Settings</h1></div>
  <div class="admin-form-section">
    <div class="admin-form-header">Facebook Pixel</div>
    <div class="admin-form-body">
      <form id="analyticsForm" onsubmit="saveAnalyticsSettings(this);return false">
        <div class="admin-form-grid">
          <div class="form-group"><label class="form-label">Facebook Pixel ID</label><input class="form-input" name="fb_pixel_id" value="${esc(fbVal)}" placeholder="e.g. 123456789012345"></div>
          <div class="form-group"><label class="form-label">GA4 Measurement ID</label><input class="form-input" name="ga4_id" value="${esc(gaVal)}" placeholder="e.g. G-XXXXXXXXXX"></div>
          <div class="form-group"><label class="form-label">Hotjar Site ID</label><input class="form-input" name="hotjar_id" value="${esc(hjVal)}" placeholder="e.g. 1234567"></div>
        </div>
        <div style="margin-top:var(--space-4);"><button type="submit" class="btn btn-primary">Save Tracking Settings</button></div>
      </form>
    </div>
  </div>
  <div class="admin-card"><div class="admin-card-header"><h3>📘 How to get your Pixel ID</h3></div><div class="admin-card-body" style="font-size:var(--text-sm);color:var(--text-secondary);line-height:1.7;">
    <p><strong>Facebook Pixel:</strong> Go to Meta Events Manager → Data Sources → Add → Web → Create pixel. Copy the Pixel ID (15 digits).</p>
    <p><strong>GA4:</strong> Go to Google Analytics → Admin → Data Streams → Your stream → Copy Measurement ID (starts with G-).</p>
    <p><strong>Hotjar:</strong> Go to Hotjar → Sites → Add site → Copy Site ID.</p>
    <p style="margin-top:var(--space-2);color:var(--text-muted);">After saving, refresh the website for changes to take effect.</p>
  </div></div>`;
}
async function saveAnalyticsSettings(form) {
  const fd = new FormData(form);
  const settings = [];
  for (const [key, value] of fd.entries()) {
    settings.push({ key, value: value || '', group: 'analytics' });
  }
  try { await AdminAPI.put('/settings', { settings }); showToast('Tracking settings saved! Refresh website.'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── AUDIT LOGS ───────────────────────────────────────────────────────────────
async function initAuditLogs() {
  const el = $('page-audit-logs');
  el.innerHTML = `<div class="admin-page-header"><h1>Audit Logs</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>User</th><th>Action</th><th>Entity</th><th>Time</th></tr></thead><tbody id="auditBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/security/audit-logs?limit=20');
    $('auditBody').innerHTML = (res.data.items || []).map(l => `<tr>
      <td style="font-size:var(--text-sm);">${esc(l.user_name || 'System')}</td>
      <td><span class="badge badge-secondary">${esc(l.action)}</span></td>
      <td style="font-size:var(--text-xs);">${esc(l.entity)} #${l.entity_id || ''}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(l.created_at)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No audit logs</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── LOGIN HISTORY ────────────────────────────────────────────────────────────
async function initLoginHistory() {
  const el = $('page-login-history');
  el.innerHTML = `<div class="admin-page-header"><h1>Login History</h1></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>User</th><th>IP</th><th>Status</th><th>Time</th></tr></thead><tbody id="loginHistBody"><tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const res = await AdminAPI.get('/security/login-history?limit=20');
    $('loginHistBody').innerHTML = (res.data.items || []).map(l => `<tr>
      <td style="font-size:var(--text-sm);">${esc(l.user_name || 'N/A')}</td>
      <td style="font-family:monospace;font-size:var(--text-xs);">${l.ip_address || '-'}</td>
      <td><span class="badge ${l.status === 'success' ? 'badge-success' : 'badge-danger'}">${l.status}</span></td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(l.created_at)}</td>
    </tr>`).join('') || '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">No login history</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

// ── MODAL ────────────────────────────────────────────────────────────────────
function showModal(title, body) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay active';
  overlay.innerHTML = `<div class="modal modal-lg"><div class="modal-header"><h3>${esc(title)}</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">&times;</button></div><div class="modal-body">${body}</div></div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
}

// ── ABANDONED CART ────────────────────────────────────────────────────────────
async function initAbandonedCart() {
  const el = $('page-abandoned-cart');
  el.innerHTML = `<div class="admin-page-header"><h1>Abandoned Cart Recovery</h1>
    <div style="display:flex;gap:var(--space-3);">
      <button class="btn btn-primary" onclick="processAbandonedCarts()">⚡ Process Now</button>
      <button class="btn btn-outline" onclick="initAbandonedCart()">🔄 Refresh</button>
    </div>
  </div>
  <div class="admin-stats-grid" style="grid-template-columns:repeat(3,1fr);" id="abandonedStats"></div>
  <div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Customer</th><th>Email</th><th>Items</th><th>Cart Total</th><th>Last Active</th></tr></thead><tbody id="abandonedCartBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>`;
  try {
    const [statsRes, cartsRes] = await Promise.all([
      AdminAPI.get('/cart/recovery/stats'),
      AdminAPI.get('/cart/recovery/abandoned?hours=24')
    ]);
    const s = statsRes.data;
    if ($('abandonedStats')) $('abandonedStats').innerHTML = `
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Abandoned (24h)</div><div class="admin-stat-value">${s.total_abandoned}</div></div></div>
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Total Recovered</div><div class="admin-stat-value">${s.total_recovered}</div></div></div>
      <div class="admin-stat-card"><div class="admin-stat-info"><div class="admin-stat-label">Sent Today</div><div class="admin-stat-value">${s.today_sent}</div></div></div>`;
    $('abandonedCartBody').innerHTML = (cartsRes.data.items || []).length ? cartsRes.data.items.map(c => `<tr>
      <td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${esc(c.customer_name)}</td>
      <td style="font-size:var(--text-xs);">${esc(c.email)}</td>
      <td>${c.item_count}</td>
      <td style="font-weight:var(--weight-semibold);">${currency(c.cart_total || 0)}</td>
      <td style="font-size:var(--text-xs);color:var(--text-muted);">${timeAgo(c.updated_at)}</td>
    </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No abandoned carts found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function processAbandonedCarts() {
  if (!await showConfirm('Process Abandoned Carts', 'Send recovery emails to all abandoned carts?')) return;
  try {
    const res = await AdminAPI.post('/cart/recovery/process', { hours: 24 });
    showToast(res.message || 'Processing complete');
    initAbandonedCart();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const user = AdminAuth.checkAuth();
  if (!user) { showLoginPage(); return; }

  // Load admin user info
  const avatarBtn = $('adminAvatarBtn');
  if (avatarBtn) avatarBtn.textContent = (user.first_name?.[0] || 'A').toUpperCase();

  // Sidebar nav
  qsa('.admin-nav-item').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(el.dataset.page);
    });
  });

  // Sidebar toggle
  const toggleBtn = $('toggleSidebar');
  const sidebar = $('adminSidebar');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
    });
  }

  // Notification toggle
  const notifBtn = qs('.notification-dot');
  const notifDropdown = $('notifDropdown');
  if (notifBtn && notifDropdown) {
    notifBtn.addEventListener('click', e => {
      e.stopPropagation();
      notifDropdown.classList.toggle('visible');
    });
    document.addEventListener('click', () => notifDropdown.classList.remove('visible'));
  }

  // Avatar dropdown
  const avatarToggle = $('adminAvatarDropdown');
  const avatarDropdown = $('avatarDropdown');
  if (avatarToggle && avatarDropdown) {
    qs('.admin-avatar', avatarToggle)?.addEventListener('click', e => {
      e.stopPropagation();
      avatarDropdown.classList.toggle('visible');
    });
    document.addEventListener('click', () => avatarDropdown.classList.remove('visible'));
  }

  // Logout
  const logoutBtn = $('adminLogoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', () => AdminAuth.logout());

  // Theme toggle
  const themeBtn = $('adminThemeToggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const html = document.documentElement;
      const isDark = html.getAttribute('data-theme') === 'dark';
      html.setAttribute('data-theme', isDark ? 'light' : 'dark');
      qs('.icon-sun', themeBtn).style.display = isDark ? '' : 'none';
      qs('.icon-moon', themeBtn).style.display = isDark ? 'none' : '';
      localStorage.setItem('adminTheme', isDark ? 'light' : 'dark');
    });
    const savedTheme = localStorage.getItem('adminTheme');
    if (savedTheme) document.documentElement.setAttribute('data-theme', savedTheme);
  }

  // Admin search with Ctrl+K
  const searchInput = $('adminSearch');
  if (searchInput) {
    document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); searchInput.focus(); } });
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.toLowerCase();
      qsa('.admin-nav-item').forEach(el => {
        el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }

  // Navigate to initial page (from URL hash or default)
  const hashPage = location.hash.slice(1) || 'dashboard-overview';
  navigateTo(hashPage);
});

function showLoginPage() {
  document.body.innerHTML = `<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg,#0a0a0f);padding:20px;">
    <div style="background:var(--surface,#1a1a2e);padding:40px;border-radius:16px;width:100%;max-width:400px;box-shadow:0 25px 50px rgba(0,0,0,0.3);border:1px solid var(--border,#2d2d44);">
      <div style="text-align:center;margin-bottom:32px;">
        <div style="font-size:36px;margin-bottom:8px;">&#9971;</div>
        <h1 style="font-size:22px;font-weight:700;margin:0 0 4px;color:var(--text,#e2e8f0);">Admin Login</h1>
        <p style="margin:0;color:var(--text-muted,#94a3b8);font-size:14px;">Bangalirhaat</p>
      </div>
      <form id="loginForm" onsubmit="handleLogin(this);return false">
        <div class="form-group"><label class="form-label" style="color:var(--text-secondary,#cbd5e1);">Email</label>
          <input class="form-input" type="email" name="email" value="admin@bangalirhaat.com" required style="min-height:46px;font-size:15px;"></div>
        <div class="form-group" style="margin-bottom:24px;"><label class="form-label" style="color:var(--text-secondary,#cbd5e1);">Password</label>
          <input class="form-input" type="password" name="password" value="Admin@123" required style="min-height:46px;font-size:15px;"></div>
        <button type="submit" class="btn btn-primary w-full" id="loginBtn" style="min-height:48px;font-size:15px;">Sign In</button>
        <p style="text-align:center;margin-top:16px;font-size:12px;color:var(--text-muted,#64748b);">Default: admin@bangalirhaat.com / Admin@123</p>
      </form>
    </div>
  </div>`;
}

async function handleLogin(form) {
  const btn = $('loginBtn'); loading(btn, true);
  const fd = new FormData(form);
  try {
    const res = await AdminAuth.login(fd.get('email'), fd.get('password'));
    if (res.success) { location.reload(); }
    else showToast(res.message || 'Login failed', 'error');
  } catch (e) { showToast(e.message || 'Login failed', 'error'); } finally { loading(btn, false); }
}

// ── MEDIA LIBRARY ────────────────────────────────────────────────────────────
async function initMedia() {
  const el = $('page-media');
  el.innerHTML = '<div class="admin-page-header"><h1>Media Library</h1><button class="btn btn-primary" onclick="document.getElementById(\'mediaUploadInput\').click()">+ Upload Files</button></div>' +
    '<input type="file" id="mediaUploadInput" multiple accept="image/*,.pdf,.doc,.docx" style="display:none;" onchange="uploadMediaFiles(this)">' +
    '<div class="admin-card"><div class="admin-card-body"><div id="mediaGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:var(--space-3);"><p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">Loading...</p></div></div></div>';
  await loadMedia();
}

async function loadMedia() {
  try {
    const res = await AdminAPI.get('/media');
    const items = res.data?.data || res.data?.items || res.data || [];
    const grid = $('mediaGrid');
    if (!grid) return;
    grid.innerHTML = items.length ? items.map(function (f) {
      var isImg = f.mime_type && f.mime_type.startsWith('image/');
      return '<div style="position:relative;border:1px solid var(--card-border);border-radius:var(--radius);overflow:hidden;background:var(--card);">' +
        (isImg ? '<img src="' + esc(f.url) + '" alt="' + esc(f.alt_text || f.original_name) + '" style="width:100%;height:120px;object-fit:cover;display:block;cursor:pointer;" onclick="window.open(\'' + esc(f.url) + '\',\'_blank\')">' :
          '<div style="width:100%;height:120px;display:flex;align-items:center;justify-content:center;background:var(--surface-secondary);font-size:32px;">📄</div>') +
        '<div style="padding:6px 8px;font-size:11px;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(f.original_name || f.filename) + '</div>' +
        '<button class="btn btn-sm btn-danger-ghost" style="position:absolute;top:4px;right:4px;padding:2px 6px;font-size:12px;border-radius:4px;" onclick="deleteMediaFile(' + f.id + ')">&times;</button></div>';
    }).join('') : '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:40px;">No files uploaded yet</p>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function uploadMediaFiles(input) {
  var files = input.files;
  if (!files.length) return;
  var formData = new FormData();
  for (var i = 0; i < files.length; i++) formData.append('files', files[i]);
  try {
    await AdminAPI.post('/media/upload', formData);
    showToast(files.length + ' file(s) uploaded');
    input.value = '';
    await loadMedia();
  } catch (e) { showToast(e.message, 'error'); }
}

async function deleteMediaFile(id) {
  if (!await showConfirm('Delete File', 'Are you sure?')) return;
  try {
    await AdminAPI.del('/media/' + id);
    showToast('File deleted');
    await loadMedia();
  } catch (e) { showToast(e.message, 'error'); }
}

// ── BANNERS ──────────────────────────────────────────────────────────────────
async function initBanners() {
  const el = $('page-banners');
  el.innerHTML = '<div class="admin-page-header"><h1>Banners</h1><button class="btn btn-primary" onclick="showAddBanner()">+ Add Banner</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Image</th><th>Title</th><th>Position</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead><tbody id="bannersBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadBanners();
}

async function loadBanners() {
  try {
    const res = await AdminAPI.get('/banners/admin/all');
    const items = res.data?.data || res.data?.items || res.data?.banners || [];
    $('bannersBody').innerHTML = items.length ? items.map(function (b) {
      return '<tr><td>' + (b.image_url ? '<img src="' + esc(b.image_url) + '" alt="" style="width:64px;height:40px;object-fit:cover;border-radius:var(--radius-sm);display:block;">' : '<div style="width:64px;height:40px;background:var(--glass-bg);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:18px;">🖼</div>') + '</td>' +
        '<td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(b.title) + '</div>' + (b.subtitle ? '<div style="font-size:var(--text-xs);color:var(--text-muted);">' + esc(b.subtitle) + '</div>' : '') + '</td>' +
        '<td><span class="badge badge-info">' + esc(b.position) + '</span></td>' +
        '<td style="text-align:center;">' + (b.sort_order || 0) + '</td>' +
        '<td><span class="badge ' + (b.is_active ? 'badge-success' : 'badge-secondary') + '">' + (b.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditBanner(' + b.id + ')">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteBanner(' + b.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No banners found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddBanner() {
  showModal('Add Banner', '<form id="bannerForm" onsubmit="saveBanner(this);return false">' +
    '<div class="form-group"><label class="form-label">Title *</label><input class="form-input" name="title" required></div>' +
    '<div class="form-group"><label class="form-label">Subtitle</label><input class="form-input" name="subtitle"></div>' +
    '<div class="form-group"><label class="form-label">Image URL *</label><input class="form-input" name="image_url" placeholder="https://..." required oninput="document.getElementById(\'bannerPreview\').src=this.value;document.getElementById(\'bannerPreview\').style.display=this.value?\'block\':\'none\'"><img id="bannerPreview" style="max-width:200px;max-height:80px;margin-top:6px;border-radius:var(--radius-sm);display:none;object-fit:cover;"></div>' +
    '<div class="form-group"><label class="form-label">Link URL</label><input class="form-input" name="link_url" placeholder="https://..."></div>' +
    '<div class="form-group"><label class="form-label">Link Text</label><input class="form-input" name="link_text" value="Shop Now"></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Position</label><select class="form-input" name="position"><option value="hero">Hero</option><option value="promo">Promo</option><option value="featured">Featured</option><option value="sidebar">Sidebar</option></select></div>' +
    '<div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="0"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">BG Color</label><input class="form-input" name="bg_color" type="color" value="#1a1a2e"></div>' +
    '<div class="form-group"><label class="form-label">Text Color</label><input class="form-input" name="text_color" type="color" value="#ffffff"></div></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Banner</button></form>');
}

async function saveBanner(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  data.sort_order = parseInt(data.sort_order) || 0;
  try { await AdminAPI.post('/banners', data); showToast('Banner created'); qs('.modal-overlay.active')?.classList.remove('active'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditBanner(id) {
  try {
    var res = await AdminAPI.get('/banners/admin/all');
    var items = res.data?.data || res.data?.items || res.data?.banners || [];
    var b = items.find(function (x) { return x.id === id; });
    if (!b) { showToast('Banner not found', 'error'); return; }
    showModal('Edit Banner', '<form id="bannerForm" onsubmit="updateBanner(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Title *</label><input class="form-input" name="title" value="' + esc(b.title) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Subtitle</label><input class="form-input" name="subtitle" value="' + esc(b.subtitle || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Image URL *</label><input class="form-input" name="image_url" value="' + esc(b.image_url) + '" required oninput="document.getElementById(\'bannerPreview\').src=this.value;document.getElementById(\'bannerPreview\').style.display=this.value?\'block\':\'none\'"><img id="bannerPreview" src="' + esc(b.image_url) + '" style="max-width:200px;max-height:80px;margin-top:6px;border-radius:var(--radius-sm);display:block;object-fit:cover;"></div>' +
      '<div class="form-group"><label class="form-label">Link URL</label><input class="form-input" name="link_url" value="' + esc(b.link_url || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Link Text</label><input class="form-input" name="link_text" value="' + esc(b.link_text || 'Shop Now') + '"></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Position</label><select class="form-input" name="position"><option value="hero"' + (b.position === 'hero' ? ' selected' : '') + '>Hero</option><option value="promo"' + (b.position === 'promo' ? ' selected' : '') + '>Promo</option><option value="featured"' + (b.position === 'featured' ? ' selected' : '') + '>Featured</option><option value="sidebar"' + (b.position === 'sidebar' ? ' selected' : '') + '>Sidebar</option></select></div>' +
      '<div class="form-group"><label class="form-label">Sort Order</label><input class="form-input" name="sort_order" type="number" value="' + (b.sort_order || 0) + '"></div></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (b.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Banner</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateBanner(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  data.sort_order = parseInt(data.sort_order) || 0;
  try { await AdminAPI.put('/banners/' + id, data); showToast('Banner updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteBanner(id) {
  if (!await showConfirm('Delete Banner', 'Are you sure?')) return;
  try { await AdminAPI.del('/banners/' + id); showToast('Banner deleted'); loadBanners(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── REVIEWS (ADMIN MODERATION) ───────────────────────────────────────────────
async function initAdminReviews() {
  var el = $('page-reviews');
  el.innerHTML = '<div class="admin-page-header"><h1>Reviews</h1><div style="display:flex;gap:8px;"><button class="btn btn-sm ' + (window._reviewFilter === 'pending' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'pending\';initAdminReviews()">Pending</button><button class="btn btn-sm ' + (window._reviewFilter === 'approved' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'approved\';initAdminReviews()">Approved</button><button class="btn btn-sm ' + (!window._reviewFilter || window._reviewFilter === 'all' ? 'btn-primary' : 'btn-ghost') + '" onclick="window._reviewFilter=\'all\';initAdminReviews()">All</button></div></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody id="reviewsBody"><tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  try {
    var status = window._reviewFilter || 'all';
    var res = await AdminAPI.get('/reviews?status=' + status + '&limit=50');
    var items = res.data?.data?.items || res.data?.items || [];
    $('reviewsBody').innerHTML = items.length ? items.map(function (r) {
      var stars = ''; for (var s = 0; s < 5; s++) stars += '<svg width="14" height="14" viewBox="0 0 24 24" fill="' + (s < r.rating ? '#f59e0b' : '#333') + '" stroke="' + (s < r.rating ? '#f59e0b' : '#555') + '" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
      return '<tr><td style="font-size:var(--text-sm);font-weight:var(--weight-medium);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(r.product_name) + '</td>' +
        '<td style="font-size:var(--text-sm);">' + esc(r.user_name || 'N/A') + '</td>' +
        '<td>' + stars + '</td>' +
        '<td style="font-size:var(--text-sm);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-secondary);">' + esc(r.comment || r.title || '-') + '</td>' +
        '<td><span class="badge ' + (r.is_approved ? 'badge-success' : 'badge-warning') + '">' + (r.is_approved ? 'Approved' : 'Pending') + '</span></td>' +
        '<td style="font-size:var(--text-xs);color:var(--text-muted);">' + dateStr(r.created_at) + '</td>' +
        '<td><div class="admin-actions">' +
        (!r.is_approved ? '<button class="btn btn-sm btn-success-ghost" onclick="approveReview(' + r.id + ',1)">Approve</button>' : '<button class="btn btn-sm btn-ghost" onclick="approveReview(' + r.id + ',0)">Reject</button>') +
        '<button class="btn btn-sm btn-danger-ghost" onclick="deleteReview(' + r.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">No reviews found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

async function approveReview(id, approved) {
  try { await AdminAPI.put('/reviews/' + id + '/approve', { approved: approved }); showToast(approved ? 'Review approved' : 'Review rejected'); initAdminReviews(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteReview(id) {
  if (!await showConfirm('Delete Review', 'Delete this review permanently?')) return;
  try { await AdminAPI.del('/reviews/' + id); showToast('Review deleted'); initAdminReviews(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── PAYMENT GATEWAY SETTINGS ─────────────────────────────────────────────────
async function initPaymentSettings() {
  var el = $('page-settings-payment');
  el.innerHTML = '<div class="admin-page-header"><h1>Payment Gateway Settings</h1></div><div class="admin-card"><div class="admin-card-body"><p style="color:var(--text-muted);margin-bottom:var(--space-4);">Configure payment gateways for your store.</p><form id="paymentForm" onsubmit="savePaymentSettings(this);return false"><div id="paymentFormFields">Loading...</div><button type="submit" class="btn btn-primary">Save Settings</button></form></div></div>';
  try {
    var res = await AdminAPI.get('/payment-methods');
    var cfg = res.data?.data?.config || res.data?.config || {};
    $('paymentFormFields').innerHTML =
      '<div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="cod_enabled" value="1" ' + (cfg.cod_enabled === '1' ? 'checked' : '') + '> Cash on Delivery (COD)</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="bkash_enabled" value="1" ' + (cfg.bkash_enabled === '1' ? 'checked' : '') + '> bKash</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="nagad_enabled" value="1" ' + (cfg.nagad_enabled === '1' ? 'checked' : '') + '> Nagad</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="rocket_enabled" value="1" ' + (cfg.rocket_enabled === '1' ? 'checked' : '') + '> Rocket</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="sslcommerz_enabled" value="1" ' + (cfg.sslcommerz_enabled === '1' ? 'checked' : '') + '> SSLCommerz</label></div>' +
      '<div class="form-group"><label class="form-checkbox"><input type="checkbox" name="stripe_enabled" value="1" ' + (cfg.stripe_enabled === '1' ? 'checked' : '') + '> Stripe</label></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>bKash / Nagad / Rocket</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">bKash Number</label><input class="form-input" name="bkash_number" value="' + esc(cfg.bkash_number || '') + '" placeholder="01XXXXXXXXX"></div>' +
      '<div class="form-group"><label class="form-label">Nagad Number</label><input class="form-input" name="nagad_number" value="' + esc(cfg.nagad_number || '') + '" placeholder="01XXXXXXXXX"></div>' +
      '<div class="form-group"><label class="form-label">Rocket Number</label><input class="form-input" name="rocket_number" value="' + esc(cfg.rocket_number || '') + '" placeholder="01XXXXXXXXX"></div></div></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>SSLCommerz</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">Store ID</label><input class="form-input" name="sslcommerz_store_id" value="' + esc(cfg.sslcommerz_store_id || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Store Password</label><input class="form-input" name="sslcommerz_store_pass" type="password" value="' + esc(cfg.sslcommerz_store_pass || '') + '"></div></div></div></div>' +
      '<div class="admin-card" style="margin-top:var(--space-4);"><div class="admin-card-header"><h3>Stripe</h3></div><div class="admin-card-body"><div class="admin-form-grid">' +
      '<div class="form-group"><label class="form-label">Publishable Key</label><input class="form-input" name="stripe_publishable_key" value="' + esc(cfg.stripe_publishable_key || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Secret Key</label><input class="form-input" name="stripe_secret_key" type="password" value="' + esc(cfg.stripe_secret_key || '') + '"></div></div></div></div>';
  } catch (e) { $('paymentFormFields').innerHTML = '<p style="color:var(--text-muted);">Error loading settings</p>'; }
}

async function savePaymentSettings() {
  var form = $('paymentForm');
  var fd = new FormData(form);
  var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  ['cod_enabled','bkash_enabled','nagad_enabled','rocket_enabled','sslcommerz_enabled','stripe_enabled'].forEach(function (k) { if (data[k] !== '1') data[k] = '0'; });
  try { await AdminAPI.put('/payment-methods', data); showToast('Payment settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── TAX / VAT SETTINGS ───────────────────────────────────────────────────────
async function initTaxSettings() {
  var el = $('page-settings-tax');
  el.innerHTML = '<div class="admin-page-header"><h1>Tax / VAT Settings</h1></div><div class="admin-card"><div class="admin-card-body"><form id="taxForm" onsubmit="saveTaxSettings(this);return false"><div class="admin-form-grid">' +
    '<div class="form-group"><label class="form-label">VAT Rate (%)</label><input class="form-input" name="vat_rate" id="taxVatRate" type="number" step="0.01" value="5"></div>' +
    '<div class="form-group"><label class="form-label">Tax Name / Label</label><input class="form-input" name="tax_name" id="taxName" value="VAT"></div></div>' +
    '<div class="form-group"><label class="form-label">VAT Registration No.</label><input class="form-input" name="vat_registration_no" id="taxRegNo"></div>' +
    '<div class="form-group"><div class="form-checkbox"><input type="checkbox" name="tax_included" id="taxIncluded" value="1"> Prices include tax (inclusive pricing)</div></div>' +
    '<button type="submit" class="btn btn-primary">Save Settings</button></form></div></div>';
  try {
    var res = await AdminAPI.get('/tax-settings');
    var cfg = res.data?.data || res.data || {};
    if ($('taxVatRate')) $('taxVatRate').value = cfg.vat_rate || '5';
    if ($('taxName')) $('taxName').value = cfg.tax_name || 'VAT';
    if ($('taxRegNo')) $('taxRegNo').value = cfg.vat_registration_no || '';
    if ($('taxIncluded')) $('taxIncluded').checked = cfg.tax_included === '1';
  } catch (e) { /* ignore */ }
}

async function saveTaxSettings(form) {
  var fd = new FormData(form);
  var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  if (data.tax_included !== '1') data.tax_included = '0';
  try { await AdminAPI.put('/tax-settings', data); showToast('Tax settings saved'); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── EMAIL TEMPLATES ──────────────────────────────────────────────────────────
async function initEmailTemplates() {
  var el = $('page-settings-email-templates');
  el.innerHTML = '<div class="admin-page-header"><h1>Email Templates</h1><button class="btn btn-primary" onclick="showAddEmailTemplate()">+ Add Template</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Slug</th><th>Type</th><th>Subject</th><th>Status</th><th>Actions</th></tr></thead><tbody id="emailTemplatesBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadEmailTemplates();
}

async function loadEmailTemplates() {
  try {
    var res = await AdminAPI.get('/email-templates');
    var items = res.data?.data?.items || res.data?.data || res.data?.items || res.data || [];
    if (!Array.isArray(items)) items = [];
    $('emailTemplatesBody').innerHTML = items.length ? items.map(function (t) {
      return '<tr><td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(t.name) + '</td>' +
        '<td style="font-size:var(--text-xs);font-family:monospace;color:var(--text-muted);">' + esc(t.slug) + '</td>' +
        '<td><span class="badge badge-info">' + esc(t.type) + '</span></td>' +
        '<td style="font-size:var(--text-sm);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-secondary);">' + esc(t.subject) + '</td>' +
        '<td><span class="badge ' + (t.is_active ? 'badge-success' : 'badge-secondary') + '">' + (t.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showEditEmailTemplate(' + t.id + ')">Edit</button><button class="btn btn-sm btn-danger-ghost" onclick="deleteEmailTemplate(' + t.id + ')">Delete</button></div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No templates found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddEmailTemplate() {
  showModal('Add Email Template', '<form id="emailTemplateForm" onsubmit="saveEmailTemplate(this);return false">' +
    '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" required></div>' +
    '<div class="form-group"><label class="form-label">Subject *</label><input class="form-input" name="subject" required></div>' +
    '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="email">Email</option><option value="sms">SMS</option></select></div>' +
    '<div class="form-group"><label class="form-label">Body *<br><small style="color:var(--text-muted);">Use {variable_name} for placeholders</small></label><textarea class="form-input" name="body" rows="8" required></textarea></div>' +
    '<div class="form-group"><label class="form-label">Variables (comma-separated)</label><input class="form-input" name="variables" placeholder="e.g. order_number, customer_name, total"></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Template</button></form>');
}

async function saveEmailTemplate(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.post('/email-templates', data); showToast('Template created'); qs('.modal-overlay.active')?.classList.remove('active'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditEmailTemplate(id) {
  try {
    var res = await AdminAPI.get('/email-templates');
    var items = res.data?.data?.items || res.data?.data || res.data?.items || res.data || [];
    if (!Array.isArray(items)) items = [];
    var t = items.find(function (x) { return x.id === id; });
    if (!t) { showToast('Template not found', 'error'); return; }
    showModal('Edit Email Template', '<form id="emailTemplateForm" onsubmit="updateEmailTemplate(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" value="' + esc(t.name) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Subject *</label><input class="form-input" name="subject" value="' + esc(t.subject) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="email"' + (t.type === 'email' ? ' selected' : '') + '>Email</option><option value="sms"' + (t.type === 'sms' ? ' selected' : '') + '>SMS</option></select></div>' +
      '<div class="form-group"><label class="form-label">Body *</label><textarea class="form-input" name="body" rows="8" required>' + esc(t.body) + '</textarea></div>' +
      '<div class="form-group"><label class="form-label">Variables</label><input class="form-input" name="variables" value="' + esc(t.variables || '') + '"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (t.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Template</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateEmailTemplate(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/email-templates/' + id, data); showToast('Template updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteEmailTemplate(id) {
  if (!await showConfirm('Delete Template', 'Are you sure?')) return;
  try { await AdminAPI.del('/email-templates/' + id); showToast('Template deleted'); loadEmailTemplates(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── STAFF MANAGEMENT ─────────────────────────────────────────────────────────
async function initStaff() {
  var el = $('page-staff');
  el.innerHTML = '<div class="admin-page-header"><h1>Staff Management</h1><button class="btn btn-primary" onclick="showAddStaff()">+ Add Staff</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead><tbody id="staffBody"><tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  await loadStaff();
}

async function loadStaff() {
  try {
    var res = await AdminAPI.get('/staff');
    var items = res.data?.data?.items || res.data?.items || [];
    $('staffBody').innerHTML = items.length ? items.map(function (u) {
      var roleBadge = { super_admin: 'badge-danger', admin: 'badge-primary', moderator: 'badge-warning', staff: 'badge-info' };
      return '<tr><td><div style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(u.first_name + ' ' + (u.last_name || '')) + '</div></td>' +
        '<td style="font-size:var(--text-xs);">' + esc(u.email) + '</td>' +
        '<td>' + esc(u.phone || '-') + '</td>' +
        '<td><span class="badge ' + (roleBadge[u.role] || 'badge-secondary') + '">' + esc(u.role) + '</span></td>' +
        '<td><span class="badge ' + (u.is_active ? 'badge-success' : 'badge-secondary') + '">' + (u.is_active ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions">' +
        '<button class="btn btn-sm btn-ghost" onclick="showEditStaff(' + u.id + ')">Edit</button>' +
        (u.role !== 'super_admin' ? '<button class="btn btn-sm btn-danger-ghost" onclick="deleteStaff(' + u.id + ')">Delete</button>' : '') +
        '</div></td></tr>';
    }).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">No staff found</td></tr>';
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddStaff() {
  showModal('Add Staff', '<form id="staffForm" onsubmit="saveStaff(this);return false">' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">First Name *</label><input class="form-input" name="first_name" required></div>' +
    '<div class="form-group"><label class="form-label">Last Name</label><input class="form-input" name="last_name"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Email *</label><input class="form-input" name="email" type="email" required></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone"></div></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Password *</label><input class="form-input" name="password" type="password" required minlength="6"></div>' +
    '<div class="form-group"><label class="form-label">Role</label><select class="form-input" name="role"><option value="staff">Staff</option><option value="moderator">Moderator</option><option value="admin">Admin</option></select></div></div>' +
    '<button type="submit" class="btn btn-primary w-full">Add Staff</button></form>');
}

async function saveStaff(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  try { await AdminAPI.post('/staff', data); showToast('Staff added'); qs('.modal-overlay.active')?.classList.remove('active'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function showEditStaff(id) {
  try {
    var res = await AdminAPI.get('/staff');
    var items = res.data?.data?.items || res.data?.items || [];
    var u = items.find(function (x) { return x.id === id; });
    if (!u) { showToast('Staff not found', 'error'); return; }
    showModal('Edit Staff', '<form id="staffForm" onsubmit="updateStaff(' + id + ',this);return false">' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">First Name</label><input class="form-input" name="first_name" value="' + esc(u.first_name) + '"></div>' +
      '<div class="form-group"><label class="form-label">Last Name</label><input class="form-input" name="last_name" value="' + esc(u.last_name || '') + '"></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="phone" value="' + esc(u.phone || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Role</label><select class="form-input" name="role"><option value="staff"' + (u.role === 'staff' ? ' selected' : '') + '>Staff</option><option value="moderator"' + (u.role === 'moderator' ? ' selected' : '') + '>Moderator</option><option value="admin"' + (u.role === 'admin' ? ' selected' : '') + '>Admin</option></select></div></div>' +
      '<div class="form-group"><label class="form-label">New Password (leave blank to keep)</label><input class="form-input" name="password" type="password" minlength="6"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (u.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Staff</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateStaff(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  if (!data.password) delete data.password;
  try { await AdminAPI.put('/staff/' + id, data); showToast('Staff updated'); qs('.modal-overlay.active')?.classList.remove('active'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteStaff(id) {
  if (!await showConfirm('Delete Staff', 'Remove this staff member permanently?')) return;
  try { await AdminAPI.del('/staff/' + id); showToast('Staff deleted'); loadStaff(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── THEME SETTINGS ────────────────────────────────────────────────────────────
function initThemeSettings() {
  var currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
  $('page-settings-theme').innerHTML = '<div class="admin-page-header"><h1>Theme Settings</h1></div>' +
    '<div class="admin-card"><div class="admin-card-body">' +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-4);margin-bottom:var(--space-6);">' +
    '<div onclick="setAdminTheme(\'dark\')" style="cursor:pointer;padding:var(--space-4);border-radius:var(--radius-lg);border:2px solid ' + (currentTheme === 'dark' ? 'var(--primary)' : 'var(--card-border)') + ';background:#0f0f1a;color:#e2e8f0;text-align:center;"><div style="font-size:36px;margin-bottom:8px;">🌙</div><div style="font-weight:var(--weight-semibold);">Dark Mode</div><div style="font-size:var(--text-xs);color:#94a3b8;">Default theme</div></div>' +
    '<div onclick="setAdminTheme(\'light\')" style="cursor:pointer;padding:var(--space-4);border-radius:var(--radius-lg);border:2px solid ' + (currentTheme === 'light' ? 'var(--primary)' : 'var(--card-border)') + ';background:#ffffff;color:#1a1a2e;text-align:center;"><div style="font-size:36px;margin-bottom:8px;">☀️</div><div style="font-weight:var(--weight-semibold);">Light Mode</div><div style="font-size:var(--text-xs);color:#64748b;">Clean & bright</div></div></div>' +
    '<p style="color:var(--text-muted);font-size:var(--text-sm);">Theme settings are stored in your browser. More customization options coming soon.</p></div></div>';
}

function setAdminTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('adminTheme', theme);
  initThemeSettings();
  showToast('Theme set to ' + theme + ' mode');
}

// ── DELIVERY ZONES (dynamic) ──────────────────────────────────────────────────
async function initDeliveryZones() {
  var el = $('page-delivery-zones');
  el.innerHTML = '<div class="admin-page-header"><h1>Delivery Zones</h1><button class="btn btn-primary" onclick="showAddZone()">+ Add Zone</button></div>' +
    '<div class="admin-card"><div class="admin-card-body" style="padding:0;"><div class="table-wrapper"><table class="table table-hover"><thead><tr><th>Zone</th><th>Inside Dhaka</th><th>Outside Dhaka</th><th>Status</th><th>Actions</th></tr></thead><tbody id="zonesBody"><tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Loading...</td></tr></tbody></table></div></div></div>';
  try {
    var res = await AdminAPI.get('/delivery/zones');
    var items = res.data?.data?.zones || res.data?.zones || res.data?.data || res.data || [];
    if (!Array.isArray(items)) items = [];
    $('zonesBody').innerHTML = items.length ? items.map(function (z) {
      return '<tr><td style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">' + esc(z.name || z.zone) + '</td>' +
        '<td>' + currency(z.inside_dhaka || z.dhaka_rate || 0) + '</td>' +
        '<td>' + currency(z.outside_dhaka || z.outside_rate || 0) + '</td>' +
        '<td><span class="badge ' + (z.is_active !== 0 ? 'badge-success' : 'badge-secondary') + '">' + ((z.is_active !== 0) ? 'Active' : 'Inactive') + '</span></td>' +
        '<td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="showToast(\'Edit: implement\')">Edit</button></div></td></tr>';
    }).join('') : '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">No zones configured</td></tr>';
  } catch (e) {
    $('zonesBody').innerHTML = '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Could not load zones</td></tr>';
  }
}

function showAddZone() {
  showModal('Add Delivery Zone', '<form id="zoneForm" onsubmit="saveZone(this);return false">' +
    '<div class="form-group"><label class="form-label">Zone Name *</label><input class="form-input" name="name" required></div>' +
    '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Inside Dhaka Rate</label><input class="form-input" name="inside_dhaka" type="number" step="0.01" value="60"></div>' +
    '<div class="form-group"><label class="form-label">Outside Dhaka Rate</label><input class="form-input" name="outside_dhaka" type="number" step="0.01" value="120"></div></div>' +
    '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" checked value="1" style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
    '<button type="submit" class="btn btn-primary w-full">Save Zone</button></form>');
}

async function saveZone(form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.inside_dhaka = parseFloat(data.inside_dhaka) || 0;
  data.outside_dhaka = parseFloat(data.outside_dhaka) || 0;
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.post('/delivery/zones', data); showToast('Zone created'); qs('.modal-overlay.active')?.classList.remove('active'); initDeliveryZones(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: BRANDS EDIT/DELETE ──────────────────────────────────────────────────
async function showEditBrand(id) {
  try {
    var res = await AdminAPI.get('/brands');
    var items = res.data?.items || [];
    var b = items.find(function (x) { return x.id === id; });
    if (!b) { showToast('Brand not found', 'error'); return; }
    showModal('Edit Brand', '<form id="brandEditForm" onsubmit="updateBrand(' + id + ',this);return false">' +
      '<div class="form-group"><label class="form-label">Name *</label><input class="form-input" name="name" value="' + esc(b.name) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Description</label><textarea class="form-input" name="description" rows="3">' + esc(b.description || '') + '</textarea></div>' +
      '<div class="form-group"><label class="form-label">Logo URL</label><input class="form-input" name="logo" value="' + esc(b.logo || '') + '"></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (b.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Brand</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateBrand(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/brands/' + id, data); showToast('Brand updated'); qs('.modal-overlay.active')?.classList.remove('active'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

async function deleteBrand(id) {
  if (!await showConfirm('Delete Brand', 'Permanently delete this brand?')) return;
  try { await AdminAPI.del('/brands/' + id); showToast('Brand deleted'); initBrands(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: COUPONS EDIT ────────────────────────────────────────────────────────
async function showEditCoupon(id) {
  try {
    var res = await AdminAPI.get('/marketing/coupons');
    var items = res.data?.items || [];
    var c = items.find(function (x) { return x.id === id; });
    if (!c) { showToast('Coupon not found', 'error'); return; }
    showModal('Edit Coupon', '<form id="couponEditForm" onsubmit="updateCoupon(' + id + ',this);return false">' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Code</label><input class="form-input" name="code" value="' + esc(c.code) + '" required></div>' +
      '<div class="form-group"><label class="form-label">Type</label><select class="form-input" name="type"><option value="percentage"' + (c.type === 'percentage' ? ' selected' : '') + '>Percentage</option><option value="fixed"' + (c.type === 'fixed' ? ' selected' : '') + '>Fixed</option><option value="free_shipping"' + (c.type === 'free_shipping' ? ' selected' : '') + '>Free Shipping</option></select></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Value</label><input class="form-input" name="value" type="number" step="0.01" value="' + c.value + '"></div>' +
      '<div class="form-group"><label class="form-label">Min Order</label><input class="form-input" name="minimum_order" type="number" step="0.01" value="' + c.minimum_order + '"></div></div>' +
      '<div class="admin-form-grid"><div class="form-group"><label class="form-label">Usage Limit</label><input class="form-input" name="usage_limit" type="number" value="' + (c.usage_limit || '') + '"></div>' +
      '<div class="form-group"><label class="form-label">Max Discount</label><input class="form-input" name="maximum_discount" type="number" step="0.01" value="' + (c.maximum_discount || '') + '"></div></div>' +
      '<div class="form-group" style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" ' + (c.is_active ? 'checked' : '') + ' style="width:18px;height:18px;"><label style="margin:0;">Active</label></div>' +
      '<button type="submit" class="btn btn-primary w-full">Update Coupon</button></form>');
  } catch (e) { showToast(e.message, 'error'); }
}

async function updateCoupon(id, form) {
  var fd = new FormData(form); var data = {};
  fd.forEach(function (v, k) { data[k] = v; });
  data.value = parseFloat(data.value) || 0;
  data.minimum_order = parseFloat(data.minimum_order) || 0;
  data.usage_limit = data.usage_limit ? parseInt(data.usage_limit) : null;
  data.maximum_discount = data.maximum_discount ? parseFloat(data.maximum_discount) : null;
  data.is_active = data.is_active ? 1 : 0;
  try { await AdminAPI.put('/marketing/coupons/' + id, data); showToast('Coupon updated'); qs('.modal-overlay.active')?.classList.remove('active'); initCoupons(); }
  catch (e) { showToast(e.message, 'error'); }
}

// ── FIX: CUSTOMER DETAIL VIEW ────────────────────────────────────────────────
async function viewCustomer(id) {
  try {
    var res = await AdminAPI.get('/customers');
    var items = res.data?.items || [];
    var c = items.find(function (x) { return x.id === id; });
    if (!c) { showToast('Customer not found', 'error'); return; }
    showModal('Customer Details: ' + esc(c.first_name + ' ' + c.last_name),
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);">' +
      '<div><strong>Name:</strong> ' + esc(c.first_name + ' ' + (c.last_name || '')) + '</div>' +
      '<div><strong>Email:</strong> ' + esc(c.email) + '</div>' +
      '<div><strong>Phone:</strong> ' + esc(c.phone || '-') + '</div>' +
      '<div><strong>Total Orders:</strong> ' + (c.total_orders || 0) + '</div>' +
      '<div><strong>Total Spent:</strong> ' + currency(c.total_spent || 0) + '</div>' +
      '<div><strong>VIP:</strong> ' + (c.is_vip ? 'Yes' : 'No') + '</div>' +
      '<div><strong>Registered:</strong> ' + dateStr(c.created_at) + '</div>' +
      '<div><strong>Last Order:</strong> ' + (c.last_order_at ? dateStr(c.last_order_at) : '-') + '</div></div>');
  } catch (e) { showToast(e.message, 'error'); }
}
