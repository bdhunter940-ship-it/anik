import { getDb } from '../database/db.js';
import config from '../config/index.js';

const STEADFAST_BASE = 'https://portal.packzy.com/api/v1';

function normalizeBdPhone(phone) {
  if (!phone) return '';
  let cleaned = phone.replace(/[\s\-()]/g, '');
  if (cleaned.startsWith('+880')) cleaned = '0' + cleaned.slice(4);
  if (cleaned.startsWith('880')) cleaned = '0' + cleaned.slice(3);
  if (!cleaned.startsWith('0')) cleaned = '0' + cleaned;
  return cleaned;
}

class CourierService {
  _getCourierConfig(courier) {
    const slug = (courier.slug || courier.name || '').toLowerCase().replace(/[\s\-]/g, '');
    const configs = {
      steadfast: {
        apiKey: courier.api_key || config.courier?.steadfast?.apiKey || '',
        apiSecret: courier.api_secret || config.courier?.steadfast?.apiSecret || '',
        apiUrl: courier.api_url || config.courier?.steadfast?.url || STEADFAST_BASE,
        provider: 'steadfast',
      },
      sf2: {
        apiKey: config.courier?.sf2?.apiKey || courier.api_key || '',
        apiSecret: config.courier?.sf2?.apiSecret || courier.api_secret || '',
        apiUrl: config.courier?.sf2?.url || STEADFAST_BASE,
        provider: 'steadfast',
      },
      pathao: {
        clientId: process.env.PATHAO_CLIENT_ID || courier.api_key || '',
        clientSecret: process.env.PATHAO_CLIENT_SECRET || courier.api_secret || '',
        merchantId: process.env.PATHAO_MERCHANT_ID || '',
        username: process.env.PATHAO_USERNAME || '',
        password: process.env.PATHAO_PASSWORD || '',
        apiUrl: process.env.PATHAO_API_BASE || 'https://merchant-api-express.pathao.com',
        tokenUrl: 'https://merchant-api-oauth.pathao.com',
        provider: 'pathao',
      },
      redx: {
        apiToken: courier.api_key || process.env.REDX_API_TOKEN || '',
        apiUrl: courier.api_url || process.env.REDX_API_BASE || 'https://openapi.redx.com.bd/v1.0.0-beta',
        provider: 'redx',
      },
      paperfly: {
        apiKey: courier.api_key || process.env.PAPERFLY_API_KEY || '',
        apiSecret: courier.api_secret || process.env.PAPERFLY_API_SECRET || '',
        apiUrl: courier.api_url || 'https://merchant.paperfly.com.bd/api',
        provider: 'paperfly',
      },
    };

    if (slug.includes('steadfast') || slug === 'sf2') return { ...configs.steadfast, ...configs[slug] };
    if (slug.includes('pathao')) return configs.pathao;
    if (slug.includes('redx')) return configs.redx;
    if (slug.includes('paperfly')) return configs.paperfly;
    return { provider: 'unknown' };
  }

  _getOrderDetails(orderId) {
    const db = getDb();
    const order = db.prepare(
      `SELECT o.*, u.first_name, u.last_name, u.phone as user_phone, u.email as user_email
       FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?`
    ).get(orderId);

    if (!order) throw new Error('Order not found');

    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(orderId);
    const shippingAddr = order.shipping_address ? JSON.parse(order.shipping_address) : {};

    return { order, items, shippingAddr };
  }

  _updateShipment(db, shipmentId, updates) {
    const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    const values = Object.values(updates);
    db.prepare(`UPDATE shipments SET ${fields}, updated_at = datetime('now') WHERE id = ?`).run(...values, shipmentId);
  }

  _updateOrderCourier(db, orderId, updates) {
    const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    const values = Object.values(updates);
    db.prepare(`UPDATE orders SET ${fields}, updated_at = datetime('now') WHERE id = ?`).run(...values, orderId);
  }

  _insertShipment(db, { orderId, courierId, consignmentId, trackingNumber, status, cost }) {
    return db.prepare(
      `INSERT INTO shipments (order_id, courier_id, consignment_id, tracking_number, status, status_update, cost, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
    ).run(orderId, courierId, consignmentId || null, trackingNumber || null, status || 'pending', '[]', cost || 0);
  }

  // =====================================================================
  //  STEADFAST COURIER API — https://portal.packzy.com/api/v1
  //  Auth headers: Api-Key, Secret-Key, Content-Type: application/json
  // =====================================================================

  _steadfastHeaders(cfg) {
    return {
      'Content-Type': 'application/json',
      'Api-Key': cfg.apiKey,
      'Secret-Key': cfg.apiSecret,
    };
  }

  async createSteadfastOrder(order, courier) {
    const cfg = this._getCourierConfig(courier);
    const { order: orderData, items, shippingAddr } = this._getOrderDetails(order.id);
    const merchantConfig = courier.config ? JSON.parse(courier.config) : {};
    const invoice = orderData.order_number.replace(/[^a-zA-Z0-9\-_]/g, '');

    const recipientName = shippingAddr.name || `${orderData.first_name || ''} ${orderData.last_name || ''}`.trim();
    const recipientPhone = normalizeBdPhone(shippingAddr.phone || orderData.user_phone);
    const recipientAddress = [
      shippingAddr.line1 || shippingAddr.address,
      shippingAddr.line2,
      shippingAddr.city || shippingAddr.district,
      shippingAddr.state || shippingAddr.division,
    ].filter(Boolean).join(', ');

    const body = {
      invoice: invoice,
      recipient_name: recipientName.substring(0, 100),
      recipient_phone: recipientPhone,
      recipient_address: recipientAddress.substring(0, 250),
      cod_amount: orderData.payment_method === 'cod' ? orderData.total : 0,
      note: items.map(i => `${i.product_name || i.name || ''} x${i.quantity}`).join(', ').substring(0, 200),
      item_description: items.map(i => i.product_name || i.name || '').join(', ').substring(0, 200),
      total_lot: 1,
      delivery_type: merchantConfig.delivery_type || 0,
    };

    if (merchantConfig.institution_id) {
      body.institution_id = merchantConfig.institution_id;
    }
    if (recipientPhone && recipientPhone !== orderData.user_phone) {
      body.alternative_phone = normalizeBdPhone(orderData.user_phone);
    }

    console.log('[CourierService] SteadFast create_order:', cfg.apiUrl + '/create_order');

    const response = await fetch(`${cfg.apiUrl}/create_order`, {
      method: 'POST',
      headers: this._steadfastHeaders(cfg),
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });

    const result = await response.json();

    if (result.status !== 200 || !result.consignment) {
      console.error('[CourierService] SteadFast create error:', JSON.stringify(result));
      const errMsg = result.message || 'SteadFast order creation failed';
      const errDetail = result.error ? JSON.stringify(result.error) : '';
      throw new Error(errDetail ? `${errMsg}: ${errDetail}` : errMsg);
    }

    const db = getDb();
    const shipmentResult = this._insertShipment(db, {
      orderId: orderData.id,
      courierId: courier.id,
      consignmentId: String(result.consignment.consignment_id),
      trackingNumber: result.consignment.tracking_code,
      status: 'pending',
      cost: orderData.shipping_cost || 0,
    });

    this._updateOrderCourier(db, orderData.id, {
      courier_id: courier.id,
      consignment_id: String(result.consignment.consignment_id),
      tracking_number: result.consignment.tracking_code,
      status: 'courier_sent',
      shipped_at: new Date().toISOString(),
    });

    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, created_at)
       VALUES (?, 'courier_sent', ?, datetime('now'))`
    ).run(orderData.id, `Shipped via SteadFast. Tracking: ${result.consignment.tracking_code}`);

    return {
      success: true,
      consignmentId: result.consignment.consignment_id,
      trackingCode: result.consignment.tracking_code,
      invoice: result.consignment.invoice,
      shipmentId: shipmentResult.lastInsertRowid,
    };
  }

  async trackSteadfast(consignmentId, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/status_by_cid/${consignmentId}`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast tracking failed: HTTP ${response.status}`);
    }

    const result = await response.json();

    return {
      consignmentId,
      status: result.status || 'unknown',
      statusDescription: result.status || 'Unknown',
      currentLocation: result.present_location || '',
      estimatedDelivery: result.estimated_delivery_date || null,
      events: result.status_updates || [],
      codStatus: result.cod_status || null,
      amountCollected: result.amount_to_collect || 0,
      trackingMessage: result.tracking_message || '',
    };
  }

  async trackSteadfastByInvoice(invoice, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/status_by_invoice/${invoice}`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast tracking by invoice failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async trackSteadfastByTrackingCode(trackingCode, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/status_by_trackingcode/${trackingCode}`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast tracking by code failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async getSteadfastBalance(courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/get_balance`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast balance check failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async getSteadfastPayments(courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/payments`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast payments fetch failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async fraudCheckSteadfast(phone, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/fraud_check/${phone}`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast fraud check failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async createSteadfastReturnRequest(consignmentId, reason, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/create_return_request`, {
      method: 'POST',
      headers: this._steadfastHeaders(cfg),
      body: JSON.stringify({
        consignment_id: parseInt(consignmentId, 10),
        reason: reason || 'Customer requested return',
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast return request failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  async getSteadfastReturnRequests(courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/get_return_requests`, {
      method: 'GET',
      headers: this._steadfastHeaders(cfg),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error(`SteadFast return requests fetch failed: HTTP ${response.status}`);
    }

    return await response.json();
  }

  // =====================================================================
  //  PATHAO COURIER API
  // =====================================================================

  async createPathaoOrder(order, courier) {
    const cfg = this._getCourierConfig(courier);
    const { order: orderData, items, shippingAddr } = this._getOrderDetails(order.id);

    const token = await this._getPathaoToken(cfg);

    const merchantConfig = courier.config ? JSON.parse(courier.config) : {};

    const body = {
      merchant_order_id: orderData.order_number,
      recipient_name: shippingAddr.name || `${orderData.first_name} ${orderData.last_name}`.trim(),
      recipient_phone: normalizeBdPhone(shippingAddr.phone || orderData.user_phone),
      recipient_address: [shippingAddr.line1, shippingAddr.line2, shippingAddr.city].filter(Boolean).join(', '),
      city_id: merchantConfig.city_id || 1,
      zone_id: merchantConfig.zone_id || 1,
      area_id: merchantConfig.area_id || 1,
      delivery_type: merchantConfig.delivery_type || 'normal',
      amount_to_collect: orderData.payment_method === 'cod' ? orderData.total : 0,
      note: `Order: ${orderData.order_number}`,
    };

    const response = await fetch(`${cfg.apiUrl}/merchant/order`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });

    const result = await response.json();

    if (!result.data || result.data.error) {
      throw new Error(result.data?.error || result.message || 'Pathao order creation failed');
    }

    const db = getDb();
    const shipmentResult = this._insertShipment(db, {
      orderId: orderData.id,
      courierId: courier.id,
      consignmentId: String(result.data.consignment_id || result.data.order_id),
      trackingNumber: String(result.data.invoice || orderData.order_number),
      status: 'pending',
      cost: orderData.shipping_cost || 0,
    });

    this._updateOrderCourier(db, orderData.id, {
      courier_id: courier.id,
      consignment_id: String(result.data.consignment_id || result.data.order_id),
      tracking_number: String(result.data.invoice || orderData.order_number),
      status: 'courier_sent',
      shipped_at: new Date().toISOString(),
    });

    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, 'courier_sent', ?, datetime('now'))`
    ).run(orderData.id, `Shipped via Pathao. Invoice: ${result.data.invoice || 'N/A'}`);

    return {
      success: true,
      consignmentId: result.data.consignment_id || result.data.order_id,
      invoice: result.data.invoice,
      shipmentId: shipmentResult.lastInsertRowid,
    };
  }

  async _getPathaoToken(cfg) {
    const body = new URLSearchParams({
      username: cfg.username,
      password: cfg.password,
      grant_type: 'password',
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
    });

    const response = await fetch(`${cfg.tokenUrl}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error('Pathao authentication failed');
    }

    const data = await response.json();
    return data.access_token;
  }

  async trackPathao(orderId, courier) {
    const cfg = this._getCourierConfig(courier);
    const token = await this._getPathaoToken(cfg);

    const response = await fetch(`${cfg.apiUrl}/merchant/order-status/${orderId}`, {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${token}` },
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error('Pathao tracking request failed');
    }

    const result = await response.json();

    return {
      orderId,
      status: result.data?.status || 'unknown',
      statusDescription: result.data?.status || 'Unknown',
      currentLocation: result.data?.current_city || '',
      events: result.data?.status_history || [],
    };
  }

  // =====================================================================
  //  REDX COURIER API
  // =====================================================================

  async createRedXOrder(order, courier) {
    const cfg = this._getCourierConfig(courier);
    const { order: orderData, items, shippingAddr } = this._getOrderDetails(order.id);

    const merchantConfig = courier.config ? JSON.parse(courier.config) : {};

    const body = {
      invoice: orderData.order_number,
      recipient_name: shippingAddr.name || `${orderData.first_name} ${orderData.last_name}`.trim(),
      recipient_phone: normalizeBdPhone(shippingAddr.phone || orderData.user_phone),
      recipient_address: [shippingAddr.line1, shippingAddr.line2, shippingAddr.city, shippingAddr.district].filter(Boolean).join(', '),
      cod_amount: orderData.payment_method === 'cod' ? orderData.total : 0,
      note: `Order: ${orderData.order_number}. Items: ${items.map(i => i.product_name).join(', ')}`.substring(0, 250),
    };

    if (merchantConfig.delivery_area_id) {
      body.delivery_area_id = merchantConfig.delivery_area_id;
    }

    const response = await fetch(`${cfg.apiUrl}/create-order`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api_key': cfg.apiToken,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || err.error || 'RedX order creation failed');
    }

    const result = await response.json();
    const db = getDb();

    const shipmentResult = this._insertShipment(db, {
      orderId: orderData.id,
      courierId: courier.id,
      consignmentId: String(result.data?.tracking_code || orderData.order_number),
      trackingNumber: String(result.data?.tracking_code || orderData.order_number),
      status: 'pending',
      cost: orderData.shipping_cost || 0,
    });

    this._updateOrderCourier(db, orderData.id, {
      courier_id: courier.id,
      consignment_id: String(result.data?.tracking_code || orderData.order_number),
      tracking_number: String(result.data?.tracking_code || orderData.order_number),
      status: 'courier_sent',
      shipped_at: new Date().toISOString(),
    });

    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, 'courier_sent', ?, datetime('now'))`
    ).run(orderData.id, `Shipped via RedX. Tracking: ${result.data?.tracking_code || 'N/A'}`);

    return {
      success: true,
      trackingCode: result.data?.tracking_code,
      shipmentId: shipmentResult.lastInsertRowid,
    };
  }

  async trackRedX(trackingCode, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/parcel/${trackingCode}/status`, {
      method: 'GET',
      headers: { 'api_key': cfg.apiToken },
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error('RedX tracking request failed');
    }

    const result = await response.json();

    return {
      trackingCode,
      status: result.data?.current_status || 'unknown',
      statusDescription: result.data?.current_status || 'Unknown',
      currentLocation: result.data?.current_hub || '',
      events: result.data?.status_history || [],
    };
  }

  // =====================================================================
  //  PAPERFLY COURIER API
  // =====================================================================

  async createPaperflyOrder(order, courier) {
    const cfg = this._getCourierConfig(courier);
    const { order: orderData, items, shippingAddr } = this._getOrderDetails(order.id);

    const merchantConfig = courier.config ? JSON.parse(courier.config) : {};

    const body = {
      merchant_order_id: orderData.order_number,
      recipient_name: shippingAddr.name || `${orderData.first_name} ${orderData.last_name}`.trim(),
      recipient_phone: normalizeBdPhone(shippingAddr.phone || orderData.user_phone),
      address: [shippingAddr.line1, shippingAddr.line2, shippingAddr.city, shippingAddr.district].filter(Boolean).join(', '),
      cod_amount: orderData.payment_method === 'cod' ? orderData.total : 0,
      note: `Order: ${orderData.order_number}`,
    };

    if (merchantConfig.delivery_area) {
      body.delivery_area = merchantConfig.delivery_area;
    }

    const response = await fetch(`${cfg.apiUrl}/order/createOrder`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.message || err.error || 'Paperfly order creation failed');
    }

    const result = await response.json();
    const db = getDb();

    const shipmentResult = this._insertShipment(db, {
      orderId: orderData.id,
      courierId: courier.id,
      consignmentId: String(result.data?.tracking_code || orderData.order_number),
      trackingNumber: String(result.data?.tracking_code || orderData.order_number),
      status: 'pending',
      cost: orderData.shipping_cost || 0,
    });

    this._updateOrderCourier(db, orderData.id, {
      courier_id: courier.id,
      consignment_id: String(result.data?.tracking_code || orderData.order_number),
      tracking_number: String(result.data?.tracking_code || orderData.order_number),
      status: 'courier_sent',
      shipped_at: new Date().toISOString(),
    });

    db.prepare(
      `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, 'courier_sent', ?, datetime('now'))`
    ).run(orderData.id, `Shipped via Paperfly. Tracking: ${result.data?.tracking_code || 'N/A'}`);

    return {
      success: true,
      trackingCode: result.data?.tracking_code,
      shipmentId: shipmentResult.lastInsertRowid,
    };
  }

  async trackPaperfly(orderId, courier) {
    const cfg = this._getCourierConfig(courier);

    const response = await fetch(`${cfg.apiUrl}/order/statusByMerchantOrderId/${orderId}`, {
      method: 'GET',
      headers: { 'Authorization': `Bearer ${cfg.apiKey}` },
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      throw new Error('Paperfly tracking request failed');
    }

    const result = await response.json();

    return {
      orderId,
      status: result.data?.current_status || 'unknown',
      statusDescription: result.data?.current_status || 'Unknown',
      currentLocation: result.data?.current_hub || '',
      events: result.data?.status_history || [],
    };
  }

  // =====================================================================
  //  DISPATCHER METHODS
  // =====================================================================

  async createShipment(orderId, courierId) {
    const db = getDb();
    const courier = db.prepare('SELECT * FROM couriers WHERE id = ? AND is_active = 1').get(courierId);
    if (!courier) {
      throw new Error('Courier not found or inactive');
    }

    const existing = db.prepare('SELECT id FROM shipments WHERE order_id = ? AND courier_id = ?').get(orderId, courierId);
    if (existing) {
      throw new Error('Shipment already exists for this order and courier');
    }

    const order = db.prepare('SELECT id FROM orders WHERE id = ?').get(orderId);
    if (!order) {
      throw new Error('Order not found');
    }

    const courierConfig = this._getCourierConfig(courier);
    switch (courierConfig.provider) {
      case 'steadfast':
        return this.createSteadfastOrder({ id: orderId }, courier);
      case 'pathao':
        return this.createPathaoOrder({ id: orderId }, courier);
      case 'redx':
        return this.createRedXOrder({ id: orderId }, courier);
      case 'paperfly':
        return this.createPaperflyOrder({ id: orderId }, courier);
      default:
        throw new Error(`Unsupported courier: ${courier.name}`);
    }
  }

  async trackShipment(shipmentId) {
    const db = getDb();
    const shipment = db.prepare(
      `SELECT s.*, c.name as courier_name, c.slug as courier_slug, c.api_key, c.api_secret, c.api_url, c.config
       FROM shipments s JOIN couriers c ON s.courier_id = c.id WHERE s.id = ?`
    ).get(shipmentId);

    if (!shipment) {
      throw new Error('Shipment not found');
    }

    const courierConfig = this._getCourierConfig(shipment);
    let trackingResult;

    switch (courierConfig.provider) {
      case 'steadfast':
        trackingResult = await this.trackSteadfast(shipment.consignment_id, shipment);
        break;
      case 'pathao':
        trackingResult = await this.trackPathao(shipment.consignment_id, shipment);
        break;
      case 'redx':
        trackingResult = await this.trackRedX(shipment.tracking_number, shipment);
        break;
      case 'paperfly':
        trackingResult = await this.trackPaperfly(shipment.consignment_id, shipment);
        break;
      default:
        throw new Error(`Unsupported courier: ${shipment.courier_name}`);
    }

    const statusMap = {
      pending: 'pending',
      in_review: 'pending',
      picked: 'in_transit',
      picked_up: 'in_transit',
      in_transit: 'in_transit',
      on_the_way: 'in_transit',
      out_for_delivery: 'out_for_delivery',
      delivered_approval_pending: 'in_transit',
      delivered: 'delivered',
      delivered_completed: 'delivered',
      partial_delivered: 'delivered',
      partial_delivered_approval_pending: 'in_transit',
      returned: 'returned',
      cancelled: 'cancelled',
      cancelled_approval_pending: 'cancelled',
      hold: 'in_transit',
      hub_in_transit: 'in_transit',
      unknown: 'pending',
      unknown_approval_pending: 'pending',
    };

    const normalizedStatus = trackingResult.status.toLowerCase().replace(/[\s]+/g, '_');
    const shipmentStatus = statusMap[normalizedStatus] || 'in_transit';

    this._updateShipment(db, shipmentId, {
      status: shipmentStatus,
      status_update: JSON.stringify(trackingResult.events || []),
      estimated_delivery: trackingResult.estimatedDelivery || null,
      actual_delivery: shipmentStatus === 'delivered' ? new Date().toISOString() : null,
    });

    const orderStatusMap = {
      delivered: 'delivered',
      returned: 'returned',
      cancelled: 'cancelled',
    };
    const orderStatus = orderStatusMap[shipmentStatus] || null;

    if (orderStatus) {
      const currentOrder = db.prepare('SELECT status FROM orders WHERE id = ?').get(shipment.order_id);
      if (currentOrder && currentOrder.status !== orderStatus) {
        const updateData = { status: orderStatus };
        if (orderStatus === 'delivered') updateData.delivered_at = new Date().toISOString();

        this._updateOrderCourier(db, shipment.order_id, updateData);
        db.prepare(
          `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, ?, ?, datetime('now'))`
        ).run(shipment.order_id, orderStatus, `Courier status updated: ${trackingResult.status}`);
      }
    }

    return { ...trackingResult, shipmentId, orderStatus };
  }

  async syncStatuses() {
    const db = getDb();
    const pendingShipments = db.prepare(
      `SELECT s.id FROM shipments s
       WHERE s.status NOT IN ('delivered', 'returned', 'cancelled')
       ORDER BY s.updated_at ASC`
    ).all();

    console.log(`[CourierService] Syncing ${pendingShipments.length} pending shipment statuses...`);
    let updated = 0;
    let failed = 0;

    for (const shipment of pendingShipments) {
      try {
        await this.trackShipment(shipment.id);
        updated++;
      } catch (error) {
        failed++;
        console.error(`[CourierService] Failed to sync shipment ${shipment.id}:`, error.message);
      }
    }

    console.log(`[CourierService] Sync complete: ${updated} updated, ${failed} failed`);
    return { total: pendingShipments.length, updated, failed };
  }

  // =====================================================================
  //  WEBHOOK HANDLER — called from courier.routes.js
  // =====================================================================

  handleSteadfastWebhook(payload) {
    const { consignment_id, invoice, status, cod_amount, delivery_charge } = payload;
    const db = getDb();

    console.log('[CourierService] SteadFast webhook received:', JSON.stringify(payload));

    const statusMap = {
      pending: 'pending',
      in_review: 'pending',
      picked: 'in_transit',
      picked_up: 'in_transit',
      in_transit: 'in_transit',
      on_the_way: 'in_transit',
      out_for_delivery: 'out_for_delivery',
      delivered_approval_pending: 'in_transit',
      delivered: 'delivered',
      delivered_completed: 'delivered',
      partial_delivered: 'delivered',
      partial_delivered_approval_pending: 'in_transit',
      returned: 'returned',
      cancelled: 'cancelled',
      cancelled_approval_pending: 'cancelled',
      hold: 'in_transit',
      hub_in_transit: 'in_transit',
      unknown: 'pending',
      unknown_approval_pending: 'pending',
    };

    const normalizedStatus = (status || '').toLowerCase().replace(/[\s]+/g, '_');
    const shipmentStatus = statusMap[normalizedStatus] || 'in_transit';

    const shipment = db.prepare(
      `SELECT s.*, o.id as oid, o.status as order_status
       FROM shipments s JOIN orders o ON s.order_id = o.id
       WHERE s.consignment_id = ? OR s.tracking_number = ?`
    ).get(String(consignment_id), invoice);

    if (!shipment) {
      console.warn(`[CourierService] Webhook: no shipment found for consignment ${consignment_id}`);
      return { matched: false };
    }

    this._updateShipment(db, shipment.id, {
      status: shipmentStatus,
      actual_delivery: shipmentStatus === 'delivered' ? new Date().toISOString() : null,
    });

    const orderStatusMap = { delivered: 'delivered', returned: 'returned', cancelled: 'cancelled' };
    const newOrderStatus = orderStatusMap[shipmentStatus];

    if (newOrderStatus && shipment.order_status !== newOrderStatus) {
      const updateData = { status: newOrderStatus };
      if (newOrderStatus === 'delivered') updateData.delivered_at = new Date().toISOString();

      this._updateOrderCourier(db, shipment.oid, updateData);
      db.prepare(
        `INSERT INTO order_status_history (order_id, status, note, created_at) VALUES (?, ?, ?, datetime('now'))`
      ).run(shipment.oid, newOrderStatus, `SteadFast webhook: ${status}`);
    }

    return { matched: true, shipmentId: shipment.id, newStatus: shipmentStatus };
  }
}

export default new CourierService();
