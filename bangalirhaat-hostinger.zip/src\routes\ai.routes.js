import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { authenticate, authorize, optionalAuth } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import aiService from '../services/ai.service.js';
import { getDb } from '../database/db.js';

const router = Router();

const adminAuth = [authenticate, authorize('admin', 'super_admin')];

function getProductById(id) {
  const db = getDb();
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (product) {
    product.images = db.prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order').all(id);
    product.category = db.prepare('SELECT * FROM categories WHERE id = ?').get(product.category_id);
    product.brand = product.brand_id ? db.prepare('SELECT * FROM brands WHERE id = ?').get(product.brand_id) : null;
  }
  return product;
}

function getProductReviews(productId) {
  const db = getDb();
  return db.prepare('SELECT pr.*, u.first_name, u.last_name FROM product_reviews pr LEFT JOIN users u ON pr.user_id = u.id WHERE pr.product_id = ? ORDER BY pr.created_at DESC').all(productId);
}

function searchProducts(query, limit = 20) {
  const db = getDb();
  const q = `%${query}%`;
  return db.prepare('SELECT * FROM products WHERE is_active = 1 AND (name LIKE ? OR description LIKE ? OR sku LIKE ?) LIMIT ?').all(q, q, q, limit);
}

const describeValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
];

const seoValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
];

const reviewSummaryValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
];

const recommendValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
];

const searchValidation = [
  body('query').isString().trim().isLength({ min: 1, max: 200 }).withMessage('Search query is required'),
];

router.post('/describe', adminAuth, describeValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const product = getProductById(req.body.product_id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    const description = aiService.generateProductDescription(product);

    res.json({ success: true, data: { description } });
  } catch (error) {
    next(error);
  }
});

router.post('/seo', adminAuth, seoValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const product = getProductById(req.body.product_id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    const seo = aiService.generateSEO(product);

    res.json({ success: true, data: seo });
  } catch (error) {
    next(error);
  }
});

router.post('/review-summary', adminAuth, reviewSummaryValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const product = getProductById(req.body.product_id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    const reviews = getProductReviews(req.body.product_id);
    const summary = aiService.generateReviewSummary(reviews);

    res.json({ success: true, data: summary });
  } catch (error) {
    next(error);
  }
});

router.get('/predict/sales', adminAuth, async (req, res, next) => {
  try {
    const { product_id, days } = req.query;
    const productId = parseInt(product_id);
    if (!productId || productId < 1) {
      throw new AppError('Valid product_id query parameter is required', 400);
    }

    const prediction = aiService.predictSales(productId, parseInt(days) || 30);

    res.json({ success: true, data: prediction });
  } catch (error) {
    next(error);
  }
});

router.get('/predict/stock', adminAuth, async (req, res, next) => {
  try {
    const { product_id } = req.query;
    const productId = parseInt(product_id);
    if (!productId || productId < 1) {
      throw new AppError('Valid product_id query parameter is required', 400);
    }

    const prediction = aiService.predictStock(productId);

    res.json({ success: true, data: prediction });
  } catch (error) {
    next(error);
  }
});

router.post('/recommend', optionalAuth, recommendValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const userId = req.user?.id || null;
    const recommendations = await aiService.smartRecommend(userId, req.body.product_id);

    res.json({ success: true, data: { recommendations } });
  } catch (error) {
    next(error);
  }
});

router.post('/search', searchValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { query, limit } = req.body;
    const products = searchProducts(query, parseInt(limit) || 20);
    const results = aiService.optimizeSearch(query, products);

    res.json({ success: true, data: { results, total: results.length } });
  } catch (error) {
    next(error);
  }
});

export default router;
