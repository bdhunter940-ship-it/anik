import { getDb } from '../database/db.js';

class BundleService {
  async createBundle({ name, description, discountType, discountValue, minQuantity, productIds, startsAt, endsAt }) {
    const db = getDb();

    if (!name) throw new Error('Bundle name is required');
    if (!discountType || !['percentage', 'fixed'].includes(discountType)) {
      throw new Error('Discount type must be percentage or fixed');
    }
    if (discountValue === undefined || discountValue <= 0) {
      throw new Error('Discount value must be greater than 0');
    }
    if (!productIds || !Array.isArray(productIds) || productIds.length < 2) {
      throw new Error('At least 2 product IDs are required');
    }

    const result = db.prepare(
      `INSERT INTO bundles (name, description, discount_type, discount_value, min_quantity, starts_at, ends_at, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))`
    ).run(
      name, description || null, discountType, discountValue,
      minQuantity || productIds.length, startsAt || null, endsAt || null
    );

    const bundleId = result.lastInsertRowid;

    const insertProduct = db.prepare(
      `INSERT INTO bundle_products (bundle_id, product_id, created_at)
       VALUES (?, ?, datetime('now'))`
    );

    for (const productId of productIds) {
      insertProduct.run(bundleId, productId);
    }

    const bundle = db.prepare('SELECT * FROM bundles WHERE id = ?').get(bundleId);

    return { bundle };
  }

  async updateBundle(id, data) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM bundles WHERE id = ?').get(id);
    if (!existing) throw new Error('Bundle not found');

    const { name, description, discountType, discountValue, minQuantity, productIds, startsAt, endsAt, isActive } = data;

    const updateTransaction = db.transaction(() => {
      db.prepare(
        `UPDATE bundles SET
          name = ?, description = ?, discount_type = ?, discount_value = ?,
          min_quantity = ?, starts_at = ?, ends_at = ?, is_active = ?,
          updated_at = datetime('now')
         WHERE id = ?`
      ).run(
        name !== undefined ? name : existing.name,
        description !== undefined ? description : existing.description,
        discountType !== undefined ? discountType : existing.discount_type,
        discountValue !== undefined ? discountValue : existing.discount_value,
        minQuantity !== undefined ? minQuantity : existing.min_quantity,
        startsAt !== undefined ? startsAt : existing.starts_at,
        endsAt !== undefined ? endsAt : existing.ends_at,
        isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
        id
      );

      if (productIds && Array.isArray(productIds)) {
        db.prepare('DELETE FROM bundle_products WHERE bundle_id = ?').run(id);
        const insertProduct = db.prepare(
          `INSERT INTO bundle_products (bundle_id, product_id, created_at)
           VALUES (?, ?, datetime('now'))`
        );
        for (const productId of productIds) {
          insertProduct.run(id, productId);
        }
      }
    });

    updateTransaction();

    const bundle = db.prepare('SELECT * FROM bundles WHERE id = ?').get(id);

    return { bundle };
  }

  async deleteBundle(id) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM bundles WHERE id = ?').get(id);
    if (!existing) throw new Error('Bundle not found');

    db.prepare('DELETE FROM bundle_products WHERE bundle_id = ?').run(id);
    db.prepare('DELETE FROM bundles WHERE id = ?').run(id);

    return { message: 'Bundle deleted successfully' };
  }

  async getBundle(id) {
    const db = getDb();
    const bundle = db.prepare('SELECT * FROM bundles WHERE id = ?').get(id);
    if (!bundle) throw new Error('Bundle not found');

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price, p.compare_price,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM bundle_products bp
       JOIN products p ON bp.product_id = p.id
       WHERE bp.bundle_id = ?
       ORDER BY bp.created_at ASC`
    ).all(id);

    return { bundle: { ...bundle, products } };
  }

  async getAllBundles({ page = 1, limit = 20 } = {}) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    const total = db.prepare('SELECT COUNT(*) as count FROM bundles').get().count;

    const bundles = db.prepare(
      `SELECT b.*,
              (SELECT COUNT(*) FROM bundle_products WHERE bundle_id = b.id) as product_count
       FROM bundles b
       ORDER BY b.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(limit, offset);

    return {
      bundles,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getBundlesForProduct(productId) {
    const db = getDb();

    const bundles = db.prepare(
      `SELECT b.*
       FROM bundles b
       JOIN bundle_products bp ON b.id = bp.bundle_id
       WHERE bp.product_id = ? AND b.is_active = 1
         AND (b.starts_at IS NULL OR b.starts_at <= datetime('now'))
         AND (b.ends_at IS NULL OR b.ends_at >= datetime('now'))
       ORDER BY b.created_at DESC`
    ).all(productId);

    const bundlesWithProducts = bundles.map((bundle) => {
      const products = db.prepare(
        `SELECT p.id, p.name, p.slug, p.price,
                (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
         FROM bundle_products bp
         JOIN products p ON bp.product_id = p.id
         WHERE bp.bundle_id = ?`
      ).all(bundle.id);

      return { ...bundle, products };
    });

    return { bundles: bundlesWithProducts };
  }

  async calculateBundlePrice(bundleId, quantity = 1) {
    const db = getDb();
    const bundle = db.prepare('SELECT * FROM bundles WHERE id = ? AND is_active = 1').get(bundleId);
    if (!bundle) throw new Error('Bundle not found or inactive');

    if (quantity < bundle.min_quantity) {
      throw new Error(`Minimum quantity for this bundle is ${bundle.min_quantity}`);
    }

    if (bundle.starts_at && new Date(bundle.starts_at) > new Date()) {
      throw new Error('Bundle has not started yet');
    }
    if (bundle.ends_at && new Date(bundle.ends_at) < new Date()) {
      throw new Error('Bundle has expired');
    }

    const products = db.prepare(
      `SELECT p.id, p.name, p.price
       FROM bundle_products bp
       JOIN products p ON bp.product_id = p.id
       WHERE bp.bundle_id = ?`
    ).all(bundleId);

    if (products.length === 0) throw new Error('Bundle has no products');

    const originalTotal = products.reduce((sum, p) => sum + p.price, 0) * quantity;

    let discountedTotal;
    if (bundle.discount_type === 'percentage') {
      discountedTotal = originalTotal - (originalTotal * bundle.discount_value / 100);
    } else {
      discountedTotal = originalTotal - (bundle.discount_value * quantity);
    }

    discountedTotal = Math.max(0, discountedTotal);

    return {
      bundleId: bundle.id,
      bundleName: bundle.name,
      quantity,
      originalTotal,
      discountType: bundle.discount_type,
      discountValue: bundle.discount_value,
      discountedTotal,
      savings: originalTotal - discountedTotal,
      perUnitPrice: discountedTotal / quantity,
      products,
    };
  }

  async addFBT(productId, relatedProductId) {
    const db = getDb();

    if (productId === relatedProductId) {
      throw new Error('Cannot add a product as frequently bought together with itself');
    }

    const product = db.prepare('SELECT id FROM products WHERE id = ?').get(productId);
    if (!product) throw new Error('Product not found');

    const relatedProduct = db.prepare('SELECT id FROM products WHERE id = ?').get(relatedProductId);
    if (!relatedProduct) throw new Error('Related product not found');

    const existing = db.prepare(
      'SELECT id FROM frequently_bought_together WHERE product_id = ? AND related_product_id = ?'
    ).get(productId, relatedProductId);
    if (existing) throw new Error('This FBT association already exists');

    const reverseExisting = db.prepare(
      'SELECT id FROM frequently_bought_together WHERE product_id = ? AND related_product_id = ?'
    ).get(relatedProductId, productId);
    if (reverseExisting) throw new Error('This FBT association already exists');

    const result = db.prepare(
      `INSERT INTO frequently_bought_together (product_id, related_product_id, frequency, created_at, updated_at)
       VALUES (?, ?, 0, datetime('now'), datetime('now'))`
    ).run(productId, relatedProductId);

    const fbt = db.prepare('SELECT * FROM frequently_bought_together WHERE id = ?').get(result.lastInsertRowid);

    return { fbt };
  }

  async removeFBT(id) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM frequently_bought_together WHERE id = ?').get(id);
    if (!existing) throw new Error('FBT association not found');

    db.prepare('DELETE FROM frequently_bought_together WHERE id = ?').run(id);

    return { message: 'FBT association removed successfully' };
  }

  async getFBTProducts(productId) {
    const db = getDb();

    const recommendations = db.prepare(
      `SELECT fbt.id as fbt_id, p.id, p.name, p.slug, p.price, p.compare_price,
              fbt.frequency,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM frequently_bought_together fbt
       JOIN products p ON fbt.related_product_id = p.id
       WHERE fbt.product_id = ? AND p.is_active = 1
       ORDER BY fbt.frequency DESC`
    ).all(productId);

    return { products: recommendations };
  }

  async getFBTData(productId) {
    const db = getDb();

    const products = db.prepare(
      `SELECT p.id, p.name, p.slug, p.price,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM frequently_bought_together fbt
       JOIN products p ON fbt.related_product_id = p.id
       WHERE fbt.product_id = ? AND p.is_active = 1
       ORDER BY fbt.frequency DESC`
    ).all(productId);

    if (products.length === 0) {
      return { products: [], totalPrice: 0, savings: 0 };
    }

    const mainProduct = db.prepare('SELECT id, price FROM products WHERE id = ?').get(productId);
    if (!mainProduct) throw new Error('Product not found');

    const fbtTotal = products.reduce((sum, p) => sum + p.price, 0);
    const allPrices = mainProduct.price + fbtTotal;
    const bundleSavings = Math.round(fbtTotal * 0.1 * 100) / 100;

    return {
      products,
      totalPrice: Math.round((allPrices - bundleSavings) * 100) / 100,
      savings: bundleSavings,
    };
  }

  async trackFBT(productId, relatedProductId) {
    const db = getDb();

    const result = db.prepare(
      `UPDATE frequently_bought_together
       SET frequency = frequency + 1, updated_at = datetime('now')
       WHERE product_id = ? AND related_product_id = ?`
    ).run(productId, relatedProductId);

    if (result.changes === 0) {
      db.prepare(
        `INSERT INTO frequently_bought_together (product_id, related_product_id, frequency, created_at, updated_at)
         VALUES (?, ?, 1, datetime('now'), datetime('now'))`
      ).run(productId, relatedProductId);
    }

    return { message: 'FBT frequency tracked' };
  }
}

export default new BundleService();
