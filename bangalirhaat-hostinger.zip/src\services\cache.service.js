import { getDb } from '../database/db.js';

class CacheService {
  constructor() {
    this.cache = new Map();
    this.ttls = new Map();
    this.cleanupInterval = null;
  }

  set(key, value, ttlSeconds = 300) {
    this.cache.set(key, value);
    this.ttls.set(key, Date.now() + ttlSeconds * 1000);
  }

  get(key) {
    if (!this.cache.has(key)) return undefined;

    const expiry = this.ttls.get(key);
    if (expiry && Date.now() > expiry) {
      this.delete(key);
      return undefined;
    }

    return this.cache.get(key);
  }

  delete(key) {
    this.cache.delete(key);
    this.ttls.delete(key);
  }

  has(key) {
    if (!this.cache.has(key)) return false;
    const expiry = this.ttls.get(key);
    if (expiry && Date.now() > expiry) {
      this.delete(key);
      return false;
    }
    return true;
  }

  clear(pattern) {
    if (!pattern) {
      this.cache.clear();
      this.ttls.clear();
      return;
    }

    const regex = new RegExp(pattern.replace(/\*/g, '.*'));
    for (const key of this.cache.keys()) {
      if (regex.test(key)) {
        this.delete(key);
      }
    }
  }

  cleanup() {
    const now = Date.now();
    for (const [key, expiry] of this.ttls) {
      if (now > expiry) {
        this.delete(key);
      }
    }
  }

  startCleanup(intervalMs = 60000) {
    if (this.cleanupInterval) return;
    this.cleanupInterval = setInterval(() => this.cleanup(), intervalMs);
    if (this.cleanupInterval.unref) {
      this.cleanupInterval.unref();
    }
  }

  stopCleanup() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  get size() {
    return this.cache.size;
  }

  async getProduct(productId) {
    const key = `product:${productId}`;
    const cached = this.get(key);
    if (cached) return cached;

    const db = getDb();
    const product = db.prepare(`
      SELECT p.*, c.name as category_name, b.name as brand_name,
        (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      LEFT JOIN brands b ON b.id = p.brand_id
      WHERE p.id = ? AND p.is_active = 1 AND p.deleted_at IS NULL
    `).get(productId);

    if (product) {
      this.set(key, product, 300);
    }

    return product || null;
  }

  async getFeaturedProducts() {
    const key = 'products:featured';
    const cached = this.get(key);
    if (cached) return cached;

    const db = getDb();
    const products = db.prepare(`
      SELECT p.id, p.uuid, p.name, p.slug, p.price, p.compare_price,
        (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
        p.average_rating, p.review_count, p.stock_quantity
      FROM products p
      WHERE p.is_active = 1 AND p.is_featured = 1 AND p.deleted_at IS NULL
      ORDER BY p.created_at DESC
      LIMIT 20
    `).all();

    this.set(key, products, 600);
    return products;
  }

  async getCategoryTree() {
    const key = 'categories:tree';
    const cached = this.get(key);
    if (cached) return cached;

    const db = getDb();
    const categories = db.prepare(`
      SELECT id, uuid, name, slug, description, image, parent_id, sort_order, is_active
      FROM categories
      WHERE is_active = 1 AND deleted_at IS NULL
      ORDER BY sort_order ASC, name ASC
    `).all();

    const tree = this.buildCategoryTree(categories);
    this.set(key, tree, 1800);
    return tree;
  }

  buildCategoryTree(categories, parentId = null) {
    return categories
      .filter((cat) => cat.parent_id === parentId)
      .map((cat) => ({
        ...cat,
        children: this.buildCategoryTree(categories, cat.id),
      }));
  }

  async getSettings(group = null) {
    const key = group ? `settings:${group}` : 'settings:all';
    const cached = this.get(key);
    if (cached) return cached;

    const db = getDb();
    let settings;

    if (group) {
      settings = db.prepare(
        'SELECT key, value, group_name FROM settings WHERE group_name = ?'
      ).all(group);
    } else {
      settings = db.prepare('SELECT key, value, group_name FROM settings').all();
    }

    const parsed = {};
    for (const setting of settings) {
      try {
        parsed[setting.key] = JSON.parse(setting.value);
      } catch {
        parsed[setting.key] = setting.value;
      }
    }

    this.set(key, parsed, 3600);
    return parsed;
  }

  invalidateProduct(productId) {
    this.delete(`product:${productId}`);
    this.clear('products:featured');
  }

  invalidateCategories() {
    this.clear('categories:tree');
  }

  invalidateSettings(group) {
    if (group) {
      this.delete(`settings:${group}`);
    }
    this.delete('settings:all');
  }
}

export default new CacheService();
