import express from 'express';
import { getDb } from '../database/db.js';
import { authenticate, authorize } from '../middleware/auth.js';
import cartService from '../services/cart.service.js';

const router = express.Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

// GET /api/cart/recovery/abandoned — List abandoned carts
router.get('/recovery/abandoned', adminAuth, async (req, res, next) => {
  try {
    const hours = parseInt(req.query.hours) || 24;
    const carts = cartService.getAbandonedCarts(hours);
    res.json({ success: true, data: { items: carts, hours } });
  } catch (err) { next(err); }
});

// POST /api/cart/recovery/process — Process abandoned carts manually
router.post('/recovery/process', adminAuth, async (req, res, next) => {
  try {
    const hours = parseInt(req.body.hours) || 24;
    const result = await cartService.processAbandonedCarts(hours);
    res.json({ success: true, message: `Processed ${result.processed} abandoned carts`, data: result });
  } catch (err) { next(err); }
});

// GET /api/cart/recovery/stats — Recovery stats
router.get('/recovery/stats', adminAuth, async (req, res, next) => {
  try {
    const db = getDb();
    const totalAbandoned = db.prepare(`SELECT COUNT(*) as count FROM carts WHERE updated_at < datetime('now', '-24 hours') AND (SELECT COUNT(*) FROM cart_items WHERE cart_id = carts.id) > 0`).get();
    const totalRecovered = db.prepare(`SELECT COUNT(*) as count FROM abandoned_cart_recoveries`).get();
    const todaySent = db.prepare(`SELECT COUNT(*) as count FROM abandoned_cart_recoveries WHERE date(sent_at) = date('now')`).get();
    res.json({ success: true, data: { total_abandoned: totalAbandoned.count, total_recovered: totalRecovered.count, today_sent: todaySent.count } });
  } catch (err) { next(err); }
});

export default router;
