import crypto from 'crypto';
import { getDb } from '../database/db.js';

const REWARD_AMOUNT = 100;
const WELCOME_BONUS = 50;
const MAX_CODE_LENGTH = 12;

function generateUniqueCode() {
  return crypto.randomBytes(6).toString('hex').toUpperCase().slice(0, MAX_CODE_LENGTH);
}

class ReferralService {
  async generateCode(userId) {
    const db = getDb();
    const user = db.prepare('SELECT id, referral_code FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');

    if (user.referral_code) {
      return { code: user.referral_code, isNew: false };
    }

    let code;
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      code = generateUniqueCode();
      const exists = db.prepare('SELECT id FROM users WHERE referral_code = ?').get(code);
      if (!exists) break;
      attempts++;
    }

    if (attempts >= maxAttempts) {
      throw new Error('Failed to generate unique referral code');
    }

    db.prepare(`
      UPDATE users SET referral_code = ?, updated_at = datetime('now') WHERE id = ?
    `).run(code, userId);

    return { code, isNew: true };
  }

  async applyReferral(newUserId, referralCode) {
    const db = getDb();
    if (!referralCode || !referralCode.trim()) return null;

    const code = referralCode.trim().toUpperCase();

    const referrer = db.prepare(
      'SELECT id, referral_code FROM users WHERE referral_code = ?'
    ).get(code);

    if (!referrer) throw new Error('Invalid referral code');
    if (referrer.id === newUserId) throw new Error('Cannot refer yourself');

    const newUser = db.prepare(
      'SELECT id, referred_by FROM users WHERE id = ?'
    ).get(newUserId);

    if (!newUser) throw new Error('User not found');
    if (newUser.referred_by) throw new Error('User was already referred');

    const applyTransaction = db.transaction(() => {
      db.prepare(`
        UPDATE users SET referred_by = ?, updated_at = datetime('now') WHERE id = ?
      `).run(referrer.id, newUserId);

      db.prepare(`
        INSERT INTO loyalty_transactions (user_id, points, type, reference, description)
        VALUES (?, ?, 'earned', ?, ?)
      `).run(
        referrer.id,
        REWARD_AMOUNT,
        `referral:referrer:${referrer.id}`,
        `Referral reward: referred user #${newUserId}`,
      );

      db.prepare(`
        UPDATE users SET loyalty_points = loyalty_points + ?, updated_at = datetime('now') WHERE id = ?
      `).run(REWARD_AMOUNT, referrer.id);

      db.prepare(`
        INSERT INTO loyalty_transactions (user_id, points, type, reference, description)
        VALUES (?, ?, 'earned', ?, ?)
      `).run(
        newUserId,
        WELCOME_BONUS,
        `referral:welcomed:${referrer.id}`,
        `Welcome bonus for joining via referral`,
      );

      db.prepare(`
        UPDATE users SET loyalty_points = loyalty_points + ?, updated_at = datetime('now') WHERE id = ?
      `).run(WELCOME_BONUS, newUserId);
    });

    applyTransaction();

    return {
      referrerId: referrer.id,
      referrerReward: REWARD_AMOUNT,
      newUserReward: WELCOME_BONUS,
    };
  }

  async getReferralStats(userId) {
    const db = getDb();
    const user = db.prepare('SELECT id, referral_code FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');

    if (!user.referral_code) {
      return {
        referralCode: null,
        totalReferrals: 0,
        totalRewards: 0,
        pendingRewards: 0,
      };
    }

    const stats = db.prepare(`
      SELECT COUNT(*) as totalReferrals
      FROM users WHERE referred_by = ?
    `).get(userId);

    const rewards = db.prepare(`
      SELECT COALESCE(SUM(CASE WHEN points > 0 THEN points ELSE 0 END), 0) as totalRewards
      FROM loyalty_transactions
      WHERE user_id = ? AND type = 'earned' AND reference LIKE 'referral:referrer:%'
    `).get(userId);

    const pending = db.prepare(`
      SELECT COUNT(*) as pendingRewards
      FROM users WHERE referred_by = ? AND email_verified = 0
    `).get(userId);

    return {
      referralCode: user.referral_code,
      totalReferrals: stats.totalReferrals,
      totalRewards: rewards.totalRewards,
      pendingRewards: pending.pendingRewards,
    };
  }

  async getReferralHistory(userId, page = 1, limit = 20) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    const total = db.prepare(
      'SELECT COUNT(*) as count FROM users WHERE referred_by = ?'
    ).get(userId).count;

    const referrals = db.prepare(`
      SELECT id, first_name, last_name, email, created_at
      FROM users
      WHERE referred_by = ?
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(userId, limit, offset);

    return {
      referrals,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async generateReferralLink(userId) {
    const { code } = await this.generateCode(userId);
    const baseUrl = process.env.FRONTEND_URL || 'https://bangalirhaat.com';
    return {
      code,
      link: `${baseUrl}/register?ref=${code}`,
      shareText: `Join Bangalirhaat using my referral code ${code} and get ${WELCOME_BONUS} bonus points! ${baseUrl}/register?ref=${code}`,
    };
  }
}

export default new ReferralService();
