CREATE TABLE IF NOT EXISTS abandoned_cart_recoveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cart_id INTEGER NOT NULL,
  notification_type TEXT NOT NULL DEFAULT 'email',
  coupon_code TEXT,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  recovered_at DATETIME,
  FOREIGN KEY (cart_id) REFERENCES carts(id)
);
