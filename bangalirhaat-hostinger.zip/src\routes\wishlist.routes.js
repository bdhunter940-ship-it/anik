import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

router.use(authenticate);

const addValidation = [
  body('product_id').optional().isInt({ min: 1 }).toInt(),
  body('productId').optional().isInt({ min: 1 }).toInt(),
];

const productIdValidation = [
  param('productId').isInt({ min: 1 }).toInt().withMessage('Invalid product ID'),
];

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const countRow = db.prepare('SELECT COUNT(*) as total FROM wishlists WHERE user_id = ?').get(userId);

    const items = db.prepare(
      `SELECT w.id, w.product_id, w.created_at,
              p.name, p.slug, p.price, p.compare_price, p.average_rating, p.stock_quantity,
              b.name as brand_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM wishlists w
       JOIN products p ON w.product_id = p.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE w.user_id = ? AND p.is_active = 1
       ORDER BY w.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(userId, limit, offset);

    res.json({
      success: true,
      data: {
        items,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/', addValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const product_id = req.body.product_id || req.body.productId;

    const product = db.prepare('SELECT id, is_active FROM products WHERE id = ?').get(product_id);
    if (!product || product.is_active !== 1) {
      throw new AppError('Product not found or unavailable', 404);
    }

    const existing = db.prepare(
      'SELECT id FROM wishlists WHERE user_id = ? AND product_id = ?'
    ).get(userId, product_id);

    if (existing) {
      throw new AppError('Product already in wishlist', 409);
    }

    db.prepare(
      `INSERT INTO wishlists (user_id, product_id, created_at) VALUES (?, ?, datetime('now'))`
    ).run(userId, product_id);

    const count = db.prepare('SELECT COUNT(*) as total FROM wishlists WHERE user_id = ?').get(userId);

    res.status(201).json({
      success: true,
      message: 'Added to wishlist',
      data: { total: count.total },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/:productId', productIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const result = db.prepare(
      'DELETE FROM wishlists WHERE user_id = ? AND product_id = ?'
    ).run(userId, req.params.productId);

    if (result.changes === 0) {
      throw new AppError('Product not in wishlist', 404);
    }

    const count = db.prepare('SELECT COUNT(*) as total FROM wishlists WHERE user_id = ?').get(userId);

    res.json({
      success: true,
      message: 'Removed from wishlist',
      data: { total: count.total },
    });
  } catch (error) {
    next(error);
  }
});

router.get('/check/:productId', productIdValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const item = db.prepare(
      'SELECT id FROM wishlists WHERE user_id = ? AND product_id = ?'
    ).get(userId, req.params.productId);

    res.json({
      success: true,
      data: { is_in_wishlist: !!item },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
