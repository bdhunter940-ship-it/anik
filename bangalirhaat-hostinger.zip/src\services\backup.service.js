import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import { existsSync } from 'fs';
import { getDb } from '../database/db.js';
import config from '../config/index.js';

const execAsync = promisify(exec);

const BACKUP_DIR = path.resolve(config.root || process.cwd(), 'backups');
const DB_PATH = config.db.path;
const MAX_BACKUPS = 30;

class BackupService {
  constructor() {
    this._cronJob = null;
    this._backupDir = BACKUP_DIR;
  }

  async _ensureBackupDir() {
    try {
      await fs.access(this._backupDir);
    } catch {
      await fs.mkdir(this._backupDir, { recursive: true });
      console.log(`[BackupService] Created backup directory: ${this._backupDir}`);
    }
  }

  _getBackupPath(timestamp) {
    return path.join(this._backupDir, `bangalirhaat-${timestamp}.db`);
  }

  _getMetadataPath() {
    return path.join(this._backupDir, 'backups.json');
  }

  async _loadMetadata() {
    try {
      const data = await fs.readFile(this._getMetadataPath(), 'utf-8');
      return JSON.parse(data);
    } catch {
      return { backups: [] };
    }
  }

  async _saveMetadata(metadata) {
    await fs.writeFile(this._getMetadataPath(), JSON.stringify(metadata, null, 2), 'utf-8');
  }

  _generateTimestamp() {
    return new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').substring(0, 19);
  }

  async _getDbSize() {
    try {
      const stat = await fs.stat(DB_PATH);
      return stat.size;
    } catch {
      return 0;
    }
  }

  _formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  async createBackup() {
    await this._ensureBackupDir();

    const timestamp = this._generateTimestamp();
    const backupPath = this._getBackupPath(timestamp);
    const dbSize = await this._getDbSize();

    console.log(`[BackupService] Creating backup... (DB: ${this._formatSize(dbSize)})`);

    try {
      try {
        const db = getDb();
        db.pragma('wal_checkpoint(TRUNCATE)');
      } catch (e) {
        console.warn('[BackupService] WAL checkpoint warning:', e.message);
      }

      await fs.copyFile(DB_PATH, backupPath);

      const walPath = DB_PATH + '-wal';
      const shmPath = DB_PATH + '-shm';
      const backupWal = backupPath + '-wal';
      const backupShm = backupPath + '-shm';

      try {
        await fs.access(walPath);
        await fs.copyFile(walPath, backupWal);
      } catch {}

      try {
        await fs.access(shmPath);
        await fs.copyFile(shmPath, backupShm);
      } catch {}

      const stat = await fs.stat(backupPath);
      const backupSize = stat.size;

      const metadata = await this._loadMetadata();
      const backupEntry = {
        id: timestamp,
        filename: path.basename(backupPath),
        path: backupPath,
        size: backupSize,
        formattedSize: this._formatSize(backupSize),
        originalDbSize: dbSize,
        originalDbFormatted: this._formatSize(dbSize),
        createdAt: new Date().toISOString(),
        type: 'manual',
      };

      metadata.backups.push(backupEntry);
      await this._saveMetadata(metadata);

      console.log(`[BackupService] Backup created: ${backupEntry.filename} (${backupEntry.formattedSize})`);

      if (metadata.backups.length > MAX_BACKUPS) {
        const toDelete = metadata.backups.splice(0, metadata.backups.length - MAX_BACKUPS);
        for (const old of toDelete) {
          await this.deleteBackup(old.id);
        }
      }

      return {
        success: true,
        backup: backupEntry,
      };
    } catch (error) {
      console.error('[BackupService] Backup creation failed:', error.message);
      throw new Error(`Backup creation failed: ${error.message}`);
    }
  }

  async listBackups() {
    await this._ensureBackupDir();

    const metadata = await this._loadMetadata();
    const existingBackups = [];

    for (const backup of metadata.backups) {
      try {
        await fs.access(backup.path);
        const stat = await fs.stat(backup.path);
        existingBackups.push({
          ...backup,
          exists: true,
          currentSize: stat.size,
          formattedCurrentSize: this._formatSize(stat.size),
        });
      } catch {
        existingBackups.push({
          ...backup,
          exists: false,
        });
      }
    }

    return {
      total: existingBackups.length,
      backups: existingBackups.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
      maxSize: MAX_BACKUPS,
    };
  }

  async restoreBackup(backupId) {
    await this._ensureBackupDir();

    const metadata = await this._loadMetadata();
    const backup = metadata.backups.find(b => b.id === backupId);

    if (!backup) {
      throw new Error(`Backup not found: ${backupId}`);
    }

    if (!existsSync(backup.path)) {
      throw new Error(`Backup file does not exist on disk: ${backup.filename}`);
    }

    const preRestoreBackup = await this.createBackup();
    console.log(`[BackupService] Pre-restore backup created: ${preRestoreBackup.backup.filename}`);

    try {
      try {
        const db = getDb();
        db.pragma('wal_checkpoint(TRUNCATE)');
      } catch (e) {
        console.warn('[BackupService] WAL checkpoint before restore:', e.message);
      }

      const tempPath = DB_PATH + '.restore-temp';
      await fs.copyFile(DB_PATH, tempPath);

      try {
        await fs.copyFile(backup.path, DB_PATH);

        const walBackupPath = backup.path + '-wal';
        const shmBackupPath = backup.path + '-shm';
        const walTargetPath = DB_PATH + '-wal';
        const shmTargetPath = DB_PATH + '-shm';

        try {
          await fs.access(walBackupPath);
          await fs.copyFile(walBackupPath, walTargetPath);
        } catch {
          try { await fs.unlink(walTargetPath); } catch {}
        }

        try {
          await fs.access(shmBackupPath);
          await fs.copyFile(shmBackupPath, shmTargetPath);
        } catch {
          try { await fs.unlink(shmTargetPath); } catch {}
        }

        console.log(`[BackupService] Database restored from backup: ${backup.filename}`);
        console.log(`[BackupService] Pre-restore backup: ${preRestoreBackup.backup.filename}`);
        console.log(`[BackupService] IMPORTANT: Restart the server for changes to take effect`);

        return {
          success: true,
          restoredFrom: backup,
          preRestoreBackup: preRestoreBackup.backup,
          message: 'Database restored. Please restart the server.',
        };
      } catch (restoreError) {
        console.error('[BackupService] Restore failed, attempting rollback...');
        try {
          await fs.copyFile(tempPath, DB_PATH);
          console.log('[BackupService] Rollback successful');
        } catch (rollbackError) {
          console.error('[BackupService] CRITICAL: Rollback also failed:', rollbackError.message);
        }
        throw restoreError;
      } finally {
        try { await fs.unlink(tempPath); } catch {}
      }
    } catch (error) {
      throw new Error(`Restore failed: ${error.message}`);
    }
  }

  async deleteBackup(backupId) {
    const metadata = await this._loadMetadata();
    const backupIndex = metadata.backups.findIndex(b => b.id === backupId);

    if (backupIndex === -1) {
      throw new Error(`Backup not found: ${backupId}`);
    }

    const backup = metadata.backups[backupIndex];

    try {
      if (existsSync(backup.path)) {
        await fs.unlink(backup.path);
      }

      try { await fs.unlink(backup.path + '-wal'); } catch {}
      try { await fs.unlink(backup.path + '-shm'); } catch {}

      metadata.backups.splice(backupIndex, 1);
      await this._saveMetadata(metadata);

      console.log(`[BackupService] Deleted backup: ${backup.filename}`);
      return { success: true, deleted: backup.filename };
    } catch (error) {
      throw new Error(`Failed to delete backup: ${error.message}`);
    }
  }

  async scheduleAutoBackup() {
    if (this._cronJob) {
      this._cronJob.stop();
    }

    let cronModule;
    try {
      cronModule = await import('node-cron');
    } catch {
      console.warn('[BackupService] node-cron not available, auto-backup disabled');
      return;
    }

    this._cronJob = cronModule.default.schedule('0 3 * * *', async () => {
      console.log('[BackupService] Running auto-backup...');
      try {
        await this.createBackup();
        console.log('[BackupService] Auto-backup completed successfully');
      } catch (error) {
        console.error('[BackupService] Auto-backup failed:', error.message);
      }
    }, {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    });

    console.log('[BackupService] Auto-backup scheduled daily at 03:00 AM (Asia/Dhaka)');
  }

  stopAutoBackup() {
    if (this._cronJob) {
      this._cronJob.stop();
      this._cronJob = null;
      console.log('[BackupService] Auto-backup stopped');
    }
  }

  async getBackupStats() {
    const metadata = await this._loadMetadata();
    const dbSize = await this._getDbSize();

    let totalBackupSize = 0;
    for (const backup of metadata.backups) {
      try {
        const stat = await fs.stat(backup.path);
        totalBackupSize += stat.size;
      } catch {}
    }

    return {
      database: {
        path: DB_PATH,
        size: dbSize,
        formattedSize: this._formatSize(dbSize),
      },
      backups: {
        count: metadata.backups.length,
        totalSize: totalBackupSize,
        formattedTotalSize: this._formatSize(totalBackupSize),
        maxAllowed: MAX_BACKUPS,
        directory: this._backupDir,
      },
      autoBackup: {
        enabled: !!this._cronJob,
        schedule: '0 3 * * * (daily at 3:00 AM)',
        timezone: 'Asia/Dhaka',
      },
    };
  }
}

export default new BackupService();
