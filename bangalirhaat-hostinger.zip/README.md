# Bangalirhaat

**Premium Bangladeshi E-Commerce Platform — Enterprise-Level Quality**

A world-class, production-ready e-commerce platform built for the Bangladeshi market with premium UI/UX inspired by Apple, Nike, Louis Vuitton, and Tesla. Features glassmorphism design, dark/light themes, 3D product viewers, GSAP animations, and a comprehensive admin panel.

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Quick Start](#quick-start)
- [Default Login Credentials](#default-login-credentials)
- [API Endpoints](#api-endpoints)
- [Deployment](#deployment)
- [Environment Variables](#environment-variables)
- [Scripts Reference](#scripts-reference)
- [License](#license)

---

## Overview

Bangalirhaat is a full-stack e-commerce solution tailored for Bangladesh. It combines a luxury frontend experience with a robust, secure backend — ready for production deployment on any VPS or cloud provider.

**Key Highlights:**
- 16 frontend pages with premium glassmorphism UI
- 8 backend route modules with full REST API
- Real-time WebSocket notifications
- 5-tier role-based access control (Super Admin → Customer)
- SQLite for development, PostgreSQL/MySQL ready for production
- Docker, PM2, and Nginx deployment configs included

---

## Features

### Frontend

| Feature | Description |
|---------|-------------|
| Luxury Hero Section | 3D product viewer powered by Three.js |
| GSAP Animations | Scroll-triggered animations & parallax effects |
| Swiper Carousels | Product carousels, review sliders, promotional banners |
| Lenis Smooth Scrolling | Buttery-smooth page navigation |
| Lottie Animations | Loading states and micro-interactions |
| Glassmorphism UI | Frosted-glass design language throughout |
| Dark & Light Themes | Toggle with system preference detection |
| Responsive Design | Mobile-first, works on all screen sizes |
| 360° Product Viewer | Interactive product gallery with zoom |
| Real-time Cart | Live totals, coupon application, instant updates |
| Multi-step Checkout | Guided checkout flow with validation |
| Customer Dashboard | 9-tab dashboard (orders, wishlist, wallet, loyalty, referrals, addresses, settings, reviews, notifications) |
| SEO Optimized | Meta tags, semantic HTML, Open Graph |
| PWA Ready | Service worker, manifest, offline support |

### Backend

| Feature | Description |
|---------|-------------|
| RESTful API | Clean, versioned endpoint architecture |
| JWT Authentication | Access + refresh token strategy |
| HTTP-only Cookie Security | Tokens stored in secure, httpOnly cookies |
| Role-based Access Control | `super_admin`, `admin`, `staff`, `moderator`, `customer` |
| Rate Limiting | Configurable per-IP rate limiting |
| Security Headers | Helmet.js with CSP, HSTS, and more |
| XSS & SQL Injection Protection | Input sanitization, parameterized queries |
| WebSocket Real-time | Live notifications, order updates, broadcasts |
| File Uploads | Multer + Sharp for image processing & optimization |
| Audit Logging | Track all critical operations |
| Input Validation | Express-validator on all endpoints |
| Error Handling | Global error handler with environment-aware responses |
| Graceful Shutdown | Clean close of HTTP, WebSocket, and database |

### Admin Panel

| Feature | Description |
|---------|-------------|
| Real-time Dashboard | Chart.js analytics, KPI cards, recent activity |
| Order Management | 11 order statuses with status transitions |
| Inventory Management | Stock tracking, low-stock alerts |
| Financial Management | Revenue reports, transaction history, payouts |
| Customer Management | Customer profiles, VIP tiers, blacklist |
| Marketing Tools | Coupons, campaigns, promotional banners |
| Product Management | Full CRUD with image uploads |
| Category & Brand Management | Hierarchical categories, brand profiles |
| Supplier Management | Supplier database, purchase orders |
| Settings Management | Store settings, payment config, shipping |
| Security Audit Logs | Track admin actions and login history |

### Database

- **30+ normalized tables** with proper foreign key constraints
- Performance-optimized indexes on frequently queried columns
- Soft deletes for data retention and recovery
- Audit triggers for change tracking
- SQLite for development (`better-sqlite3`)
- Migration-ready schema for PostgreSQL/MySQL in production

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | HTML5, CSS3, JavaScript (ES2025+) |
| **Animations** | GSAP, Lenis, Lottie |
| **3D / WebGL** | Three.js |
| **Carousels** | Swiper |
| **Charts** | Chart.js |
| **Backend** | Node.js, Express.js |
| **Database** | SQLite (`better-sqlite3`) — PostgreSQL/MySQL ready |
| **Authentication** | JWT (Access + Refresh Tokens), HttpOnly Cookies |
| **Real-time** | WebSocket (`ws`) |
| **Image Processing** | Sharp, Multer |
| **Email** | Nodemailer |
| **Security** | Helmet, CORS, express-rate-limit, express-validator |
| **Process Manager** | PM2 |
| **Reverse Proxy** | Nginx |
| **Containerization** | Docker, Docker Compose |
| **Task Scheduling** | node-cron |

---

## Project Structure

```
bangalirhaat/
├── public/                        # Static frontend files
│   ├── index.html                 # Homepage
│   ├── pages/                     # Frontend pages (16 pages)
│   │   ├── about.html
│   │   ├── cart.html
│   │   ├── checkout.html
│   │   ├── contact.html
│   │   ├── dashboard.html
│   │   ├── faq.html
│   │   ├── forgot-password.html
│   │   ├── login.html
│   │   ├── order-success.html
│   │   ├── privacy.html
│   │   ├── product.html
│   │   ├── products.html
│   │   ├── register.html
│   │   ├── terms.html
│   │   ├── track-order.html
│   │   └── wishlist.html
│   ├── admin/                     # Admin panel
│   │   └── index.html
│   ├── css/                       # Stylesheets
│   │   ├── variables.css          # CSS custom properties & themes
│   │   ├── base.css               # Reset & global styles
│   │   ├── layout.css             # Grid, flexbox, page layout
│   │   ├── components.css         # Reusable UI components
│   │   ├── pages.css              # Page-specific styles
│   │   ├── responsive.css         # Media queries & breakpoints
│   │   └── admin.css              # Admin panel styles
│   ├── js/                        # Client-side JavaScript
│   │   ├── app.js                 # Main application logic
│   │   └── admin.js               # Admin panel logic
│   └── uploads/                   # User-uploaded files
├── src/
│   ├── config/
│   │   └── index.js               # Centralized configuration
│   ├── database/
│   │   ├── db.js                  # Database connection & initialization
│   │   ├── schema.sql             # Full database schema (30+ tables)
│   │   ├── init.js                # Database initialization script
│   │   ├── seed.js                # Sample data seeder
│   │   └── reset.js               # Database reset script
│   ├── middleware/
│   │   ├── auth.js                # JWT verification & role checking
│   │   ├── security.js            # Security headers & sanitization
│   │   ├── rateLimiter.js         # Rate limiting configuration
│   │   ├── errorHandler.js        # Global error handling
│   │   └── upload.js              # Multer + Sharp file upload
│   └── routes/
│       ├── auth.routes.js         # Authentication endpoints
│       ├── products.routes.js     # Product catalog endpoints
│       ├── orders.routes.js       # Order management endpoints
│       ├── cart.routes.js         # Shopping cart endpoints
│       ├── wishlist.routes.js     # Wishlist endpoints
│       ├── customers.routes.js    # Customer profile endpoints
│       ├── categories.routes.js   # Category management endpoints
│       └── admin.routes.js        # Admin panel endpoints
├── nginx/                         # Nginx configuration
├── data/                          # SQLite database files
├── logs/                          # Application logs
├── Dockerfile                     # Docker build instructions
├── docker-compose.yml             # Docker Compose orchestration
├── ecosystem.config.cjs           # PM2 process configuration
├── server.js                      # Application entry point
├── package.json                   # Dependencies & scripts
└── package-lock.json              # Locked dependency tree
```

---

## Quick Start

### Prerequisites

- **Node.js** 18.0.0 or higher
- **npm** (or yarn/pnpm)

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/bangalirhaat.git
cd bangalirhaat

# Install dependencies
npm install
```

### Environment Setup

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your configuration
# At minimum, set JWT_SECRET and JWT_REFRESH_SECRET to secure random strings
```

### Database Setup

```bash
# Initialize the database schema
npm run db:init

# Seed with sample data (optional, for development)
npm run db:seed
```

### Development

```bash
# Start with hot-reload (nodemon)
npm run dev
```

The server starts at `http://localhost:5000`.

### Production

```bash
# Start the server
npm start
```

---

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | `admin@bangalirhaat.com` | `Admin@123` |
| Admin | `manager@bangalirhaat.com` | `Manager@123` |
| Staff | `staff@bangalirhaat.com` | `Staff@123` |
| Moderator | `mod@bangalirhaat.com` | `Mod@123` |
| Customer | `customer@bangalirhaat.com` | `Customer@123` |

> **Important:** Change these credentials before deploying to production.

---

## API Endpoints

### Health & Info

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Health check |
| `GET` | `/api` | API information |

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/auth/register` | Register new account |
| `POST` | `/api/auth/login` | Login |
| `POST` | `/api/auth/logout` | Logout (clear cookies) |
| `POST` | `/api/auth/refresh` | Refresh access token |
| `POST` | `/api/auth/forgot-password` | Request password reset |
| `POST` | `/api/auth/verify-otp` | Verify OTP code |
| `POST` | `/api/auth/reset-password` | Reset password with token |
| `GET` | `/api/auth/me` | Get current user profile |

### Products

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/products` | List all products (paginated, filterable) |
| `GET` | `/api/products/featured` | Featured products |
| `GET` | `/api/products/trending` | Trending products |
| `GET` | `/api/products/new-arrivals` | New arrivals |
| `GET` | `/api/products/best-sellers` | Best sellers |
| `GET` | `/api/products/flash-sales` | Flash sale products |
| `GET` | `/api/products/search` | Search products |
| `GET` | `/api/products/:id` | Get product by ID |

### Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/orders` | Create order |
| `GET` | `/api/orders` | List user orders |
| `GET` | `/api/orders/:id` | Get order details |
| `GET` | `/api/orders/track/:orderNumber` | Track order by number |
| `POST` | `/api/orders/:id/cancel` | Cancel order |

### Cart

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/cart` | Get cart contents |
| `POST` | `/api/cart/add` | Add item to cart |
| `PUT` | `/api/cart/update/:itemId` | Update item quantity |
| `DELETE` | `/api/cart/remove/:itemId` | Remove item from cart |
| `DELETE` | `/api/cart/clear` | Clear entire cart |
| `POST` | `/api/cart/apply-coupon` | Apply coupon code |
| `POST` | `/api/cart/remove-coupon` | Remove applied coupon |

### Wishlist

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/wishlist` | Get wishlist |
| `POST` | `/api/wishlist/add` | Add product to wishlist |
| `DELETE` | `/api/wishlist/remove/:productId` | Remove from wishlist |
| `GET` | `/api/wishlist/check/:productId` | Check if product is wishlisted |

### Customer

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/customers/profile` | Get profile |
| `PUT` | `/api/customers/profile` | Update profile |
| `GET` | `/api/customers/addresses` | Manage addresses |
| `GET` | `/api/customers/wallet` | Wallet balance & transactions |
| `GET` | `/api/customers/loyalty` | Loyalty points & tier |
| `GET` | `/api/customers/referral` | Referral code & stats |

### Admin (requires `admin` or `super_admin` role)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/admin/dashboard` | Dashboard overview & KPIs |
| `GET` | `/api/admin/analytics` | Detailed analytics data |
| `GET/POST/PUT/DELETE` | `/api/admin/orders` | Order management |
| `GET/POST/PUT/DELETE` | `/api/admin/products` | Product management |
| `GET/POST/PUT/DELETE` | `/api/admin/categories` | Category management |
| `GET/POST/PUT/DELETE` | `/api/admin/brands` | Brand management |
| `GET/POST/PUT/DELETE` | `/api/admin/suppliers` | Supplier management |
| `GET/POST/PUT/DELETE` | `/api/admin/customers` | Customer management |
| `GET/POST/PUT/DELETE` | `/api/admin/coupons` | Coupon management |
| `GET/POST/PUT/DELETE` | `/api/admin/campaigns` | Campaign management |
| `GET/POST/PUT/DELETE` | `/api/admin/settings` | Store settings |

### WebSocket

| Path | Description |
|------|-------------|
| `ws://host/ws` | Real-time notifications and broadcasts |

**Supported messages:**
```json
// Subscribe to a channel
{ "type": "subscribe", "channel": "orders" }

// Ping/pong keep-alive
{ "type": "ping" }

// Unsubscribe
{ "type": "unsubscribe", "channel": "orders" }
```

---

## Deployment

### Docker Deployment

```bash
# Build and start
docker compose up -d

# View logs
docker compose logs -f app

# Stop
docker compose down
```

### PM2 Deployment

```bash
# Start in production
npm run pm2:start

# View logs
npm run pm2:logs

# Restart
npm run pm2:restart

# Stop
npm run pm2:stop

# Monitor
npm run pm2:monit
```

### Hostinger VPS Deployment (Step-by-Step)

#### 1. Connect to VPS

```bash
ssh root@your-vps-ip
```

#### 2. Install Node.js 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # Should output v20.x.x
npm -v    # Should output 10.x.x
```

#### 3. Install PM2

```bash
sudo npm install -g pm2
pm2 startup
```

#### 4. Clone and Setup

```bash
git clone https://github.com/yourusername/bangalirhaat.git
cd bangalirhaat
npm install --production

# Configure environment
cp .env.example .env
nano .env    # Edit with your production values

# Initialize database
npm run db:init
npm run db:seed
```

#### 5. Start with PM2

```bash
pm2 start ecosystem.config.cjs --env production
pm2 save
```

#### 6. Configure Nginx

```bash
sudo cp nginx/nginx.conf /etc/nginx/sites-available/bangalirhaat
sudo ln -s /etc/nginx/sites-available/bangalirhaat /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default   # Remove default site
sudo nginx -t
sudo systemctl reload nginx
```

#### 7. SSL with Certbot

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d bangalirhaat.com -d www.bangalirhaat.com

# Auto-renewal is configured by default. Verify with:
sudo certbot renew --dry-run
```

#### 8. Setup Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

---

## Environment Variables

Copy `.env.example` to `.env` and configure:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `5000` | Server port |
| `NODE_ENV` | `development` | `development`, `production`, or `test` |
| `JWT_SECRET` | — | Secret key for JWT signing |
| `JWT_EXPIRES_IN` | `7d` | Access token expiry |
| `JWT_REFRESH_SECRET` | — | Secret key for refresh token signing |
| `JWT_REFRESH_EXPIRES_IN` | `30d` | Refresh token expiry |
| `SESSION_SECRET` | — | Cookie signing secret |
| `DB_PATH` | `./data/bangalirhaat.db` | SQLite database path |
| `CORS_ORIGINS` | `*` | Comma-separated allowed origins |
| `RATE_LIMIT_WINDOW_MS` | `900000` | Rate limit window (15 minutes) |
| `RATE_LIMIT_MAX` | `100` | Max requests per window |
| `SMTP_HOST` | `smtp.gmail.com` | Email SMTP host |
| `SMTP_PORT` | `587` | Email SMTP port |
| `SMTP_USER` | — | SMTP username |
| `SMTP_PASS` | — | SMTP password |
| `SMTP_FROM` | — | Sender email address |
| `STEADFAST_API_KEY` | — | Steadfast courier API key |
| `STEADFAST_API_SECRET` | — | Steadfast courier API secret |
| `CLOUDINARY_URL` | — | Cloudinary URL for image hosting |
| `IMG_UPLOAD_PATH` | `./public/uploads` | Local upload directory |
| `STRIPE_SECRET_KEY` | — | Stripe payment gateway key |
| `STRIPE_WEBHOOK_SECRET` | — | Stripe webhook signing secret |
| `SSLCOMMERZ_STORE_ID` | — | SSLCommerz store ID |
| `SSLCOMMERZ_STORE_PASS` | — | SSLCommerz store password |

---

## Scripts Reference

| Command | Description |
|---------|-------------|
| `npm start` | Start production server |
| `npm run dev` | Start with hot-reload (nodemon) |
| `npm run db:init` | Initialize database schema |
| `npm run db:seed` | Seed sample data |
| `npm run db:reset` | Reset database (drop & recreate) |
| `npm run lint` | Run ESLint on `src/` |
| `npm test` | Run Jest tests with coverage |
| `npm run build` | Run production build script |
| `npm run pm2:start` | Start with PM2 |
| `npm run pm2:stop` | Stop PM2 process |
| `npm run pm2:restart` | Restart PM2 process |
| `npm run pm2:logs` | View PM2 logs |
| `npm run pm2:monit` | Monitor PM2 processes |
| `npm run docker:build` | Build Docker image |
| `npm run docker:up` | Start Docker containers |
| `npm run docker:down` | Stop Docker containers |
| `npm run docker:logs` | View Docker logs |
| `npm run docker:restart` | Restart Docker containers |

---

## License

MIT License. See [LICENSE](LICENSE) for details.

---

## Author

**Bangalirhaat Team**

Built with care for the Bangladeshi market.
