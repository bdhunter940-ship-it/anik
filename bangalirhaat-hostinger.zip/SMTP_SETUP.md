# SMTP Email Setup Guide

## Option 1: Gmail (সবচেয়ে সহজ — free)

1. Create a Gmail account (e.g. `bangalirhaat@gmail.com`)
2. Go to: https://myaccount.google.com/apppasswords
   - If you don't see App Passwords, enable **2-Step Verification** first
3. Create an app password → copy the 16-character code
4. Set these in `.env`:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=bangalirhaat@gmail.com
SMTP_PASS=your-16-char-app-password
SMTP_FROM=bangalirhaat@gmail.com
EMAIL_FROM_NAME=Bangalirhaat
```

> ⚠️ NEVER use your normal Gmail password — only the App Password.

## Option 2: Hostinger Email (যদি Hostinger ডোমেইন থাকে)

1. Hostinger hPanel → **Email Accounts** → create `info@yourdomain.com`
2. Get these from hPanel:
   - Host: `mail.yourdomain.com`
   - Port: `587` (TLS) or `465` (SSL)
3. Set in `.env`:

```
SMTP_HOST=mail.yourdomain.com
SMTP_PORT=587
SMTP_USER=info@yourdomain.com
SMTP_PASS=your-email-password
SMTP_FROM=info@yourdomain.com
EMAIL_FROM_NAME=Bangalirhaat
```

## Option 3: SendGrid / Mailgun (free tiers for production)

- Create account → get API key
- Use their SMTP host (`smtp.sendgrid.net` port `587`)

## Render.com Deploy এ set করবেন

1. Render dashboard → আপনার service → **Environment**
2. Add these variables (values from your email provider):

| Key | Example |
|-----|---------|
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `587` |
| `SMTP_USER` | `bangalirhaat@gmail.com` |
| `SMTP_PASS` | `xxxx xxxx xxxx xxxx` |
| `SMTP_FROM` | `bangalirhaat@gmail.com` |
| `EMAIL_FROM_NAME` | `Bangalirhaat` |

3. Save → Redeploy

## Test

After setup, order করে দেখুন — কাস্টমারের email এ confirmation যাবে।

---

## Admin Login (seed account)

| Role | Email | Password |
|------|-------|----------|
| **Super Admin** | `admin@bangalirhaat.com` | `Admin@123` |
| Manager | `manager@bangalirhaat.com` | `Manager@123` |
| Staff | `staff@bangalirhaat.com` | `Staff@123` |
| Customer | `customer@bangalirhaat.com` | `Customer@123` |

> ⚠️ Deploy করার পর সাথে সাথে সব password change করে নেবেন!
