import { Router } from 'express';
import { query, body, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate, optionalAuth } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;
    const sort = req.query.sort || 'recent';

    let orderClause;
    switch (sort) {
      case 'recent': orderClause = 'ORDER BY r.created_at DESC'; break;
      case 'rating_high': orderClause = 'ORDER BY r.rating DESC'; break;
      case 'rating_low': orderClause = 'ORDER BY r.rating ASC'; break;
      case 'helpful': orderClause = 'ORDER BY r.helpful_count DESC'; break;
      default: orderClause = 'ORDER BY r.created_at DESC';
    }

    let where = ['r.is_approved = 1'];
    let params = [];

    if (req.query.product_id) {
      where.push('r.product_id = ?');
      params.push(parseInt(req.query.product_id));
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const countRow = db.prepare(
      `SELECT COUNT(*) as total FROM product_reviews r ${whereClause}`
    ).get(...params);

    const reviews = db.prepare(
      `SELECT r.id, r.rating, r.title, r.comment, r.created_at,
              u.first_name || ' ' || u.last_name as user_name,
              u.avatar as user_avatar,
              p.name as product_name, p.slug as product_slug,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as product_thumbnail
       FROM product_reviews r
       JOIN users u ON r.user_id = u.id
       JOIN products p ON r.product_id = p.id
       ${whereClause}
       ${orderClause}
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    res.json({
      success: true,
      data: {
        reviews,
        pagination: {
          total: countRow.total,
          page,
          limit,
          totalPages: Math.ceil(countRow.total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

const submitValidation = [
  body('product_id').isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
  body('rating').isInt({ min: 1, max: 5 }).toInt().withMessage('Rating must be 1-5'),
  body('title').optional().isString().trim().isLength({ max: 200 }),
  body('comment').isString().trim().isLength({ min: 3, max: 2000 }).withMessage('Review must be 3-2000 characters'),
];

router.post('/', authenticate, submitValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const { product_id, rating, title, comment } = req.body;

    const product = db.prepare('SELECT id, is_active FROM products WHERE id = ?').get(product_id);
    if (!product || !product.is_active) {
      throw new AppError('Product not found', 404);
    }

    const existing = db.prepare(
      'SELECT id FROM product_reviews WHERE user_id = ? AND product_id = ?'
    ).get(userId, product_id);
    if (existing) {
      throw new AppError('You have already reviewed this product', 400);
    }

    const result = db.prepare(
      'INSERT INTO product_reviews (user_id, product_id, rating, title, comment, is_approved) VALUES (?, ?, ?, ?, ?, 1)'
    ).run(userId, product_id, rating, title || null, comment);

    const avgRow = db.prepare(
      'SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM product_reviews WHERE product_id = ? AND is_approved = 1'
    ).get(product_id);

    db.prepare(
      'UPDATE products SET average_rating = ?, review_count = ? WHERE id = ?'
    ).run(avgRow.avg_rating || 0, avgRow.review_count || 0, product_id);

    res.status(201).json({
      success: true,
      message: 'Review submitted successfully',
      data: { id: result.lastInsertRowid },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    const db = getDb();
    const review = db.prepare(
      'SELECT id, user_id, product_id FROM product_reviews WHERE id = ?'
    ).get(req.params.id);

    if (!review) {
      throw new AppError('Review not found', 404);
    }

    if (review.user_id !== req.user.id && req.user.role !== 'super_admin' && req.user.role !== 'admin') {
      throw new AppError('Not authorized', 403);
    }

    db.prepare('DELETE FROM product_reviews WHERE id = ?').run(req.params.id);

    const avgRow = db.prepare(
      'SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM product_reviews WHERE product_id = ? AND is_approved = 1'
    ).get(review.product_id);

    db.prepare(
      'UPDATE products SET average_rating = ?, review_count = ? WHERE id = ?'
    ).run(avgRow.avg_rating || 0, avgRow.review_count || 0, review.product_id);

    res.json({ success: true, message: 'Review deleted' });
  } catch (error) {
    next(error);
  }
});

export default router;
