import path from 'node:path';
import { fileURLToPath } from 'node:url';
import config from '../config/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.resolve(__dirname, '..', '..', 'public');

export function maintenanceMode(req, res, next) {
  if (config.maintenance?.enabled && req.path !== '/health') {
    if (req.path.startsWith('/api/') && req.path !== '/api/auth/login') {
      return res.status(503).json({
        success: false,
        message: config.maintenance.message || 'Site is under maintenance.',
      });
    }
    if (!req.path.startsWith('/api/')) {
      return res.status(503).sendFile('maintenance.html', { root: PUBLIC_DIR });
    }
  }
  next();
}
