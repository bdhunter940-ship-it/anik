import { getDb } from '../database/db.js';

class ExportService {
  generateCSV(headers, rows) {
    if (!Array.isArray(headers) || headers.length === 0) {
      throw new Error('Headers must be a non-empty array');
    }

    const escapeCSV = (value) => {
      if (value === null || value === undefined) return '';
      const str = String(value);
      if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    };

    const headerLine = headers.map(escapeCSV).join(',');
    const dataLines = rows.map(row =>
      headers.map(header => {
        const value = typeof row === 'object' && row !== null ? row[header] : row;
        return escapeCSV(value);
      }).join(',')
    );

    return '\uFEFF' + headerLine + '\n' + dataLines.join('\n');
  }

  generateJSON(data) {
    return JSON.stringify(data, null, 2);
  }

  _formatDate(dateStr) {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  async exportOrders(format = 'csv', filters = {}) {
    const db = getDb();
    const { startDate, endDate, status, paymentStatus, paymentMethod } = filters;

    let where = ['o.deleted_at IS NULL'];
    const params = [];

    if (startDate) {
      where.push('o.created_at >= ?');
      params.push(startDate);
    }
    if (endDate) {
      where.push('o.created_at <= ?');
      params.push(endDate);
    }
    if (status) {
      where.push('o.status = ?');
      params.push(status);
    }
    if (paymentStatus) {
      where.push('o.payment_status = ?');
      params.push(paymentStatus);
    }
    if (paymentMethod) {
      where.push('o.payment_method = ?');
      params.push(paymentMethod);
    }

    const whereClause = where.join(' AND ');

    const orders = db.prepare(`
      SELECT o.id, o.order_number, o.status, o.subtotal, o.discount, o.shipping_cost,
             o.tax, o.total, o.currency, o.payment_status, o.payment_method, o.notes,
             o.created_at, o.updated_at, o.shipped_at, o.delivered_at,
             u.first_name || ' ' || u.last_name as customer_name,
             u.email as customer_email, u.phone as customer_phone
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      WHERE ${whereClause}
      ORDER BY o.created_at DESC
    `).all(...params);

    const rows = orders.map(order => ({
      id: order.id,
      order_number: order.order_number,
      status: order.status,
      customer_name: order.customer_name,
      customer_email: order.customer_email,
      customer_phone: order.customer_phone,
      subtotal: order.subtotal,
      discount: order.discount,
      shipping_cost: order.shipping_cost,
      tax: order.tax,
      total: order.total,
      currency: order.currency,
      payment_status: order.payment_status,
      payment_method: order.payment_method,
      notes: order.notes || '',
      created_at: this._formatDate(order.created_at),
      shipped_at: this._formatDate(order.shipped_at),
      delivered_at: this._formatDate(order.delivered_at),
    }));

    const headers = [
      'id', 'order_number', 'status', 'customer_name', 'customer_email', 'customer_phone',
      'subtotal', 'discount', 'shipping_cost', 'tax', 'total', 'currency',
      'payment_status', 'payment_method', 'notes', 'created_at', 'shipped_at', 'delivered_at',
    ];

    if (format === 'csv') {
      return {
        data: this.generateCSV(headers, rows),
        filename: `orders-export-${new Date().toISOString().split('T')[0]}.csv`,
        contentType: 'text/csv; charset=utf-8',
        count: rows.length,
      };
    }

    if (format === 'json') {
      return {
        data: this.generateJSON({ orders: rows, exported_at: new Date().toISOString(), count: rows.length }),
        filename: `orders-export-${new Date().toISOString().split('T')[0]}.json`,
        contentType: 'application/json',
        count: rows.length,
      };
    }

    throw new Error(`Unsupported format: ${format}. Use 'csv' or 'json'.`);
  }

  async exportProducts(format = 'csv', filters = {}) {
    const db = getDb();
    const { categoryId, brandId, isActive, search, lowStock } = filters;

    let where = ['p.deleted_at IS NULL'];
    const params = [];

    if (categoryId) {
      where.push('p.category_id = ?');
      params.push(categoryId);
    }
    if (brandId) {
      where.push('p.brand_id = ?');
      params.push(brandId);
    }
    if (isActive !== undefined && isActive !== null) {
      where.push('p.is_active = ?');
      params.push(isActive ? 1 : 0);
    }
    if (search) {
      where.push('(p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ?)');
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    if (lowStock) {
      where.push('p.stock_quantity <= p.low_stock_threshold AND p.track_stock = 1');
    }

    const whereClause = where.join(' AND ');

    const products = db.prepare(`
      SELECT p.id, p.name, p.sku, p.barcode, p.price, p.compare_price, p.cost_price,
             p.stock_quantity, p.low_stock_threshold, p.tax_rate, p.weight,
             p.is_active, p.is_featured, p.total_sold, p.average_rating, p.review_count,
             p.tags, p.meta_title, p.meta_description, p.created_at, p.updated_at,
             c.name as category_name, b.name as brand_name,
             (SELECT GROUP_CONCAT(url) FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN brands b ON p.brand_id = b.id
      WHERE ${whereClause}
      ORDER BY p.name ASC
    `).all(...params);

    const rows = products.map(product => ({
      id: product.id,
      name: product.name,
      sku: product.sku || '',
      barcode: product.barcode || '',
      category: product.category_name || '',
      brand: product.brand_name || '',
      price: product.price,
      compare_price: product.compare_price || '',
      cost_price: product.cost_price || '',
      stock_quantity: product.stock_quantity,
      low_stock_threshold: product.low_stock_threshold,
      is_active: product.is_active ? 'Yes' : 'No',
      is_featured: product.is_featured ? 'Yes' : 'No',
      total_sold: product.total_sold,
      average_rating: product.average_rating,
      review_count: product.review_count,
      tax_rate: product.tax_rate,
      weight: product.weight || '',
      tags: product.tags || '',
      primary_image: product.primary_image || '',
      created_at: this._formatDate(product.created_at),
      updated_at: this._formatDate(product.updated_at),
    }));

    const headers = [
      'id', 'name', 'sku', 'barcode', 'category', 'brand', 'price', 'compare_price',
      'cost_price', 'stock_quantity', 'low_stock_threshold', 'is_active', 'is_featured',
      'total_sold', 'average_rating', 'review_count', 'tax_rate', 'weight', 'tags',
      'primary_image', 'created_at', 'updated_at',
    ];

    if (format === 'csv') {
      return {
        data: this.generateCSV(headers, rows),
        filename: `products-export-${new Date().toISOString().split('T')[0]}.csv`,
        contentType: 'text/csv; charset=utf-8',
        count: rows.length,
      };
    }

    if (format === 'json') {
      return {
        data: this.generateJSON({ products: rows, exported_at: new Date().toISOString(), count: rows.length }),
        filename: `products-export-${new Date().toISOString().split('T')[0]}.json`,
        contentType: 'application/json',
        count: rows.length,
      };
    }

    throw new Error(`Unsupported format: ${format}. Use 'csv' or 'json'.`);
  }

  async exportCustomers(format = 'csv', filters = {}) {
    const db = getDb();
    const { isActive, role, search, startDate, endDate } = filters;

    let where = ['u.deleted_at IS NULL'];
    const params = [];

    if (isActive !== undefined && isActive !== null) {
      where.push('u.is_active = ?');
      params.push(isActive ? 1 : 0);
    }
    if (role) {
      where.push('u.role = ?');
      params.push(role);
    }
    if (search) {
      where.push('(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)');
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    if (startDate) {
      where.push('u.created_at >= ?');
      params.push(startDate);
    }
    if (endDate) {
      where.push('u.created_at <= ?');
      params.push(endDate);
    }

    const whereClause = where.join(' AND ');

    const customers = db.prepare(`
      SELECT u.id, u.uuid, u.first_name, u.last_name, u.email, u.phone, u.role,
             u.is_active, u.email_verified, u.phone_verified,
             u.loyalty_points, u.wallet_balance, u.referral_code, u.created_at,
             (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND deleted_at IS NULL) as order_count,
             (SELECT COALESCE(SUM(total), 0) FROM orders WHERE user_id = u.id AND payment_status = 'paid' AND deleted_at IS NULL) as total_spent,
             (SELECT MAX(created_at) FROM orders WHERE user_id = u.id) as last_order_date
      FROM users u
      WHERE ${whereClause}
      ORDER BY u.created_at DESC
    `).all(...params);

    const rows = customers.map(c => ({
      id: c.id,
      uuid: c.uuid,
      first_name: c.first_name,
      last_name: c.last_name,
      email: c.email,
      phone: c.phone || '',
      role: c.role,
      is_active: c.is_active ? 'Yes' : 'No',
      email_verified: c.email_verified ? 'Yes' : 'No',
      phone_verified: c.phone_verified ? 'Yes' : 'No',
      loyalty_points: c.loyalty_points,
      wallet_balance: c.wallet_balance,
      referral_code: c.referral_code || '',
      order_count: c.order_count,
      total_spent: c.total_spent,
      last_order_date: c.last_order_date ? this._formatDate(c.last_order_date) : 'Never',
      registered_at: this._formatDate(c.created_at),
    }));

    const headers = [
      'id', 'uuid', 'first_name', 'last_name', 'email', 'phone', 'role',
      'is_active', 'email_verified', 'phone_verified', 'loyalty_points', 'wallet_balance',
      'referral_code', 'order_count', 'total_spent', 'last_order_date', 'registered_at',
    ];

    if (format === 'csv') {
      return {
        data: this.generateCSV(headers, rows),
        filename: `customers-export-${new Date().toISOString().split('T')[0]}.csv`,
        contentType: 'text/csv; charset=utf-8',
        count: rows.length,
      };
    }

    if (format === 'json') {
      return {
        data: this.generateJSON({ customers: rows, exported_at: new Date().toISOString(), count: rows.length }),
        filename: `customers-export-${new Date().toISOString().split('T')[0]}.json`,
        contentType: 'application/json',
        count: rows.length,
      };
    }

    throw new Error(`Unsupported format: ${format}. Use 'csv' or 'json'.`);
  }

  async exportReport(reportType, dateRange = {}) {
    const db = getDb();
    const { startDate, endDate } = dateRange;
    const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const end = endDate || new Date().toISOString().split('T')[0];

    switch (reportType) {
      case 'sales': {
        const data = db.prepare(`
          SELECT DATE(o.created_at) as date,
                 COUNT(*) as total_orders,
                 SUM(CASE WHEN o.payment_status = 'paid' THEN 1 ELSE 0 END) as paid_orders,
                 SUM(CASE WHEN o.payment_status = 'paid' THEN o.total ELSE 0 END) as revenue,
                 SUM(CASE WHEN o.payment_status = 'paid' THEN o.subtotal ELSE 0 END) as gross_sales,
                 SUM(CASE WHEN o.payment_status = 'paid' THEN o.discount ELSE 0 END) as discounts,
                 SUM(CASE WHEN o.payment_status = 'paid' THEN o.shipping_cost ELSE 0 END) as shipping_revenue,
                 SUM(CASE WHEN o.status = 'returned' THEN 1 ELSE 0 END) as returns
          FROM orders o
          WHERE DATE(o.created_at) BETWEEN ? AND ?
            AND o.deleted_at IS NULL
          GROUP BY DATE(o.created_at)
          ORDER BY date ASC
        `).all(start, end);

        return {
          report: 'sales',
          period: { start, end },
          data,
          totals: {
            total_orders: data.reduce((s, d) => s + d.total_orders, 0),
            paid_orders: data.reduce((s, d) => s + d.paid_orders, 0),
            revenue: data.reduce((s, d) => s + d.revenue, 0),
            gross_sales: data.reduce((s, d) => s + d.gross_sales, 0),
            discounts: data.reduce((s, d) => s + d.discounts, 0),
            shipping_revenue: data.reduce((s, d) => s + d.shipping_revenue, 0),
            returns: data.reduce((s, d) => s + d.returns, 0),
          },
          exported_at: new Date().toISOString(),
        };
      }

      case 'products': {
        const data = db.prepare(`
          SELECT p.id, p.name, p.sku, c.name as category, b.name as brand,
                 p.price, p.total_sold, p.average_rating, p.review_count,
                 p.stock_quantity, (p.total_sold * p.price) as total_revenue
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.id
          LEFT JOIN brands b ON p.brand_id = b.id
          WHERE p.deleted_at IS NULL AND p.is_active = 1
          ORDER BY p.total_sold DESC
        `).all();

        return {
          report: 'products',
          period: { start, end },
          data,
          totals: {
            total_products: data.length,
            total_units_sold: data.reduce((s, d) => s + d.total_sold, 0),
            total_revenue: data.reduce((s, d) => s + d.total_revenue, 0),
            avg_rating: data.length > 0 ? (data.reduce((s, d) => s + d.average_rating, 0) / data.length).toFixed(2) : 0,
          },
          exported_at: new Date().toISOString(),
        };
      }

      case 'customers': {
        const data = db.prepare(`
          SELECT u.id, u.first_name || ' ' || u.last_name as name, u.email, u.phone,
                 COUNT(o.id) as total_orders,
                 COALESCE(SUM(CASE WHEN o.payment_status = 'paid' THEN o.total ELSE 0 END), 0) as total_spent,
                 MIN(o.created_at) as first_order,
                 MAX(o.created_at) as last_order
          FROM users u
          LEFT JOIN orders o ON u.id = o.user_id AND o.deleted_at IS NULL
          WHERE u.deleted_at IS NULL AND u.role = 'customer'
          GROUP BY u.id
          ORDER BY total_spent DESC
        `).all();

        return {
          report: 'customers',
          period: { start, end },
          data,
          totals: {
            total_customers: data.length,
            active_customers: data.filter(d => d.total_orders > 0).length,
            total_revenue: data.reduce((s, d) => s + d.total_spent, 0),
            avg_order_value: data.filter(d => d.total_orders > 0).length > 0
              ? (data.reduce((s, d) => s + d.total_spent, 0) / data.filter(d => d.total_orders > 0).length).toFixed(2)
              : 0,
          },
          exported_at: new Date().toISOString(),
        };
      }

      case 'inventory': {
        const data = db.prepare(`
          SELECT p.id, p.name, p.sku, c.name as category, p.stock_quantity,
                 p.low_stock_threshold, p.cost_price, p.price,
                 (p.stock_quantity * COALESCE(p.cost_price, 0)) as stock_value,
                 p.total_sold, p.is_active,
                 CASE
                   WHEN p.stock_quantity = 0 THEN 'out_of_stock'
                   WHEN p.stock_quantity <= p.low_stock_threshold THEN 'low_stock'
                   ELSE 'in_stock'
                 END as stock_status
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.id
          WHERE p.deleted_at IS NULL AND p.track_stock = 1
          ORDER BY stock_status ASC, p.stock_quantity ASC
        `).all();

        return {
          report: 'inventory',
          period: { start, end },
          data,
          totals: {
            total_products: data.length,
            in_stock: data.filter(d => d.stock_status === 'in_stock').length,
            low_stock: data.filter(d => d.stock_status === 'low_stock').length,
            out_of_stock: data.filter(d => d.stock_status === 'out_of_stock').length,
            total_stock_value: data.reduce((s, d) => s + d.stock_value, 0),
            formatted_stock_value: '৳' + data.reduce((s, d) => s + d.stock_value, 0).toLocaleString(),
          },
          exported_at: new Date().toISOString(),
        };
      }

      case 'daily_analytics': {
        const data = db.prepare(`
          SELECT date, visitors, page_views, orders, revenue, new_users, returns
          FROM analytics_daily
          WHERE date BETWEEN ? AND ?
          ORDER BY date ASC
        `).all(start, end);

        return {
          report: 'daily_analytics',
          period: { start, end },
          data,
          totals: {
            total_visitors: data.reduce((s, d) => s + d.visitors, 0),
            total_page_views: data.reduce((s, d) => s + d.page_views, 0),
            total_orders: data.reduce((s, d) => s + d.orders, 0),
            total_revenue: data.reduce((s, d) => s + d.revenue, 0),
            total_new_users: data.reduce((s, d) => s + d.new_users, 0),
            total_returns: data.reduce((s, d) => s + d.returns, 0),
          },
          exported_at: new Date().toISOString(),
        };
      }

      default:
        throw new Error(`Unknown report type: ${reportType}. Available: sales, products, customers, inventory, daily_analytics`);
    }
  }
}

export default new ExportService();
