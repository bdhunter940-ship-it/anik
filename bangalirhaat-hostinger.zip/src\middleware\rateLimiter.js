import rateLimit from 'express-rate-limit';
import config from '../config/index.js';

const message = {
  success: false,
  message: 'Too many requests. Please try again later.',
};

const standardOptions = {
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip,
  skip: (req) => {
    if (req.headers['x-api-key']) return true;
    return false;
  },
};

export const generalLimiter = rateLimit({
  ...standardOptions,
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  message,
});

export const authLimiter = rateLimit({
  ...standardOptions,
  windowMs: config.rateLimit.windowMs,
  max: 10,
  message: {
    success: false,
    message: 'Too many authentication attempts. Please try again after 15 minutes.',
  },
  skipSuccessfulRequests: true,
});

export const apiLimiter = rateLimit({
  ...standardOptions,
  windowMs: config.rateLimit.windowMs,
  max: 200,
  message: {
    success: false,
    message: 'API rate limit exceeded. Please slow down your requests.',
  },
});

export const strictLimiter = rateLimit({
  ...standardOptions,
  windowMs: config.rateLimit.windowMs,
  max: 5,
  message: {
    success: false,
    message: 'Too many requests for this action. Please try again after 15 minutes.',
  },
  skipSuccessfulRequests: false,
});

export const createCustomLimiter = ({
  windowMs = config.rateLimit.windowMs,
  max = 60,
  message: customMessage = message,
  keyGenerator,
  skip,
  skipSuccessfulRequests = false,
} = {}) => {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    message: customMessage,
    keyGenerator: keyGenerator || standardOptions.keyGenerator,
    skip: skip || standardOptions.skip,
    skipSuccessfulRequests,
  });
};
