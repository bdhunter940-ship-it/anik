import cron from 'node-cron';
import { getDb } from '../database/db.js';

class CronService {
  constructor() {
    this._jobs = [];
    this._running = false;
  }

  start() {
    if (this._running) {
      console.log('[CronService] Already running, skipping start');
      return;
    }

    console.log('[CronService] Starting scheduled jobs...');

    this._jobs.push(cron.schedule('* * * * *', () => this.syncFlashSales(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('*/5 * * * *', () => this.syncCourierStatuses(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 * * * *', () => this.checkLowStock(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 * * * *', () => this.expireOTPs(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 0 * * *', () => this.expireLoyaltyPoints(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 0 * * *', () => this.generateDailyAnalytics(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 1 * * *', () => this.cleanupAbandonedCarts(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 2 * * *', () => this.cleanupTokens(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 3 * * 0', () => this.updateProductRatings(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._jobs.push(cron.schedule('0 4 * * 0', () => this.cleanupOldNotifications(), {
      scheduled: true,
      timezone: 'Asia/Dhaka',
    }));

    this._running = true;
    console.log(`[CronService] Started ${this._jobs.length} scheduled jobs (timezone: Asia/Dhaka)`);
  }

  stop() {
    for (const job of this._jobs) {
      job.stop();
    }
    this._jobs = [];
    this._running = false;
    console.log('[CronService] All scheduled jobs stopped');
  }

  async syncFlashSales() {
    try {
      const db = getDb();
      const now = new Date().toISOString();

      const activated = db.prepare(
        `UPDATE flash_sales SET is_active = 1 WHERE is_active = 0 AND start_at <= datetime('now') AND end_at > datetime('now')`
      ).run();

      const deactivated = db.prepare(
        `UPDATE flash_sales SET is_active = 0 WHERE is_active = 1 AND end_at <= datetime('now')`
      ).run();

      if (activated.changes > 0 || deactivated.changes > 0) {
        console.log(`[CronService] Flash sales synced: ${activated.changes} activated, ${deactivated.changes} deactivated`);
      }
    } catch (error) {
      console.error('[CronService] syncFlashSales error:', error.message);
    }
  }

  async syncCourierStatuses() {
    try {
      let courierService;
      try {
        courierService = (await import('./courier.service.js')).default;
      } catch (importError) {
        console.warn('[CronService] Could not import courier service, skipping sync');
        return;
      }

      const result = await courierService.syncStatuses();
      if (result.total > 0) {
        console.log(`[CronService] Courier sync: ${result.updated}/${result.total} updated, ${result.failed} failed`);
      }
    } catch (error) {
      console.error('[CronService] syncCourierStatuses error:', error.message);
    }
  }

  async checkLowStock() {
    try {
      const db = getDb();
      const lowStockProducts = db.prepare(
        `SELECT p.id, p.name, p.stock_quantity, p.low_stock_threshold, p.sku,
                (SELECT url FROM product_images WHERE product_id = p.id AND is_active = 1 AND is_primary = 1 LIMIT 1) as thumbnail
         FROM products p
         WHERE p.is_active = 1 AND p.track_stock = 1
           AND p.stock_quantity <= p.low_stock_threshold
           AND p.stock_quantity > 0`
      ).all();

      if (lowStockProducts.length === 0) return;

      console.log(`[CronService] Found ${lowStockProducts.length} low stock products`);

      let notificationService;
      try {
        notificationService = (await import('./notification.service.js')).default;
      } catch (importError) {
        console.warn('[CronService] Could not import notification service');
        return;
      }

      for (const product of lowStockProducts) {
        await notificationService.sendStockAlert(
          product.id,
          product.name,
          product.stock_quantity,
          product.low_stock_threshold
        );
      }

      const outOfStock = db.prepare(
        `SELECT id, name, stock_quantity FROM products
         WHERE is_active = 1 AND track_stock = 1 AND stock_quantity = 0`
      ).all();

      if (outOfStock.length > 0) {
        console.warn(`[CronService] WARNING: ${outOfStock.length} products are out of stock`);
        for (const product of outOfStock) {
          await notificationService.createBulk(
            db.prepare('SELECT id FROM users WHERE role IN (?, ?)').all('admin', 'staff').map(u => u.id),
            'Out of Stock',
            `"${product.name}" is now out of stock.`,
            'stock_alert',
            { product_id: product.id, product_name: product.name, current_stock: 0 }
          );
        }
      }
    } catch (error) {
      console.error('[CronService] checkLowStock error:', error.message);
    }
  }

  async expireOTPs() {
    try {
      const db = getDb();
      const result = db.prepare(
        `DELETE FROM otp_codes WHERE expires_at < datetime('now') AND used_at IS NULL`
      ).run();

      if (result.changes > 0) {
        console.log(`[CronService] Expired ${result.changes} OTP codes`);
      }
    } catch (error) {
      console.error('[CronService] expireOTPs error:', error.message);
    }
  }

  async expireLoyaltyPoints() {
    try {
      const db = getDb();
      const sixMonthsAgo = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString();

      const expiredPoints = db.prepare(
        `SELECT user_id, SUM(points) as total_points
         FROM loyalty_transactions
         WHERE type = 'earned' AND created_at < datetime(?, 'unixepoch')
         GROUP BY user_id
         HAVING total_points > 0`
      ).all(sixMonthsAgo);

      if (expiredPoints.length === 0) {
        console.log('[CronService] No loyalty points to expire');
        return;
      }

      const insertExpire = db.prepare(
        `INSERT INTO loyalty_transactions (user_id, points, type, reference, description, created_at)
         VALUES (?, ?, 'expired', 'auto_expire', ?, datetime('now'))`
      );

      const deductBalance = db.prepare(
        `UPDATE users SET loyalty_points = MAX(0, loyalty_points - ?), updated_at = datetime('now') WHERE id = ?`
      );

      const expireAll = db.transaction(() => {
        let total = 0;
        for (const row of expiredPoints) {
          const pointsToExpire = Math.min(row.total_points, 1000);
          insertExpire.run(
            row.user_id,
            pointsToExpire,
            `Auto-expired ${pointsToExpire} points earned before ${new Date(sixMonthsAgo).toLocaleDateString()}`
          );
          deductBalance.run(pointsToExpire, row.user_id);
          total += pointsToExpire;
        }
        return total;
      });

      const totalExpired = expireAll();
      console.log(`[CronService] Expired ${totalExpired} loyalty points for ${expiredPoints.length} users`);
    } catch (error) {
      console.error('[CronService] expireLoyaltyPoints error:', error.message);
    }
  }

  async generateDailyAnalytics() {
    try {
      const db = getDb();
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      const existing = db.prepare(
        'SELECT id FROM analytics_daily WHERE date = ?'
      ).get(yesterday);

      if (existing) {
        return;
      }

      const stats = db.prepare(`
        SELECT
          (SELECT COUNT(DISTINCT user_id) FROM orders WHERE DATE(created_at) = ?) as orders,
          COALESCE((SELECT SUM(total) FROM orders WHERE DATE(created_at) = ? AND payment_status = 'paid'), 0) as revenue,
          (SELECT COUNT(*) FROM users WHERE DATE(created_at) = ?) as new_users,
          (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = ? AND status = 'returned') as returns
      `).get(yesterday, yesterday, yesterday, yesterday);

      const pageViews = db.prepare(
        `SELECT COUNT(*) as count FROM audit_logs WHERE entity = 'page_view' AND DATE(created_at) = ?`
      ).get(yesterday);

      db.prepare(
        `INSERT INTO analytics_daily (date, visitors, page_views, orders, revenue, new_users, returns, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))`
      ).run(
        yesterday,
        Math.max(stats.orders * 3, pageViews.count || 0, 0),
        pageViews.count || 0,
        stats.orders || 0,
        stats.revenue || 0,
        stats.new_users || 0,
        stats.returns || 0
      );

      console.log(`[CronService] Daily analytics generated for ${yesterday}: ${stats.orders} orders, ৳${stats.revenue} revenue`);
    } catch (error) {
      console.error('[CronService] generateDailyAnalytics error:', error.message);
    }
  }

  async cleanupAbandonedCarts() {
    try {
      const db = getDb();
      const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString();

      const result = db.prepare(
        `DELETE FROM cart_items WHERE cart_id IN (
          SELECT id FROM carts
          WHERE user_id IS NULL
            AND updated_at < datetime(?)
        )`
      ).run(threeDaysAgo);

      const emptyCarts = db.prepare(
        `DELETE FROM carts WHERE user_id IS NULL AND updated_at < datetime(?)`
      ).run(threeDaysAgo);

      if (result.changes > 0 || emptyCarts.changes > 0) {
        console.log(`[CronService] Cleaned up ${result.changes} abandoned cart items and ${emptyCarts.changes} empty guest carts`);
      }
    } catch (error) {
      console.error('[CronService] cleanupAbandonedCarts error:', error.message);
    }
  }

  async cleanupTokens() {
    try {
      const db = getDb();
      const result = db.prepare(
        `DELETE FROM refresh_tokens WHERE expires_at < datetime('now') OR revoked_at IS NOT NULL`
      ).run();

      if (result.changes > 0) {
        console.log(`[CronService] Cleaned up ${result.changes} expired/revoked refresh tokens`);
      }
    } catch (error) {
      console.error('[CronService] cleanupTokens error:', error.message);
    }
  }

  async updateProductRatings() {
    try {
      const db = getDb();
      const products = db.prepare(
        `SELECT DISTINCT product_id FROM product_reviews WHERE is_approved = 1 AND deleted_at IS NULL`
      ).all();

      const updateRating = db.prepare(
        `UPDATE products SET
          average_rating = COALESCE((
            SELECT ROUND(AVG(rating), 2) FROM product_reviews
            WHERE product_id = ? AND is_approved = 1 AND deleted_at IS NULL
          ), 0),
          review_count = (
            SELECT COUNT(*) FROM product_reviews
            WHERE product_id = ? AND is_approved = 1 AND deleted_at IS NULL
          ),
          updated_at = datetime('now')
        WHERE id = ?`
      );

      let updated = 0;
      const updateAll = db.transaction(() => {
        for (const { product_id } of products) {
          updateRating.run(product_id, product_id, product_id);
          updated++;
        }
      });

      updateAll();

      const zeroReviews = db.prepare(
        `SELECT id FROM products WHERE review_count > 0 AND id NOT IN (
          SELECT DISTINCT product_id FROM product_reviews WHERE is_approved = 1 AND deleted_at IS NULL
        )`
      ).all();

      const clearRating = db.prepare(
        `UPDATE products SET average_rating = 0, review_count = 0, updated_at = datetime('now') WHERE id = ?`
      );

      for (const { id } of zeroReviews) {
        clearRating.run(id);
      }

      if (updated > 0 || zeroReviews.length > 0) {
        console.log(`[CronService] Updated ratings for ${updated} products, cleared ${zeroReviews.length} stale ratings`);
      }
    } catch (error) {
      console.error('[CronService] updateProductRatings error:', error.message);
    }
  }

  async cleanupOldNotifications() {
    try {
      let notificationService;
      try {
        notificationService = (await import('./notification.service.js')).default;
      } catch (importError) {
        return;
      }

      const result = await notificationService.cleanupOldNotifications(90);
      if (result.deleted > 0) {
        console.log(`[CronService] Cleaned up ${result.deleted} old notifications`);
      }
    } catch (error) {
      console.error('[CronService] cleanupOldNotifications error:', error.message);
    }
  }
}

export default new CronService();
