import express from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import giftCardService from '../services/giftcard.service.js';

const router = express.Router();
const adminAuth = [authenticate, authorize('admin', 'super_admin')];

router.post('/', authenticate, async (req, res) => {
  try {
    const { amount, recipientEmail, recipientName, message, expiresAt } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Amount must be greater than 0' });
    }

    const giftCard = await giftCardService.createGiftCard({
      amount,
      purchaserId: req.user.id,
      recipientEmail,
      recipientName,
      message,
      expiresAt,
    });

    res.status(201).json({
      success: true,
      data: { giftCard },
      message: 'Gift card created successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/', authenticate, async (req, res) => {
  try {
    const giftCards = await giftCardService.getUserGiftCards(req.user.id);

    res.json({
      success: true,
      data: { giftCards },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/admin/all', adminAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const status = req.query.status;

    const result = await giftCardService.getAllGiftCards({ page, limit, status });

    res.json({
      success: true,
      data: {
        items: result.giftCards,
        pagination: result.pagination,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/redeem', authenticate, async (req, res) => {
  try {
    const { code, amount, orderId } = req.body;

    if (!code) {
      return res.status(400).json({ success: false, message: 'Gift card code is required' });
    }

    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Amount must be greater than 0' });
    }

    const validation = await giftCardService.validateGiftCard(code, amount);
    if (!validation.valid) {
      return res.status(400).json({ success: false, message: validation.message });
    }

    const giftCard = await giftCardService.redeemGiftCard(code, amount, orderId);

    res.json({
      success: true,
      data: { giftCard },
      message: 'Gift card redeemed successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/validate/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const amount = parseFloat(req.query.amount) || 0;

    const result = await giftCardService.validateGiftCard(code, amount);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/:id/transactions', authenticate, async (req, res) => {
  try {
    const giftCardId = parseInt(req.params.id);

    const giftCard = await giftCardService.getGiftCardById(giftCardId);
    if (!giftCard) {
      return res.status(404).json({ success: false, message: 'Gift card not found' });
    }

    const transactions = await giftCardService.getGiftCardTransactions(giftCardId);

    res.json({
      success: true,
      data: { transactions },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.put('/:id', adminAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, amount, recipient_email, recipient_name, message, expires_at } = req.body;

    const giftCard = await giftCardService.updateGiftCard(id, {
      status,
      amount,
      recipient_email,
      recipient_name,
      message,
      expires_at,
    });

    res.json({
      success: true,
      data: { giftCard },
      message: 'Gift card updated successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.delete('/:id', adminAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    await giftCardService.deleteGiftCard(id);

    res.json({
      success: true,
      message: 'Gift card deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
