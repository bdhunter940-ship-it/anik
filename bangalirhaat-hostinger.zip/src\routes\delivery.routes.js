import express from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import deliveryService from '../services/delivery.service.js';

const router = express.Router();

const adminAuth = [authenticate, authorize('admin', 'super_admin')];

// POST /calculate — Calculate delivery charge (public)
router.post('/calculate', async (req, res, next) => {
  try {
    const { district, upazila, weight, courier_id } = req.body;

    if (!district) throw new AppError('district is required', 400);

    const result = await deliveryService.calculateDeliveryCharge({
      district,
      upazila,
      weight: weight ? parseFloat(weight) : undefined,
      courierId: courier_id ? parseInt(courier_id) : undefined,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// GET /zones — Get delivery zones (public)
router.get('/zones', async (req, res, next) => {
  try {
    const result = await deliveryService.getDeliveryZones();
    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// GET /courier-performance — All couriers performance report (admin)
router.get('/courier-performance', ...adminAuth, async (req, res, next) => {
  try {
    const { start_date, end_date } = req.query;

    const result = await deliveryService.getAllCouriersPerformance({
      startDate: start_date,
      endDate: end_date,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// GET /courier-performance/:courierId — Specific courier performance (admin)
router.get('/courier-performance/:courierId', ...adminAuth, async (req, res, next) => {
  try {
    const courierId = parseInt(req.params.courierId);
    if (isNaN(courierId)) throw new AppError('Invalid courier ID', 400);

    const { start_date, end_date } = req.query;

    const result = await deliveryService.getCourierPerformance({
      courierId,
      startDate: start_date,
      endDate: end_date,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

// POST /return-charge — Calculate return charge (admin)
router.post('/return-charge', ...adminAuth, async (req, res, next) => {
  try {
    const { order_id, reason } = req.body;

    if (!order_id) throw new AppError('order_id is required', 400);

    const result = await deliveryService.calculateReturnCharge({
      orderId: parseInt(order_id),
      reason,
    });

    res.json({ success: true, data: result });
  } catch (error) {
    next(error);
  }
});

export default router;
