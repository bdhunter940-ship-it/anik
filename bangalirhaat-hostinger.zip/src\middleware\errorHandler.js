import config from '../config/index.js';

export class AppError extends Error {
  constructor(message, statusCode = 500, isOperational = true) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class BadRequestError extends AppError {
  constructor(message = 'Bad request') {
    super(message, 400);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Unauthorized') {
    super(message, 401);
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'Forbidden') {
    super(message, 403);
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Resource not found') {
    super(message, 404);
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Resource already exists') {
    super(message, 409);
  }
}

export class ValidationError extends AppError {
  constructor(message = 'Validation failed', errors = []) {
    super(message, 422);
    this.errors = errors;
  }
}

export class TooManyRequestsError extends AppError {
  constructor(message = 'Too many requests') {
    super(message, 429);
  }
}

function handleDatabaseError(err) {
  if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    const match = err.message.match(/UNIQUE constraint failed: (\w+\.\w+)/);
    const field = match ? match[1].split('.').pop() : 'value';
    return new ConflictError(`A record with this ${field} already exists`);
  }
  if (err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
    return new BadRequestError('Referenced resource does not exist');
  }
  if (err.code === 'SQLITE_CONSTRAINT_CHECK') {
    return new BadRequestError('Invalid data: constraint check failed');
  }
  if (err.code === 'SQLITE_ERROR') {
    return new BadRequestError('Database operation failed');
  }
  return null;
}

function handleJWTError(err) {
  if (err.name === 'JsonWebTokenError') {
    return new UnauthorizedError('Invalid token');
  }
  if (err.name === 'TokenExpiredError') {
    return new UnauthorizedError('Token expired');
  }
  if (err.name === 'NotBeforeError') {
    return new UnauthorizedError('Token not yet valid');
  }
  return null;
}

function formatValidationErrors(err) {
  if (err.errors && Array.isArray(err.errors)) {
    return err.errors.map((e) => ({
      field: e.path || e.param || e.location,
      message: e.msg || e.message,
    }));
  }
  return undefined;
}

function sanitizeError(err) {
  return {
    statusCode: err.statusCode || 500,
    message: err.isOperational ? err.message : 'Internal server error',
    ...(err.errors && { errors: err.errors }),
    ...(config.isDevelopment && {
      stack: err.stack,
      name: err.name,
    }),
  };
}

export function errorHandler(err, req, res, _next) {
  let error = err;

  const dbError = handleDatabaseError(err);
  if (dbError) error = dbError;

  const jwtError = handleJWTError(err);
  if (jwtError) error = jwtError;

  if (err.name === 'ValidationError' || err.name === 'ValidatorError') {
    error = new ValidationError(
      err.message || 'Validation failed',
      formatValidationErrors(err),
    );
  }

  if (err.type === 'entity.too.large') {
    error = new BadRequestError('Request body too large');
  }

  if (err.type === 'entity.parse.failed') {
    error = new BadRequestError('Invalid JSON in request body');
  }

  if (err.statusCode >= 500 || !err.statusCode) {
    console.error('══════════════════════════════════════════');
    console.error('  UNHANDLED / SERVER ERROR');
    console.error('══════════════════════════════════════════');
    console.error(`  Method  : ${req.method} ${req.originalUrl}`);
    console.error(`  IP      : ${req.ip}`);
    console.error(`  User    : ${req.user?.id || 'anonymous'}`);
    console.error(`  Time    : ${new Date().toISOString()}`);
    console.error(`  Error   : ${err.message}`);
    if (config.isDevelopment) {
      console.error(`  Stack   : ${err.stack}`);
    }
    console.error('══════════════════════════════════════════');
  }

  const formatted = sanitizeError(error);

  res.status(formatted.statusCode).json({
    success: false,
    message: formatted.message,
    ...(formatted.errors && { errors: formatted.errors }),
    ...(config.isDevelopment && { stack: formatted.stack }),
  });
}
