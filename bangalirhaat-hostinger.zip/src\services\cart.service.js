import crypto from 'crypto';
import { getDb } from '../database/db.js';

class CartService {
  // Get carts older than N hours with items
  getAbandonedCarts(hours = 24) {
    const db = getDb();
    return db.prepare(`
      SELECT c.id, c.user_id, c.updated_at,
             u.email, u.first_name || ' ' || u.last_name as customer_name,
             u.phone,
             (SELECT COUNT(*) FROM cart_items WHERE cart_id = c.id) as item_count,
             (SELECT SUM(total_price) FROM cart_items WHERE cart_id = c.id) as cart_total
      FROM carts c
      JOIN users u ON c.user_id = u.id
      WHERE c.updated_at < datetime('now', ? || ' hours')
        AND c.updated_at > datetime('now', '-30 days')
        AND (SELECT COUNT(*) FROM cart_items WHERE cart_id = c.id) > 0
        AND c.id NOT IN (SELECT cart_id FROM abandoned_cart_recoveries)
      ORDER BY c.updated_at ASC
    `).all(`-${hours}`);
  }

  // Mark cart as recovered (notification sent)
  markRecovered(cartId, notificationType = 'email') {
    const db = getDb();
    db.prepare(`
      INSERT INTO abandoned_cart_recoveries (cart_id, notification_type, sent_at)
      VALUES (?, ?, datetime('now'))
    `).run(cartId, notificationType);
  }

  // Generate recovery coupon
  generateRecoveryCoupon(cartId, userId) {
    const code = `WELCOME${Date.now().toString(36).toUpperCase()}`;
    const db = getDb();
    db.prepare(`
      INSERT INTO coupons (uuid, code, type, value, minimum_order, applies_to, is_active, created_at, updated_at)
      VALUES (?, ?, 'percentage', 10, 500, 'all', 1, datetime('now'), datetime('now'))
    `).run(crypto.randomUUID(), code);
    return code;
  }

  // Send recovery notification (placeholder - logs to console)
  async sendRecoveryNotification(cart, type = 'email') {
    const couponCode = this.generateRecoveryCoupon(cart.id, cart.user_id);
    console.log(`[AbandonedCart] Sending ${type} to ${cart.email} for cart #${cart.id}`);
    console.log(`[AbandonedCart] Coupon: ${couponCode} | Items: ${cart.item_count} | Total: ৳${cart.cart_total}`);
    // In production: Send email via nodemailer or SMS via WhatsApp API
    this.markRecovered(cart.id, type);
    return { sent: true, couponCode };
  }

  // Process all abandoned carts
  async processAbandonedCarts(hours = 24) {
    const carts = this.getAbandonedCarts(hours);
    const results = [];
    for (const cart of carts) {
      try {
        const result = await this.sendRecoveryNotification(cart, 'email');
        results.push({ cartId: cart.id, status: 'sent', ...result });
      } catch (err) {
        results.push({ cartId: cart.id, status: 'failed', error: err.message });
      }
    }
    return { processed: results.length, results };
  }
}

export default new CartService();
