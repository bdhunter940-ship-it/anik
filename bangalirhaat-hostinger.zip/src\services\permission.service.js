import { getDb } from '../database/db.js';

const DEFAULT_PERMISSIONS = {
  products: ['create', 'read', 'update', 'delete'],
  orders: ['read', 'update', 'delete', 'bulk_action'],
  users: ['read', 'update', 'delete', 'change_role'],
  settings: ['read', 'update'],
  finance: ['read', 'create', 'update', 'delete'],
  marketing: ['read', 'create', 'update', 'delete'],
  couriers: ['read', 'create', 'update', 'delete'],
  reports: ['read', 'export'],
  inventory: ['read', 'adjust', 'transfer'],
};

const DEFAULT_ROLES = ['super_admin', 'admin', 'manager', 'staff', 'customer'];

const ROLE_HIERARCHY = {
  super_admin: null,
  admin: 'super_admin',
  manager: 'admin',
  staff: 'manager',
  customer: null,
};

class PermissionService {
  async initPermissions() {
    const db = getDb();

    const insertPermission = db.prepare(
      `INSERT OR IGNORE INTO permissions (module, action, name, created_at)
       VALUES (?, ?, ?, datetime('now'))`
    );

    const insertRole = db.prepare(
      `INSERT OR IGNORE INTO roles (name, display_name, is_default, created_at)
       VALUES (?, ?, ?, datetime('now'))`
    );

    const insertRolePermission = db.prepare(
      `INSERT OR IGNORE INTO role_permissions (role_id, permission_id, created_at)
       VALUES (?, ?, datetime('now'))`
    );

    const seed = db.transaction(() => {
      for (const [module, actions] of Object.entries(DEFAULT_PERMISSIONS)) {
        for (const action of actions) {
          const name = `${module}.${action}`;
          insertPermission.run(module, action, name);
        }
      }

      for (const role of DEFAULT_ROLES) {
        const displayName = role.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        insertRole.run(role, displayName, role === 'customer' ? 1 : 0);
      }

      const superAdmin = db.prepare("SELECT id FROM roles WHERE name = 'super_admin'").get();
      const admin = db.prepare("SELECT id FROM roles WHERE name = 'admin'").get();
      const manager = db.prepare("SELECT id FROM roles WHERE name = 'manager'").get();
      const staff = db.prepare("SELECT id FROM roles WHERE name = 'staff'").get();
      const customer = db.prepare("SELECT id FROM roles WHERE name = 'customer'").get();

      const allPermissions = db.prepare('SELECT id FROM permissions').all();
      for (const perm of allPermissions) {
        insertRolePermission.run(superAdmin.id, perm.id);
      }

      const adminExcluded = db.prepare(
        `SELECT id FROM permissions WHERE name IN (
          'settings.update', 'users.change_role'
        )`
      ).all();
      const adminPermIds = allPermissions
        .map(p => p.id)
        .filter(id => !adminExcluded.find(e => e.id === id));
      for (const permId of adminPermIds) {
        insertRolePermission.run(admin.id, permId);
      }

      const managerPerms = db.prepare(
        `SELECT id FROM permissions WHERE module IN ('products', 'orders', 'inventory', 'couriers', 'reports')
          AND action NOT IN ('delete')`
      ).all();
      for (const perm of managerPerms) {
        insertRolePermission.run(manager.id, perm.id);
      }

      const staffPerms = db.prepare(
        `SELECT id FROM permissions WHERE module IN ('products', 'orders', 'inventory', 'couriers')
          AND action IN ('read', 'update')`
      ).all();
      for (const perm of staffPerms) {
        insertRolePermission.run(staff.id, perm.id);
      }

      const customerPerms = db.prepare(
        `SELECT id FROM permissions WHERE module = 'orders' AND action = 'read'`
      ).all();
      for (const perm of customerPerms) {
        insertRolePermission.run(customer.id, perm.id);
      }
    });

    seed();

    const totalPerms = db.prepare('SELECT COUNT(*) as count FROM permissions').get().count;
    const totalRoles = db.prepare('SELECT COUNT(*) as count FROM roles').get().count;

    return {
      permissions_created: totalPerms,
      roles_created: totalRoles,
      modules: Object.keys(DEFAULT_PERMISSIONS),
    };
  }

  async getPermissions() {
    const db = getDb();
    const permissions = db.prepare(
      'SELECT id, module, action, name, created_at FROM permissions ORDER BY module ASC, action ASC'
    ).all();

    const grouped = {};
    for (const perm of permissions) {
      if (!grouped[perm.module]) grouped[perm.module] = [];
      grouped[perm.module].push(perm);
    }

    return { permissions, grouped };
  }

  async getRolePermissions(role) {
    const db = getDb();
    const roleRecord = db.prepare('SELECT id, name, display_name FROM roles WHERE name = ?').get(role);
    if (!roleRecord) throw new Error(`Role '${role}' not found`);

    const permissions = db.prepare(`
      SELECT p.id, p.module, p.action, p.name
      FROM permissions p
      JOIN role_permissions rp ON p.id = rp.permission_id
      WHERE rp.role_id = ?
      ORDER BY p.module ASC, p.action ASC
    `).all(roleRecord.id);

    const grouped = {};
    for (const perm of permissions) {
      if (!grouped[perm.module]) grouped[perm.module] = [];
      grouped[perm.module].push(perm);
    }

    return {
      role: { id: roleRecord.id, name: roleRecord.name, display_name: roleRecord.display_name },
      permissions,
      grouped,
    };
  }

  async setRolePermissions(role, permissionIds) {
    const db = getDb();
    const roleRecord = db.prepare('SELECT id, name FROM roles WHERE name = ?').get(role);
    if (!roleRecord) throw new Error(`Role '${role}' not found`);

    if (!Array.isArray(permissionIds)) {
      throw new Error('permissionIds must be an array');
    }

    const setPerms = db.transaction(() => {
      db.prepare('DELETE FROM role_permissions WHERE role_id = ?').run(roleRecord.id);

      const insert = db.prepare(
        'INSERT INTO role_permissions (role_id, permission_id, created_at) VALUES (?, ?, datetime(\'now\'))'
      );

      for (const permId of permissionIds) {
        insert.run(roleRecord.id, permId);
      }
    });

    setPerms();

    return {
      role: roleRecord.name,
      permissions_set: permissionIds.length,
    };
  }

  async checkPermission(role, permissionName) {
    const db = getDb();

    const result = db.prepare(`
      SELECT 1
      FROM roles r
      JOIN role_permissions rp ON r.id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE r.name = ? AND p.name = ?
      LIMIT 1
    `).get(role, permissionName);

    return {
      role,
      permission: permissionName,
      allowed: !!result,
    };
  }

  async getAllRoles() {
    const db = getDb();

    const roles = db.prepare(
      'SELECT id, name, display_name, is_default, created_at FROM roles ORDER BY id ASC'
    ).all();

    const rolesWithPerms = roles.map(role => {
      const permissions = db.prepare(`
        SELECT p.id, p.module, p.action, p.name
        FROM permissions p
        JOIN role_permissions rp ON p.id = rp.permission_id
        WHERE rp.role_id = ?
        ORDER BY p.module ASC, p.action ASC
      `).all(role.id);

      const grouped = {};
      for (const perm of permissions) {
        if (!grouped[perm.module]) grouped[perm.module] = [];
        grouped[perm.module].push(perm.action);
      }

      return {
        id: role.id,
        name: role.name,
        display_name: role.display_name,
        is_default: !!role.is_default,
        parent_role: ROLE_HIERARCHY[role.name] || null,
        permissions,
        grouped,
      };
    });

    return { roles: rolesWithPerms };
  }
}

export default new PermissionService();
