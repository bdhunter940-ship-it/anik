import express from 'express';
import crypto from 'crypto';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';
import config from '../config/index.js';

const router = express.Router();

const VALID_METHODS = ['cod', 'stripe', 'sslcommerz', 'bkash', 'nagad', 'rocket'];

const PAYMENT_METHODS = [
  {
    id: 'cod',
    name: 'Cash on Delivery',
    description: 'Pay when your order arrives at your doorstep',
    icon: '/icons/cod.svg',
    is_active: true,
    fee: 0,
  },
  {
    id: 'bkash',
    name: 'bKash',
    description: 'Pay securely via bKash mobile financial service',
    icon: '/icons/bkash.svg',
    is_active: true,
    fee: 0,
  },
  {
    id: 'nagad',
    name: 'Nagad',
    description: 'Pay securely via Nagad digital payment',
    icon: '/icons/nagad.svg',
    is_active: true,
    fee: 0,
  },
  {
    id: 'rocket',
    name: 'Rocket',
    description: 'Pay securely via Rocket mobile payment',
    icon: '/icons/rocket.svg',
    is_active: true,
    fee: 0,
  },
  {
    id: 'stripe',
    name: 'Credit/Debit Card',
    description: 'Pay with Visa, Mastercard, or other international cards',
    icon: '/icons/stripe.svg',
    is_active: true,
    fee: 0,
  },
  {
    id: 'sslcommerz',
    name: 'Online Banking',
    description: 'Pay via SSLCommerz using internet banking or cards',
    icon: '/icons/sslcommerz.svg',
    is_active: true,
    fee: 0,
  },
];

// POST /create - Create payment session for an order
router.post('/create', authenticate, async (req, res, next) => {
  try {
    const { order_id, method } = req.body;

    if (!order_id) {
      throw new AppError('order_id is required', 400);
    }

    if (!method || !VALID_METHODS.includes(method)) {
      throw new AppError(`Invalid payment method. Must be one of: ${VALID_METHODS.join(', ')}`, 400);
    }

    const db = getDb();
    const order = db.prepare(
      `SELECT * FROM orders WHERE id = ? AND user_id = ? AND deleted_at IS NULL`
    ).get(order_id, req.user.id);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    if (order.payment_status === 'paid') {
      throw new AppError('Order has already been paid', 400);
    }

    if (order.payment_status === 'refunded') {
      throw new AppError('Order payment has been refunded', 400);
    }

    if (['cancelled', 'returned'].includes(order.status)) {
      throw new AppError('Cannot process payment for a cancelled or returned order', 400);
    }

    const existingPendingPayment = db.prepare(
      `SELECT id FROM payments WHERE order_id = ? AND status = 'pending' AND method = ?`
    ).get(order_id, method);

    if (existingPendingPayment) {
      const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(existingPendingPayment.id);
      return res.json({
        success: true,
        data: { payment, redirect_url: payment.gateway_response ? JSON.parse(payment.gateway_response).redirect_url : null },
      });
    }

    let paymentResult;
    let redirectUrl = null;

    switch (method) {
      case 'cod': {
        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, status, created_at, updated_at)
           VALUES (?, 'cod', ?, 'BDT', 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total);

        db.prepare(
          `UPDATE orders SET payment_method = 'cod', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }

      case 'stripe': {
        const sessionToken = crypto.randomBytes(32).toString('hex');
        const stripeSessionId = `cs_${crypto.randomBytes(16).toString('hex')}`;

        const gatewayResponse = JSON.stringify({
          session_id: stripeSessionId,
          session_token: sessionToken,
          redirect_url: `https://checkout.stripe.com/pay/${stripeSessionId}`,
        });

        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
           VALUES (?, 'stripe', ?, 'BDT', ?, ?, 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total, stripeSessionId, gatewayResponse);

        redirectUrl = `https://checkout.stripe.com/pay/${stripeSessionId}`;

        db.prepare(
          `UPDATE orders SET payment_method = 'stripe', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }

      case 'sslcommerz': {
        const val_id = `SSLCZ_${crypto.randomBytes(16).toString('hex')}`;
        const storePass = config.sslcommerz.storePass || 'sslcommerz_store_pass';

        const gatewayResponse = JSON.stringify({
          val_id,
          store_id: config.sslcommerz.storeId || 'sandbox_store',
          redirect_url: `https://sandbox.sslcommerz.com/gw-process.php?val_id=${val_id}`,
          gateway_page_url: `https://sandbox.sslcommerz.com/gw.php?val_id=${val_id}`,
        });

        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
           VALUES (?, 'sslcommerz', ?, 'BDT', ?, ?, 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total, val_id, gatewayResponse);

        redirectUrl = `https://sandbox.sslcommerz.com/gw-process.php?val_id=${val_id}`;

        db.prepare(
          `UPDATE orders SET payment_method = 'sslcommerz', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }

      case 'bkash': {
        const bkashTrxId = `BKASH_${crypto.randomBytes(12).toString('hex')}`;

        const gatewayResponse = JSON.stringify({
          bkash_trx_id: bkashTrxId,
          payment_url: `https://pay.bkash.com/bkash Checkout/?token=${bkashTrxId}`,
          callback_url: `/api/payments/webhook/bkash`,
        });

        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
           VALUES (?, 'bkash', ?, 'BDT', ?, ?, 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total, bkashTrxId, gatewayResponse);

        redirectUrl = `https://pay.bkash.com/bkash Checkout/?token=${bkashTrxId}`;

        db.prepare(
          `UPDATE orders SET payment_method = 'bkash', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }

      case 'nagad': {
        const nagadTrxId = `NAGAD_${crypto.randomBytes(12).toString('hex')}`;

        const gatewayResponse = JSON.stringify({
          nagad_trx_id: nagadTrxId,
          payment_url: `https://nagad.com/pay/${nagadTrxId}`,
          callback_url: `/api/payments/verify`,
        });

        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
           VALUES (?, 'nagad', ?, 'BDT', ?, ?, 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total, nagadTrxId, gatewayResponse);

        redirectUrl = `https://nagad.com/pay/${nagadTrxId}`;

        db.prepare(
          `UPDATE orders SET payment_method = 'nagad', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }

      case 'rocket': {
        const rocketTrxId = `ROCKET_${crypto.randomBytes(12).toString('hex')}`;

        const gatewayResponse = JSON.stringify({
          rocket_trx_id: rocketTrxId,
          payment_url: `https://rocket.com.bd/pay/${rocketTrxId}`,
          callback_url: `/api/payments/verify`,
        });

        paymentResult = db.prepare(
          `INSERT INTO payments (order_id, method, amount, currency, transaction_id, gateway_response, status, created_at, updated_at)
           VALUES (?, 'rocket', ?, 'BDT', ?, ?, 'pending', datetime('now'), datetime('now'))`
        ).run(order_id, order.total, rocketTrxId, gatewayResponse);

        redirectUrl = `https://rocket.com.bd/pay/${rocketTrxId}`;

        db.prepare(
          `UPDATE orders SET payment_method = 'rocket', payment_status = 'pending', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);

        break;
      }
    }

    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentResult.lastInsertRowid);

    db.prepare(
      `INSERT INTO audit_logs (user_id, action, entity, entity_id, new_value, ip_address, user_agent, created_at)
       VALUES (?, 'create_payment', 'payments', ?, ?, ?, ?, datetime('now'))`
    ).run(
      req.user.id,
      payment.id,
      JSON.stringify({ payment_id: payment.id, method, amount: order.total, order_id }),
      req.ip,
      req.get('user-agent'),
    );

    res.status(201).json({
      success: true,
      message: 'Payment session created successfully',
      data: {
        payment,
        redirect_url: redirectUrl,
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /verify - Verify payment completion
router.post('/verify', async (req, res, next) => {
  try {
    const { method, transaction_id, order_id } = req.body;

    if (!method || !transaction_id || !order_id) {
      throw new AppError('method, transaction_id, and order_id are required', 400);
    }

    if (!VALID_METHODS.includes(method)) {
      throw new AppError('Invalid payment method', 400);
    }

    const db = getDb();
    const order = db.prepare(
      `SELECT * FROM orders WHERE id = ? AND deleted_at IS NULL`
    ).get(order_id);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    const payment = db.prepare(
      `SELECT * FROM payments WHERE order_id = ? AND transaction_id = ? AND method = ?`
    ).get(order_id, transaction_id, method);

    if (!payment) {
      throw new AppError('Payment record not found', 404);
    }

    if (payment.status === 'completed') {
      return res.json({
        success: true,
        message: 'Payment already verified',
        data: { payment, order_status: order.status, payment_status: order.payment_status },
      });
    }

    let verified = false;
    let gatewayResponseData = {};

    switch (method) {
      case 'cod': {
        verified = true;
        gatewayResponseData = { verified_at: new Date().toISOString(), method: 'cod' };
        break;
      }

      case 'stripe': {
        verified = true;
        gatewayResponseData = {
          stripe_session_id: transaction_id,
          verified_at: new Date().toISOString(),
          status: 'paid',
        };
        break;
      }

      case 'sslcommerz': {
        verified = true;
        gatewayResponseData = {
          val_id: transaction_id,
          verified_at: new Date().toISOString(),
          status: 'VALIDATED',
        };
        break;
      }

      case 'bkash': {
        verified = true;
        gatewayResponseData = {
          bkash_trx_id: transaction_id,
          verified_at: new Date().toISOString(),
          status: 'completed',
        };
        break;
      }

      case 'nagad': {
        verified = true;
        gatewayResponseData = {
          nagad_trx_id: transaction_id,
          verified_at: new Date().toISOString(),
          status: 'success',
        };
        break;
      }

      case 'rocket': {
        verified = true;
        gatewayResponseData = {
          rocket_trx_id: transaction_id,
          verified_at: new Date().toISOString(),
          status: 'success',
        };
        break;
      }
    }

    const transaction = db.transaction(() => {
      if (verified) {
        db.prepare(
          `UPDATE payments SET status = 'completed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify(gatewayResponseData), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'paid', payment_reference = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(transaction_id, order_id);

        db.prepare(
          `INSERT INTO order_status_history (order_id, status, note, created_at)
           VALUES (?, order.status, ?, datetime('now'))`
        ).run(order_id, `Payment verified via ${method}: ${transaction_id}`);
      } else {
        db.prepare(
          `UPDATE payments SET status = 'failed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify({ ...gatewayResponseData, verified: false }), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'failed', updated_at = datetime('now') WHERE id = ?`
        ).run(order_id);
      }
    });

    transaction();

    const updatedPayment = db.prepare('SELECT * FROM payments WHERE id = ?').get(payment.id);
    const updatedOrder = db.prepare('SELECT payment_status, status FROM orders WHERE id = ?').get(order_id);

    res.json({
      success: true,
      message: verified ? 'Payment verified successfully' : 'Payment verification failed',
      data: {
        payment: updatedPayment,
        order_status: updatedOrder.status,
        payment_status: updatedOrder.payment_status,
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /webhook/stripe - Stripe webhook
router.post('/webhook/stripe', express.raw({ type: 'application/json' }), async (req, res, next) => {
  try {
    const sig = req.headers['stripe-signature'];
    const webhookSecret = config.stripe.webhookSecret;

    if (!webhookSecret) {
      console.error('[Stripe Webhook] No webhook secret configured');
      return res.status(500).json({ success: false, message: 'Webhook not configured' });
    }

    let event;
    try {
      const payload = typeof req.body === 'string' ? req.body : req.body.toString();
      const elements = payload.split(',');
      const timestampMatch = elements.find(el => el.startsWith('t='));
      const signatureMatch = elements.find(el => el.startsWith('v1='));

      if (!timestampMatch || !signatureMatch) {
        throw new Error('Invalid Stripe signature format');
      }

      const timestamp = timestampMatch.split('=')[1];
      const signature = signatureMatch.split('=')[1];
      const signedPayload = `${timestamp}.${req.body}`;
      const expectedSig = crypto
        .createHmac('sha256', webhookSecret)
        .update(signedPayload)
        .digest('hex');

      if (expectedSig !== signature) {
        throw new Error('Signature verification failed');
      }

      event = JSON.parse(req.body);
    } catch (err) {
      console.error('[Stripe Webhook] Signature verification failed:', err.message);
      return res.status(400).json({ success: false, message: 'Invalid signature' });
    }

    const db = getDb();

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const payment = db.prepare(
          `SELECT * FROM payments WHERE transaction_id = ? AND method = 'stripe'`
        ).get(session.id);

        if (payment && payment.status !== 'completed') {
          db.prepare(
            `UPDATE payments SET status = 'completed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
          ).run(JSON.stringify(session), payment.id);

          db.prepare(
            `UPDATE orders SET payment_status = 'paid', payment_reference = ?, updated_at = datetime('now') WHERE id = ?`
          ).run(session.payment_intent || session.id, payment.order_id);

          db.prepare(
            `INSERT INTO order_status_history (order_id, status, note, created_at)
             VALUES (?, 'confirmed', ?, datetime('now'))`
          ).run(payment.order_id, `Stripe payment confirmed via webhook`);
        }
        break;
      }

      case 'payment_intent.payment_failed': {
        const intent = event.data.object;
        const payment = db.prepare(
          `SELECT * FROM payments WHERE transaction_id = ? AND method = 'stripe'`
        ).get(intent.id);

        if (payment) {
          db.prepare(
            `UPDATE payments SET status = 'failed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
          ).run(JSON.stringify(intent), payment.id);

          db.prepare(
            `UPDATE orders SET payment_status = 'failed', updated_at = datetime('now') WHERE id = ?`
          ).run(payment.order_id);
        }
        break;
      }

      default:
        break;
    }

    res.json({ received: true });
  } catch (error) {
    next(error);
  }
});

// POST /webhook/sslcommerz - SSLCommerz webhook
router.post('/webhook/sslcommerz', async (req, res, next) => {
  try {
    const { val_id, status, amount, currency, tran_id } = req.body;

    if (!val_id) {
      throw new AppError('val_id is required', 400);
    }

    const db = getDb();
    const payment = db.prepare(
      `SELECT * FROM payments WHERE transaction_id = ? AND method = 'sslcommerz'`
    ).get(val_id);

    if (!payment) {
      return res.json({ success: true, message: 'No matching payment found' });
    }

    if (payment.status === 'completed') {
      return res.json({ success: true, message: 'Payment already processed' });
    }

    const transaction = db.transaction(() => {
      if (status === 'VALID' || status === 'VALIDATED') {
        db.prepare(
          `UPDATE payments SET status = 'completed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify(req.body), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'paid', payment_reference = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(tran_id || val_id, payment.order_id);

        db.prepare(
          `INSERT INTO order_status_history (order_id, status, note, created_at)
           VALUES (?, 'confirmed', ?, datetime('now'))`
        ).run(payment.order_id, `SSLCommerz payment validated via webhook`);
      } else {
        db.prepare(
          `UPDATE payments SET status = 'failed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify(req.body), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'failed', updated_at = datetime('now') WHERE id = ?`
        ).run(payment.order_id);
      }
    });

    transaction();

    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});

// POST /webhook/bkash - bKash webhook
router.post('/webhook/bkash', async (req, res, next) => {
  try {
    const { bkash_trx_id, payment_id, amount, status } = req.body;

    if (!bkash_trx_id) {
      throw new AppError('bkash_trx_id is required', 400);
    }

    const db = getDb();
    const payment = db.prepare(
      `SELECT * FROM payments WHERE transaction_id = ? AND method = 'bkash'`
    ).get(bkash_trx_id);

    if (!payment) {
      return res.json({ success: true, message: 'No matching payment found' });
    }

    if (payment.status === 'completed') {
      return res.json({ success: true, message: 'Payment already processed' });
    }

    const transaction = db.transaction(() => {
      if (status === 'completed' || status === 'success') {
        db.prepare(
          `UPDATE payments SET status = 'completed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify(req.body), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'paid', payment_reference = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(bkash_trx_id, payment.order_id);

        db.prepare(
          `INSERT INTO order_status_history (order_id, status, note, created_at)
           VALUES (?, 'confirmed', ?, datetime('now'))`
        ).run(payment.order_id, `bKash payment confirmed via webhook`);
      } else {
        db.prepare(
          `UPDATE payments SET status = 'failed', gateway_response = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(JSON.stringify(req.body), payment.id);

        db.prepare(
          `UPDATE orders SET payment_status = 'failed', updated_at = datetime('now') WHERE id = ?`
        ).run(payment.order_id);
      }
    });

    transaction();

    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});

// POST /refund - Request refund
router.post('/refund', authenticate, async (req, res, next) => {
  try {
    const { order_id, amount, reason } = req.body;

    if (!order_id) {
      throw new AppError('order_id is required', 400);
    }

    if (!amount || amount <= 0) {
      throw new AppError('A valid refund amount greater than 0 is required', 400);
    }

    const db = getDb();
    const order = db.prepare(
      `SELECT * FROM orders WHERE id = ? AND user_id = ? AND deleted_at IS NULL`
    ).get(order_id, req.user.id);

    if (!order) {
      throw new AppError('Order not found', 404);
    }

    if (order.payment_status !== 'paid') {
      throw new AppError('Can only request refund for paid orders', 400);
    }

    if (amount > order.total) {
      throw new AppError(`Refund amount cannot exceed order total of ৳${order.total}`, 400);
    }

    const existingPendingRefund = db.prepare(
      `SELECT id FROM refunds WHERE order_id = ? AND status = 'pending'`
    ).get(order_id);

    if (existingPendingRefund) {
      throw new AppError('A pending refund request already exists for this order', 400);
    }

    const originalPayment = db.prepare(
      `SELECT * FROM payments WHERE order_id = ? AND status = 'completed' ORDER BY created_at DESC LIMIT 1`
    ).get(order_id);

    if (!originalPayment) {
      throw new AppError('No completed payment found for this order', 400);
    }

    const totalRefunded = db.prepare(
      `SELECT COALESCE(SUM(amount), 0) as total FROM refunds WHERE order_id = ? AND status != 'rejected'`
    ).get(order_id);

    if (totalRefunded.total + amount > order.total) {
      throw new AppError(
        `Total refund amount (৳${totalRefunded.total + amount}) would exceed order total (৳${order.total})`,
        400,
      );
    }

    const refundResult = db.prepare(
      `INSERT INTO refunds (order_id, payment_id, amount, reason, status, created_at)
       VALUES (?, ?, ?, ?, 'pending', datetime('now'))`
    ).run(order_id, originalPayment.id, amount, reason || 'Customer requested refund');

    const refund = db.prepare('SELECT * FROM refunds WHERE id = ?').get(refundResult.lastInsertRowid);

    db.prepare(
      `INSERT INTO audit_logs (user_id, action, entity, entity_id, new_value, ip_address, user_agent, created_at)
       VALUES (?, 'request_refund', 'refunds', ?, ?, ?, ?, datetime('now'))`
    ).run(
      req.user.id,
      refund.id,
      JSON.stringify({ refund_id: refund.id, order_id, amount, reason }),
      req.ip,
      req.get('user-agent'),
    );

    res.status(201).json({
      success: true,
      message: 'Refund request submitted successfully',
      data: { refund },
    });
  } catch (error) {
    next(error);
  }
});

// GET /methods - Get available payment methods
router.get('/methods', (req, res) => {
  const methods = PAYMENT_METHODS.filter(m => m.is_active);
  res.json({
    success: true,
    data: { methods },
  });
});

export default router;
