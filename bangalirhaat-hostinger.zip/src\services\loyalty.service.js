import { getDb } from '../database/db.js';

const TIER_THRESHOLDS = {
  Bronze: { min: 0, max: 999, multiplier: 1, benefits: 'Standard rewards' },
  Silver: { min: 1000, max: 4999, multiplier: 1.25, benefits: '1.25x point earning, free shipping on orders over ৳1000' },
  Gold: { min: 5000, max: 19999, multiplier: 1.5, benefits: '1.5x point earning, free shipping, priority support' },
  Platinum: { min: 20000, max: Infinity, multiplier: 2, benefits: '2x point earning, free shipping, priority support, exclusive deals' },
};

const POINTS_PER_BDT = 1;
const POINT_EXPIRY_DAYS = 365;
const POINT_VALUE_BDT = 0.5;

class LoyaltyService {
  async earnPoints(userId, amount, orderId, description) {
    const db = getDb();
    const user = db.prepare('SELECT id, loyalty_points, loyalty_tier FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');

    const tier = this.getTierName(user.loyalty_points);
    const multiplier = TIER_THRESHOLDS[tier].multiplier;
    const points = Math.floor(amount * POINTS_PER_BDT * multiplier);

    if (points <= 0) return { points: 0, newBalance: user.loyalty_points };

    const insertTransaction = db.transaction(() => {
      db.prepare(`
        INSERT INTO loyalty_transactions (user_id, points, type, reference, description)
        VALUES (?, ?, 'earned', ?, ?)
      `).run(userId, points, orderId ? `order:${orderId}` : null, description || `Earned ${points} points`);

      db.prepare(`
        UPDATE users SET loyalty_points = loyalty_points + ?, updated_at = datetime('now') WHERE id = ?
      `).run(points, userId);
    });

    insertTransaction();

    return {
      points,
      multiplier,
      newBalance: user.loyalty_points + points,
    };
  }

  async redeemPoints(userId, points, orderId, description) {
    const db = getDb();

    if (points <= 0) throw new Error('Points must be positive');

    const user = db.prepare('SELECT id, loyalty_points FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');
    if (user.loyalty_points < points) throw new Error('Insufficient points balance');

    const redeemValue = points * POINT_VALUE_BDT;

    const redeemTransaction = db.transaction(() => {
      db.prepare(`
        INSERT INTO loyalty_transactions (user_id, points, type, reference, description)
        VALUES (?, ?, 'redeemed', ?, ?)
      `).run(userId, -points, orderId ? `order:${orderId}` : null, description || `Redeemed ${points} points`);

      db.prepare(`
        UPDATE users SET loyalty_points = loyalty_points - ?, updated_at = datetime('now') WHERE id = ?
      `).run(points, userId);
    });

    redeemTransaction();

    return {
      pointsRedeemed: points,
      discountAmount: redeemValue,
      newBalance: user.loyalty_points - points,
    };
  }

  async getBalance(userId) {
    const db = getDb();
    const user = db.prepare('SELECT id, loyalty_points FROM users WHERE id = ?').get(userId);
    if (!user) throw new Error('User not found');

    const tier = this.getTier(user.loyalty_points);

    return {
      points: user.loyalty_points,
      estimatedValue: user.loyalty_points * POINT_VALUE_BDT,
      tier: tier.name,
      tierBenefits: tier.benefits,
      pointsToNextTier: this.pointsToNextTier(user.loyalty_points),
    };
  }

  async getHistory(userId, page = 1, limit = 20) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    const total = db.prepare(
      'SELECT COUNT(*) as count FROM loyalty_transactions WHERE user_id = ?'
    ).get(userId).count;

    const transactions = db.prepare(`
      SELECT id, user_id, points, type, reference, description, created_at
      FROM loyalty_transactions
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(userId, limit, offset);

    return {
      transactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async expirePoints(userId) {
    const db = getDb();
    const expiryDate = new Date(Date.now() - POINT_EXPIRY_DAYS * 24 * 60 * 60 * 1000).toISOString();

    const expired = db.prepare(`
      SELECT id, user_id, points FROM loyalty_transactions
      WHERE user_id = ? AND type = 'earned' AND created_at < ? AND points > 0
    `).all(userId, expiryDate);

    if (expired.length === 0) return { expired: 0, totalPoints: 0 };

    let totalPoints = 0;
    const expireTransaction = db.transaction(() => {
      for (const tx of expired) {
        db.prepare(`
          INSERT INTO loyalty_transactions (user_id, points, type, reference, description)
          VALUES (?, ?, 'expired', ?, 'Points expired after 365 days')
        `).run(userId, -tx.points, `earned:${tx.id}`);

        totalPoints += tx.points;
      }

      db.prepare(`
        UPDATE users SET loyalty_points = MAX(0, loyalty_points - ?), updated_at = datetime('now')
        WHERE id = ?
      `).run(totalPoints, userId);
    });

    expireTransaction();

    return { expired: expired.length, totalPoints };
  }

  getTierName(points) {
    if (points >= TIER_THRESHOLDS.Platinum.min) return 'Platinum';
    if (points >= TIER_THRESHOLDS.Gold.min) return 'Gold';
    if (points >= TIER_THRESHOLDS.Silver.min) return 'Silver';
    return 'Bronze';
  }

  getTier(points) {
    const name = this.getTierName(points);
    return { name, ...TIER_THRESHOLDS[name] };
  }

  pointsToNextTier(points) {
    const currentTier = this.getTierName(points);
    const tiers = ['Bronze', 'Silver', 'Gold', 'Platinum'];
    const currentIdx = tiers.indexOf(currentTier);

    for (let i = currentIdx + 1; i < tiers.length; i++) {
      const tierName = tiers[i];
      const needed = TIER_THRESHOLDS[tierName].min - points;
      if (needed > 0) {
        return { nextTier: tierName, pointsNeeded: needed };
      }
    }

    return { nextTier: null, pointsNeeded: 0 };
  }
}

export default new LoyaltyService();
