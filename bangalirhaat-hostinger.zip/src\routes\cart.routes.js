import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import { getDb } from '../database/db.js';
import { authenticate } from '../middleware/auth.js';
import { AppError } from '../middleware/errorHandler.js';

const router = Router();

router.use(authenticate);

const addItemValidation = [
  body('product_id').optional().isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
  body('productId').optional().isInt({ min: 1 }).toInt().withMessage('Valid product ID is required'),
  body('variant_id').optional({ nullable: true }).isInt({ min: 1 }).toInt(),
  body('variantId').optional({ nullable: true }).isInt({ min: 1 }).toInt(),
  body('quantity').isInt({ min: 1, max: 99 }).toInt().withMessage('Quantity must be 1-99'),
];

const updateItemValidation = [
  param('itemId').isInt({ min: 1 }).toInt().withMessage('Invalid cart item ID'),
  body('quantity').isInt({ min: 1, max: 99 }).toInt().withMessage('Quantity must be 1-99'),
];

const removeItemValidation = [
  param('itemId').isInt({ min: 1 }).toInt().withMessage('Invalid cart item ID'),
];

const couponValidation = [
  body('coupon_code').optional().isString().trim().isLength({ min: 1, max: 50 }),
  body('code').optional().isString().trim().isLength({ min: 1, max: 50 }),
];

router.get('/', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    let cart = db.prepare('SELECT * FROM carts WHERE user_id = ?').get(userId);

    if (!cart) {
      cart = db.prepare(
        `INSERT INTO carts (user_id, created_at, updated_at) VALUES (?, datetime('now'), datetime('now'))`
      ).run(userId);
      cart = db.prepare('SELECT * FROM carts WHERE user_id = ?').get(userId);
    }

    const items = db.prepare(
      `SELECT ci.id, ci.product_id, ci.variant_id, ci.quantity, ci.price,
              p.name as product_name, p.slug as product_slug, b.name as brand_name,
              p.stock_quantity as product_stock, p.is_active as product_active,
              pv.name as variant_name, pv.stock_quantity as variant_stock,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN product_variants pv ON ci.variant_id = pv.id
       WHERE ci.cart_id = ? AND p.is_active = 1
       ORDER BY ci.created_at DESC`
    ).all(cart.id);

    let subtotal = 0;
    let totalDiscount = 0;
    let validItems = 0;

    items.forEach(item => {
      item.total_price = item.price * item.quantity;
      subtotal += item.total_price;
      if (item.product_active === 1) {
        validItems++;
      }
    });

    const couponDiscount = cart.coupon_discount || 0;
    // Default delivery (inside Dhaka) — actual charge calculated at checkout
    const shippingCost = subtotal <= 3000 ? 100 : subtotal <= 6000 ? 120 : 120 + Math.ceil((subtotal - 6000) / 3000) * 20;
    const serviceCharge = 5;
    const total = subtotal - couponDiscount + shippingCost + serviceCharge;

    res.json({
      success: true,
      data: {
        cart: {
          id: cart.id,
          items,
          item_count: validItems,
          subtotal,
          coupon_code: cart.coupon_code,
          coupon_discount: couponDiscount,
          shipping_cost: shippingCost,
          service_charge: serviceCharge,
          total,
          updated_at: cart.updated_at,
        },
      },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/items', addItemValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const product_id = req.body.product_id || req.body.productId;
    const variant_id = req.body.variant_id || req.body.variantId;
    const quantity = req.body.quantity;

    const product = db.prepare(
      'SELECT id, price, stock_quantity, is_active FROM products WHERE id = ?'
    ).get(product_id);

    if (!product || product.is_active !== 1) {
      throw new AppError('Product not found or unavailable', 404);
    }

    let price = product.price;
    let availableStock = product.stock_quantity;

    if (variant_id) {
      const variant = db.prepare(
        'SELECT id, price, stock_quantity, is_active FROM product_variants WHERE id = ? AND product_id = ?'
      ).get(variant_id, product_id);

      if (!variant || !variant.is_active) {
        throw new AppError('Product variant not found', 404);
      }

      price = variant.price;
      availableStock = variant.stock_quantity;
    }

    if (availableStock < quantity) {
      throw new AppError('Insufficient stock available', 400);
    }

    let cart = db.prepare('SELECT * FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      const result = db.prepare(
        `INSERT INTO carts (user_id, created_at, updated_at) VALUES (?, datetime('now'), datetime('now'))`
      ).run(userId);
      cart = db.prepare('SELECT * FROM carts WHERE id = ?').get(result.lastInsertRowid);
    }

    const existingItem = db.prepare(
      'SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? AND (variant_id = ? OR (variant_id IS NULL AND ? IS NULL))'
    ).get(cart.id, product_id, variant_id, variant_id);

    if (existingItem) {
      const newQuantity = existingItem.quantity + quantity;
      if (newQuantity > availableStock) {
        throw new AppError('Cannot add more than available stock', 400);
      }

      db.prepare(
        `UPDATE cart_items SET quantity = ?, total_price = ? * ?, updated_at = datetime('now') WHERE id = ?`
      ).run(newQuantity, price, newQuantity, existingItem.id);
    } else {
      db.prepare(
        `INSERT INTO cart_items (cart_id, product_id, variant_id, quantity, price, total_price, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
      ).run(cart.id, product_id, variant_id || null, quantity, price, price * quantity);
    }

    db.prepare(`UPDATE carts SET updated_at = datetime('now') WHERE id = ?`).run(cart.id);

    const items = db.prepare(
      `SELECT ci.id, ci.product_id, ci.variant_id, ci.quantity, ci.price, ci.total_price,
              p.name as product_name,
              (SELECT url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       WHERE ci.cart_id = ?`
    ).all(cart.id);

    let subtotal = 0;
    items.forEach(item => { subtotal += item.total_price; });

    res.status(201).json({
      success: true,
      message: 'Item added to cart',
      data: {
        item_count: items.length,
        subtotal,
        items,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.put('/items/:itemId', updateItemValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const { quantity } = req.body;

    const cart = db.prepare('SELECT id FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    const cartItem = db.prepare(
      `SELECT ci.id, ci.price, ci.product_id, ci.variant_id,
              p.stock_quantity as product_stock, pv.stock_quantity as variant_stock
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       LEFT JOIN product_variants pv ON ci.variant_id = pv.id
       WHERE ci.id = ? AND ci.cart_id = ?`
    ).get(req.params.itemId, cart.id);

    if (!cartItem) {
      throw new AppError('Cart item not found', 404);
    }

    const availableStock = cartItem.variant_id ? cartItem.variant_stock : cartItem.product_stock;
    if (quantity > availableStock) {
      throw new AppError('Insufficient stock', 400);
    }

    db.prepare(
      `UPDATE cart_items SET quantity = ?, total_price = price * ?, updated_at = datetime('now') WHERE id = ?`
    ).run(quantity, quantity, cartItem.id);

    db.prepare(`UPDATE carts SET updated_at = datetime('now') WHERE id = ?`).run(cart.id);

    const items = db.prepare(
      `SELECT ci.id, ci.product_id, ci.variant_id, ci.quantity, ci.price, ci.total_price,
              p.name as product_name
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       WHERE ci.cart_id = ?`
    ).all(cart.id);

    let subtotal = 0;
    items.forEach(item => { subtotal += item.total_price; });

    res.json({
      success: true,
      message: 'Cart item updated',
      data: { item_count: items.length, subtotal },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/items/:itemId', removeItemValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;

    const cart = db.prepare('SELECT id FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    const result = db.prepare('DELETE FROM cart_items WHERE id = ? AND cart_id = ?')
      .run(req.params.itemId, cart.id);

    if (result.changes === 0) {
      throw new AppError('Cart item not found', 404);
    }

    db.prepare(`UPDATE carts SET updated_at = datetime('now') WHERE id = ?`).run(cart.id);

    const items = db.prepare('SELECT COUNT(*) as count FROM cart_items WHERE cart_id = ?').get(cart.id);
    const subtotalRow = db.prepare('SELECT COALESCE(SUM(total_price), 0) as subtotal FROM cart_items WHERE cart_id = ?').get(cart.id);

    res.json({
      success: true,
      message: 'Item removed from cart',
      data: { item_count: items.count, subtotal: subtotalRow.subtotal },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const cart = db.prepare('SELECT id FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(cart.id);
    db.prepare(
      `UPDATE carts SET coupon_code = NULL, coupon_discount = 0, updated_at = datetime('now') WHERE id = ?`
    ).run(cart.id);

    res.json({
      success: true,
      message: 'Cart cleared',
      data: { item_count: 0, subtotal: 0 },
    });
  } catch (error) {
    next(error);
  }
});

router.post('/coupon', couponValidation, async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const db = getDb();
    const userId = req.user.id;
    const coupon_code = (req.body.coupon_code || req.body.code || '').toUpperCase();

    const coupon = db.prepare(
      `SELECT * FROM coupons WHERE code = ? AND is_active = 1 
       AND (starts_at IS NULL OR starts_at <= datetime('now'))
       AND (expires_at IS NULL OR expires_at >= datetime('now'))`
    ).get(coupon_code.toUpperCase());

    if (!coupon) {
      throw new AppError('Invalid or expired coupon code', 404);
    }

    const cart = db.prepare('SELECT id, coupon_code FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    if (cart.coupon_code) {
      throw new AppError('A coupon is already applied. Remove it first.', 400);
    }

    if (coupon.usage_limit && coupon.used_count >= coupon.usage_limit) {
      throw new AppError('Coupon usage limit reached', 400);
    }

    if (coupon.minimum_order) {
      const subtotalRow = db.prepare(
        'SELECT COALESCE(SUM(total_price), 0) as subtotal FROM cart_items WHERE cart_id = ?'
      ).get(cart.id);

      if (subtotalRow.subtotal < coupon.minimum_order) {
        throw new AppError(`Minimum purchase of ৳${coupon.minimum_order} required`, 400);
      }
    }

    const subtotalRow = db.prepare(
      'SELECT COALESCE(SUM(total_price), 0) as subtotal FROM cart_items WHERE cart_id = ?'
    ).get(cart.id);

    let discount = 0;
    if (coupon.type === 'percentage') {
      discount = (subtotalRow.subtotal * coupon.value) / 100;
      if (coupon.maximum_discount && discount > coupon.maximum_discount) {
        discount = coupon.maximum_discount;
      }
    } else {
      discount = coupon.value;
    }

    discount = Math.min(discount, subtotalRow.subtotal);

    db.prepare(
      `UPDATE carts SET coupon_code = ?, coupon_discount = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(coupon.code, discount, cart.id);

    res.json({
      success: true,
      message: 'Coupon applied successfully',
      data: {
        coupon_code: coupon.code,
        discount,
        subtotal: subtotalRow.subtotal,
        total: subtotalRow.subtotal - discount,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.delete('/coupon', async (req, res, next) => {
  try {
    const db = getDb();
    const userId = req.user.id;

    const cart = db.prepare('SELECT id, coupon_code FROM carts WHERE user_id = ?').get(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    if (!cart.coupon_code) {
      throw new AppError('No coupon applied', 400);
    }

    db.prepare(
      `UPDATE carts SET coupon_code = NULL, coupon_discount = 0, updated_at = datetime('now') WHERE id = ?`
    ).run(cart.id);

    const subtotalRow = db.prepare(
      'SELECT COALESCE(SUM(total_price), 0) as subtotal FROM cart_items WHERE cart_id = ?'
    ).get(cart.id);

    res.json({
      success: true,
      message: 'Coupon removed',
      data: { subtotal: subtotalRow.subtotal },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
