import { getDb } from '../database/db.js';

class PreorderService {
  async createPreorder({ productId, userId, quantity, expectedDate, depositAmount }) {
    const db = getDb();

    if (!productId) throw new Error('Product ID is required');
    if (!userId) throw new Error('User ID is required');
    if (!quantity || quantity < 1) throw new Error('Quantity must be at least 1');

    const product = db.prepare('SELECT id, name, price FROM products WHERE id = ? AND deleted_at IS NULL').get(productId);
    if (!product) throw new Error('Product not found');

    if (depositAmount !== undefined && depositAmount < 0) {
      throw new Error('Deposit amount cannot be negative');
    }

    const result = db.prepare(
      `INSERT INTO preorders (product_id, user_id, quantity, expected_date, deposit_amount, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'pending', datetime('now'), datetime('now'))`
    ).run(productId, userId, quantity, expectedDate || null, depositAmount || 0);

    const preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(result.lastInsertRowid);

    return { preorder };
  }

  async updatePreorder(id, data) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);
    if (!existing) throw new Error('Preorder not found');

    const { quantity, expectedDate, depositAmount, status } = data;

    if (status && !['pending', 'confirmed', 'fulfilled', 'cancelled'].includes(status)) {
      throw new Error('Invalid preorder status');
    }

    db.prepare(
      `UPDATE preorders SET
        quantity = ?, expected_date = ?, deposit_amount = ?, status = ?,
        updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      quantity !== undefined ? quantity : existing.quantity,
      expectedDate !== undefined ? expectedDate : existing.expected_date,
      depositAmount !== undefined ? depositAmount : existing.deposit_amount,
      status || existing.status,
      id
    );

    const preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);

    return { preorder };
  }

  async cancelPreorder(id) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);
    if (!existing) throw new Error('Preorder not found');

    if (existing.status === 'cancelled') throw new Error('Preorder is already cancelled');
    if (existing.status === 'fulfilled') throw new Error('Cannot cancel a fulfilled preorder');

    db.prepare(
      `UPDATE preorders SET status = 'cancelled', updated_at = datetime('now') WHERE id = ?`
    ).run(id);

    const preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);

    return { preorder };
  }

  async fulfillPreorder(id, orderId) {
    const db = getDb();
    const existing = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);
    if (!existing) throw new Error('Preorder not found');

    if (existing.status === 'cancelled') throw new Error('Cannot fulfil a cancelled preorder');
    if (existing.status === 'fulfilled') throw new Error('Preorder is already fulfilled');

    if (orderId) {
      const order = db.prepare('SELECT id FROM orders WHERE id = ?').get(orderId);
      if (!order) throw new Error('Referenced order not found');
    }

    const fulfillTransaction = db.transaction(() => {
      db.prepare(
        `UPDATE preorders SET status = 'fulfilled', order_id = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(orderId || null, id);
    });

    fulfillTransaction();

    const preorder = db.prepare('SELECT * FROM preorders WHERE id = ?').get(id);

    return { preorder };
  }

  async getUserPreorders(userId) {
    const db = getDb();

    const preorders = db.prepare(
      `SELECT pr.*, p.name as product_name, p.slug as product_slug,
              (SELECT url FROM product_images WHERE product_id = pr.product_id AND is_primary = 1 LIMIT 1) as thumbnail
       FROM preorders pr
       JOIN products p ON pr.product_id = p.id
       WHERE pr.user_id = ?
       ORDER BY pr.created_at DESC`
    ).all(userId);

    return { preorders };
  }

  async getAllPreorders({ page = 1, limit = 20, status } = {}) {
    const db = getDb();
    const offset = (Math.max(1, page) - 1) * limit;

    let where = ['1=1'];
    let params = [];

    if (status) {
      where.push('pr.status = ?');
      params.push(status);
    }

    const whereClause = `WHERE ${where.join(' AND ')}`;

    const total = db.prepare(
      `SELECT COUNT(*) as count FROM preorders pr ${whereClause}`
    ).get(...params).count;

    const preorders = db.prepare(
      `SELECT pr.*, p.name as product_name, p.slug as product_slug,
              u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email
       FROM preorders pr
       JOIN products p ON pr.product_id = p.id
       JOIN users u ON pr.user_id = u.id
       ${whereClause}
       ORDER BY pr.created_at DESC
       LIMIT ? OFFSET ?`
    ).all(...params, limit, offset);

    return {
      preorders,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getPreordersForProduct(productId) {
    const db = getDb();

    const preorders = db.prepare(
      `SELECT pr.*, u.first_name || ' ' || u.last_name as customer_name, u.email as customer_email
       FROM preorders pr
       JOIN users u ON pr.user_id = u.id
       WHERE pr.product_id = ? AND pr.status != 'cancelled'
       ORDER BY pr.created_at DESC`
    ).all(productId);

    return { preorders };
  }

  async getPreorderStats() {
    const db = getDb();

    const stats = db.prepare(
      `SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN status = 'fulfilled' THEN 1 ELSE 0 END) as fulfilled,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN quantity ELSE 0 END), 0) as total_quantity,
        COALESCE(SUM(CASE WHEN status != 'cancelled' THEN deposit_amount ELSE 0 END), 0) as total_deposits
       FROM preorders`
    ).get();

    return { stats };
  }
}

export default new PreorderService();
